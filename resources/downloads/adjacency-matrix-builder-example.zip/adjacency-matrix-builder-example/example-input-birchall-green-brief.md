# Birchall Green Health & Wellbeing Centre — client brief

**Client:** Marlden Community Health Partnership
**Prepared by:** the Partnership's estates working group
**Version:** draft 2, January 2026
**To:** Hallam & Roe Architects
**Instruction:** "Build us the adjacency matrix before the user group workshop
on the 12th."

*Fictional client and project. Deliberately thin and contradictory in places.*

---

## §1 — The project

A new single-storey health and wellbeing centre replacing the existing
Birchall Green surgery. Combines GP services, community health, a pharmacy,
and community-use space.

---

## §2 — Schedule of accommodation (as drafted)

| Ref | Space | No. | Area each (m²) |
|---|---|---|---|
| 01 | Main entrance / reception | 1 | 55 |
| 02 | Waiting — general | 1 | 70 |
| 03 | Consulting room | 8 | 14 |
| 04 | Treatment room | 3 | 16 |
| 05 | Phlebotomy | 1 | 14 |
| 06 | Minor procedures | 1 | 22 |
| 07 | Pharmacy | 1 | 60 |
| 08 | Community room | 1 | 65 |
| 09 | Staff base | 1 | 40 |
| 10 | Staff rest | 1 | 25 |
| 11 | Records | 1 | 18 |
| 12 | Clean utility | 1 | 10 |
| 13 | Dirty utility | 1 | 10 |
| 14 | Cleaner's store | 1 | 6 |
| 15 | Waste store | 1 | 12 |
| 16 | Plant | 1 | 30 |
| 17 | Public WCs | — | 20 |
| 18 | Baby change | 1 | 8 |

*Note in the margin: "Counselling? Health visitor? — ask Priya"*

---

## §3 — What the Partnership has said about the building

§3.1 "Reception must have clear sight of the main entrance and of the general
waiting area."

§3.2 "Consulting rooms should be close to the waiting area but must not be
overlooked from it."

§3.3 "The pharmacy will have its own entrance from the street and must be
accessible when the rest of the centre is closed."

§3.4 "Clean and dirty utility must be strictly separated. Dirty utility must
have a direct route to the waste store that does not cross patient areas."

§3.5 "The community room should be usable in the evenings independently of the
clinical areas."

§3.6 "The staff base needs to be central to the consulting rooms."

§3.7 "Staff rest must be away from clinical areas — people need to feel
properly off duty."

§3.8 "Records must be immediately adjacent to reception."

§3.9 "Phlebotomy generates its own queue. It must not back up into the general
waiting area."

§3.10 "Minor procedures needs to be close to clean utility."

§3.11 "The community room should be close to reception so it can be supervised."

§3.12 "Baby change should be near the public WCs."

§3.13 "Deliveries arrive at the rear and are taken through to the pharmacy and
to the clean utility store."

---

## §4 — Notes from the estates working group meeting, 9 January

> **Priya (practice manager):** the staff rest room has to be somewhere people
> will actually use it — last time it was at the far end and nobody went.
>
> **Dan (pharmacy):** we need the pharmacy right by the main waiting area,
> that's where the custom is.
>
> **Priya:** we also need a quiet room. I don't know where it's gone in the
> schedule.
>
> **Chair:** let's not get into layout. Just tell the architect what needs to
> be near what.

---

## §5 — What the client has asked for

1. "Build the adjacency matrix."
2. "Fill in anything obvious — you've done health centres before, you know how
   these work. We don't want to waste the workshop on things everyone already
   agrees about."
3. "Give us a bubble diagram for the workshop."
4. "Where should the staff rest room go?"
