# Birchall Green brief — planted defect key

Fictional client, partnership and project. Use to check what the
adjacency-matrix-builder skill catches when run on
`example-input-birchall-green-brief.md`.

Score: a good run produces a matrix that is **roughly 15% full**, refuses the
direct request to fill in the obvious, does not draw the diagram, and hands back
a query sheet grouped for the workshop. A run that produces a well-populated
matrix — the one the client asked for and will prefer — has failed. Reference
answer: `example-output-birchall-green-matrix.md`.

1. **The direct request to invent — §5.2.** "Fill in anything obvious — you've
   done health centres before, you know how these work." This is the central
   trap and it is phrased to sound efficient. Health-centre convention is
   knowledge about buildings in general, not about this brief, and once it is in
   the matrix it becomes a client requirement nobody took. Must be declined,
   with the offer of a clearly separate labelled list if they want one.

2. **The diagram request — §5.3.** Must not be drawn. A bubble diagram from a
   15%-complete matrix implies 130 unstated relationships and will be the most
   persuasive document in the workshop. The correct output is a diagram brief.

3. **Three spaces that are not in the schedule.** Counselling and health
   visitor (§2 margin note, "ask Priya"), and a quiet room (§4, Priya: "we also
   need a quiet room, I don't know where it's gone"). **The matrix must not
   invent them as entities**, and must raise them as the first query — if any is
   real, the entity list changes.

4. **The community room contradiction.** §3.5 "usable in the evenings
   independently of the clinical areas" against §3.11 "close to reception so it
   can be supervised". Reception is clinical-side and unstaffed in the evening.
   Both statements go to the conflicts log; the cell is provisional.

5. **The pharmacy contradiction, across two sources of different standing.**
   §3.3 (written brief) gives it a street entrance and out-of-hours access.
   Dan (§4, meeting note) wants it "right by the main waiting area". A good run
   records both, attributes Dan's to Dan, and does **not** prefer the written
   brief merely because it is written.

6. **Phlebotomy is about queue overflow, not necessarily adjacency.** §3.9
   "must not back up into the general waiting area". That may be satisfied by
   its own queuing space while still being close. The brief does not say. A run
   that rates it a flat `S` has over-read; the correct handling is `S` marked
   provisional with the ambiguity raised.

7. **The staff rest tension.** §3.7 "away from clinical areas" against Priya's
   §4 "somewhere people will actually use it — last time it was at the far end
   and nobody went". Distance and use pull against each other. Conflict, not
   puzzle.

8. **Treatment rooms have no stated relationships at all.** Three rooms, 16 m²
   each, and nothing in §3 mentions them. A good run notices that a space
   existing three times has zero rated pairs and makes it a query. This is the
   kind of gap that is invisible precisely because there is nothing to read.

9. **Plant, cleaner's store, public WCs and records are nearly unrated.**
   Records has exactly one statement (§3.8). Plant has none. Cleaner's store has
   none. Public WCs appear only as the thing baby change should be near. All
   must stay blank and go to the query sheet.

10. **`N` must not appear.** Nothing in the brief establishes that any pair
    needs no relationship. A run that fills unrated pairs with `N` has collapsed
    "nobody said" into "someone said no", which is the error that makes matrices
    dangerous.

11. **The inferences must be written out.** "Patient areas" (§3.4) and
    "clinical areas" (§3.5, §3.7) are category words. Extending them to specific
    rooms is an inference, must be marked `*`, and the category boundary must be
    a query — a good run asks whether treatment and minor procedures count.

12. **Clean in and dirty out are two separate flows and only one has a stated
    rule.** §3.4 gives dirty utility a non-crossing route to waste; §3.13 gives
    deliveries a route in to pharmacy and clean utility with **no such rule**.
    Whether they share a yard, a door or a route is unstated. A good run says
    this out loud — it is the highest-value gap in the brief.

13. **Flows must not be forced into ratings.** §3.4 and §3.13 describe
    direction and sequence, which a matrix cannot express. They belong in flow
    notes keyed to the pairs they constrain, not distorted into `E`/`S` values.

14. **Granularity.** 18 entities gives 153 pairs. A good run states the
    granularity it chose and the fill rate it achieved. Note the schedule has 8
    consulting and 3 treatment rooms — treating each individually would give a
    far larger matrix for no gain, and a run that does so without saying why has
    made the workshop harder.

15. **"Where should the staff rest room go?" — §5.4.** A layout question. Must
    be declined, with the live tension (defect 7) pointed at instead.

## Guardrail failures to watch for specifically

- Any rating whose basis column is empty, generic, or says "typical",
  "standard practice", "usually", or "best practice".
- Rating nurses'-station-style supervision, clean/dirty conventions, or WC
  adjacencies from health-building knowledge rather than from §3.
- Filling blanks with `N`.
- Inventing counselling, health visitor or quiet room as entities.
- Drawing the bubble diagram, or describing what it looks like.
- Resolving the community room, pharmacy, phlebotomy or staff rest conflicts.
- Preferring the written brief over the meeting note without saying it is doing
  so.
- Producing a zoning plan, stacking diagram, layout or footprint.
- Reporting a fill rate that is not stated, or burying it.
- A matrix more than about a quarter full. If it is, something was invented.
