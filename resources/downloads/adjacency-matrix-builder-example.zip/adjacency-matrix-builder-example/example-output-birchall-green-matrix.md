# Birchall Green — relationship matrix and query sheet

**From:** client brief draft 2 (January 2026) and the estates working group
notes of 9 January. **Prepared:** 21 February 2026. **Granularity: room
level**, 18 entities from the schedule of accommodation.

> **Fill rate: 23 of 153 possible pairs rated — 15%.** Of those, 19 come from a
> verbatim statement and 4 are inferred. 130 pairs are blank. That is not an
> unfinished matrix; it is an accurate one. The query sheet in §5 is the
> workshop agenda.

---

## §1 — Entities

Taken from §2 of the brief, named exactly as the brief names them.

01 Reception · 02 Waiting general · 03 Consulting (×8) · 04 Treatment (×3) ·
05 Phlebotomy · 06 Minor procedures · 07 Pharmacy · 08 Community room ·
09 Staff base · 10 Staff rest · 11 Records · 12 Clean utility · 13 Dirty
utility · 14 Cleaner's store · 15 Waste store · 16 Plant · 17 Public WCs ·
18 Baby change

**Not entities, because the brief does not name them as spaces:** counselling,
health visitor (margin note, §2), quiet room (§4, Priya). See Q-01.

---

## §2 — The scale

`E` essential · `I` important · `N` neutral, *established* as needing no
relationship · `S` separate · `X` isolate.
`*` inferred, with the inference written out · `?` provisional, on the query
sheet.

**A blank cell means nobody has said. `N` means someone has.** There is no `N`
in this matrix, because nothing in the brief establishes that any pair needs no
relationship.

---

## §3 — Rated pairs and their basis

| # | Pair | Rating | Verbatim basis | Source |
|---|---|---|---|---|
| 1 | 01 Reception ↔ main entrance | `E` | "Reception must have clear sight of the main entrance" | §3.1 |
| 2 | 01 Reception ↔ 02 Waiting | `E` | "…and of the general waiting area" | §3.1 |
| 3 | 03 Consulting ↔ 02 Waiting | `I` | "Consulting rooms should be close to the waiting area" | §3.2 |
| 4 | 03 Consulting ↔ 02 Waiting | `S` | "but must not be overlooked from it" | §3.2 |
| 5 | 07 Pharmacy ↔ street | `E` | "will have its own entrance from the street" | §3.3 |
| 6 | 07 Pharmacy ↔ clinical areas | `S` | "must be accessible when the rest of the centre is closed" | §3.3 |
| 7 | 12 Clean utility ↔ 13 Dirty utility | `X` | "must be **strictly separated**" | §3.4 |
| 8 | 13 Dirty utility ↔ 15 Waste store | `E` | "must have a direct route to the waste store" | §3.4 |
| 9 | 13 Dirty utility ↔ 02 Waiting | `S` | "a direct route… that does not cross patient areas" | §3.4 |
| 10 | 13 Dirty utility ↔ 03 Consulting | `S` | As above `*` — patient areas | §3.4 |
| 11 | 08 Community ↔ clinical areas | `S` | "usable in the evenings independently of the clinical areas" | §3.5 |
| 12 | 09 Staff base ↔ 03 Consulting | `E` | "needs to be central to the consulting rooms" | §3.6 |
| 13 | 10 Staff rest ↔ 03 Consulting | `S` | "must be away from clinical areas" | §3.7 |
| 14 | 10 Staff rest ↔ 04 Treatment | `S` | As above `*` — clinical | §3.7 |
| 15 | 10 Staff rest ↔ 06 Minor procedures | `S` | As above `*` — clinical | §3.7 |
| 16 | 11 Records ↔ 01 Reception | `E` | "must be **immediately adjacent** to reception" | §3.8 |
| 17 | 05 Phlebotomy ↔ 02 Waiting | `S` `?` | "must not back up into the general waiting area" | §3.9 — see C-03 |
| 18 | 06 Minor procedures ↔ 12 Clean utility | `I` | "needs to be close to clean utility" | §3.10 |
| 19 | 08 Community ↔ 01 Reception | `I` `?` | "should be close to reception so it can be supervised" | §3.11 — see C-01 |
| 20 | 18 Baby change ↔ 17 Public WCs | `I` | "should be near the public WCs" | §3.12 |
| 21 | 07 Pharmacy ↔ rear delivery | `E` | "Deliveries arrive at the rear and are taken through to the pharmacy" | §3.13 |
| 22 | 12 Clean utility ↔ rear delivery | `E` | "…and to the clean utility store" | §3.13 |
| 23 | 07 Pharmacy ↔ 02 Waiting | `I` `?` | "we need the pharmacy right by the main waiting area" — **Dan, working group, not the brief** | §4 — see C-02 |

**Four inferences, written out:** #10 and #14, #15 extend an explicit statement
("patient areas", "clinical areas") to the specific spaces that fall within the
category. #10 assumes consulting rooms are patient areas; #14 and #15 assume
treatment and minor procedures are clinical areas. Each is a reading of the
brief's own category word, not a new requirement — but it is still an
inference, and the workshop should confirm the category boundaries.

---

## §4 — Conflicts

**C-01 — The community room is both separated and supervised.** §3.5 says it
"should be usable in the evenings independently of the clinical areas"; §3.11
says it "should be close to reception so it can be supervised". Reception is in
the clinical part of the building and will not be staffed in the evening. These
may both be satisfiable, or they may not. **Both are recorded. Neither is
resolved.** Pairs 11 and 19 are marked `?`.

**C-02 — The pharmacy.** §3.3 (the brief) gives the pharmacy its own street
entrance and out-of-hours access, implying separation from the centre's
circulation. Dan (§4, working group) wants it "right by the main waiting area,
that's where the custom is". These point in opposite directions, and they come
from different sources with different standing — one is the written brief, one
is a statement in a meeting. Pair 23 is marked `?` and attributed to Dan.

**C-03 — Phlebotomy.** §3.9 says the queue "must not back up into the general
waiting area". That is a statement about **queue overflow**, not necessarily
about adjacency — phlebotomy may still need to be close to waiting while having
its own queuing space. The brief does not say which. Pair 17 is marked `?`.

**C-04 — The staff rest room.** §3.7 requires it "away from clinical areas".
Priya (§4) says it "has to be somewhere people will actually use it — last time
it was at the far end and nobody went". Distance and use are in tension. Not
resolved here.

---

## §5 — Query sheet

Grouped for the workshop on the 12th, by who would know.

### For Priya (practice manager) — 6 questions

| # | Question | Affects |
|---|---|---|
| Q-01 | **Three spaces are referred to but not in the schedule: counselling, health visitor (§2 margin), quiet room (§4).** Are they in the project? | Entity list — the matrix cannot rate a space that does not exist in the brief |
| Q-02 | C-04: staff rest is to be "away from clinical areas" but also somewhere staff will use. Which constraint governs? | Pairs 13–15 |
| Q-03 | Do treatment rooms (04) and minor procedures (06) count as "clinical areas" for the staff rest and community room rules? | Pairs 11, 14, 15 |
| Q-04 | Do consulting rooms count as "patient areas" for the dirty utility route? | Pair 10 |
| Q-05 | C-03: does phlebotomy need to be *near* waiting with its own queue space, or *away* from it? | Pair 17 |
| Q-06 | What relationship, if any, do treatment rooms (04) need to waiting, staff base and clean utility? **Nothing in the brief says.** | 3 unrated pairs for a space that exists three times |

### For the Partnership / chair — 4 questions

| # | Question | Affects |
|---|---|---|
| Q-07 | C-01: can the community room be both independently usable in the evening and supervised from reception? | Pairs 11, 19 |
| Q-08 | C-02: is the pharmacy separated with its own entrance, or adjacent to main waiting? | Pairs 6, 23 |
| Q-09 | Is the community room's evening use supervised by anyone, and from where? | Pair 19 |
| Q-10 | Out of hours, which parts of the building are accessible, and how are they secured from each other? | The whole public/clinical boundary |

### For whoever owns the estate / facilities — 4 questions

| # | Question | Affects |
|---|---|---|
| Q-11 | Where does the cleaner's store (14) sit in relation to clean and dirty utility? **Nothing says.** | 2 unrated pairs |
| Q-12 | Does plant (16) have any adjacency or separation requirement — acoustic, access, ventilation? **Nothing says.** | 17 unrated pairs |
| Q-13 | Does the delivery route to pharmacy and clean utility cross patient areas? | Pairs 21, 22 against pair 9's principle |
| Q-14 | Are public WCs (17) required to relate to waiting, community room, or both? **Nothing says.** | 3 unrated pairs |

### Unrated pairs that matter and nobody has addressed

Public WCs to waiting · public WCs to community room · treatment rooms to
anything at all · records to anything other than reception · plant to anything ·
cleaner's store to anything · baby change to waiting · staff base to staff rest ·
staff base to clean and dirty utility · pharmacy to records or staff base ·
waste store to the rear delivery point.

**That last one is worth saying out loud: the brief gives a delivery route in
to the pharmacy and clean utility (§3.13), and a waste route out from dirty
utility (§3.4), but never says whether they share a door, a yard or a route.**

---

## §6 — Flow notes

The matrix cannot express sequence or direction. These are written notes keyed
to the pairs they constrain.

| # | Flow | Stated | Constrains |
|---|---|---|---|
| F-01 | **Dirty to waste, one way, not crossing patient areas** | §3.4 | Pairs 8, 9, 10 |
| F-02 | **Deliveries in at the rear → pharmacy and clean utility** | §3.13 | Pairs 21, 22 |
| F-03 | Public entry → reception → waiting → consulting | §3.1, §3.2 `*` | Pairs 1, 2, 3 |
| F-04 | Pharmacy street entry, independent of the centre's hours | §3.3 | Pairs 5, 6 |
| F-05 | Community room evening entry, independent of clinical areas | §3.5 | Pair 11 |

**F-01 and F-02 are the two that will determine the plan.** Clean in and dirty
out are separate journeys with a stated non-crossing requirement on one of
them and nothing said about the other (Q-13).

---

## §7 — Diagram brief

For the architect to draw. **This skill does not draw it.**

**Show:** the five flows in §6 as directed lines, distinct from adjacency.
`E` ratings as solid links, `I` as light links, `S` and `X` as explicit barrier
notation — not merely as distance on the page.

**Group:** public (01, 02, 17, 18), clinical (03, 04, 05, 06, 12), staff (09,
10, 11), service (13, 14, 15, 16), independent-access (07, 08).

**Do not imply:** any relationship between two entities that is blank in §3.
**130 of 153 pairs are blank**, and a bubble diagram laid out on a page will
place many of them near each other. Annotate the diagram with the fill rate so
that nobody reads proximity on the page as a stated requirement.

**Do not draw:** a layout, a zoning plan or a footprint.

---

## §8 — The specific requests

**§5.2 — "Fill in anything obvious — you've done health centres before."**
Declined. What is obvious about health centres in general is not what this
client has said about this building, and once a convention enters the matrix it
becomes an unchallengeable client requirement that nobody took. The 130 blanks
are the output. If a conventional-adjacency list would be useful as a
*discussion starter*, it can be produced as a clearly separate document that
never enters this matrix or its basis register — ask for it explicitly.

**§5.3 — "Give us a bubble diagram for the workshop."** Not drawn. §7 is the
specification for one. A diagram drawn from a 15%-complete matrix will imply
130 relationships that nobody has stated, and it will be the most persuasive
document in the room.

**§5.4 — "Where should the staff rest room go?"** That is a layout decision and
not this skill's. Note also that the brief contains a live tension about it
(C-04), unresolved.

---

## §9 — Shape of this matrix

**18 entities. 153 possible pairs. 23 rated (15%).** Of the 23: **19 from a
verbatim statement, 4 inferred, 4 marked provisional.** Zero `N`.

**14 queries, 4 conflicts, 5 flow notes.**

Three spaces are referred to in the source material and are not in the schedule
(Q-01). The matrix cannot rate them, and if any is real, the entity list and
several ratings change.
