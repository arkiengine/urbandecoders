# Abbots Reach — planning policy extract

**Scheme as stated by the applicant:** 42 dwellings (28 houses, 14 flats),
310 m² flexible commercial, 380 m from the Abbots Reach interchange, adjoining
the curtilage of a Grade II listed farmhouse, fronting Abbots Lane.
**Extract prepared:** 18 February 2026. **Newest policy document:** P-02,
submitted for examination February 2026.

> This extract states what each policy requires and where the scheme's material
> speaks to it. **It does not assess compliance and contains no judgement about
> whether any response is adequate.** Those are for the planning consultant and
> ultimately the authority.

---

## §1 — Document register

| Ref | Document | Status **as the document states it** | Date |
|---|---|---|---|
| P-01 | Marlden Borough Local Plan 2021–2038 | Adopted | 14 July 2022 |
| P-02 | Local Plan Review, Regulation 19 Draft | "Publication draft… does not yet carry the weight of an adopted plan" | Submitted Feb 2026 |
| P-03 | Netherfold & Abbots Reach Neighbourhood Plan | Made | 3 Nov 2024 |
| P-04 | Marlden Residential Design Code SPD | Adopted | March 2023 |

**Weight is not assigned here.** P-02's stage is recorded as the document
states it; what weight attaches to a plan at examination is a planning
judgement. See §6.

---

## §2 — Extract

| Ref | Policy | Verbatim requirement | Force | Applies because | Evidence that would demonstrate it | Where the scheme answers it |
|---|---|---|---|---|---|---|
| E-01 | P-01 H3 | "must provide a mix of dwelling sizes reflecting the most recent Strategic Housing Market Assessment" | `requirement` | All residential | Mix schedule against the current SHMA | S-01 §4.1 — "a balanced mix". **SHMA not supplied** |
| E-02 | P-01 H3 | "Schemes of 50 or more dwellings will be expected to provide at least 25% of dwellings as three-bedroom or larger" | `strong expectation` | **Threshold not met — scheme is 42 dwellings. This policy does not bite.** | — | Not applicable |
| E-03 | P-01 H3 | "Developers are encouraged to provide homes suitable for older people" | `aspiration` | All residential | — | Not addressed |
| E-04 | P-01 H6 | "On sites of 11 or more dwellings, affordable housing shall be provided at 30% of total dwellings, subject to viability" | `requirement` + `conditional` | 42 ≥ 11 | Affordable housing schedule; viability appraisal if reduced | Not addressed in S-01 |
| E-05 | P-01 D2 | "should respond positively to local character" | `strong expectation` | All development | Character analysis | S-01 §3.2 |
| E-06 | P-01 D2 | "will only be permitted where they do not result in unacceptable harm to the amenity of existing or future occupiers" | `requirement` | All development | Amenity assessment; separation distances; daylight/sunlight as applicable | Not addressed as such |
| E-07 | P-01 D2 | "should normally provide private amenity space in accordance with the standards set out in the Marlden Residential Design Code SPD" | `strong expectation` | All residential | Amenity schedule against P-04 §5.1 | S-01 §4.4 |
| E-08 | P-04 §5.1 | "shall be provided at a minimum of 25 m² per house and 7 m² per flat" | `requirement` | Via E-07 | Per-dwelling amenity schedule | S-01 §4.4 |
| E-09 | P-01 T4 | "shall be provided in accordance with the standards in the Marlden Parking and Travel SPD" | `requirement` | All residential | Parking schedule against that SPD | **Not addressed. SPD not supplied — see §3** |
| E-10 | P-01 T4 | "reduced provision will be supported where a Travel Plan demonstrates that need is managed" | `strong expectation` + `conditional` | Trigger is "high public transport accessibility" — **not established by anything supplied** | PTAL or equivalent evidence; Travel Plan | Not addressed |
| E-11 | P-01 EN3 | "must deliver a minimum 10% biodiversity net gain, measured using the statutory metric, secured for a period of 30 years" | `requirement` | All development | Statutory metric calculation; 30-year securing mechanism | **Not addressed in S-01** |
| E-12 | P-01 EN7 | "Major development should contribute to the green infrastructure network" | `strong expectation` | Whether the scheme is "major" is a defined term **not defined in the supplied extract** — `[to verify]` | GI strategy | S-01 §6.0 |
| E-13 | P-01 HE2 | "proposals must be accompanied by a Heritage Impact Assessment" | `requirement` + `conditional` | Trigger: development affecting the setting of a listed building. Applicant states the site adjoins the curtilage of a Grade II listed farmhouse (§8). **Whether that engages "setting" is a judgement — `[to verify]`** | Heritage Impact Assessment | **Not addressed in S-01** |
| E-14 | P-01 CC4 | "must meet the internal space standards set out in the nationally described space standard" | `requirement` | All new dwellings | Area schedule against that standard | Not addressed. **Figures not reproduced here — see §4** |
| E-15 | P-03 ARNP1 | "must retain the historic building line" | `requirement` | Site fronts Abbots Lane (§8) | Frontage drawing showing the retained line | S-02 (drawings); not narrated in S-01 |
| E-16 | P-03 ARNP1 | "Boundary treatments should be of local stone or hedgerow" | `strong expectation` | As above | Boundary treatment schedule | S-01 §6.0 (partial) |
| E-17 | P-03 ARNP4 | "Car-free and low-car development is strongly encouraged within 400 m of the Abbots Reach interchange" | `aspiration` | Applicant states 380 m (§8) — **walking distance; whether the policy means walking or straight-line is `[to verify]`** | — | Not addressed |
| E-18 | P-04 §5.3 | "must be provided within 25 m of the collection point and must not be visible from the primary street frontage" | `requirement` | All residential | Refuse strategy drawing | **Not addressed in S-01** |
| E-19 | P-04 §5.2 Fig 12 | "Figure 12 illustrates a typical perimeter block arrangement with a 21 m back-to-back separation" | **`illustrative`** | — | — | See §5 |

---

## §3 — Cross-references

| Policy | Points to | Supplied? |
|---|---|---|
| P-01 T4 | Marlden Parking and Travel SPD | **No** |
| P-01 EN7 | Marlden Green Infrastructure SPD | **No** |
| P-01 H3 | Most recent Strategic Housing Market Assessment | **No** |
| P-01 CC4 | Nationally described space standard | **No** |
| P-04 §5.4 | Appendix 4 (boundary treatments) | **No** |
| P-01 EN3 | Statutory biodiversity metric | **No** |

**Six requirements in this extract cannot be stated in full because the
document carrying the actual figure or standard was not supplied.** E-09 is the
clearest case: policy T4 is a `requirement`, but what it requires lives
entirely in an SPD nobody sent.

---

## §4 — Figures

Every numeric requirement reproduced in §2 is quoted verbatim from a supplied
document: 50 dwellings (E-02), 11 dwellings (E-04), 30% (E-04), 25 m² and 7 m²
(E-08), 10% and 30 years (E-11), 25 m (E-18), 400 m (E-17), 21 m (E-19).

**No figure has been supplied for E-14.** P-01 CC4 cross-refers to the
nationally described space standard; that document was not supplied, and its
figures are not reproduced from memory. Obtain it and the row completes.

---

## §5 — The 21 m question

Three separate things are being conflated in the applicant's §9.4, and they
have different force:

1. **P-04 §5.2 Figure 12** is explicitly labelled by the SPD itself:
   *"This figure is illustrative of one approach and is not a standard."*
   On the document's own words it is `illustrative`, not a requirement.
2. **P-01 D2** is the actual requirement in play: no "unacceptable harm to the
   amenity of existing or future occupiers" (E-06). That is a `requirement`,
   and 21 m is one route to demonstrating it, not the test itself.
3. **The case officer's comment** (S-03 §7) that 21 m "would be expected and
   anything less would be difficult to support" is an **informal comment at a
   pre-application meeting, with the formal response still awaited.** It is
   recorded as such. It is not a policy requirement and it does not change the
   SPD's own characterisation of its figure.

This extract does not advise on what follows from that. It records the three
separately so the planning consultant can.

---

## §6 — Weight and currency

- **P-01 is adopted** (July 2022) and is the development plan document in the
  extract.
- **P-03 is made** (November 2024) and forms part of the development plan.
- **P-02 is a publication draft submitted for examination.** Its own front
  matter states it "does not yet carry the weight of an adopted plan". **What
  weight it attracts is a planning judgement and is not made here.** Its
  policies are kept in a separate table below and are deliberately not merged
  into §2.

### P-02 draft policies, recorded separately

| Ref | Policy | Verbatim | Force | Note |
|---|---|---|---|---|
| D-01 | P-02 H3A | "Schemes of 10 or more dwellings will be expected to provide at least 30% of dwellings as three-bedroom or larger" | `strong expectation` | **This threshold would bite at 42 dwellings, where the adopted H3 threshold (50) does not.** |
| D-02 | P-02 CC9 | "must achieve a space heating demand not exceeding 15 kWh/m²/yr and must not be connected to the gas network" | `requirement` | Material to the services strategy |

**Answer to §9.3 ("does the draft plan apply?"):** this extract records that
P-02 is at examination and that its own front matter disclaims adopted-plan
weight. It does not determine what weight applies — that is the planning
consultant's judgement and ultimately the decision-maker's. The extract has
been built so the consequence is visible either way: D-01 and D-02 are the two
draft policies that would change the scheme.

---

## §7 — Unanswered

Requirements with no corresponding material in S-01, requirements first.

| Ref | Policy | Force |
|---|---|---|
| E-11 | EN3 — 10% biodiversity net gain, 30 years | `requirement` |
| E-13 | HE2 — Heritage Impact Assessment | `requirement` (conditional, trigger `[to verify]`) |
| E-18 | P-04 §5.3 — refuse storage | `requirement` |
| E-09 | T4 — parking standards | `requirement` (standard not supplied) |
| E-14 | CC4 — space standards | `requirement` (standard not supplied) |
| E-04 | H6 — affordable housing | `requirement` (conditional) |
| E-06 | D2 — amenity harm | `requirement` |
| E-10 | T4 — reduced parking | `strong expectation` (trigger not established) |
| E-03 | H3 — homes for older people | `aspiration` |
| E-17 | ARNP4 — car-free | `aspiration` |

S-01 has five sections. Ten requirements and aspirations have no corresponding
section. **This list is the contents page for the DAS.**

---

## §8 — Response to "tell us where we stand"

This extract does not assess compliance, so it cannot answer that question, and
nothing in it should be read as doing so. What it can report factually:

- Nineteen requirements and aspirations extracted from four documents.
- One adopted-plan policy (E-02) **does not apply** at 42 dwellings. The
  equivalent draft policy (D-01) would.
- Six requirements cannot be stated in full because the document carrying the
  figure was not supplied (§3).
- Ten have no corresponding material in the draft DAS (§7).
- The "21 m requirement" is, on the SPD's own words, not a requirement (§5).

The two documents most worth obtaining before anything else are the **Parking
and Travel SPD** and the **nationally described space standard** — between
them they carry the actual content of two adopted-plan requirements.
