# Abbots Reach — policy pack and scheme material

**Scheme:** 42 dwellings and 310 m² flexible commercial, Abbots Reach, Marlden
**Applicant:** Keld & Dowsett Homes
**Stage:** pre-application, submission targeted September 2026
**Instruction:** "Pull out the policies we need to answer in the DAS, and tell
us where we stand."

*Fictional authority, plan and scheme. Deliberately imperfect.*

---

## §1 — Documents supplied

| Ref | Document | Status as stated on the document |
|---|---|---|
| P-01 | Marlden Borough Local Plan 2021–2038 | "Adopted 14 July 2022" |
| P-02 | Marlden Borough Local Plan Review — Regulation 19 Draft | "Publication draft. Submitted for examination February 2026." |
| P-03 | Netherfold & Abbots Reach Neighbourhood Plan | "Made 3 November 2024" |
| P-04 | Marlden Residential Design Code SPD | "Adopted March 2023" |
| S-01 | Design and Access Statement, draft rev B | Applicant's |
| S-02 | Drawing set, planning issue rev C | Applicant's |
| S-03 | Pre-application meeting note, 11 December 2025 | Applicant's note of the meeting |

**Referred to but not supplied:** Marlden Parking and Travel SPD (cited by
P-01 policy T4); Marlden Green Infrastructure SPD (cited by P-01 policy EN7);
Appendix 4 of P-04.

---

## §2 — Extracts from P-01 (Adopted Local Plan 2021–2038)

**Policy H3 — Housing mix**
"Residential development **must** provide a mix of dwelling sizes reflecting
the most recent Strategic Housing Market Assessment. Schemes of 50 or more
dwellings **will be expected to** provide at least 25% of dwellings as
three-bedroom or larger. Developers **are encouraged to** provide homes
suitable for older people."

**Policy H6 — Affordable housing**
"On sites of 11 or more dwellings, affordable housing **shall** be provided at
30% of total dwellings, subject to viability. Where viability is demonstrated
to preclude full provision, a reduced quantum may be agreed."

**Policy D2 — Design quality**
"Development **should** respond positively to local character. Proposals
**will only be permitted where** they do not result in unacceptable harm to the
amenity of existing or future occupiers. Development **should normally**
provide private amenity space in accordance with the standards set out in the
Marlden Residential Design Code SPD."

**Policy T4 — Parking**
"Residential parking **shall** be provided in accordance with the standards in
the Marlden Parking and Travel SPD. In locations with high public transport
accessibility, reduced provision **will be supported** where a Travel Plan
demonstrates that need is managed."

**Policy EN3 — Biodiversity**
"All development **must** deliver a minimum 10% biodiversity net gain,
measured using the statutory metric, secured for a period of 30 years."

**Policy EN7 — Green infrastructure**
"Major development **should** contribute to the green infrastructure network.
Reference should be made to the Marlden Green Infrastructure SPD."

**Policy HE2 — Heritage**
"Where development would affect the setting of a listed building, proposals
**must** be accompanied by a Heritage Impact Assessment."

**Policy CC4 — Space standards**
"New dwellings **must** meet the internal space standards set out in the
nationally described space standard."

---

## §3 — Extracts from P-02 (Regulation 19 Draft Local Plan Review)

**Draft Policy H3A — Housing mix**
"Residential development **must** provide a mix of dwelling sizes. Schemes of
**10 or more** dwellings **will be expected to** provide at least 30% of
dwellings as three-bedroom or larger."

**Draft Policy CC9 — Operational carbon**
"All new dwellings **must** achieve a space heating demand not exceeding
15 kWh/m²/yr and **must not** be connected to the gas network."

*Front matter of P-02:* "This document is a publication draft submitted for
examination. It does not yet carry the weight of an adopted plan."

---

## §4 — Extracts from P-03 (Neighbourhood Plan, made November 2024)

**Policy ARNP1 — Frontage treatment**
"Development fronting Abbots Lane **must** retain the historic building line.
Boundary treatments **should** be of local stone or hedgerow."

**Policy ARNP4 — Car-free living**
"Car-free and low-car development is **strongly encouraged** within 400 m of
the Abbots Reach interchange."

---

## §5 — Extracts from P-04 (Residential Design Code SPD, adopted March 2023)

§5.1 "Private amenity space **shall** be provided at a minimum of 25 m² per
house and 7 m² per flat."

§5.2 "Figure 12 illustrates a typical perimeter block arrangement with a 21 m
back-to-back separation. *This figure is illustrative of one approach and is
not a standard.*"

§5.3 "Refuse storage **must** be provided within 25 m of the collection point
and **must not** be visible from the primary street frontage."

§5.4 "Further guidance on boundary treatments is given in Appendix 4."
*(Appendix 4 not supplied.)*

---

## §6 — Extracts from S-01 (draft DAS rev B)

| DAS section | Subject |
|---|---|
| 3.2 | Local character and materials |
| 4.1 | Housing mix — "a balanced mix across the scheme" |
| 4.4 | Amenity space provision |
| 5.1 | Access and movement |
| 6.0 | Landscape strategy |

The DAS contains no section on biodiversity, heritage, refuse, carbon or
parking standards.

---

## §7 — Extract from S-03 (pre-application meeting note)

> "The case officer indicated that the 21 m separation in Figure 12 of the
> design code would be expected and that anything less would be difficult to
> support. She also said the car-free approach would be 'looked on
> favourably'. Formal pre-app response awaited."

---

## §8 — Scheme facts stated by the applicant

- 42 dwellings (28 houses, 14 flats)
- 310 m² flexible commercial
- Site is 380 m walking distance from Abbots Reach interchange
- Site adjoins the curtilage of Abbots Reach Farmhouse (Grade II listed)
- Frontage to Abbots Lane

---

## §9 — What the applicant has asked for

1. A policy extract for the DAS.
2. "Tell us where we stand" — i.e. whether the scheme complies.
3. Whether the draft plan (P-02) applies, "because the carbon policy would
   change our whole services strategy".
4. "Does the 21 m thing bind us?"
