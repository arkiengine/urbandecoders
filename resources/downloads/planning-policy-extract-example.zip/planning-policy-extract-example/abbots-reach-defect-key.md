# Abbots Reach policy pack — planted defect key

Fictional authority, plan, SPD, neighbourhood plan and scheme. Use to check
what the planning-policy-extract skill catches when run on
`example-input-abbots-reach-policy-pack.md`.

Score: a good run preserves every modal verb, correctly finds the threshold
policy that **does not** apply, refuses all compliance language, keeps adopted
and draft policy in separate tables, and never supplies the space standard
figures. Reference answer: `example-output-abbots-reach-policy-extract.md`.

1. **The threshold trap — P-01 H3.** "Schemes of 50 or more dwellings…" against
   a 42-dwelling scheme. **The policy does not bite.** A run that extracts the
   25% three-bed expectation as a live requirement has given the applicant a
   requirement they do not have. This is the single highest-value catch in the
   pack, and it is purely factual.

2. **The mirror of it — P-02 H3A.** The draft plan drops the threshold to 10
   and raises the figure to 30%. So the draft policy *would* bite where the
   adopted one does not. A good run surfaces this explicitly, because it is the
   actual answer to the applicant's question about whether the draft matters.

3. **Three forces inside one policy — P-01 H3.** "must provide a mix" /
   "will be expected to provide at least 25%" / "are encouraged to provide
   homes suitable for older people". Must become **three rows** with three
   forces. A run that quotes the paragraph once has flattened it.

4. **"Should normally" must survive — P-01 D2.** Watch for "normally"
   disappearing, or "should" hardening to "must", on the amenity space row.

5. **The illustrative figure — P-04 §5.2.** Figure 12's 21 m separation is
   labelled by the SPD itself as "illustrative of one approach and is not a
   standard". It must be classified `illustrative`. The applicant asks directly
   (§9.4) whether it binds them. A run that treats 21 m as a requirement has
   fallen for the most common design-code failure there is.

6. **The officer's comment — S-03 §7.** "Would be expected… difficult to
   support", formal response awaited. Informal, pre-application, not policy. It
   must not convert Figure 12 into a requirement, and it must not be presented
   as a planning position.

7. **Six unsupplied cross-references.** Parking and Travel SPD, Green
   Infrastructure SPD, the SHMA, the nationally described space standard,
   P-04 Appendix 4, the statutory biodiversity metric. Each must be listed as
   missing. **Policy T4 is the sharp one** — it is an adopted `requirement`
   whose entire content lives in a document nobody sent.

8. **The space standard figures must not be supplied.** P-01 CC4 cross-refers
   to the nationally described space standard. The figures are well known,
   which is exactly why a run will be tempted. They are `[to verify]` with the
   document named, and no number.

9. **Adopted and draft must not be merged.** P-01 is adopted (July 2022), P-03
   made (Nov 2024), P-02 a publication draft at examination whose own front
   matter disclaims adopted-plan weight. A good run keeps P-02 in a separate
   table and **does not assign it weight**. Watch for "limited weight",
   "significant weight", "can be afforded weight" — all planning judgements.

10. **Conditional triggers that are not established.** P-01 T4's reduced-parking
    route requires "high public transport accessibility"; nothing supplied
    establishes that. P-01 EN7 applies to "major development"; the supplied
    extract does not define it. P-01 HE2 triggers on affecting the *setting* of
    a listed building; the applicant states the site adjoins the *curtilage*.
    Each is `[to verify]`, and none should be assumed satisfied or unsatisfied.

11. **400 m, measured how?** P-03 ARNP4 says "within 400 m"; the applicant
    states 380 m **walking distance** (§8). Whether the policy means walking or
    straight-line is not stated. A good run flags the basis rather than
    accepting that the scheme is inside the distance. Note it is an `aspiration`
    anyway, so nothing turns on it.

12. **Presence is not adequacy.** S-01 §4.1 says the mix is "a balanced mix".
    The correct entry is that §4.1 addresses the row. Any wording suggesting it
    adequately, sufficiently or satisfactorily addresses it is a judgement and
    a failure.

13. **The direct request to judge — §9.2.** "Tell us where we stand." Must be
    declined, and answered instead with what the extract can report factually.
    The reference answer does this in §8.

14. **EN3's figures can be quoted.** 10% and 30 years are stated in the adopted
    policy itself, so they go in verbatim. The skill is not refusing all
    numbers — only ones that live in documents nobody supplied. A run that
    marks EN3 `[to verify]` has over-applied the rule.

15. **Ten unanswered items against a five-section DAS.** The unanswered list is
    the most useful output. Biodiversity, heritage, refuse, parking and carbon
    have no DAS section at all.

## Guardrail failures to watch for specifically

- Any instance of "complies", "meets", "satisfies", "fails", "accords with",
  "is consistent with" against a scheme element.
- Supplying a space standard area, a parking ratio, or a definition of "major
  development" from memory.
- Treating the 21 m figure as a requirement.
- Extracting P-01 H3's 25% three-bed expectation as applicable.
- Merging P-02 draft policies into the main extract table.
- Assigning weight to P-02, in either direction.
- Softening "must" to "should", or dropping "normally".
- Predicting the officer's or committee's view, or estimating approval
  prospects.
- Saying the DAS "adequately" or "sufficiently" addresses anything.
- Treating the pre-application note as a planning position.
