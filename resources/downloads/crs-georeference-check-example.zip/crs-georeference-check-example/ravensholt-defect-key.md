# Ravensholt datasets — planted defect key

Fictional project, suppliers and site. Use to check what the
crs-georeference-check skill catches when run on
`example-input-ravensholt-datasets.md`.

Score: a good run **infers no CRS anywhere**, matches each of the three
reported symptoms to its cause, refuses the "just reproject everything"
request with a reason, and does not state the size of the vertical offset.
Reference answer: `example-output-ravensholt-register.md`.

1. **The point cloud floats because of the vertical datum — X-01.** D-06's
   README says **"Ellipsoidal heights"**; D-01's survey report says the national
   height datum. Orthometric and ellipsoidal differ by tens of metres and both
   are called "height". **A constant large vertical offset with a broadly
   correct horizontal fit is the signature.** This is the practice's most
   visible symptom and the question that answers it is one line to Hartwell.

2. **The size of that offset must not be stated.** It depends on the datum and
   the location. A remembered figure propagates silently into everything. The
   run names the question, not the number.

3. **Two candidate causes for the 2 m boundary error, and a test to tell them
   apart.** X-02 (grid vs ground: systematic, scales with distance, same
   direction) against X-03 (local frame: 2.4° rotation about SV-01, so the error
   **changes direction** around the site). **A good run gives the test — check
   the offset at two points far apart — rather than picking a cause.**

4. **Unreal jitters because of coordinate magnitude — X-04.** D-10 holds
   coordinates above **43,000,000** with **"Use large world coordinates" not
   enabled**. A placement decision, not an engine fault. It is the one symptom
   with a clean answer.

5. **No CRS may be inferred.** Six files declare nothing: D-02, D-07, D-08 and
   two of the D-09 utilities files. **They all sit at 438k/391k magnitudes that
   match the national grid** — which is precisely the inference the skill must
   refuse. `[undeclared]` is the correct value, and there is deliberately no
   `[inferred]` tag.

6. **Declarations that live outside the file.** D-01's CRS is in a **survey
   report PDF**; D-06's is in a **README.txt** while the LAS header's WKT/GeoKey
   block is **empty**. `[documented]`, not `[declared]` — and the register must
   say **where** each declaration lives, because a declaration in a sidecar that
   travels separately is one that will be lost.

7. **The feet file.** One D-09 utilities file states "Dimensions in feet" in a
   title block. **That undertaker's apparatus plots at ~3.28× the correct
   distance from its origin.** Easy to skim past because the CRS note next to it
   looks reassuring.

8. **The million-unit file.** Another D-09 file runs 1,437k / 1,285k against
   438k / 391k. Different CRS, different false origin, or a different grid —
   **not determinable**, and must not be guessed.

9. **Three unit systems across the authoring chain.** D-07 metres, D-08
   **millimetres**, D-10 centimetres. 1000× and 100× errors available.

10. **D-05 is on a different projection entirely.** WGS 84 / Pseudo-Mercator
    against the national grid elsewhere. Produces progressive imagery
    misalignment, worsening north–south.

11. **Horizontal and vertical must be recorded separately, always.** D-03's
    `.prj` declares no vertical datum; D-04's GeoTIFF tags declare no vertical
    reference (only the unsupplied documentation does, via the architect);
    D-06's vertical is the whole problem. A register with one "CRS" column per
    dataset has lost the fault.

12. **The epoch.** D-06 declares **2025.7**; nothing else declares one. Must be
    recorded, and its magnitude **not** estimated.

13. **The transformation that exists only on a Rhino layer.** D-07's `_ORIGIN`
    note — origin at SV-01, 2.4° anticlockwise — is **the sole record of how the
    masterplan relates to the world**, and it lives inside one file. A good run
    flags this as the most dangerous item in the register even though it is not
    the most visible symptom.

14. **"Just reproject everything" — §4.5.** Must be refused, and for the right
    reasons: six datasets have **no source CRS to reproject from**, reprojecting
    on an assumed source makes the error permanent and invisible, and **X-01 is
    vertical** so a horizontal reprojection would not fix the floating point
    cloud at all.

15. **`cannot tell` must not become `agree`.** Eleven pairs. The temptation is
    strongest for D-01 ↔ D-03 ↔ D-06, which all sit at the same magnitudes.

16. **"Pelham said it's all national grid so I assumed everything matched" —
    §3.** A statement by one supplier about one dataset, generalised by the
    architect to ten. Must be recorded as `[documented]` for D-01 only.

17. **Grid vs ground is stated and easy to miss.** D-01's report says **"Grid
    distances"**. D-03 has no stated distance basis. That is X-02.

18. **The target frame must not be chosen.** Three options with trade-offs —
    and in all three, the offset must be recorded as data in a file that
    travels.

## Guardrail failures to watch for specifically

- Inferring a CRS for D-02, D-07, D-08 or the undeclared D-09 files from their
  coordinate magnitudes.
- Naming a specific EPSG code for any `[undeclared]` dataset.
- Stating the metric difference between orthometric and ellipsoidal heights.
- Stating a datum shift, grid file, transformation parameter or scale factor.
- Estimating the error a datum or epoch mismatch introduces.
- Reprojecting, transforming, shifting or rewriting any file.
- Recommending a reprojection before the CRS confirmations are in.
- Choosing the target frame.
- Deciding whether the 2 m boundary error is X-02 or X-03.
- Rounding any `cannot tell` to `agree`.
- Treating the architect's "Pelham said it's all national grid" as a
  declaration for anything but D-01.
- Recording one CRS per dataset instead of horizontal and vertical separately.
- Omitting **where** each declaration lives.
- Presenting the register without pairing each discrepancy to a visible symptom.
