# Ravensholt — dataset inventory for the twin

**Project:** Ravensholt masterplan twin, 46 ha former airfield
**Target:** three.js / Cesium web viewer with an Unreal walkthrough of phase 1
**Instruction:** "Nothing lines up. The point cloud floats, the buildings are
two metres off the plot boundaries, and the model jitters in Unreal."

*Fictional project, suppliers and site. Deliberately imperfect.*

---

## §1 — Datasets supplied

| # | Dataset | Format | Supplier | Date |
|---|---|---|---|---|
| D-01 | Topographical survey | `.dwg` | Pelham Surveys | Jun 2025 |
| D-02 | Topographical survey, same job | `.csv` point list | Pelham Surveys | Jun 2025 |
| D-03 | Site boundary and plots | `.shp` | Tarnside Developments | Jan 2026 |
| D-04 | Terrain raster | `.tif` | Open national dataset | 2024 |
| D-05 | Aerial imagery | `.tif` | Open national dataset | 2023 |
| D-06 | Point cloud | `.las` | Hartwell Geospatial | Sep 2025 |
| D-07 | Masterplan massing model | `.3dm` (Rhino) | Hallam & Roe | Feb 2026 |
| D-08 | Phase 1 building model | `.ifc` | Hallam & Roe | Feb 2026 |
| D-09 | Existing utilities | `.dxf` | Various statutory undertakers | 2024–25 |
| D-10 | Unreal scene | `.umap` | Hallam & Roe | Feb 2026 |

---

## §2 — What each file declares, and where

**D-01 — Topographical survey (.dwg)**
- No CRS metadata in the file.
- Survey report PDF (supplied) states: *"Coordinates and levels are on the
  national grid and national height datum. Grid distances. Survey station
  SV-01 at E 438,210.45 N 392,118.30."*
- Drawing units: metres.

**D-02 — Same survey, .csv point list**
- Header row: `PointID,X,Y,Z,Code`
- First row: `SV-01,438210.450,392118.300,61.220,STN`
- No CRS declared in the file or in any sidecar.

**D-03 — Site boundary and plots (.shp)**
- `.prj` sidecar present. Contents declare a **projected coordinate system
  matching the national grid**.
- Coordinate range: E 438,050–438,940 · N 391,880–392,610.

**D-04 — Terrain raster (.tif)**
- GeoTIFF tags present, declaring the **national grid**.
- **Vertical reference not declared in the file.** The dataset's published
  documentation (not supplied) is said by the architect to describe it as
  "orthometric heights".

**D-05 — Aerial imagery (.tif)**
- GeoTIFF tags present, declaring **WGS 84 / Pseudo-Mercator**.

**D-06 — Point cloud (.las)**
- LAS header **WKT/GeoKey block is empty.**
- `README.txt` supplied with it states: *"Delivered in national grid.
  **Ellipsoidal heights.** Epoch 2025.7."*
- Coordinate range: X 438,040–438,950 · Y 391,870–392,620 · Z 110.4–134.8.

**D-07 — Masterplan massing (.3dm)**
- No CRS metadata.
- Rhino file units: **metres**.
- Geometry located close to origin: X −420 to +510, Y −360 to +480.
- Note in a layer called `_ORIGIN`: *"Model origin = survey station SV-01.
  Rotated 2.4° anticlockwise to align with the main street grid."*

**D-08 — Phase 1 building model (.ifc)**
- `IfcProjectedCRS` **absent.**
- `IfcMapConversion` **absent.**
- `LENGTHUNIT` = **millimetre.**
- Element coordinates: X −18,400 to +42,600 (mm), Y −22,100 to +31,800 (mm).

**D-09 — Utilities (.dxf)**
- Several files from different undertakers.
- **Two** declare nothing.
- **One** carries a title block note: *"Coordinates in national grid.
  Dimensions in feet."*
- Coordinate magnitudes vary between files: one set runs 438,xxx / 391,xxx;
  another runs 1,437,xxx / 1,285,xxx.

**D-10 — Unreal scene (.umap)**
- World origin set at `0,0,0`.
- Imported geometry placed at coordinates in the range 43,800,000 to
  43,894,000 in X.
- Project settings: **"Use large world coordinates" — not enabled.**

---

## §3 — What the architect has said

> "Pelham said it's all national grid so I assumed everything matched. The
> point cloud sits about 50 m above the survey which can't be right. The
> plots from Tarnside are about 2 m out from where the survey says the
> boundary is. And the Unreal scene jitters when you move the camera."

---

## §4 — What the practice has asked for

1. "Build a georeferencing register."
2. "Why does the point cloud float?"
3. "Why is the boundary 2 m out?"
4. "Why does Unreal jitter?"
5. "Just reproject everything to the national grid and be done with it."
