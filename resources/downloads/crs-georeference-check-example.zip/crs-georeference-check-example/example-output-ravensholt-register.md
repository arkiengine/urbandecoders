# Ravensholt — georeferencing register

**Prepared:** 4 March 2026 · **Target:** three.js / Cesium web viewer, plus an
Unreal walkthrough of phase 1.

> **Nothing in this register has been reprojected, transformed or rewritten.**
> It reconciles what each file declares and names what must be confirmed. The
> transformations themselves are a job for GDAL/OGR, PROJ or the authoring tool,
> run deliberately with parameters somebody has confirmed.

---

## §1 — Declaration table

| # | Dataset | CRS as declared | **Where the declaration lives** | Horiz. datum | **Vert. datum** | Units H / V | Origin / offset | Rotation | Epoch | Magnitude | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| D-01 | Topo survey `.dwg` | National grid | **Survey report PDF, not the file** | `[undeclared]` | **National height datum**, per report | m / m | — | — | — | 438k / 392k | **`[documented]`** |
| D-02 | Topo survey `.csv` | **Nothing** | **Nowhere** | `[undeclared]` | `[undeclared]` | `[undeclared]` | — | — | — | 438k / 392k | **`[undeclared]`** |
| D-03 | Boundary + plots `.shp` | Projected CS matching the national grid | **`.prj` sidecar** | Per `.prj` | **`[undeclared]`** | m / — | — | — | — | 438k / 392k | `[declared]` |
| D-04 | Terrain raster `.tif` | National grid | **GeoTIFF tags** | Per tags | **`[undeclared]` in the file**; "orthometric" per unsupplied documentation | m / `[stated]` | — | — | — | — | `[declared]` H, **`[stated]` V** |
| D-05 | Aerial imagery `.tif` | **WGS 84 / Pseudo-Mercator** | GeoTIFF tags | Per tags | n/a | m / — | — | — | — | — | `[declared]` |
| D-06 | Point cloud `.las` | National grid | **`README.txt`, not the LAS header — header WKT/GeoKey block is EMPTY** | `[undeclared]` | **Ellipsoidal**, per README | m / m | — | — | **2025.7** | 438k / 392k, **Z 110.4–134.8** | **`[documented]`** |
| D-07 | Massing `.3dm` | **Nothing** | **Nowhere** | — | — | m / m | **Model origin = survey station SV-01** | **2.4° anticlockwise** | — | ±510 | **`[undeclared]`** + layer note |
| D-08 | Phase 1 `.ifc` | **Absent** — no `IfcProjectedCRS`, no `IfcMapConversion` | — | — | — | **mm / mm** | `[undeclared]` | `[undeclared]` | — | ±42,600 mm | **`[undeclared]`** |
| D-09a | Utilities `.dxf` (2 files) | **Nothing** | **Nowhere** | — | — | `[undeclared]` | — | — | — | 438k / 391k | **`[undeclared]`** |
| D-09b | Utilities `.dxf` (1 file) | National grid | **Title block note** | — | — | **FEET** / — | — | — | — | 1,437k / 1,285k | **`[documented]`** |
| D-10 | Unreal `.umap` | n/a | — | — | — | cm | World origin `0,0,0` | — | — | **43,800,000+** | `[declared]` |

**No CRS has been inferred anywhere in this register.** Where a file declares
nothing, it is `[undeclared]` and it is a question — never a guess from
coordinate magnitude or from what the neighbouring datasets use.

---

## §2 — Agreement matrix

| Pair | CRS | Datum | Units | Origin |
|---|---|---|---|---|
| D-01 ↔ D-02 | **cannot tell** | cannot tell | **cannot tell** | agree |
| D-01 ↔ D-03 | **cannot tell** | cannot tell | agree | agree |
| D-01 ↔ D-06 | **cannot tell** | **DIFFER (vertical)** | agree | agree |
| D-01 ↔ D-07 | **differ** | — | agree | **differ** |
| D-03 ↔ D-04 | agree (both declare the national grid) | cannot tell | agree | agree |
| D-04 ↔ D-05 | **DIFFER** | differ | agree | differ |
| D-04 ↔ D-06 | cannot tell | **DIFFER (vertical)** | agree | agree |
| D-06 ↔ D-07 | **differ** | — | agree | **differ** |
| D-07 ↔ D-08 | cannot tell | — | **DIFFER (m vs mm)** | cannot tell |
| D-09a ↔ D-09b | **cannot tell** | — | **DIFFER (unknown vs feet)** | **differ** |
| D-08 ↔ D-10 | cannot tell | — | **differ (mm vs cm)** | cannot tell |

**`cannot tell` appears eleven times and has not been rounded to `agree`
anywhere.** Six of the ten datasets declare nothing in the file itself.

---

## §3 — Discrepancies, each with the symptom it produces

**This is the section that answers the practice's questions.** Match the
symptom you are seeing to its cause.

| # | Discrepancy | **Symptom it produces** |
|---|---|---|
| **X-01** | **D-06 is in ellipsoidal heights (README); D-01 is on the national height datum (survey report).** Orthometric and ellipsoidal heights differ by tens of metres and both are called "height" | **The point cloud sits a constant, large vertical offset above or below the survey across the whole site.** Horizontal position is unaffected |
| **X-02** | **D-01's survey report states "grid distances".** D-03's plots come from a different supplier with no stated distance basis | **A small, systematic horizontal mismatch that grows with distance from the survey origin** — metre-scale over a 46 ha site |
| **X-03** | **D-07 is in a local frame: origin at SV-01, rotated 2.4° anticlockwise** (layer `_ORIGIN` note) | **The massing is both offset and rotated relative to everything georeferenced.** The error grows across the site, so the north end is further out than the south |
| **X-04** | **D-10 holds coordinates above 43 million with "Use large world coordinates" NOT enabled** | **Jitter.** Geometry shimmers, the camera stutters, snapping fails. **It looks like an engine bug and it is a placement problem** |
| **X-05** | **D-05 is WGS 84 / Pseudo-Mercator; D-03 and D-04 are on the national grid** | **Imagery progressively misaligns from the vectors**, worsening north–south |
| **X-06** | **One D-09 utilities file is in FEET** (title block note) | **That undertaker's apparatus plots at roughly 3.28× the correct distance from its origin** |
| **X-07** | **D-09 files run at two different magnitudes** — 438k/391k and 1,437k/1,285k | **One undertaker's apparatus lands a million units away.** Different CRS, different false origin, or a different grid entirely — **not determinable from what was supplied** |
| **X-08** | **D-08 is in millimetres; D-07 in metres; D-10 in centimetres** | **1000× and 100× scale errors** if any is imported assuming the wrong unit |
| **X-09** | **D-06 carries epoch 2025.7; no other dataset declares an epoch** | A realisation/epoch difference. **Magnitude not stated here** — it depends on the datum and the region, and this register does not estimate it |
| **X-10** | **D-02 declares nothing at all**, yet carries the same magnitudes as D-01 | A `.csv` with no CRS is a file that will eventually be loaded with the wrong assumption |
| **X-11** | **D-03's `.prj` declares no vertical datum** | Plot levels, if any, cannot be reconciled with D-01, D-04 or D-06 |

---

## §4 — The three symptoms the practice reported

**"The point cloud floats about 50 m above the survey" → X-01.**
The LAS header's WKT/GeoKey block is **empty**; the only statement of
georeferencing is the supplied `README.txt`, which says *"Ellipsoidal
heights"*. The survey report says the national height datum. **These are two
different vertical references, and a constant large offset is exactly the
symptom.** The horizontal fit being broadly right while the vertical is
badly wrong is the signature of this fault.

**This register does not state the size of that offset.** It depends on the
datum and the location, and a remembered figure would propagate silently into
everything. **Q-04** asks Hartwell Geospatial to confirm.

**"The plots are about 2 m out" → X-02, and possibly X-03.**
Two candidate causes, and they are distinguishable by a test:
- **X-02 (grid vs ground):** the error is systematic, scales with distance
  from the survey origin, and is in the same direction everywhere.
- **X-03 (local frame):** if the comparison was made against D-07 rather than
  D-01, a 2.4° rotation about SV-01 produces an error that **grows with
  distance and changes direction** around the site.

**Check the offset at two points far apart.** Same magnitude and direction →
X-02. Different direction → X-03. This register does not assume which.

**"Unreal jitters" → X-04.**
D-10 holds coordinates above 43,000,000 with **"Use large world coordinates"
not enabled**. That is a single-precision range problem, and it is a placement
decision, not an engine fault. It is also the one problem here with a clean
answer: see the target frame options in §6.

---

## §5 — Confirmation requests

One-line questions, addressed to whoever can answer them in one line.

| # | To | Question |
|---|---|---|
| Q-01 | **Pelham Surveys** | Which CRS is the topographical survey delivered in, and which vertical datum? |
| Q-02 | **Pelham Surveys** | Are the coordinates grid or ground distances, and if grid, what is the scale factor at this site? |
| Q-03 | **Pelham Surveys** | Is the `.csv` (D-02) in the same CRS and units as the `.dwg` (D-01)? |
| Q-04 | **Hartwell Geospatial** | Confirm the point cloud's horizontal CRS and **vertical datum**, and the epoch. Can it be delivered on the same vertical datum as the topographical survey? |
| Q-05 | **Tarnside Developments** | Which CRS were the plot boundaries drawn in, and were they derived from the Pelham survey or from a separate source? |
| Q-06 | **Each statutory undertaker** | Which CRS and which units is your apparatus data supplied in? (One file states feet; two state nothing; one is a million units away.) |
| Q-07 | **Hallam & Roe** | Is the `_ORIGIN` note in D-07 the complete transformation — origin at SV-01, 2.4° anticlockwise — and is it recorded anywhere outside the Rhino file? |
| Q-08 | **The terrain raster publisher** | Confirm the vertical reference of D-04. (The architect reports the documentation says "orthometric"; the documentation was not supplied.) |

---

## §6 — Target frame options

**The register does not choose. These are the trade-offs.**

| Option | What it is | Protects | Costs |
|---|---|---|---|
| **A — Single georeferenced frame** | Everything on the national grid, true coordinates throughout | GIS correctness; Cesium works natively; one source of truth | **Unreal jitters** unless large world coordinates are enabled (X-04). Authoring in Rhino and Revit at 438k/392k is unpleasant and error-prone |
| **B — Single local frame** | Everything shifted to a project origin (SV-01 is the obvious candidate — D-07 already uses it) | Authoring is comfortable; **Unreal does not jitter**; the ±510 m range is ideal for an engine | **GIS and Cesium need the offset applied on the way out.** If the offset is ever lost, nothing can be re-placed |
| **C — Dual frame with a recorded transformation** | Georeferenced for GIS/Cesium, local for authoring and Unreal, **with the transformation held as project data in a file that travels** | Both; this is the normal answer for a twin | Discipline. The transformation must be versioned, owned and distributed, or it decays into option B with a lost offset |

**Whichever is chosen, the offset and rotation must be recorded as data in a
file that travels with the project.** The transformation that currently exists
only as a note on a Rhino layer (D-07, `_ORIGIN`) is one file-save away from
being lost, and it is the only record of how the massing relates to the world.

---

## §7 — "Just reproject everything and be done with it"

**This register performs no reprojection, and doing so now would make things
worse rather than better.**

Six of the ten datasets (D-02, D-07, D-08, D-09a ×2) declare **no CRS at all**.
A reprojection needs a source CRS, and for those files there is nothing to
reproject *from* — only an assumption. Reprojecting on an assumed source is how
a dataset becomes permanently and invisibly wrong: the output carries a
confident declaration, and the error is no longer recoverable.

Two further datasets (D-01, D-06) declare their CRS **outside the file** — in a
report and a README. Those declarations will not travel with the data.

And **X-01 is a vertical datum problem**, which a horizontal reprojection does
not touch at all. The point cloud would still float.

**Sequence:** answer Q-01 to Q-08 → record each confirmed CRS **into** each
file or its sidecar → choose the target frame (§6) → then transform, once,
deliberately, in GDAL/OGR, PROJ or the authoring tool, with confirmed
parameters.

---

## §8 — Shape of this register

**10 datasets. 4 `[declared]` in the file itself. 2 `[documented]` outside the
file. 4 `[undeclared]`.** (D-09 counts as three files: one `[documented]`, two
`[undeclared]`.)

**11 discrepancies. 11 `cannot tell` pairs. 8 confirmation requests.**

**The most consequential disagreement is X-01** — the point cloud's vertical
datum. It is the symptom the practice can already see, it is a one-line
question to Hartwell Geospatial, and no horizontal work will fix it.

**The most dangerous is X-03** — a transformation that exists only as a note on
a layer inside one Rhino file, and which is the sole record of how the
masterplan massing relates to the world.
