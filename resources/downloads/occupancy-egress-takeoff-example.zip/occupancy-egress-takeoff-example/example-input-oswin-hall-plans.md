# Oswin Hall — drawing takeoff for egress review

**Project:** Oswin Hall, Marlden — conversion of a Victorian assembly hall to a
mixed community and workspace building
**Stage:** pre-Building Control, fire engineer not yet appointed
**Instruction:** "Work out the occupancy and check the escape routes before we
pay a fire engineer."

*Fictional building and scheme. Deliberately imperfect.*

---

## §1 — Drawings supplied

| Ref | Drawing | Scale stated | Notes |
|---|---|---|---|
| E-100 | Ground floor plan, rev C | 1:100 @ A1 | **Issued as A3 PDF. No scale bar.** |
| E-101 | First floor plan, rev C | 1:100 @ A1 | As above |
| E-102 | Second floor (mezzanine) plan, rev B | 1:100 @ A1 | **One revision behind** |
| E-200 | Sections AA and BB, rev C | 1:100 @ A1 | — |
| S-01 | Room schedule (partial) | — | Covers ground floor only |

**No measured survey supplied. No existing fire strategy supplied. No
governing code or edition named by the applicant.**

---

## §2 — Ground floor, from E-100

| Space | Name on drawing | Area stated | Notes on drawing |
|---|---|---|---|
| G01 | Main Hall | 288 m² | Retractable seating, "capacity 300" annotated by hand |
| G02 | Foyer | 64 m² | — |
| G03 | Café | 71 m² | Counter and seating shown |
| G04 | Kitchen | 24 m² | — |
| G05 | Store | 11 m² | — |
| G06 | **"Studio"** | 46 m² | No use stated |
| G07 | **"Flex"** | 38 m² | No use stated |
| G08 | WCs | 22 m² | — |
| G09 | Plant | 18 m² | — |
| G10 | Lobby | 9 m² | Between hall and rear exit |
| G11 | Corridor | 31 m² | Labelled **1200 wide** |
| — | Riser | — | **Riser door shown opening into G11, not dimensioned** |

**Exits shown on E-100:** main entrance to Oswin Street (double doors, leaves
dimensioned 900 each); rear exit via G10 to the yard (single door, leaf
dimensioned 850); a door from G03 to Oswin Street (single, **not dimensioned**).

**Annotation on E-100, handwritten:** *"Escape via café if needed"*

---

## §3 — First floor, from E-101

| Space | Name on drawing | Area stated | Notes |
|---|---|---|---|
| F01 | Workspace 1 | 96 m² | Open plan |
| F02 | Workspace 2 | 88 m² | Open plan |
| F03 | Meeting | 26 m² | — |
| F04 | Meeting | 24 m² | — |
| F05 | Tea point | 12 m² | — |
| F06 | WCs | 18 m² | — |
| F07 | Corridor | 42 m² | Not dimensioned |
| F08 | **"Room"** | 19 m² | No use stated |

**Stairs:** Stair 1 (from foyer G02, enclosed, **width not dimensioned**);
Stair 2 (from G11 corridor, **shown on E-100 and E-101 but not on E-200
sections**).

---

## §4 — Second floor / mezzanine, from E-102 (rev B)

| Space | Name | Area | Notes |
|---|---|---|---|
| M01 | Mezzanine gallery | 74 m² | Open to Main Hall below |
| M02 | Store | 8 m² | — |

**Access to mezzanine:** Stair 1 only, per E-102.

**Note on E-102:** *"Mezzanine capacity to be confirmed."*

---

## §5 — Room schedule S-01 (ground floor only)

| Ref | Name | Area (m²) | Use class as stated |
|---|---|---|---|
| G01 | Main Hall | 285 | Assembly |
| G02 | Foyer | 64 | Circulation |
| G03 | Café | 71 | Assembly |
| G06 | Studio | 46 | **blank** |
| G07 | Flex | 38 | **blank** |

*G01 area differs from E-100. The schedule does not state a measurement basis.*

---

## §6 — What the client has asked for

1. "Work out the occupancy for the whole building."
2. "The hall says 300 on the drawing — is that right?"
3. "How wide do the exits need to be?"
4. "Are the travel distances OK? It's not a big building."
5. "Do we actually need a fire engineer, or can we take this straight to
   Building Control?"
