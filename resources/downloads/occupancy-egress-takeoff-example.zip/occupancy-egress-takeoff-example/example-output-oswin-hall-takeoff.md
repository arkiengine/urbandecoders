# Oswin Hall — occupancy and egress takeoff

**Prepared:** 20 February 2026. **For:** fire engineer appointment and
Building Control pre-submission.

> **This worksheet contains no occupancy figures, no capacities, no travel
> distance limits and no widths-per-person.** Every such figure depends on the
> governing document, its edition, and the use of each space — and a remembered
> one is worse than a blank. The columns are built so that the fire engineer
> enters the code factors and the checks complete themselves.

---

## §1 — Basis

**Governing document: `[not stated]`.** The client has not named a code or
edition, and no existing fire strategy was supplied. Every clause reference
below is therefore a named placeholder. **This is the first thing to resolve**:
it is the difference between a takeoff the engineer can use and one they must
redo.

**B-01 — The drawings are not reliably measurable.** E-100, E-101 and E-102
state 1:100 @ A1 but were **issued as A3 PDFs with no scale bar** (§1). An A1
drawing printed at A3 is at 1:200, not 1:100. Nothing supplied establishes
whether the sheets were rescaled on export. **Every dimension not explicitly
written on the drawing is therefore `[to verify]`, and no dimension has been
scaled off in this takeoff.** A travel distance scaled from a rescaled sheet is
a fabricated number.

| Ref | Drawing | Revision | Status |
|---|---|---|---|
| E-100 | Ground floor | rev C | A3 PDF, no scale bar |
| E-101 | First floor | rev C | As above |
| E-102 | Second floor | **rev B — one behind** | As above |
| E-200 | Sections AA, BB | rev C | **Stair 2 does not appear on it** |
| S-01 | Room schedule | — | **Ground floor only**; no measurement basis stated |

**B-02 — Existing building, no measured survey.** Nothing supplied establishes
that the drawings match the building as it stands. For a Victorian conversion
this matters more than usual.

---

## §2 — Space schedule

| Ref | Level | Name as drawn | Use (drawn / inferred) | Area stated | Area basis | Occupancy basis to apply | Clause |
|---|---|---|---|---|---|---|---|
| G01 | 00 | Main Hall | Assembly `[as scheduled]` | **288 (E-100) / 285 (S-01)** | **Not stated — conflict, see §6 Q-01** | `[to verify]` | `[to verify]` |
| G02 | 00 | Foyer | Circulation `[as scheduled]` | 64 | Not stated | `[to verify]` | `[to verify]` |
| G03 | 00 | Café | Assembly `[as scheduled]` | 71 | Not stated | `[to verify]` | `[to verify]` |
| G04 | 00 | Kitchen | Ancillary `[inferred use]` — adjacency to G03 | 24 | Not stated | `[to verify]` | `[to verify]` |
| G05 | 00 | Store | Ancillary `[inferred use]` | 11 | Not stated | `[to verify]` | `[to verify]` |
| G06 | 00 | **Studio** | **`[inferred use]` — blank in S-01** | 46 | Not stated | **Cannot be established — Q-02** | `[to verify]` |
| G07 | 00 | **Flex** | **`[inferred use]` — blank in S-01** | 38 | Not stated | **Cannot be established — Q-02** | `[to verify]` |
| G08 | 00 | WCs | Sanitary | 22 | Not stated | `[to verify]` | `[to verify]` |
| G09 | 00 | Plant | Plant | 18 | Not stated | `[to verify]` | `[to verify]` |
| G10 | 00 | Lobby | Circulation `[inferred use]` | 9 | Not stated | `[to verify]` | `[to verify]` |
| G11 | 00 | Corridor | Circulation | 31 | Not stated | `[to verify]` | `[to verify]` |
| — | 00 | **Riser** | Service | **Not scheduled** | — | — | See §4 W-03 |
| F01 | 01 | Workspace 1 | Office `[inferred use]` | 96 | Not stated | `[to verify]` | `[to verify]` |
| F02 | 01 | Workspace 2 | Office `[inferred use]` | 88 | Not stated | `[to verify]` | `[to verify]` |
| F03 | 01 | Meeting | Office `[inferred use]` | 26 | Not stated | `[to verify]` | `[to verify]` |
| F04 | 01 | Meeting | Office `[inferred use]` | 24 | Not stated | `[to verify]` | `[to verify]` |
| F05 | 01 | Tea point | Ancillary `[inferred use]` | 12 | Not stated | `[to verify]` | `[to verify]` |
| F06 | 01 | WCs | Sanitary | 18 | Not stated | `[to verify]` | `[to verify]` |
| F07 | 01 | Corridor | Circulation | 42 | Not stated | `[to verify]` | `[to verify]` |
| F08 | 01 | **"Room"** | **`[inferred use]` — nothing establishes a use** | 19 | Not stated | **Cannot be established — Q-02** | `[to verify]` |
| M01 | 02 | Mezzanine gallery | Assembly `[inferred use]` — open to G01 | 74 | Not stated | `[to verify]` | `[to verify]` |
| M02 | 02 | Store | Ancillary `[inferred use]` | 8 | Not stated | `[to verify]` | `[to verify]` |

**22 spaces scheduled, including plant, stores, risers and circulation.** A
space left off the schedule is a space nobody assigned an occupancy basis to,
and the omission does not show up later.

**Areas are `[as scheduled]` or read from the drawing annotations. No area has
been scaled off.** S-01 covers the ground floor only, so eleven spaces have no
schedule entry at all and their areas come from drawing annotations with no
stated basis.

---

## §3 — Route schedule

| Ref | From | Path as drawn | Doors passed | Compartment lines crossed | Final exit | Status |
|---|---|---|---|---|---|---|
| R-01 | G01 Main Hall | → G02 Foyer → main entrance | 1 (double, 900 leaves) | `[to verify]` — no compartmentation shown on any supplied drawing | Oswin Street | `[as drawn]` |
| R-02 | G01 Main Hall | → G10 Lobby → rear exit | 2 (lobby, then 850 leaf) | `[to verify]` | Yard | `[as drawn]` |
| R-03 | G01 Main Hall | → G03 Café → street door | 2 | `[to verify]` | Oswin Street | **`[assumed route]` — see W-01** |
| R-04 | F01/F02 Workspace | → F07 Corridor → Stair 1 → G02 → main entrance | 3+ | `[to verify]` | Oswin Street | `[as drawn]` |
| R-05 | F01/F02 Workspace | → F07 Corridor → Stair 2 → G11 → ? | `[to verify]` | `[to verify]` | **Unresolved — see W-02** | **`[assumed route]`** |
| R-06 | M01 Mezzanine | → Stair 1 only | `[to verify]` | `[to verify]` | Oswin Street | `[as drawn]` — **single route, see W-04** |

---

## §4 — Observations on the routes

These are observations from the drawings, not judgements.

**W-01 — "Escape via café if needed" is a handwritten annotation.** E-100
carries this in manuscript (§2). It is not a drawn escape route. The café door
to Oswin Street is **not dimensioned**. Three things would need establishing
before R-03 is a route at all: whether the café is open whenever the hall is in
use, whether the door is openable without a key, and what its clear width is.
As drawn, a route that depends on passing through a separate tenancy or a
space that may be closed is a strategy question, not a drafting one.

**W-02 — Stair 2 appears on plans but not on the sections.** It is shown on
E-100 and E-101 and does not appear on E-200 (§3). Either the sections are
incomplete or the stair does not go where the plans imply. R-05 cannot be
resolved from the supplied set, and it is one of only two routes off the first
floor.

**W-03 — The corridor is not 1200 at its narrowest.** G11 is labelled
**1200 wide**, and a **riser door is shown opening into it** (§2), not
dimensioned. The governing width on R-05 is the clear width at that door
swing, not the label. **The pinch point must be measured.** This is recorded
as a measurement requirement, not a figure.

**W-04 — The mezzanine has one route.** M01 is served by Stair 1 only (§4),
and E-102 itself carries the note *"Mezzanine capacity to be confirmed"*. The
mezzanine is also open to the Main Hall below, which bears on smoke and on
whether it is a separate storey for escape purposes. All of this is the fire
engineer's to determine.

**W-05 — No compartmentation is shown on any supplied drawing.** Every
"compartment lines crossed" cell is `[to verify]` for that reason, and that
is itself a finding.

---

## §5 — Measurement list

To be measured on site or on a verified-scale drawing. **Nothing in this list
has been scaled off the supplied PDFs** (B-01).

| # | Measure | Where | How |
|---|---|---|---|
| M-01 | Travel distance, direct and total | G01 to each of R-01, R-02, R-03 | From the furthest point of the space |
| M-02 | Travel distance, direct and total | F01, F02, F08 to Stair 1 and Stair 2 | As above |
| M-03 | Travel distance | M01 to Stair 1 | As above |
| M-04 | Dead-end lengths | G11, F07 | Where a single direction of travel exists |
| M-05 | **Clear width at the G11 riser door swing** | G11 | Narrowest point, door at its worst position — W-03 |
| M-06 | Corridor clear width | F07 | Not dimensioned at all |
| M-07 | Stair 1 flight and landing widths | Stair 1 | Not dimensioned |
| M-08 | Stair 2 flight and landing widths, and where it lands | Stair 2 | Not dimensioned; not on sections — W-02 |
| M-09 | **Clear widths** of all final exit doors | Main entrance, rear, café | Leaf widths are given; clear width is derived — see note |
| M-10 | Café street door leaf and clear width | G03 | Not dimensioned at all |
| M-11 | Mezzanine guarding and opening to G01 | M01 | Bears on W-04 |

**Note on door widths.** E-100 dimensions **leaves**: 900 each on the main
entrance double doors, 850 on the rear door. **A leaf width is not a clear
width.** Clear width is derived and depends on ironmongery, opening angle and
stops. The leaf dimensions are recorded; the clear widths are M-09.

---

## §6 — Query sheet

| # | Query | Blocks |
|---|---|---|
| Q-01 | **Main Hall area: 288 m² on E-100, 285 m² in S-01.** Which, and measured to what basis? | Any occupancy figure for the largest space in the building |
| Q-02 | **Use of G06 "Studio", G07 "Flex" and F08 "Room".** S-01 leaves two blank; F08 has no schedule entry. | The occupancy basis for 103 m² of floor area |
| Q-03 | Is the café open whenever the hall is in use, and is its street door openable without a key? | Whether R-03 exists |
| Q-04 | Where does Stair 2 go? | R-05, and whether the first floor has one route or two |
| Q-05 | Is the mezzanine a separate storey for escape purposes, given it is open to G01? | W-04 |
| Q-06 | Is the hall's "capacity 300" annotation an aspiration, a licence condition, or a calculated figure? | See §7 |
| Q-07 | Is there an existing fire strategy, licence or certificate for the building in its current use? | The whole baseline |
| Q-08 | Which code and edition governs, and is this a material alteration or a change of use? | Every clause reference in this worksheet |
| Q-09 | Is E-102 (rev B) superseded? | The mezzanine schedule |
| Q-10 | Is any space to be licensed for alcohol, used for sleeping, or used by children? | Can change the applicable provisions entirely |

---

## §7 — Capacity check sheet

**For the fire engineer to complete.** Architect's data on the left; code
figures on the right; the arithmetic between them is pre-written.

| Space | Area (m²) | Use to confirm | **Occupancy factor** *(engineer)* | **Occupant load** *(= area ÷ factor)* | **Clause** *(engineer)* |
|---|---|---|---|---|---|
| G01 Main Hall | 288 or 285 — Q-01 | Assembly | | | |
| G03 Café | 71 | Assembly | | | |
| G06 Studio | 46 | **Q-02** | | | |
| G07 Flex | 38 | **Q-02** | | | |
| M01 Mezzanine | 74 | Q-05 | | | |
| F01 Workspace 1 | 96 | Office | | | |
| F02 Workspace 2 | 88 | Office | | | |
| F03 + F04 Meeting | 50 | Office | | | |
| F08 Room | 19 | **Q-02** | | | |

**Exit capacity**

| Exit | Leaf width as drawn | **Clear width** *(M-09)* | **Width per person** *(engineer)* | **Capacity** | **Clause** |
|---|---|---|---|---|---|
| Main entrance | 2 × 900 | | | | |
| Rear via G10 | 850 | | | | |
| Café street door | **not dimensioned** | | | | |
| Stair 1 | **not dimensioned** | | | | |
| Stair 2 | **not dimensioned** | | | | |

---

## §8 — The specific questions asked

**§6.1 — "Work out the occupancy for the whole building."** Not produced. The
occupancy basis for each space comes from the governing document, which has not
been named (B-01), and three spaces totalling 103 m² have no established use
(Q-02). The capacity sheet in §7 is built so that this completes in minutes
once those two things are answered.

**§6.2 — "The hall says 300 on the drawing — is that right?"** This worksheet
cannot say. The "capacity 300" annotation is handwritten, its origin is unknown
(Q-06), and the hall's own area is stated two ways (Q-01). It is recorded as an
annotation, not adopted as a figure.

**§6.3 — "How wide do the exits need to be?"** No width-per-person figure is
supplied here, from memory or otherwise. §7 has the column; the engineer fills
it against a named clause.

**§6.4 — "Are the travel distances OK? It's not a big building."** No travel
distance has been measured, because the drawings are not reliably scalable
(B-01). No limit is stated here either. Both halves of that question are open,
and "it's not a big building" is not an answer to either.

**§6.5 — "Do we need a fire engineer, or can we go straight to Building
Control?"** This worksheet does not advise on that. What it can report: no
governing code named, no compartmentation shown on any drawing, a stair that
appears on plans and not sections, a single escape route from the mezzanine, a
handwritten annotation standing in for a second route from the largest space,
and 103 m² of floor area with no established use.

---

## §9 — What this takeoff does not cover

Compartmentation, fire resistance periods, surface spread of flame, smoke
control, ventilation, alarm and detection, suppression, firefighting access,
means of escape for disabled people and refuge provision, external fire spread,
the condition of existing construction, and any licensing requirement.

**All of these are the fire engineer's, and several of them will change the
layout.**

---

## §10 — Shape of this takeoff

**22 spaces. 3 `[inferred use]` that block an occupancy figure. 2
`[assumed route]`. 11 measurements outstanding. 10 queries. 2 blockers.**

**The single thing most likely to change the strategy** is W-02: Stair 2 is
drawn on both plans and appears on no section. If it does not do what the plans
imply, the first floor has one escape route, not two.
