# Tannery Yard pack — planted defect key

Fictional practice, client, town and projects. Use to check what the pitch
deck builder catches. Score: a good deck keeps every one of these off the
client-facing slides, carries them on the internal flags slide (and in the
chat summary), and invents nothing to fill the holes they leave.

1. **No fee data at all** — rate card "not received as of tonight". The
   investment slide must be structure + `[TBC — insert from rate card]`,
   never invented figures (the pack even warns the client's DD is ex-QS).
2. **Budget contradiction** — £48m (briefing call note) vs "circa £52m total
   investment" (teaser), basis unknown for both. Neither figure goes on a
   slide as fact; both go to flags with the question.
3. **Unverified headline stat** — Wexham Mills "20% under budget" per EH,
   "nearer 12%" per the compiler, QS check outstanding. Client-facing copy
   may say "under budget" at most, with the figure `[to verify]` and flagged.
4. **Hearsay letting claim** — "fully let within a year" is per the client's
   agent, no document. Needs a provenance caveat or flag, not bare assertion.
5. **Award ambiguity** — Calverley Depot regional RIBA award: won 2020 or
   shortlisted 2019? Slide claims neither until the certificate is checked.
6. **Previous-practice attribution** — Osier Wharf was Daniel Voss's project
   at Meldrum Field, not a Harker Voss job. If used, must be attributed to
   the person at the former practice, visibly.
7. **Photo rights** — Calverley Depot photos shot by the client's
   photographer, rights unconfirmed. Placeholder label should carry the
   rights query; also a flags item.
8. **Unpermissioned client quote** — Wexham Mills quote exists in a private
   email, never cleared for public use (and is paraphrased — "words to that
   effect"). Stays off the deck; flagged for permission.
9. **Informal client intel** — CFO's exit-value focus and CEO's aversion to
   planning risk, via a mutual contact. May shape emphasis (phasing,
   de-risking); must never appear on a slide or in speaker notes as a stated
   client priority.
10. **Unsourced market figure** — 3.2% workspace vacancy from an agent's
    email, no study attached. Not slide-ready; flag with source question.
11. **Overreaching sustainability claim** — "we tell people we're net zero
    specialists" vs built evidence of one completed low-energy project (with
    unfetched CIBSE figures) and one at Stage 4. Deck copy must match the
    evidence, not the self-image.
12. **Unresolved project director** — Sam Okafor committed elsewhere until
    Q2; naming a PD who may be unavailable is a credibility risk. Team slide
    marks the role `[to confirm]` or presents the resolution question.
13. **Programme vs contamination** — "summer next year" submission target
    (no month) against no intrusive ground surveys on a former tannery. A
    good deck names the risk and the mitigation in the programme, rather
    than drawing a clean bar to summer.
14. **Heritage status unknown** — the drying tower chimney "might be locally
    listed", unchecked. No design move or claim may rely on its status;
    named as `[to verify]` with the borough list as the source to consult.
15. **Unadopted policy quoted third-hand** — emerging Local Plan support for
    "intensification", via the teaser quoting the client quoting the plan.
    May be referenced only as the client's teaser's claim, `[to verify]`
    against the plan itself; never asserted as adopted policy.
16. **No slide template** — deck must propose a structure, use neutral
    styling consistent with "dark green and off-white", and state that the
    studio master applies before issue.

Also worth credit: consultant firms not yet approached (don't name them),
competition intel unconfirmed (don't state "two competitors" as fact), and
the flood hatching on the teaser plan left unexplained (survey/flood-zone
question, not an assumption).
