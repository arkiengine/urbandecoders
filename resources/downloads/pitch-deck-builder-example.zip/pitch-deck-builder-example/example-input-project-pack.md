# Tannery Yard pitch — working pack (internal)

Compiled by RH, Thursday evening, from the briefing call note, the teaser
document and whatever I could pull together before the weekend. Pitch meeting
is in twelve days. This is raw — deck team please shape it.

---

## 1. The opportunity

**Site:** Tannery Yard, Elmsleigh — 1.9 ha former leather works between the
station approach and the river Cade. Main tannery sheds (1890s, brick, in
fair condition), the drying tower with the chimney, and a 1970s warehouse the
teaser calls "low quality". Site has been vacant since 2019.

**Client:** Bellard Group. Regional developer, privately held. In the room:
CEO (Douglas Bellard, second generation, said to be sentimental about the
town), CFO (Priya Nair), and their Development Director (Tom Osei, ex-QS,
runs the numbers hard). Decision is theirs — no panel, no scoring matrix as
far as we know.

**What they want (from the teaser + briefing call, 29 July):**

- Mixed-use: workspace, homes, food & drink, "a proper public space".
- Teaser talks about "a piece of town, not an estate".
- They want a practice for Stages 1–3 initially, with Stages 4+ "subject to
  performance and funding".
- Target: planning submission summer next year. (That's all we have — no
  month. Tom said "summer" on the call and moved on.)
- Budget: the briefing call note says **£48m**; the teaser document says
  **"circa £52m total investment"**. Not the same number and I don't know
  which is current or what either includes. Do not put a figure in front of
  Priya Nair that we can't defend.

**Competition:** we believe two others pitching — one large London practice,
one regional. Not confirmed.

**Intel (informal — handle carefully):** a mutual contact of MV's says the
CFO's main concern is exit value / fundability, and that Douglas B was burned
by a stalled scheme in 2016 and is allergic to planning risk. Useful for
tone. Obviously not something they've told us.

**Site issues from the teaser, in passing:**

- Contamination "as expected for the former use" — tanneries are nasty
  (chromium etc.). Teaser says desk study done, **no intrusive surveys yet**.
  That has to affect the summer submission target and we should say so
  rather than nod along.
- The drying tower chimney — I have it in my head that it's locally listed,
  or on some local heritage list. **Check before we claim or plan anything.**
  Couldn't find the borough list online in the ten minutes I had.
- Flood: riverside strip shown hatched on the teaser plan, no explanation
  given.

## 2. Practice profile — notes for "why us"

Harker Voss Architects. 22 people, studio in Northgate Mills. Founded 2011
by Eleanor Harker and Daniel Voss. Second studio (4 people) opened in
Marchfield last year.

- Strong on brick, industrial heritage, riverside sites. This is genuinely
  our patch.
- Sustainability: we tell people we're net zero specialists — honestly the
  built evidence is **one** completed low-energy project (Calverley Depot,
  CIBSE data first year looked good, ask DV for the actual figures) and the
  Fenn Street scheme still at Stage 4. Let's be careful how hard we push
  this.
- Awards: Calverley Depot — regional RIBA award **2019 — or was it
  shortlisted in 2019 and won 2020? EH and DV remember it differently.**
  Someone check the certificate in the meeting room before this goes on a
  slide.
- We are smaller than the London competitor. Turn that into an advantage
  (partner-led, one team start to finish) rather than apologising for it.

## 3. Project list (relevant ones)

| Project | Type | Size | Status | Notes for deck |
|---|---|---|---|---|
| Wexham Mills | Mill conversion — workspace + 14 flats | ~6,800 m² | Completed 2021 | Our best comparable. EH says "came in 20% under budget" — **I think it was nearer 12%, check with Corven & Piper (QS) before we print anything**. Fully let within a year (per the client's agent — no document). |
| Calverley Depot | Depot reuse — maker workspace | ~2,400 m² | Completed 2018 | The low-energy one. Award — see above. Photos: **shot by the client's photographer, we may not hold usage rights — check before they go in any deck.** |
| Fenn Street | Infill housing, 32 homes | — | Stage 4 | Decent story about planning in a conservation area, first time approval. |
| Osier Wharf | Riverside masterplan + Phase 1 | 3.1 ha | Phase 1 complete 2016 | **Careful: this was DV's project at his previous practice (Meldrum Field), not a Harker Voss job.** Great experience, wrong logo. If we use it, it has to say so. |
| Brantham Corn Exchange | F&B / events reuse | ~900 m² | Completed 2023 | Small but photogenic, we hold the photo rights. |

Occupier side: MV has a note from a local agent saying Elmsleigh town-centre
workspace vacancy is around **3.2%** and "demand comfortably outstrips
supply" — it's from an email, there's **no study attached**, and I wouldn't
put the number on a slide without asking where it came from.

## 4. Team (proposed)

- **Eleanor Harker** — practice principal, client lead. Available, will lead
  the pitch in person.
- **Daniel Voss** — design director. Osier Wharf experience (see caveat
  above), heritage-heavy portfolio.
- **Project director: we'd want Sam Okafor** — but Sam is committed on the
  Ridgeline job until **Q2 at the earliest**, and this client will expect a
  named PD from day one. Either we confirm Sam's release with the Ridgeline
  client or we name someone else. Unresolved.
- Landscape, structures, services: we'd bring our usual collaborators —
  nobody appointed, nobody asked yet. Don't name firms without asking them.

## 5. Fees

Nothing yet. Finance were going to send the current rate card and a stage
fee build-up for a comparable job — **not received as of tonight**. The deck
needs the investment/fee slide structured so numbers drop in later. Do NOT
let anything invent figures here; Tom Osei is ex-QS and will pull any number
apart.

## 6. Odds and ends

- A client quote exists from the Wexham Mills client ("they made the
  numbers work without killing the character" or words to that effect) — in
  an email to EH. **We have never asked permission to use it publicly.**
- Brand: deck should feel like us — dark green and off-white, the brand PDF
  is on the server somewhere. **No slide template attached** — whatever
  structure is proposed, note that our master gets applied before issue.
- Elmsleigh's emerging Local Plan supposedly supports "intensification of
  station-adjacent brownfield" — that's from the teaser, quoting the client
  quoting the plan. Nobody here has read the plan. Flag, don't assert.
- The teaser mentions Bellard "exploring phased delivery to manage funding"
  — that plus the CFO intel suggests phasing/cashflow should be a theme.
