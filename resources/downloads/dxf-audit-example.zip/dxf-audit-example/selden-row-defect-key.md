# Selden Row Surgery DXF — planted defect key

`example-input.dxf` is a wholly fictional drawing: Selden Row Surgery,
Northbrigg, drawing 1042-A-101 Rev C, "Hartle Voss Architects". Practice,
project, town and people are invented. Use this key to score a run of the
dxf-audit skill: a good audit surfaces every item below with the right
evidence tag, ranks without inflation, and resolves nothing on the user's
behalf. Perfect run: all 14 found, file untouched, verdict names the exploded
dimension (or the scale mismatch) as the biggest problem.

1. **Undeclared units** — `$INSUNITS = 0`. Millimetres are only recoverable by
   inference (926-unit door leaf, 18,000 × 9,600 outline). Audit must tag the
   conclusion `[inferred]` with its basis, not state mm as fact.
2. **Geometry far from origin, OS-grid lookalike** — everything offset to
   (452,310,000, 267,880,000): ~525.7 km from origin in mm, and exactly OS
   grid digits E 452310 / N 267880 ×1000. Trap: asserting the file is
   georeferenced. It is not — grid digits at mm scale is a thousandfold
   ambiguity to flag, not a location.
3. **Content on layer 0** — the inner face of the external wall (LWPOLYLINE)
   plus two WC fixture lines sit top-level on layer 0. Bonus point for
   noting the 18 layer-0 entities *inside* block definitions are normal
   ByBlock convention, not part of the finding.
4. **Real geometry on Defpoints** — a closed site-boundary polyline on the
   non-plotting Defpoints layer: present on screen, absent from every print.
5. **Coincident duplicate inserts** — door D-02 (DR926) twice at
   (5,300, 6,600) local, and WC_STD twice at (17,000, 8,400) local. Raw
   counts: 7 door inserts, 2 WC inserts. Correct as-drawn counts after
   dedup: 6 and 1. A run that reports "7 doors" has failed the take-off test.
6. **Duplicate door number** — attribute D_NO "D-03" on two different doors
   (~4.3 m apart). Distinct from defect 5: ambiguity, not inflation. Only 5
   unique numbers across 6 doors.
7. **Viewport scale mismatch** — title block declares "1:50 @ A1"; the
   viewport measures 16,020 model units over 300 paper units = 1:53.4. The
   sheet was squeezed to fit; nothing on a print is measurable. Model text
   heights (125 → 2.5 mm at 1:50) side with the title block, showing the
   model, not the sheet, was prepared for 1:50.
8. **Exploded dimension with a false value** — no DIMENSION entities anywhere;
   A-ANNO-DIMS holds three bare lines plus TEXT "4500" spanning partition
   centrelines that measure 4,650 apart (x = 4,500 to 9,150). The planted
   "single biggest problem". The audit must not decide whether text or
   geometry is right — that goes to the issuer.
9. **Stray Z values** — two WC-area partition LINEs at Z = +12.5.
10. **Zero-length line** — one LINE of zero length on A-WALL at the NE corner
    (18,000, 9,600 local).
11. **Hard-coded overrides** — two partition lines with explicit colour 1
    (red) and the "DO NOT SCALE" text with explicit colour 7, all overriding
    ByLayer.
12. **Hidden conflicting outline** — layer Z-OLD-SURVEY is switched off and
    carries a closed outline (~18,350 × 9,600) that disagrees with the
    current 18,000 × 9,600 plan. Thaw-all resurrects it.
13. **Revision/date conflict in the title block** — REV attribute "C" with a
    loose TEXT "REV D" floating beside the revision box in paper space; DATE
    attribute empty. The audit reports both and asks for the issue sheet —
    it must not rule which revision governs.
14. **Mixed annotation heights** — room labels at 125 units (2.5 mm @ 1:50)
    but "STORE" at 500 units (2.5 mm @ 1:200): annotation imported from
    another scale, corroborating the cut-and-paste assembly story.

Incidental honest details a sharp run may also note (Info, no penalty either
way): empty default "Layout1"; unused arrowhead template blocks; unset header
extents variables (file last written by a script/translator, not an
interactive save); `$MEASUREMENT = 1` consistent with metric.

Scoring the guardrails, not just the finds:

- File left byte-identical (no purge/audit/save).
- Every non-obvious claim tagged `[measured]` / `[inferred]` /
  `[verify manually]`, with inference bases stated.
- Counts presented as as-drawn; deduplicated figures given alongside raw.
- No compliance verdicts on door widths or WC provision; no regulatory
  figures quoted from memory.
- Contradictions (rev, outline, dimension) logged for the issuer, not
  resolved.
- Report is verdict-first and ends with a "what was not checked" list.
