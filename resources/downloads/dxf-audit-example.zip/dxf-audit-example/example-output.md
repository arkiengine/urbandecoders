# DXF audit — `example-input.dxf`

**Stated purpose (from user):** received from the outgoing architect; wanted as
a background for a Stage 3 Revit model, plus a door count for the schedule.
**Issued by / when:** user believes it is the latest issue from Hartle Voss
Architects; no transmittal available. **Xrefs travelling with it:** none
supplied.

Facts extracted read-only with `scripts/audit_dxf.py` (ezdxf). The source file
has not been modified, purged or re-saved.

---

## 1 · Verdict

**What this file is:** a ground-floor plan of Selden Row Surgery, Northbrigg,
drawing 1042-A-101, revision C, status S2 "For information", declared 1:50 @ A1
`[measured]` — drawn in millimetres `[inferred: 926-unit door leaf; 24,000-unit
model span]` on an arbitrary offset frame, not a georeferenced one (see §3).

**Usable as-is for:** visual reference and room-layout orientation; identifying
spaces and door positions.

**Not usable without the checks below:**

- **Do not take any dimension from the annotation.** The dimensions are
  exploded (dead text), and the one dimension string present reads **4500 over
  a measured 4,650 span** `[measured]` — a live false statement on the drawing.
- **Do not scale off the sheet.** The viewport plots at **1:53.4**, not the
  declared 1:50 `[measured]` — everything on a print is ~6.8% under size.
- **Do not link into Revit at these coordinates.** Geometry sits ~525,700 m
  from origin `[measured]` — far outside comfortable link range
  `[verify manually: current Autodesk guidance on link distance limits]`.
- **Do not use the raw door count.** 7 door inserts, of which one pair is
  coincident at the same point: **6 doors as-drawn**, and only 5 unique door
  numbers because D-03 is used twice `[measured]`.
- **Confirm the revision.** Title block says Rev C; a loose "REV D" text sits
  beside the revision box `[measured]`. This may not be the issued revision.

**Single biggest problem:** the exploded dimension that disagrees with the
geometry it spans. Everything else announces itself under inspection; a false
dimension looks exactly like a true one.

---

## 2 · Provenance and sheet identity

Title block (block `TB_A1`, layout "A1-101") `[measured]`:

| Field | Value |
|---|---|
| Practice | HARTLE VOSS ARCHITECTS |
| Project | SELDEN ROW SURGERY, NORTHBRIGG |
| Sheet | GROUND FLOOR PLAN - AS PROPOSED |
| Drawing no / Rev | 1042-A-101 / **C** |
| Scale | 1:50 @ A1 |
| Date | **(empty)** |
| Status | S2 - FOR INFORMATION |
| Drawn | JT |

Contradictions and gaps:

- Loose TEXT reading **"REV D"** at paper coordinates (770, 90), directly
  beside the revision box `[measured]`. Either an uncommitted revision bump or
  a leftover; the block attribute supports Rev C, but which governs is the
  issuing practice's call — **not resolved here**. `[verify manually: request
  the drawing issue sheet from Hartle Voss]`
- The DATE attribute is empty `[measured]`, so the file cannot be placed in an
  issue sequence from its own metadata.
- Status S2 is "for information" — not a coordination or construction status.
  Using it as a Stage 3 background is defensible; measuring from it is not.
- Header drawing-extents variables are unset sentinels `[measured]` — the file
  was not last saved by a typical interactive CAD session; consistent with a
  scripted or translated export. Provenance of the export is unknown.
  `[verify manually]`

## 3 · Geometry frame

**Units.** `$INSUNITS = 0` — units are **not declared** `[measured]`.
`$MEASUREMENT = 1` (metric linetypes) `[measured]`. Inference: the door block
leaf measures 926 units and the main outline spans 18,000 × 9,600 units —
consistent only with **millimetres** for a small building `[inferred]`. No
second unit hypothesis survives (metres would give an 18 km building).

**Scale — the three witnesses disagree:**

| Witness | Reading | Tag |
|---|---|---|
| Annotated (title block) | 1:50 @ A1 | `[measured]` |
| Viewport ratio | 16,020 model units ÷ 300 paper units = **1:53.4** | `[measured]` |
| Model text height | 125 units → 2.5 mm at 1:50 — supports 1:50 | `[inferred]` |

The annotation and text heights say the *model* was prepared for 1:50; the
viewport says the *sheet* was squeezed ~6.8% to fit the border. Conclusion:
the model geometry is plausibly true to size in mm; **the printed sheet is
not measurable at any stated scale** `[inferred]`. One text ("STORE") is 500
units high — it would plot at 10 mm; it was almost certainly copied in from a
1:200 drawing `[inferred]` and is further evidence of cut-and-paste assembly.

**Origin and coordinates.** Model centroid sits at (452,319,500,
267,884,750), i.e. **~525,700,000 drawing units from origin** — ~525.7 km in
real terms if the units are mm `[measured]`. Divided by 1,000 the digits
give E 452,310 / N 267,880 — a plausible Great Britain OS grid position
`[inferred]`. But the drawing's units are mm, so the file is **not**
georeferenced in its own frame: it carries OS-grid *digits* at a thousandth
of OS-grid *scale*. Treat the location as unconfirmed
`[verify manually: check one known point against a survey or OS base]`.
The offset alone is enough to degrade snapping and to misbehave as a direct
Revit link or Rhino import.

## 4 · Layer structure

11 layers; counts are top-level model-space entities `[measured]`:

| Layer | State | MS entities | Note |
|---|---|---|---|
| 0 | on, plots | **3** | inner wall outline + 2 WC fixture lines — real content on layer 0 |
| A-ANNO-DIMS | on | 4 | 3 lines + 1 text; **zero DIMENSION entities** — exploded |
| A-ANNO-TEXT | on | 8 | room labels + note |
| A-DOOR | on | 7 | door inserts (see §5) |
| A-GLAZ | on | 4 | window inserts |
| A-SANR | on | 2 | 2 inserts, 1 position (coincident pair) |
| A-WALL | on | 2 | outer outline + 1 zero-length line |
| A-WALL-PART | on | 7 | partitions; 2 carry stray Z, 2 carry colour overrides |
| Defpoints | on, **non-plotting** | 1 | a boundary polyline that will vanish from every print |
| TITLE | on | 0 (2 in paper space) | title block + loose REV D text |
| Z-OLD-SURVEY | **off** | 1 | a second, larger outline (~18,350 × 9,600) hidden from view |

Layer findings:

- The **inner face of the external wall lives on layer 0** `[measured]` — it
  obeys no layer discipline and survives every filter; anyone freezing "walls"
  keeps half a wall. (The 18 layer-0 entities *inside block definitions* are
  normal ByBlock convention — no action.)
- **Z-OLD-SURVEY is switched off and contains a conflicting outline**
  `[measured]`. Whether it is a superseded survey or an alternative extent is
  not determinable from the file `[verify manually with issuer]` — but any
  thaw-all operation resurrects it on top of the current plan.
- A closed polyline — apparently a site/curtilage boundary — sits on
  **Defpoints**, which never plots `[measured]`. If that boundary matters, it
  is currently invisible on paper.

## 5 · Blocks and annotation integrity

Block definitions and as-drawn insert counts `[measured]`:

| Block | Attribute tags | Inserts | Note |
|---|---|---|---|
| DR926 | D_NO | 7 | 926 mm leaf + swing |
| WIN1200 | — | 4 | |
| WC_STD | — | 2 | both at one point |
| TB_A1 | 9 tags | 1 | title block, paper space |
| _ARCHTICK etc. | — | 0 | unused template stock — info only |

- **Coincident duplicates:** DR926 ×2 at (452,315,300, 267,886,600) rot 180 —
  the two copies of door D-02 — and WC_STD ×2 at (452,327,000, 267,888,400)
  `[measured]`. On screen each pair reads as one object; in any take-off it
  counts as two.
- **Duplicate door number:** D_NO "D-03" appears on two different doors ~4.3 m
  apart `[measured]`. Distinct defect from the coincident pair: this one makes
  the door schedule ambiguous rather than inflated.
- **Exploded dimensions:** 0 DIMENSION entities in the file; the dimension
  layer holds 3 bare lines and the numeric text "4500" `[measured]`. The text
  sits over the Consult 1 partition span, which measures **4,650 units**
  centre-to-centre of the drawn partition lines `[measured]`. The annotation
  is wrong by 150 mm, or the partitions are — the file cannot say which.
  `[verify manually against the issued, un-exploded original or a site check]`
- **Overrides:** 2 partition lines carry hard-coded colour 1 (red) and one
  text carries explicit colour 7 `[measured]` — plot-style behaviour will not
  follow the layer. Low impact, worth cleaning on re-issue.
- **Hygiene:** one zero-length LINE on A-WALL at the NE corner; two partition
  lines at **Z = +12.5** `[measured]` — flat drawing otherwise; the stray Z
  will snag 3D snapping and some area routines.

## 6 · Extractable data (as-drawn, not as-built)

Door schedule from D_NO attributes `[measured]`; positions in local mm after
subtracting the (452,310,000, 267,880,000) offset for readability:

| D_NO | Local position (x, y) | Rotation | Flag |
|---|---|---|---|
| D-01 | 2,200, 300 | 0° | |
| D-02 | 5,300, 6,600 | 180° | **coincident duplicate — 2 inserts, count once** |
| D-03 | 10,000, 6,600 | 180° | **number shared with the door below** |
| D-03 | 14,300, 6,600 | 180° | **number shared with the door above** |
| D-04 | 15,600, 7,400 | 90° | |
| D-05 | 900, 6,600 | 180° | |

**Counts:** 7 inserts → **6 doors as-drawn** after deduplication → **5 unique
door numbers** `[measured]`. Windows: 4 × WIN1200 as-drawn, no attributes to
schedule. Sanitary: 2 × WC_STD inserts at one position → **1 as-drawn**
`[measured]`.

## 7 · Cleanup and reuse steps — for your stated purpose (Revit background + door count)

Perform on a **copy**; keep the received file untouched as the evidence copy.

1. Resolve the revision question with Hartle Voss before any modelling — Rev C
   vs the loose "REV D" text (§2).
2. In the copy: move geometry to a sensible local origin (note the applied
   offset in the file and in your Revit shared-coordinates record; the digits
   ÷1000 may be the intended OS position — confirm with the issuer first).
3. Set units explicitly to millimetres before export/link, since the header
   declares none.
4. Delete or quarantine Z-OLD-SURVEY content; move the Defpoints boundary to a
   named, plotting layer if it matters.
5. Reassign the layer-0 wall line and WC fixtures to their proper layers;
   erase the coincident duplicates (door D-02 pair, WC pair) and the
   zero-length line; flatten the two Z=12.5 lines to Z=0.
6. Strip or ignore all exploded dimension text — treat the model geometry, not
   the annotation, as the measurement source, and verify the 4,500/4,650
   discrepancy with the issuer before modelling Consult 1.
7. For the door schedule, use the deduplicated count (6) and ask the issuer to
   re-number the second D-03 before their numbers enter your schedule.
8. Do not use the sheet layout for anything; if you need a 1:50 print, make a
   new viewport at a true 1:50.

## 8 · Ranked risk table

| # | Severity | Finding | Breaks downstream | Action |
|---|---|---|---|---|
| 1 | **High** | Exploded dimension "4500" over measured 4,650 span | False figure priced/built from | Verify with issuer; measure from geometry only |
| 2 | **High** | Viewport 1:53.4 vs declared 1:50 | Anything scaled off a print is ~6.8% small | Never scale the sheet; re-viewport on the copy |
| 3 | **High** | Coincident duplicates (door D-02 ×2, WC ×2) | Take-off and schedule double-count | Deduplicate on the copy; use counts in §6 |
| 4 | **High** | Units undeclared ($INSUNITS = 0) | Wrong import assumption in Revit/Rhino | Set mm explicitly (inference basis: 926 door leaf) |
| 5 | **Medium** | Geometry ~525.7 km from origin; OS-lookalike digits in mm | Link/snap failures; false georeferencing confidence | Re-origin the copy; confirm grid position with issuer |
| 6 | **Medium** | Revision conflict: attribute Rev C vs loose "REV D" text | Working to a superseded issue | Confirm against issue sheet |
| 7 | **Medium** | Duplicate door number D-03 on two doors | Ambiguous schedule cross-references | Issuer to renumber |
| 8 | **Medium** | Hidden Z-OLD-SURVEY layer with conflicting outline | Wrong outline resurfaces on thaw-all | Quarantine on the copy; ask issuer what it is |
| 9 | **Medium** | Boundary polyline on non-plotting Defpoints | Boundary silently absent from prints | Move to a plotting layer if required |
| 10 | **Low** | Wall line + fixtures on layer 0 | Uncontrollable visibility/plot styling | Reassign layers on the copy |
| 11 | **Low** | Colour overrides (2 lines, 1 text); zero-length line; stray Z = 12.5 ×2 | Plot-style noise, snap noise, 3D artefacts | Clean on the copy |
| 12 | **Info** | Empty DATE attribute; unset header extents; empty "Layout1"; unused template blocks; 500-high "STORE" text (1:200 origin) | Evidence of assembly history, nothing to fix directly | Note for the record |

## 9 · What was not checked

- Whether Rev C is in fact the current issue — no issue sheet or transmittal
  was provided.
- The drawing's position against any survey, OS base or legal boundary; no
  control point was available.
- Dimensional accuracy of the geometry itself against the building or an
  issued original — only internal consistency was tested.
- Compliance of any drawn element with Building Regulations or standards
  (door widths, corridor clearances, WC provision) — out of scope for this
  audit; measurements in §6 are as-drawn inputs to those checks, not verdicts.
- Hatches, linetype definitions, plot-style tables and fonts — not examined
  beyond override counts.
- Any content of external references — none were supplied, and the file
  declares none `[measured]`, but a DXF export can silently strip xref
  attachments, so absence here is not proof the original had none.

*This audit reports the state of the file; whether the drawing is acceptable
for your purpose is your decision. The source file was not modified.*
