# Halden Wharf brief — planted defect key
Fictional client, borough and site. Use to check what the intake skill catches.
Score: a good run surfaces all of these as queries/conflicts without resolving them.

1. **Unit count contradiction** — body text s3.1 says "approximately 480 homes";
   Appendix A totals 520 (365 + 155); the site allocation (s7.0, Policy HW1)
   says "approximately 400". Three different numbers, none reconciled.
2. **Affordable % mismatch** — s3.1 states 35% by habitable room; Appendix A's
   155/520 is ~30% by unit. Different metrics, silently conflated.
3. **Mixed units** — workspace is 8,000 sqm in s3.2 but 86,000 sq ft in
   Appendix A (= ~7,990 sqm — close but not equal, and basis unstated).
4. **Area basis absent** — retail "basis to be confirmed"; residential areas
   never stated at all; only the printworks gets a GIA label.
5. **Aspirations dressed as requirements** — "destination people travel to",
   "authentic and characterful from day one", "exemplar", "real elegance".
6. **Precedents without attributes** — Kings Cross, Coal Drops Yard, New
   Islington cited with no statement of which qualities are binding.
7. **Undefined performance targets** — "net zero carbon" with no
   operational/embodied scope or definition; "benchmarked against best
   practice" with no benchmark named; timber "where appropriate".
8. **Referenced-but-absent documents** — site plan (Appendix C) and Planning
   Constraints Note (Appendix D) both "issued separately"; Borough policy
   documents cited but not attached.
9. **Budget scope ambiguity** — £310m "total development cost" vs £85m Phase 1
   "construction budget"; fees/VAT/contingency inclusion unstated; no cost/sqm
   derivable without areas.
10. **Height ambiguity** — "up to 14 storeys" attributed to an *emerging*
    (unadopted) Local Plan review; taller marker "may be appropriate" — is the
    14-storey figure a constraint or an opportunity?
11. **Statutory checks flagged but unresolved** — locally listed printworks,
    conservation area across the canal, Flood Zone 2, contamination with no
    intrusive surveys, GLA referability, railway-owned arches, third-party
    land for the bridge.
12. **Informal officer support treated as fact** — "indicated informally that
    a higher quantum may be acceptable" is not a planning position.
13. **Internal tension** — car-free scheme vs "destination people travel to";
    35% affordable "subject to viability" vs independently viable phases;
    majority of family homes with private amenity vs 14-storey western end.
14. **Nursery** — "60 place" with no area, operator or delivery mechanism.
15. **UGF 0.4 vs 0.8 ha open space vs 520 homes on 2.8 ha** — an envelope
    tension worth arithmetic, not assumption.
