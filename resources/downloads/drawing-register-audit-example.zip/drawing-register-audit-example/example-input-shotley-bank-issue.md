# Shotley Bank — tender issue, register and folder listing

**Project:** Shotley Bank, Marlden — 36 dwellings
**Issue purpose as stated on the transmittal:** "Issue for Tender"
**Transmittal date:** 24 February 2026
**Issued by:** Vale & Hartnoll Architects

*Fictional project and practice. Deliberately imperfect.*

---

## §1 — Drawing register, as issued

| # | Drawing no. | Title | Rev | Status | Date |
|---|---|---|---|---|---|
| 1 | VH-SB-ZZ-00-DR-A-1000 | Site location plan | C | S4 | 18.02.26 |
| 2 | VH-SB-ZZ-00-DR-A-1001 | Proposed site plan | D | S4 | 20.02.26 |
| 3 | VH-SB-ZZ-00-DR-A-1100 | Ground floor plan | E | S4 | 20.02.26 |
| 4 | VH-SB-ZZ-01-DR-A-1101 | First floor plan | E | S4 | 20.02.26 |
| 5 | VH-SB-ZZ-02-DR-A-1102 | Second floor plan | D | S4 | 11.02.26 |
| 6 | VH-SB-ZZ-RF-DR-A-1103 | Roof plan | C | S4 | 11.02.26 |
| 7 | VH-SB-ZZ-XX-DR-A-1200 | Elevations — north and east | D | S4 | 20.02.26 |
| 8 | VH-SB-ZZ-XX-DR-A-1201 | Elevations — south and west | D | S4 | 20.02.26 |
| 9 | VH-SB-ZZ-XX-DR-A-1300 | Sections AA–CC | C | S4 | 18.02.26 |
| 10 | VH-SB-ZZ-XX-DR-A-1301 | Section DD | B | **S2** | 04.02.26 |
| 11 | VH-SB-ZZ-XX-DR-A-1400 | Window schedule | B | S4 | 18.02.26 |
| 12 | VH-SB-ZZ-XX-DR-A-1401 | Door schedule | C | S4 | 20.02.26 |
| 13 | VH-SB-ZZ-XX-DR-A-1500 | Typical details sheet 1 | B | S4 | 11.02.26 |
| 14 | VH-SB-ZZ-XX-DR-A-1502 | Typical details sheet 3 | A | S4 | 24.02.26 |
| 15 | VH-SB-ZZ-XX-DR-A-1600 | External works | B | **S0** | 02.02.26 |
| 16 | VH-SB-ZZ-00-DR-A-1700 | Plot 1–6 layouts | C | S4 | 20.02.26 |
| 17 | VH-SB-ZZ-00-DR-A-1701 | Plot 7–12 layouts | C | S4 | 20.02.26 |
| 18 | VH-SB-ZZ-00-DR-A-1702 | Plot 13–18 layouts | **B** | S4 | **26.02.26** |

---

## §2 — Folder listing, as transmitted

```
VH-SB-ZZ-00-DR-A-1000_RevC.pdf
VH-SB-ZZ-00-DR-A-1001_RevD.pdf
VH-SB-ZZ-ZZ-00-DR-A-1100_RevE.pdf
VH-SB-ZZ-01-DR-A-1101_RevE.pdf
VH-SB-ZZ-02-DR-A-1102_RevD.pdf
VH-SB-ZZ-RF-DR-A-1103_RevC.pdf
VH-SB-ZZ-XX-DR-A-1200_RevD.pdf
VH-SB-ZZ-XX-DR-A-1201_RevC.pdf
VH-SB-ZZ-XX-DR-A-1300_RevC.pdf
VH-SB-ZZ-XX-DR-A-1301_RevB.pdf
VH-SB-ZZ-XX-DR-A-1400_RevB.pdf
VH-SB-ZZ-XX-DR-A-1401_RevC.pdf
VH-SB-ZZ-XX-DR-A-1500_RevB.pdf
VH-SB-ZZ-XX-DR-A-1501_RevA.pdf
VH-SB-ZZ-XX-DR-A-1502_RevA.pdf
VH-SB-ZZ-XX-DR-A-1600_RevB.pdf
VH-SB-ZZ-00-DR-A-1700_RevC.pdf
VH-SB-ZZ-00-DR-A-1701_RevC.pdf
VH-SB-ZZ-00-DR-A-1702_RevA.pdf
VH-SB-ZZ-00-DR-A-1702_RevB.pdf
VH-SB-ZZ-XX-DR-A-1401_RevB.pdf
```

---

## §3 — Title block readings

| Drawing no. in title block | Title | Rev | Status | Date |
|---|---|---|---|---|
| VH-SB-ZZ-00-DR-A-1000 | Site location plan | C | S4 | 18.02.26 |
| VH-SB-ZZ-00-DR-A-1001 | Proposed site plan | D | S4 | 20.02.26 |
| VH-SB-ZZ-00-DR-A-1100 | Ground floor plan | E | S4 | 20.02.26 |
| VH-SB-ZZ-01-DR-A-1101 | First floor plan | **D** | S4 | **11.02.26** |
| VH-SB-ZZ-02-DR-A-1102 | Second floor plan | D | S4 | 11.02.26 |
| VH-SB-ZZ-RF-DR-A-1103 | Roof plan | C | S4 | 11.02.26 |
| VH-SB-ZZ-XX-DR-A-1200 | Elevations — north and east | D | S4 | 20.02.26 |
| VH-SB-ZZ-XX-DR-A-1201 | Elevations — south and west | **C** | S4 | **18.02.26** |
| VH-SB-ZZ-XX-DR-A-1300 | Sections AA–CC | C | S4 | 18.02.26 |
| VH-SB-ZZ-XX-DR-A-1301 | Section DD | B | S2 | 04.02.26 |
| VH-SB-ZZ-XX-DR-A-1400 | Window schedule | B | S4 | 18.02.26 |
| VH-SB-ZZ-XX-DR-A-1401 | Door schedule | C | S4 | 20.02.26 |
| VH-SB-ZZ-XX-DR-A-1500 | Typical details sheet 1 | B | S4 | 11.02.26 |
| VH-SB-ZZ-XX-DR-A-1501 | **Typical details sheet 2** | A | S4 | 11.02.26 |
| VH-SB-ZZ-XX-DR-A-1502 | Typical details sheet 3 | A | S4 | 24.02.26 |
| VH-SB-ZZ-XX-DR-A-1600 | External works | B | S0 | 02.02.26 |
| VH-SB-ZZ-00-DR-A-1700 | Plot 1–6 layouts | C | S4 | 20.02.26 |
| VH-SB-ZZ-00-DR-A-1701 | Plot 7–12 layouts | C | S4 | 20.02.26 |
| VH-SB-ZZ-00-DR-A-1702 | Plot 13–18 layouts | A | S4 | 20.02.26 |
| VH-SB-ZZ-00-DR-A-1702 | Plot 13–18 layouts | B | S4 | 26.02.26 |
| VH-SB-ZZ-XX-DR-A-1401 | Door schedule | B | S4 | 18.02.26 |

---

## §4 — Notes supplied with the transmittal

- "Suitability codes per our standard. S4 = suitable for construction, S2 =
  suitable for information, S0 = work in progress." *(This definition appears
  only in this transmittal note, not in any project information protocol.)*
- "Structural and MEP packages issued separately by others."
- Drawing 1501 was created on 11.02.26. There is no entry for it on the
  register.
- 1502 was issued at Rev A on 24.02.26.

---

## §5 — What the project architect has asked for

1. "Audit the register before this goes to the contractors."
2. "Is the set complete?"
3. "We had a claim last job on a superseded sheet. Check for that."
4. "Can we just fix the register and send it?"
