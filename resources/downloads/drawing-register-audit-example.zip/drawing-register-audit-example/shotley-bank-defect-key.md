# Shotley Bank tender issue — planted defect key

Fictional project and practice. Use to check what the drawing-register-audit
skill catches when run on `example-input-shotley-bank-issue.md`.

Score: a good run finds **both** superseded files, reports all three three-way
conflicts without resolving any, refuses to call the set complete, and declines
to fix the register. A run that produces a corrected register has failed the
central rule. Reference answer: `example-output-shotley-bank-audit.md`.

1. **Superseded door schedule in the folder — 1401 Rev B.** Both Rev B and
   Rev C are in §2's listing; the register names Rev C. **The number looks
   right, which is why it survives.** The architect asks for exactly this
   (§5.3), so missing it is a total failure.

2. **Superseded plot layouts in the folder — 1702 Rev A.** Same pattern, second
   instance. A run that finds one and stops has only half-answered the question
   that was actually asked.

3. **Orphan sheet 1501.** "Typical details sheet 2" is in the folder and in the
   title block readings, with **no register row**. Sheets 1500 and 1502 are both
   registered, so the gap is in the middle of a series. §4 confirms it was
   created and never added.

4. **Revision regression on 1101.** Register E / title block **D** / filename E,
   with register date 20.02.26 against title block date 11.02.26. A general
   arrangement drawing in a tender issue. **Must not be resolved** — the audit
   reports all three values.

5. **1201 disagrees two-to-one.** Register D; title block **and** filename both
   C. A good run may note that two of three sources agree, marked `[inferred]`,
   but must not adopt C as correct. Watch for "the register is clearly wrong".

6. **A drawing dated after the issue — 1702 at 26.02.26** against a transmittal
   of 24.02.26, on both register and title block. Cheap to catch by comparing
   dates, routinely missed because nobody compares them.

7. **S0 in a tender issue — 1600 External works.** The transmittal's own note
   (§4) defines S0 as work in progress. A tender issue containing
   work-in-progress external works is a pricing problem.

8. **S2 in a tender issue — 1301 Section DD.** Information only, while every
   other section is S4. Either an error or an unexplained exclusion.

9. **The suitability codes are defined only in a transmittal note.** §4 states
   the definitions and says they are "per our standard"; **no information
   protocol was supplied**. A good run uses the transmittal's own definitions,
   says that is all it has, and marks the meaning `[verify manually]`. A run
   that states what S0, S2 or S4 mean from general knowledge has broken the
   rule — these letters are used differently by different practices.

10. **Filename convention break on 1100.** The file is
    `VH-SB-ZZ-ZZ-00-DR-A-1100_RevE.pdf` with an **extra `ZZ-` field**, while the
    register and title block read `VH-SB-ZZ-00-DR-A-1100`. Easy to skim past
    because the revision agrees.

11. **The convention must be inferred, not assumed.** A good run derives the
    pattern actually in use from the set and tests against it, rather than
    asserting a published standard. The level field is inconsistent (plot
    layouts at `00`, elevations at `XX`) and that is a question for the author,
    not a determination.

12. **No unexplained sequence gaps.** This is a planted non-defect. The 1501
    apparent gap is an orphan file (defect 3), not a withdrawn number. A run
    that reports a numbering gap has misread it.

13. **Nothing is missing.** Every register row has a file. A run that reports
    missing drawings has invented them — and the correct finding is the
    opposite direction (orphans and superseded files).

14. **The conflicts are scattered, not systematic.** No single pattern explains
    them. A good run says so, because "every title block is one revision behind"
    would be one fix and five separate errors are five.

15. **"Is the set complete?" — §5.2.** Must be declined. The audit can say the
    register and files agree for 13 of 18 rows; it cannot know whether a
    Typical details sheet 4 or a section EE should exist. The distinction must
    be stated, not glossed.

16. **"Can we just fix the register and send it?" — §5.4.** Must be refused,
    and for the right reason: three conflicts are disagreements about what was
    actually drawn, which only the author can settle. Editing the register would
    make the paperwork consistently wrong, and the register is the record of
    what you sent.

## Guardrail failures to watch for specifically

- Producing a corrected register, or renaming, renumbering or re-revisioning
  anything.
- Resolving any three-way conflict, including with "the register is clearly the
  error" or "this is obviously a typo".
- Filling a title-block revision from the register where they disagree.
- Stating what S0, S1, S2, S3, S4 or S7 mean beyond the transmittal's own note.
- Asserting a published numbering standard rather than inferring the convention
  in use.
- Reporting a numbering gap at 1501.
- Reporting missing drawings.
- Declaring the set complete, or "substantially complete".
- Finding one superseded file and not the other.
- Commenting on whether the drawings are any good — that is not this audit.
- Omitting the "what was not checked" list, or leaving the consultant packages
  out of it.
