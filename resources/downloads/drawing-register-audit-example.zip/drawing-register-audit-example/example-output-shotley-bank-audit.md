# Shotley Bank tender issue — register audit

**Audited:** 24 February 2026. **Issue purpose as stated: "Issue for Tender".**
Findings are ranked against that purpose.

---

## §1 — Verdict

**Do not issue.**

The single biggest problem: **two superseded files are in the issue folder** —
`VH-SB-ZZ-XX-DR-A-1401_RevB.pdf` (door schedule, superseded by Rev C, which is
also present) and `VH-SB-ZZ-00-DR-A-1702_RevA.pdf` (superseded by Rev B). A
contractor who opens the Rev B door schedule is pricing a superseded document
that you sent them, and the issue sheet is the evidence. This is exactly the
failure the architect describes having had on the last project (§5.3).

Beyond that: a drawing is issued with a **work-in-progress status** in a tender
issue, another at **information only**, one sheet is **present but not on the
register at all**, one register row is **dated two days after the issue**, and
**three title blocks disagree with the register** — one of them a revision
regression.

---

## §2 — Reconciliation

Three sources that should agree: register, title block, filename.

| Drawing | Register | Title block | Filename | Status |
|---|---|---|---|---|
| 1000 | C | C | C | agrees |
| 1001 | D | D | D | agrees |
| 1100 | E | E | E | agrees — **but see F-01 on the filename** |
| **1101** | **E** | **D** | **E** | **conflict** |
| 1102 | D | D | D | agrees |
| 1103 | C | C | C | agrees |
| 1200 | D | D | D | agrees |
| **1201** | **D** | **C** | **C** | **conflict** |
| 1300 | C | C | C | agrees |
| 1301 | B | B | B | agrees |
| 1400 | B | B | B | agrees |
| **1401** | **C** | **C and B** | **C and B** | **conflict — two revisions present** |
| 1500 | B | B | B | agrees |
| **1501** | **not on register** | A | A | **orphan** |
| 1502 | A | A | A | agrees |
| 1600 | B | B | B | agrees |
| 1700 | C | C | C | agrees |
| 1701 | C | C | C | agrees |
| **1702** | **B** | **A and B** | **A and B** | **conflict — two revisions present** |

**13 of 18 register rows agree across all three sources. Five do not.** The
disagreements are **scattered, not systematic** — there is no single pattern
such as "all title blocks one revision behind", so each is its own error rather
than one export problem.

---

## §3 — Missing, orphan and superseded

**H-01 — Superseded file in the issue: door schedule 1401.** Both
`_RevB.pdf` and `_RevC.pdf` are in the folder. The register lists Rev C. Rev B
is dated 18.02.26, Rev C is dated 20.02.26, and the Rev B title block confirms
it is the earlier revision. **The number looks right, so nobody checks.**

**H-02 — Superseded file in the issue: plot layouts 1702.** Both `_RevA.pdf`
and `_RevB.pdf` are in the folder. The register lists Rev B.

**H-03 — Orphan sheet: 1501, "Typical details sheet 2".** The file is in the
folder and the title block reads Rev A, 11.02.26. **There is no register entry
for it.** A detail sheet issued without a register entry has no contractual
status, and the sheets either side of it (1500 and 1502) are both on the
register — so a contractor sees sheets 1 and 3 listed and sheet 2 only in the
folder. §4 of the transmittal confirms it was created on 11.02.26 and simply
never added.

**No register row is without a file.** Nothing listed is missing.

---

## §4 — Revision integrity

**H-04 — Revision regression on 1101, first floor plan.** The register says
Rev E dated 20.02.26; **the title block says Rev D dated 11.02.26**; the
filename says Rev E. Either the file is Rev D mislabelled as E, or a Rev E was
produced and the title block was never updated. **The audit does not choose.**
Both values are recorded. This is the most consequential of the three
conflicts: it is a general arrangement drawing in a tender issue, and the
contractor will build from whichever reading they take.

**H-05 — 1201, south and west elevations.** Register says Rev D (20.02.26);
title block **and** filename both say Rev C (18.02.26). Two of three sources
agree on C, which makes the register the likely error — **but that is an
inference and the audit does not resolve it.** `[inferred]`

**M-01 — 1401 and 1702 each carry two revisions in the folder.** See H-01,
H-02. In both cases the register names the later one.

---

## §5 — Numbering and convention

**Convention inferred from the set** `[inferred]`:
`VH-SB-ZZ-<level>-DR-A-<number>`, where level is `00`, `01`, `02`, `RF` or
`XX`, and the number block runs in series by drawing type.

| Series | Numbers present | Gaps |
|---|---|---|
| 1000 | 1000, 1001 | — |
| 1100 | 1100, 1101, 1102, 1103 | — |
| 1200 | 1200, 1201 | — |
| 1300 | 1300, 1301 | — |
| 1400 | 1400, 1401 | — |
| 1500 | 1500, 1501, 1502 | — **1501 present, unregistered (H-03)** |
| 1600 | 1600 | — |
| 1700 | 1700, 1701, 1702 | — |

**No unexplained sequence gaps.** The only apparent gap — 1501 missing from the
register — is an orphan file, not a withdrawn number (H-03).

**M-02 — Filename departs from the convention on 1100.** The file is
`VH-SB-ZZ-ZZ-00-DR-A-1100_RevE.pdf`, with **an extra `ZZ-` field**. The
register and title block both read `VH-SB-ZZ-00-DR-A-1100`. The content is not
in question; the filename is wrong and will sort and search inconsistently.

**M-03 — Level field is inconsistent across the set.** Plot layout drawings
1700–1702 carry level `00`, but show plots across all levels; 1102 carries `02`
while 1200/1201 carry `XX`. Whether `00` is correct for the plot layouts is a
question for the author. `[verify manually]`

---

## §6 — Status and suitability

**The suitability codes are defined only in the transmittal note** (§4):
S4 = suitable for construction, S2 = suitable for information, S0 = work in
progress. **No project information protocol was supplied.** Different practices
and different protocols use the same letters differently, and this audit does
not state what any code means beyond what the transmittal itself says.
`[verify manually]`

Against the stated issue purpose — **Issue for Tender** — and the transmittal's
own definitions:

**H-06 — 1600 External works is issued at S0, "work in progress".** In a tender
issue. A contractor cannot price work-in-progress external works, and if they
price it anyway they will price it defensively.

**H-07 — 1301 Section DD is issued at S2, "suitable for information".** Every
other section (1300) is S4. A single section at information-only status in a
tender set is either an error or a deliberate exclusion that the transmittal
does not explain.

Sixteen of eighteen registered drawings are S4.

---

## §7 — Dates

**H-08 — Drawing 1702 is dated 26.02.26 on both the register and the title
block. The transmittal is dated 24.02.26.** A drawing in the issue is dated two
days after the issue itself. One of the two dates is wrong, and the audit does
not determine which.

Other date observations:

- 1401 Rev B (18.02.26) and Rev C (20.02.26) — consistent with Rev C
  superseding Rev B (H-01).
- 1101 register date 20.02.26 against title block 11.02.26 — part of H-04.
- 1201 register date 20.02.26 against title block and filename 18.02.26 —
  part of H-05.
- 1502 is dated 24.02.26, the day of the transmittal, at Rev A. A first-issue
  detail sheet produced on the day of a tender issue is worth a second look,
  though nothing in the audit makes it a defect.

---

## §8 — Ranked findings

**High — do not issue until resolved**

| # | Finding | What it breaks |
|---|---|---|
| H-01 | Superseded door schedule Rev B in the issue folder | Contractor may price a superseded schedule you sent them |
| H-02 | Superseded plot layouts Rev A in the issue folder | As above |
| H-04 | 1101 revision regression: register E, title block D | GA drawing; contractor builds from whichever they read |
| H-03 | Detail sheet 1501 present but not on the register | A detail sheet with no contractual status |
| H-06 | External works issued S0, work in progress, in a tender issue | Unpriceable or defensively priced |
| H-08 | 1702 dated two days after the transmittal | Dates the issue cannot be relied on |
| H-05 | 1201 register says D, title block and filename say C | Elevations; which revision was tendered |
| H-07 | Section DD issued S2 in a tender issue | Unexplained exclusion from the priced set |

**Medium**

| # | Finding |
|---|---|
| M-01 | Two revisions of 1401 and of 1702 present in one folder |
| M-02 | Filename for 1100 carries an extra field |
| M-03 | Level field inconsistent on plot layouts |
| M-04 | Suitability codes defined only in a transmittal note, not a protocol |

**Info**

| # | Finding |
|---|---|
| I-01 | 1502 first-issued on the day of the tender issue |
| I-02 | Structural and MEP packages issued separately (§4) — outside this audit |

---

## §9 — The specific questions asked

**§5.2 — "Is the set complete?"** This audit cannot say. It can say that the
register and the files agree for 13 of 18 rows, that one file is unregistered,
and that no register row lacks a file. **Completeness is measured against a
drawing list produced by someone with design knowledge of what this project
needs** — this audit has no such list and does not know, for example, whether
there should be a Typical details sheet 4, or sections EE and FF, or a separate
roof detail sheet. That is a much smaller claim than "the set is complete", and
it is deliberately phrased as one.

**§5.3 — "Check for a superseded sheet."** Two of them. H-01 and H-02. Both
are in the folder alongside their current revisions, and both have numbers that
look right.

**§5.4 — "Can we just fix the register and send it?"** No, and this audit
changes nothing itself. Three of the conflicts (H-04, H-05, H-08) are
disagreements about **what was actually drawn and when**, and only the drawing
author can resolve those. Editing the register to match the files would make
the paperwork consistent and could make it consistently wrong — and the
register is the record of what you sent.

---

## §10 — What was not checked

- **Drawing content.** Nothing about whether the drawings are correct,
  coordinated, buildable or complete.
- Whether the drawings match the specification.
- Whether the title blocks are internally complete (scale, north point,
  author, checker).
- Structural, MEP and any other consultant package (§4).
- Whether the suitability codes match any project information protocol — none
  was supplied.
- Previous issues, so no drift analysis against them.
- Whether 1501 is a drawing that should exist at all, or a stray.
- File integrity: no file was opened beyond reading its title block.

**The verdict is only as good as this list.**
