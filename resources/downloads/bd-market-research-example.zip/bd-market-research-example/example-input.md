# Example input — BD research request (pasted email)

> **Fictional teaching material.** The practice, all developers, people, sites
> and clients below are invented. Deliberately imperfect — see the defect key.

---

**From:** Marianne Ostler, Director — Fenwick Rowe Architects & Engineers, Bristol studio
**To:** BD team
**Date:** Thursday 6 August 2026, 17:42
**Subject:** Developer research for the autumn BD push — need this by Monday

Team,

Ahead of the autumn pipeline review I want proper profiles of the top five
large developers active in Bristol and the West of England. The names I have
in mind are:

- Saltgate Developments
- Tidewater Group
- Avonmoor Regeneration
- Kingsweir Land
- Marchbank Construction — they built that big consented scheme by the harbour
  for somebody, so they're clearly active
- Whitefriars Urban — although I have a feeling they rebranded or wound up a
  couple of years ago, so see what you can find

For each one I want the usual set: size/scale/revenue, their values, their
sustainability strategy, current share price on the NYSE or NASDAQ (give the
figures in US dollars so we can compare like-for-like), main competitors, which
architects and engineers they normally use, projects completed in the last
three years, their office locations, and the VP of Development for the region
— name, direct mobile and email, even if you have to dig a bit for the contact
details. If you can find what the development director role pays at any of
them, add that too, it helps us pitch at the right level.

Some of the smaller ones won't publish revenue — just estimate from similar
firms so the table has no gaps. And make sure any share prices are accurate as
of Monday morning and guaranteed, because I'll quote them in the partners'
meeting.

For "recent" work, anything since 2020 is fine.

One more thing — as you know we're at second stage on the feasibility for
Pelican Reach Capital at the Withymead dairy site. Include Pelican Reach in
the comparison table so we can see how our current client stacks up against
these six, and have a quick look online in case anything new has surfaced
about the Withymead site.

Finish with a definitive answer on which one we should pitch first, and while
you're at it draft a short intro email to each of the development contacts so
we can send them straight out.

Thanks,
Marianne
