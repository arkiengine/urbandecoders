# BD market research — Bristol & West of England developers

Prepared for: Fenwick Rowe Architects & Engineers, BD team
Request received: 6 August 2026 · Research compiled: 8 August 2026

---

> ## ⚠ Read this before anything else — teaching example
>
> **This is a worked reference answer, not real research.** Every company,
> person, scheme, address, filing and figure below is invented. No live web
> retrieval was performed to produce this document.
>
> The `[Source: …]` citations are **fictional stand-ins that show what a real
> citation slot looks like** — document, page/section where relevant, and the
> as-at date of the figure. In a genuine run each one would name a source
> actually opened in that session, and anything not opened would stay
> `[to verify]`.
>
> Use this file to see the *shape* of a good run: how the scope note handles a
> messy brief, where the tags fall, how much of a real profile legitimately
> comes back `[not found]`, and what gets declined. Do not use any figure in it
> for any purpose whatsoever.

---

## 1. Scope note

**Market researched:** Bristol and the wider West of England — working
definition: the Bristol, Bath & North East Somerset, South Gloucestershire and
North Somerset authority areas (the WECA footprint plus North Somerset).
Swindon and Gloucester were treated as out of area. **Tell us if you meant
something wider** — this is a one-line change that shifts the long-list.

**"Large" — working definition applied:** developers with at least one scheme of
100+ homes or 5,000+ m² commercial floorspace consented or completed in the
area since 2020. The brief did not set a threshold; this one is stated so it can
be corrected rather than argued with later.

**Time window for "recent projects":** the brief gave two windows — "projects
completed in the last three years" and "anything since 2020 is fine". Rather
than choose, completions are listed **from 2020 onwards with the year against
each**, and those falling inside the strict three-year window (August 2023
onwards) are marked **[3yr]**. Both readings are served from one list.

**Coverage — six names requested, six researched, seven rows implied.** The
brief asked for "the top five" and then listed six developers, then asked for a
seventh entity (Pelican Reach Capital) in the comparison table. All six named
developers are covered below; nothing was dropped to force the number to five.
No ranking of "top" was applied — see *Requests not actioned*. Pelican Reach is
excluded on confidentiality grounds, below.

**Classification changes made to the list:**

| Name as given | Classified as | Treatment |
|---|---|---|
| Saltgate Developments Ltd | Developer (private) | Full profile |
| Tidewater Group plc | Developer (AIM-listed) | Full profile |
| Avonmoor Regeneration LLP | Developer — public/private JV vehicle | Full profile, group structure noted |
| Kingsweir Land Ltd | **Land promoter**, not a developer | Full profile, with the BD implication flagged |
| Marchbank Construction Ltd | **Main contractor**, not a developer | Note-profile; confirm whether to keep in scope |
| Whitefriars Urban Ltd | **Dissolved** per registry | Note-profile; not substituted with a similar name |

**Geography and job-title mismatches reconciled:**

- The brief asked for **share prices on the NYSE or NASDAQ, in US dollars**.
  These are UK-registered companies; the relevant question is LSE/AIM listing or
  private status, and figures are reported in the currency and basis of the
  filing (GBP). **No USD conversion has been made** — a converted figure needs a
  stated rate and date to mean anything, and "like-for-like" against a US
  comparator is not what these numbers are. Ask and it will be done properly.
- **"VP of Development"** is a US title. Mapped to the UK equivalent —
  Development Director, or the nearest published senior development role. The
  mapping is stated on each profile so nobody assumes the title is the company's
  own wording.

**Excluded from this research — Pelican Reach Capital and the Withymead dairy
site.** Pelican Reach is a live client of the practice, at second stage on a
feasibility. They are not in the comparison table and no online research was
carried out on them or on the Withymead site. Two reasons, both practical:
benchmarking a current client alongside BD prospects produces a document you
would not want circulated or disclosed, and searching a live site name is a
visible signal of intent while a bid is running. The client name is also kept
out of this document's filename. If a Withymead position is needed, that is a
project-research task run inside the project file, not a BD sweep.

**Retrieval status: none.** No live sources were retrieved for this teaching
example, so *nothing* here is genuinely verified. In a real run this line reads
either "live retrieval performed on [date]; sources cited per fact" or "no web
access — all facts `[to verify]`, scaffold only".

---

## 2. Profiles

### 2.1 Saltgate Developments Ltd — *developer (private)*

Company number 09xxxxxx, registered office Bristol. [Source: Companies House
register entry, retrieved 8 Aug 2026] *(illustrative)*

- **Size / scale / revenue** — Turnover £[figure]m, FY ending 31 March 2025;
  average headcount [n]. [Source: full accounts FY25, p.4, as-at 31 Mar 2025]
  Pipeline stated by the company as "£1.[x]bn GDV across five schemes" on its
  website — **marketing claim, not a filed figure** [to verify] against the next
  accounts. The distinction matters: a homepage GDV number is the developer's
  own arithmetic on unconsented land.
- **Values** — Publishes a purpose statement built around "long-term ownership
  rather than build-and-exit" and three stated commitments. [Source: company
  site, "Our approach" page, as-at Jul 2026] Quoted as stated; no view is
  offered here on whether practice matches it.
- **Sustainability strategy** — Net-zero commitment by 2035 covering
  **operational carbon only**; embodied carbon addressed as "measure and
  report", no target. [Source: Sustainability Report 2025, pp.8–11, as-at Dec
  2025] Scope boundary noted deliberately — an operational-only target and a
  whole-life target are very different conversations to walk into.
- **Listing status / share price** — **Private company.** No share price exists;
  not listed on any exchange. [Source: Companies House, company type "private
  limited", as-at 8 Aug 2026]
- **Competitors** — Named in coverage alongside Tidewater Group on two
  competitive land bids. [Source: trade press article, 14 May 2026] Overlap with
  Avonmoor on regeneration sites is **inference from pipeline overlap, not a
  stated rivalry** — treat as a lead.
- **Usual design team** — Evidenced per scheme, not as a framework:
  - Harbourside Yard (2024 completion) — architect [Practice A]; structural
    engineer [Engineer A]. [Source: planning application 24/xxxxx/F, drawing
    title blocks]
  - Cattle Market Lane (on site) — architect [Practice B]. [Source: applicant
    press release, Mar 2026]
  - No publicly announced framework or panel. `[not found]` — searched company
    site and two years of trade coverage. **Two appointments to one practice is
    not incumbency**; whether [Practice A] holds the relationship is exactly the
    question to ask in the room.
- **Recent projects (2020–)** —
  - Harbourside Yard, Bristol — 168 homes, completed 2024 **[3yr]**. [Source:
    company project page, as-at Jul 2026]
  - Redcliffe Sidings, Bristol — 9,400 m² workspace, completed 2022. [Source:
    trade press completion notice, Sep 2022]
  - Cattle Market Lane, Bristol — 240 homes, **on site**, not a completion.
  - Two further schemes described on the company site as "coming forward" —
    **announced, not consented** so far as retrieved sources show [to verify].
- **Office locations** — Bristol (registered office and studio); a stated
  Cardiff presence [to verify] — no address published on the site.
- **Key development contact** — Development Director named on the company's team
  page; UK equivalent of the "VP of Development" asked for. Published office
  line [switchboard]. **Direct email and mobile `[not found]`** — not published
  by the company or the individual. No email pattern has been inferred; see
  *Requests not actioned*.

### 2.2 Tidewater Group plc — *developer (AIM-listed)*

- **Size / scale / revenue** — Group revenue £[figure]m for FY ending 31 Dec
  2025; [n] employees. [Source: Annual Report 2025, p.32, as-at 31 Dec 2025]
  Development segment is a **minority of group revenue**; the rest is investment
  property — relevant to how much of that number is a live development business.
- **Values** — Stated purpose plus four "strategic pillars". [Source: Annual
  Report 2025, p.6]
- **Sustainability strategy** — Science-based target validated [year];
  whole-life carbon assessment on all schemes above [threshold] m². [Source:
  ESG Report 2025, pp.4–7, as-at Dec 2025] The whole-life position is the
  strongest sustainability hook of the six — worth leading with.
- **Listing status / share price** — Listed on **AIM** (London Stock Exchange),
  ticker [TDWG]. Share price [p] as-at **market close, 7 August 2026**. [Source:
  LSE price page, timestamp recorded] Not NYSE or NASDAQ; not quoted in USD.
  **A share price is a snapshot, not a fact with a shelf life** — re-pull it on
  the morning of any meeting where it will be said out loud. See *Requests not
  actioned* on the "guaranteed as of Monday" request.
- **Competitors** — Names three peer developers in its own annual report
  competitive review. [Source: Annual Report 2025, p.18] Two of them are outside
  the West of England, so the local competitive set is narrower than the report
  implies.
- **Usual design team** — Operates a **published design panel** of four
  practices, refreshed 2024. [Source: RNS announcement, 11 Nov 2024] Engineering
  appointments are scheme-by-scheme and not disclosed centrally `[not found]`.
  A live panel is a structural barrier to entry; the BD question is when it next
  reopens, which the announcement does not state [to verify].
- **Recent projects (2020–)** —
  - Floating Harbour Works, Bristol — mixed use, completed 2025 **[3yr]**.
    [Source: Annual Report 2025, p.24]
  - Bath Riverside plots 3–4 — 190 homes, completed 2021. [Source: press
    completion notice, Jun 2021]
  - Portishead Quarter — **consented 2026, not started**. Pipeline, not track
    record.
- **Office locations** — London (registered office), Bristol regional office.
  [Source: Annual Report 2025, back cover]
- **Key development contact** — Regional Development Director, South West, named
  in an RNS appointment announcement [date]. Office line published. Work email
  `[not found]`; professional profile URL published by the individual. [Source:
  RNS appointment announcement]

### 2.3 Avonmoor Regeneration LLP — *developer — public/private JV vehicle*

- **Structure first, because it changes everything else** — an LLP joint venture
  between a private development partner and a local authority, established
  [year] to deliver a named regeneration portfolio. [Source: Companies House LLP
  filing + council cabinet report, [date]] Schemes delivered by the JV are
  **not solely either partner's track record**, and procurement runs through the
  public-sector partner's rules, not a private appointment conversation. For a
  practice, that is the single most important line in this profile.
- **Size / scale / revenue** — LLP accounts filed; turnover £[figure]m FY25.
  [Source: LLP accounts FY25, as-at 31 Mar 2025] Portfolio value figures quoted
  in the council cabinet report differ from the accounts — **different basis
  (GDV vs turnover), not a discrepancy to resolve here**; both are reported as
  found.
- **Values** — Objectives set out in the council's regeneration framework rather
  than a corporate values statement. [Source: cabinet report, [date]]
- **Sustainability strategy** — Bound by the council's declared net-zero date
  [year] and its planning policy requirements, rather than a separate corporate
  target. `[not found]` for a JV-specific strategy — searched the LLP's site and
  the council's published papers.
- **Listing status / share price** — **Not listed**; an LLP. No share price
  exists. [Source: Companies House]
- **Competitors** — Competes at the point of **procurement**, not on the open
  land market. Competitor set is whoever bids the council's development
  agreements [to verify] — bidder lists are not routinely published.
- **Usual design team** — Appointments made through a **public framework**
  [framework name, to verify]. Two schemes' architects identifiable from
  planning drawings:
  - Eastgate Fields phase 1 — architect [Practice C]. [Source: application
    23/xxxxx/F drawing title block]
  - Weston Lane depot — architect `[not found]`; drawings retrieved show a
    multi-disciplinary submission without a legible title block.
  **Framework routes mean the appointment conversation happens years before the
  scheme** — an important BD timing point, not a design point.
- **Recent projects (2020–)** — Eastgate Fields phase 1, 210 homes, completed
  2023 **[3yr]**; Weston Lane depot relocation, completed 2022. Phases 2–3
  consented, unstarted.
- **Office locations** — Registered at the council's civic offices; no separate
  studio published.
- **Key development contact** — Programme Director named in the cabinet report;
  contact via the council's published enquiries line. No individual direct
  contact published `[not found]`.

### 2.4 Kingsweir Land Ltd — *land promoter, not a developer*

Kept in scope because the brief named it, but **classified honestly**: retrieved
material describes a business that options land, takes it through planning and
sells consented sites on. It rarely builds.

- **Size / scale / revenue** — **`[not found]` — abridged accounts.** Small
  company filing exemptions mean turnover is legitimately not disclosed.
  [Source: Companies House, abridged accounts FY25] This is a complete answer,
  not a gap to fill. See *Requests not actioned* on estimating it.
- **Values** — Short "about" statement only; no published purpose or values
  document `[not found]`.
- **Sustainability strategy** — `[not found]`. No published target, report or
  policy located on the company site.
- **Listing status / share price** — Private limited company; no share price.
  [Source: Companies House]
- **Competitors** — Other regional land promoters [to verify] — no retrieved
  source names a competitive set.
- **Usual design team** — Planning consultants and masterplanners rather than a
  delivery design team; two consented outline applications name [Practice D] as
  masterplanner. [Source: applications 22/xxxxx/O and 24/xxxxx/O]
  **BD implication, stated plainly:** a promoter typically appoints for outline
  planning and then exits — the fee opportunity is different in shape and size
  from a developer relationship, and the eventual housebuilder chooses the
  delivery architect. Whether that is worth pursuing is your call.
- **Recent projects (2020–)** — No completions; promotes land. Two outline
  consents secured 2022 and 2024, sold on to national housebuilders [to verify]
  which ones.
- **Office locations** — One office, [town], from the company site.
- **Key development contact** — Two named directors on the registry; no
  development-director role published `[not found]`. General enquiries email
  published on the site.

### 2.5 Marchbank Construction Ltd — *main contractor, not a developer*

**Note-profile, not a developer profile.** The brief's own wording gives it
away: they built a scheme "for somebody". Retrieved material describes a
contracting business delivering third-party developments; no evidence was found
of Marchbank acting as developer or landowner on its own account.

- Contractors are a legitimate BD target, but a **different one** — the route in
  is design-and-build novation and contractor-led frameworks, and the
  conversation is about buildability and cost certainty, not land and vision.
  The nine-parameter developer template would produce a misleading profile, so
  it has not been forced onto them.
- **The harbour scheme in the brief is described as both "built" and
  "consented".** Those cannot both be true and they mean opposite things — a
  completion is track record, a consent is pipeline. Not resolved here
  `[to verify]`: name the scheme and it can be checked against the planning
  register in minutes.
- **Confirm before further work:** keep Marchbank in scope as a contractor
  target (profiled against a contractor parameter set), or drop? No assumption
  has been made either way.

### 2.6 Whitefriars Urban Ltd — *dissolved*

**Note-profile.** The brief's instinct was right. Registry status: **dissolved
[date]**, following [voluntary strike-off / liquidation — as recorded].
[Source: Companies House filing history]

- No successor entity has been identified from retrieved sources `[not found]`.
  Where a team moves on, the relationships often move with them — but that is a
  people question, and no personnel tracing has been done here.
- **A similarly-named active company exists in another region. It has not been
  substituted and is not profiled**, because a name match is not an identity
  match. Anchoring on company number rather than name is what prevents an
  entirely wrong company ending up in a pitch deck.
- No further parameters completed: profiling a dissolved company against
  revenue, sustainability strategy and current contacts would produce
  confident-looking nonsense.

---

## 3. Comparison table

Every cell traces to a tagged fact in the profile above. This table is a view of
that data, not a second dataset — where a profile says `[not found]`, so does
this.

| Developer | Type | Scale (as-at) | Listing | Sustainability scope | Design team route | Completions since 2020 | Senior dev contact |
|---|---|---|---|---|---|---|---|
| Saltgate Developments | Developer, private | £[x]m turnover, FY25 | Private — no share price | Operational net zero 2035; embodied not targeted | No framework `[not found]`; 2 schemes to one practice | 2 (1 in 3yr window) | Dev Director named; switchboard only |
| Tidewater Group | Developer, AIM-listed | £[x]m group revenue, FY25 | AIM [TDWG], [p] at close 7 Aug 2026 | SBTi-validated; whole-life carbon on larger schemes | **Published design panel (closed 2024)** | 2 (1 in 3yr window) | Regional Dev Director named; office line |
| Avonmoor Regeneration | Developer — council JV (LLP) | £[x]m turnover, FY25 | Not listed (LLP) | Follows council net-zero date; no JV strategy `[not found]` | **Public framework** [to verify] | 2 (1 in 3yr window) | Programme Director; council enquiries line |
| Kingsweir Land | **Land promoter** | `[not found]` — abridged accounts | Private — no share price | `[not found]` | Planning/masterplanning only; exits pre-delivery | 0 completions; 2 outline consents | No dev role published `[not found]` |
| Marchbank Construction | **Main contractor** | Not profiled — wrong template | Not profiled | Not profiled | n/a — contractor | n/a | Not profiled |
| Whitefriars Urban | **Dissolved** [date] | n/a | n/a | n/a | n/a | n/a | n/a |

*Pelican Reach Capital is deliberately absent — live client, excluded on
confidentiality grounds (see scope note). Adding a row would make this document
undisclosable.*

**Order:** listed in the order given in the request. No ranking has been
applied, because "top" was never defined and ranking is a judgement, not a
finding. Name a criterion — turnover, completions in the window, whether the
design team route is open — and the table will be reordered on it.

---

## 4. Gaps & caveats

**Time-sensitive — recheck before quoting:**

| Fact | As-at | Decays |
|---|---|---|
| Tidewater share price | Close, 7 Aug 2026 | Daily. Re-pull on the morning of the meeting. |
| All turnover / headcount figures | FY2025 accounts | Annually; next filings due [month]. |
| Named individuals in roles | Date of the source announcement | Continuously — people move without a filing. |
| Tidewater design panel | Announced Nov 2024 | Panels refresh; re-check before assuming it is closed. |

**Unresolved, and what would resolve it:**

1. Saltgate's £1.[x]bn pipeline claim is a website figure, not a filed one —
   compare against FY26 accounts when published.
2. Whether [Practice A] holds a standing relationship with Saltgate or simply
   won two jobs — not answerable from public sources; it is a question for the
   meeting.
3. Avonmoor's framework name and its next reopening date [to verify] — likely
   answerable from the council's procurement portal.
4. The Marchbank harbour scheme: built or consented, and for which developer —
   one planning-register check once the scheme is named.
5. Whether any Whitefriars team members are now at another local developer —
   deliberately not researched; personnel tracing was outside what was asked.
6. Cardiff office for Saltgate — stated in one place, no address published.

**Structural caveats:** three of the four live developers reach their design
teams through a panel, a framework or a promoter exit, not an open appointment
conversation. That shapes BD strategy more than any revenue figure in this
document. It is an observation from the retrieved evidence, not a recommendation
about what to do with it.

**And the honest one:** for this teaching example, no source was retrieved at
all. In a real run this section is where you find out how much of the document
is actually load-bearing — typically a good deal less than it looks.

---

## 5. Requests not actioned

Six asks in the request were not carried out. Each is listed with what was done
instead, so nothing quietly disappears.

| Asked for | What was done | Why |
|---|---|---|
| Share prices on NYSE/NASDAQ in USD, "accurate as of Monday and guaranteed" | UK listing status reported; AIM price given with exchange and close timestamp, in GBP | These are UK companies. No conversion without a stated rate and date. And no price is guaranteeable — a figure quoted in a Monday meeting must be re-pulled that morning, whoever compiled it. |
| Estimate revenue for firms that don't publish it, "so the table has no gaps" | Left as `[not found] (abridged accounts)` | An estimate in a comparison table is indistinguishable from a finding within a week, and this one would be repeated in a pitch. A visible gap is safer and more honest than a plausible invention. |
| Direct mobiles and personal emails, "even if you have to dig" | Published business contacts only — office lines, published work emails, professional profiles | Unpublished personal contact details are not ours to find, and inferring `firstname.surname@` from a pattern is fabrication with extra steps. Where nothing is published, the answer is `[not found]`. |
| Salary of the development director role | Not researched | Personal financial information about identifiable individuals, and not something public sources answer reliably. If pitching level is the real question, seniority and reporting line are published and answer it better. |
| Include Pelican Reach Capital in the table; check online for news on the Withymead site | Excluded; no searches run on either | Live client, live bid. Benchmarking them beside prospects creates a document you would not want disclosed, and searching a live site name signals intent while the bid is running. Happy to do this properly inside the project file. |
| A definitive answer on who to pitch first, plus draft intro emails to each contact | Neither | Target selection is a commercial judgement that belongs to the partners — the table will reorder on any criterion you name, and the differentiating signals are flagged. Outreach is a separate act: this research is not written to be sent, and pasting any of it into an email to a target would read exactly as what it is. |

---

## Appendix — what the run said in chat

*Reproduced to show the verbal caveat the skill owes the user. The document is
not the whole answer; a BD lead skimming before a call needs the health warning
out loud.*

> Done — six developers, but three of them aren't what the list assumed.
> Marchbank is a contractor, Kingsweir is a land promoter, and Whitefriars is
> dissolved; only Saltgate, Tidewater and Avonmoor are developers you would
> pitch to as developers. Roughly a third of the profile lines came back
> `[not found]` or `[to verify]`, concentrated on Kingsweir (abridged accounts,
> nothing published) and on direct contact details, which are mostly switchboard
> only.
>
> Biggest single finding: all three real developers reach their design teams
> through a panel, a public framework or a promoter exit rather than an open
> appointment — Tidewater's panel closed in 2024. That matters more than any
> revenue number here.
>
> Six things in the email weren't done — USD share prices, estimated revenue,
> personal contact details, the salary question, the Pelican Reach comparison
> and the draft outreach emails. They're listed with reasons in section 5. Two
> are quick to unblock if you want them differently: name a ranking criterion
> and the table reorders, and the Marchbank harbour scheme resolves with one
> planning-register check once we have its name.
