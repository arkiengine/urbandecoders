# Linden Court — quantity export for carbon assessment

**Project:** Linden Court, Marlden — 54 apartments, 6 storeys
**Stage:** 3
**Export:** Revit schedule export, 18 February 2026, model rev 14
**Instruction:** "Prepare the takeoff for the LCA consultant."

*Fictional project. Deliberately imperfect.*

---

## §1 — What was supplied

| Ref | Item | Note |
|---|---|---|
| Q-01 | Revit schedule export (below) | Model rev 14, 18.02.26 |
| Q-02 | Outline specification, rev 2 | 04.12.25 |
| Q-03 | Structural engineer's scheme design report | 22.01.26 |
| Q-04 | Email from the client | 17.02.26 |

**Not supplied:** the assessment methodology to be used; the required element
classification; the required life-cycle modules; any drawings; any MEP
information; any landscape information.

---

## §2 — Revit schedule export (Q-01)

| Revit category | Type | Count | Quantity | Unit |
|---|---|---|---|---|
| Structural Foundations | Pile cap — PC1 | 24 | 86.4 | m³ |
| Structural Foundations | Pile cap — PC2 | 12 | 57.6 | m³ |
| Structural Foundations | Ground beam | — | 48.2 | m³ |
| Structural Columns | Column 400×400 | 96 | 92.2 | m³ |
| Structural Framing | Beam 600×300 | 148 | 79.9 | m³ |
| Floors | Slab 250 RC | — | 2,106 | m² |
| Floors | Slab 300 RC transfer | — | 312 | m² |
| Walls | Core wall RC 250 | — | 884 | m² |
| Walls | External wall — brick/cavity/blockwork | — | 2,940 | m² |
| Walls | Internal partition — metal stud | — | 4,210 | m² |
| Walls | Separating wall — twin leaf blockwork | — | 1,180 | m² |
| Roofs | Flat roof — warm deck | — | 412 | m² |
| Windows | W-TYPE-01 | 186 | — | — |
| Windows | W-TYPE-02 | 94 | — | — |
| Doors | D-TYPE-01 | 54 | — | — |
| Doors | D-TYPE-02 | 212 | — | — |
| Curtain Panels | CW-01 | — | 268 | m² |
| Stairs | Precast flight | 36 | — | — |
| Generic Models | **"Balcony"** | 48 | — | — |
| Generic Models | **"Plant screen"** | 1 | — | — |

**Note on the export:** "Piles themselves are not modelled — they are in the
structural engineer's model only."

---

## §3 — Outline specification extracts (Q-02)

§3.1 "Concrete: **C32/40 to substructure, C40/50 to frame.** Cement
replacement to be confirmed."
§3.2 "Reinforcement: high yield steel bar to BS 4449."
§3.3 "External wall: facing brickwork, 100 mm full fill mineral wool, 100 mm
blockwork inner leaf."
§3.4 "Separating walls: twin leaf dense blockwork."
§3.5 "Windows: aluminium, polyester powder coated, double glazed."
§3.6 "Curtain walling: proprietary unitised aluminium system."
§3.7 "Roof: single ply membrane on **insulation — type and thickness TBC**."
§3.8 "Internal partitions: metal stud and plasterboard."
§3.9 "Stairs: precast concrete."
§3.10 **Balconies, plant screen, external works, and all MEP: not covered by
this specification.**

---

## §4 — Structural engineer's report extract (Q-03)

§4.1 "Reinforcement rates assumed at scheme design: **180 kg/m³ to
substructure, 140 kg/m³ to frame, 110 kg/m³ to slabs.** To be confirmed at
detailed design."
§4.2 "Piled foundations: 86 no. CFA piles, 600 mm diameter, average 14 m.
Pile concrete and reinforcement are included in the structural model and are
**not** in the architectural model."
§4.3 "Transfer slab at level 01 to accommodate the retail unit below."

---

## §5 — Client email (Q-04)

> "We need the embodied carbon number for the planning submission. The
> planning officer asked for it. Can you get us a kgCO2e/m2 figure this week?
> We're told anything under 800 is good. Also can you tell us whether switching
> to CLT would help?"

---

## §6 — What the architect has asked for

1. "Prepare the takeoff for the LCA consultant."
2. "The client wants a number this week — can we give them one?"
3. "What's missing?"
4. "Would CLT be better?"
