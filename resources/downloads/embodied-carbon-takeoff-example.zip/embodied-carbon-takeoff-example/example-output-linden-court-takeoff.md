# Linden Court — embodied carbon quantity register

**Prepared:** 20 February 2026 · **Stage 3** · **Source model rev 14**

> **This register contains no carbon factors, no totals and no kgCO₂e.** It is
> the quantity and scope input an assessor needs in order to price the work and
> produce an auditable result. Every factor column is deliberately empty.

---

## §1 — Basis of takeoff

| Item | Status |
|---|---|
| **Assessment methodology** | **`[not stated]`** — not supplied |
| **Element classification required** | **`[not stated]`** — not supplied |
| **Life-cycle modules required** | **`[not stated]`** — not supplied |
| Design stage | 3 |
| Quantity source | Revit schedule export, model rev 14, 18.02.26 |
| Specification | Outline spec rev 2, 04.12.25 — **11 weeks older than the model** |
| Structural input | Scheme design report, 22.01.26 |

**Because no methodology, classification or module set was stated, this
register is built on a generic element classification.** That is a real cost:
if the assessor requires a different structure, the register will need
rebuilding. **Settling §1 is the first action.**

---

## §2 — Scope and exclusions

**Written before any quantity, because quantities without a boundary are not
comparable to anything.**

| Element group | In scope | Basis |
|---|---|---|
| Substructure — pile caps, ground beams | **In** | Modelled (Q-01) |
| Substructure — **piles** | **OUT — not in the architectural model** | Q-01 note; Q-03 §4.2. **86 no. CFA piles, 600 mm dia, avg 14 m exist and are not quantified here** |
| Superstructure — frame, floors, cores | **In** | Modelled |
| **Reinforcement** | **Not quantified — see §4** | Rates stated by the engineer as assumptions |
| External walls, windows, curtain walling | **In** | Modelled |
| Internal walls and partitions | **In** | Modelled |
| Roof — structure and covering | **In** | Modelled |
| **Roof insulation** | **In scope, not quantifiable** | Spec §3.7: "type and thickness TBC" |
| Stairs | **In** | Modelled |
| **Balconies** | **`[to verify]`** | Modelled as Generic Models, 48 no., **no quantity, no specification** |
| **Plant screen** | **`[to verify]`** | Generic Model, 1 no., **no quantity, no specification** |
| **Finishes** | **OUT** | Not modelled, not specified |
| **MEP** | **OUT** | Not modelled, not specified (spec §3.10) |
| **External works and landscape** | **OUT** | Not modelled, not specified (spec §3.10) |
| **Fittings, furniture, equipment** | **OUT** | Not modelled |
| **Temporary works** | **OUT** | Not modelled |

**Four element groups are out of scope and two more cannot be quantified.** A
figure produced from this register would cover structure and envelope and
nothing else — which is a legitimate Stage 3 boundary, **provided it is stated
every time the result is quoted.**

---

## §3 — Life-cycle module coverage

| Module group | Supported by this register |
|---|---|
| Product stage | **Partly** — material quantities exist for the in-scope elements; material descriptions are insufficient for several (§5) |
| Construction stage | **No** — no transport, waste or site energy data supplied |
| Use stage — replacement, refurbishment | **No** — no service lives supplied or assumed. **Service lives are an assessor input** |
| End of life | **No** — no scenarios supplied |

**No module naming is used here**, because the methodology that defines the
module set has not been stated (§1).

---

## §4 — Reinforcement

**Not quantified in this register.**

The structural engineer states rates (Q-03 §4.1): 180 kg/m³ to substructure,
140 kg/m³ to frame, 110 kg/m³ to slabs — **expressly "assumed at scheme
design… to be confirmed at detailed design"**.

Those are the engineer's figures, supplied by the engineer, and they can be
applied — **by the assessor, attributed to Q-03 §4.1, and tagged as
assumptions**. They are not applied here, because doing so would convert a
stated assumption into a quantity in a register, and the register is what the
assessor audits.

**The concrete volumes below are concrete only.** Reinforcement is a separate
line the assessor adds, using the engineer's rates and the engineer's caveat.

---

## §5 — Quantity register

| Ref | Element | Classification | Material description **as stated** | Quantity | Unit | Source | Confidence | Modules | **Factor** | **Factor source** |
|---|---|---|---|---|---|---|---|---|---|---|
| S-01 | Pile cap PC1 | Substructure | Concrete **C32/40**, cement replacement **`[to verify]`** | 86.4 | m³ | Revit `Structural Foundations` | `[modelled]` | Product | | |
| S-02 | Pile cap PC2 | Substructure | As S-01 | 57.6 | m³ | Revit | `[modelled]` | Product | | |
| S-03 | Ground beam | Substructure | As S-01 | 48.2 | m³ | Revit | `[modelled]` | Product | | |
| S-04 | **Piles** | Substructure | CFA, 600 dia, avg 14 m, 86 no. | **not quantified** | — | Q-03 §4.2 | **`[not quantified]`** | — | | |
| S-05 | Reinforcement, substructure | Substructure | High yield bar to BS 4449 | **see §4** | — | Q-03 §4.1 | `[to verify]` | | | |
| F-01 | Column 400×400 | Superstructure | Concrete **C40/50**, cement replacement **`[to verify]`** | 92.2 | m³ | Revit `Structural Columns` | `[modelled]` | Product | | |
| F-02 | Beam 600×300 | Superstructure | As F-01 | 79.9 | m³ | Revit `Structural Framing` | `[modelled]` | Product | | |
| F-03 | Slab 250 RC | Superstructure | As F-01 | **2,106** | **m²** | Revit `Floors` | `[modelled]` | Product | | |
| F-04 | Slab 300 RC transfer | Superstructure | As F-01 | **312** | **m²** | Revit `Floors` | `[modelled]` | Product | | |
| F-05 | Core wall RC 250 | Superstructure | As F-01 | **884** | **m²** | Revit `Walls` | `[modelled]` | Product | | |
| F-06 | Reinforcement, frame and slabs | Superstructure | High yield bar to BS 4449 | **see §4** | — | Q-03 §4.1 | `[to verify]` | | | |
| E-01 | External wall | Envelope | Facing brick / 100 mm full fill mineral wool / 100 mm blockwork. **Brick type, block density and insulation product `[to verify]`** | 2,940 | m² | Revit `Walls` | `[modelled]` | Product | | |
| E-02 | Curtain walling CW-01 | Envelope | Proprietary unitised aluminium. **System, glass spec and recycled content `[to verify]`** | 268 | m² | Revit `Curtain Panels` | `[modelled]` | Product | | |
| E-03 | Windows W-TYPE-01 | Envelope | Aluminium PPC, double glazed. **No area; count only** | **186 no.** | — | Revit `Windows` | **`[to verify]`** — see §6 | Product | | |
| E-04 | Windows W-TYPE-02 | Envelope | As E-03 | **94 no.** | — | Revit | **`[to verify]`** | Product | | |
| R-01 | Flat roof — warm deck | Roof | Single ply membrane on insulation. **Insulation type and thickness `[to verify]` (spec §3.7)** | 412 | m² | Revit `Roofs` | `[modelled]` | Product | | |
| I-01 | Internal partition | Internal | Metal stud and plasterboard. **Stud gauge, board type and layers `[to verify]`** | 4,210 | m² | Revit `Walls` | `[modelled]` | Product | | |
| I-02 | Separating wall | Internal | Twin leaf **dense** blockwork. **Density and thickness `[to verify]`** | 1,180 | m² | Revit `Walls` | `[modelled]` | Product | | |
| I-03 | Stairs — precast flight | Internal | Precast concrete. **No volume or mass; count only** | **36 no.** | — | Revit `Stairs` | **`[to verify]`** | Product | | |
| D-01 | Doors D-TYPE-01 | Internal | **No specification at all** | **54 no.** | — | Revit `Doors` | **`[to verify]`** | Product | | |
| D-02 | Doors D-TYPE-02 | Internal | **No specification at all** | **212 no.** | — | Revit `Doors` | **`[to verify]`** | Product | | |
| X-01 | **Balcony** | `[to verify]` | **None — Generic Model** | **48 no.** | — | Revit `Generic Models` | **`[to verify]`** | — | | |
| X-02 | **Plant screen** | `[to verify]` | **None — Generic Model** | **1 no.** | — | Revit `Generic Models` | **`[to verify]`** | — | | |

---

## §6 — Units: the register's biggest structural problem

**Six rows carry areas or counts where a factor will need volume or mass.**

| Rows | What exists | What a factor typically needs |
|---|---|---|
| F-03, F-04, F-05 | m² of slab and wall | **m³ or kg.** Thickness is in the type name (250, 300, 250) but **the register does not multiply it out** — see below |
| E-03, E-04 | **Counts of windows** | m² of window, or kg by component |
| I-03 | **Count of stair flights** | m³ or kg |
| D-01, D-02 | **Counts of doors** | m² or kg |
| X-01, X-02 | **Counts** | anything at all |

**No conversion has been performed.** The slab thicknesses appear in the Revit
type names, and multiplying m² by a nominal thickness would look reasonable and
would silently assume that the modelled area is the full structural extent with
no voids, upstands, downstands or thickenings. **That assumption belongs to the
assessor, not to this register.**

Likewise, **no density has been applied anywhere.** Converting concrete volume
to mass, or blockwork area to mass, requires densities that are
product-specific. Each is a question in §9.

---

## §7 — Assumption log

| # | Where | What is incomplete | What was assumed to keep the line usable |
|---|---|---|---|
| A-01 | S-01 to S-03, F-01 to F-05 | **Cement replacement "to be confirmed"** (spec §3.1) | Nothing assumed. Concrete strength class is stated; cement replacement is the single biggest variable in concrete carbon and the row stays `[to verify]` |
| A-02 | E-01 | Brick type, block density, insulation product not stated | Nothing assumed; recorded as stated |
| A-03 | R-01 | Insulation type and thickness "TBC" (spec §3.7) | Nothing assumed. **The roof build-up cannot be priced at all** |
| A-04 | I-02 | "Dense blockwork" — density not stated | Nothing assumed |
| A-05 | E-02 | Aluminium recycled content and production route not stated | Nothing assumed. **This moves aluminium carbon by a large factor and the assessor must have it** |
| A-06 | D-01, D-02 | No door specification exists | Nothing assumed |
| A-07 | X-01, X-02 | Balconies and plant screen are Generic Models with no specification and no quantity | Nothing assumed. **48 balconies is not a small omission** |

**Nothing has been assumed anywhere.** Where a description is insufficient, the
row carries `[to verify]` and names what is needed. A placeholder number
entered here would survive into the assessor's model and then into a report.

---

## §8 — Gaps

Elements that exist in the design and are not quantified by anything supplied.

| # | Gap | Evidence it exists |
|---|---|---|
| G-01 | **Piles** — 86 no., 600 dia, avg 14 m, with concrete and reinforcement | Q-03 §4.2 |
| G-02 | **Reinforcement**, all elements | Q-03 §4.1 |
| G-03 | **Roof insulation** | Spec §3.7 |
| G-04 | **Balconies** — 48 no. | Revit Generic Models |
| G-05 | **Plant screen** | Revit Generic Models |
| G-06 | **All MEP** | Spec §3.10 |
| G-07 | **All finishes** | Not modelled or specified |
| G-08 | **External works and landscape** | Spec §3.10 |
| G-09 | **Window and door areas** | Counts only |
| G-10 | **Stair volumes** | Count only |
| G-11 | **Substructure below pile caps other than piles** — blinding, capping, membranes | Not modelled |

**A Stage 3 register with a gaps list this long is correct, not deficient.**
An early register with nothing missing has been padded.

---

## §9 — Questions for the assessor

**These change the result more than most design decisions.**

| # | Question |
|---|---|
| Q-01 | **Which assessment methodology, which element classification, and which modules?** Everything in §1 depends on it. |
| Q-02 | **What is the scope boundary for the figure the planning officer wants?** Structure and envelope only, or the full building? §2 shows what exists. |
| Q-03 | Reference study period, and service lives for the envelope, roof covering, windows and internal elements. |
| Q-04 | Which database, and which dataset vintage? |
| Q-05 | How are the engineer's reinforcement rates (Q-03 §4.1) to be treated — applied as stated assumptions, or deferred to detailed design? |
| Q-06 | Densities required for every area-to-mass conversion: concrete, dense blockwork, mineral wool, brick. |
| Q-07 | Is the modelled slab area the full structural extent? Voids, upstands, downstands and thickenings are not visible in the export. |
| Q-08 | Treatment of biogenic carbon and sequestration, and whether reported separately. |
| Q-09 | Treatment of the transfer slab (F-04) — it exists because of the retail unit below (Q-03 §4.3) and may warrant separate reporting. |
| Q-10 | Are balconies and the plant screen in or out of scope, and who quantifies them? |

---

## §10 — The specific questions asked

**§6.2 — "The client wants a number this week — can we give them one?"**

**No, and this register deliberately produces none.**

Four element groups are out of scope (§2), eleven gaps are unquantified (§8),
six rows are in units a factor cannot use (§6), reinforcement is unquantified
(§4), the piles are entirely outside the model (G-01), and the single largest
variable in concrete carbon — cement replacement — is marked "to be confirmed"
in the specification (A-01).

**A figure produced this week would be a figure for the structure and envelope
of a building whose foundations, reinforcement, balconies, finishes, services
and external works are not in it.** Quoted to a planning officer without that
boundary, it would be wrong in a way nobody could later unpick.

What *can* be done this week: settle Q-01 and Q-02, and get the assessor the
register so their fee and programme are real.

**On "anything under 800 is good"** (Q-04): **no benchmark, target or
comparison appears in this register.** Benchmarks are specific to a
methodology, a scope boundary, a building type and a floor area definition —
and a number compared against a benchmark drawn from a different boundary is
the most common error in this field.

**§6.4 — "Would CLT be better?"**

**Not answered here.** This register quantifies the design as it is. A material
comparison is a design study requiring its own scope, its own assumptions about
structural grid and build-up, service-life and end-of-life scenarios, and
sequestration treatment (Q-08) — and it is the assessor's and the design team's
work, not the register's.

---

## §11 — Shape of this register

**23 rows. 13 `[modelled]`. 0 `[scheduled]`. 0 `[measured]`. 0 `[estimated]`.
9 `[to verify]`. 1 `[not quantified]`.**

**11 gaps. 10 questions. 7 assumption-log entries, none of them an assumption
actually taken.**

**The single biggest unquantified element is the piling** — 86 no. CFA piles at
600 mm diameter and 14 m average, with concrete and reinforcement, sitting
entirely outside the architectural model.

**The single biggest material unknown is cement replacement**, which is
unresolved across every concrete row in the register.
