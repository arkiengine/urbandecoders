# Rushmere Court — site photos, 6 August 2026

Contents of `/Site visits/2026-08-06/` as exported from the phone, plus the
architect's dictated notes. Twelve frames. Descriptions below are what is
actually legible in each image, with the file metadata as read.

**Project:** Rushmere Court — 34 dwellings and ground-floor community room
**Site:** Bellhurst Road, Sittingbourne, Kent
**Client:** Wealdway Housing Association
**Contractor:** Pentlow Construction Ltd
**Architect:** Ashgrove Bell Architects — job no. 2419
**Contract:** JCT Standard Building Contract 2016, architect as Contract Administrator
**Visit:** Progress visit 07, Thursday 6 August 2026, arrived 10:15, left approx. 11:40

---

## Photo manifest

### P01 — `DSC_0412.JPG`
**Taken:** 06/08/2026 10:22 · **Orientation:** landscape, correct
**Frame shows:** Interior, ground floor. Base of the party wall between Plots 1
and 2, fair-faced blockwork. A grey-brown tide-mark of staining runs along the
bottom of the wall to a height of roughly 300 mm over about 2 m of its length,
with white efflorescence patches within it. The screed floor in the foreground
appears dry. No scale rule or tape in frame. Daylight from an unglazed opening
to the left.

### P02 — `DSC_0413.JPG`
**Taken:** 06/08/2026 10:26 · **Orientation:** landscape, correct
**Frame shows:** External. **North elevation**, facing brickwork between ground
and first floor, photographed from the second lift of the scaffold. Dark
vertical staining runs down the brickwork beneath a window cill for roughly
1.2 m. Mortar joints in the frame appear full and struck. Scaffold boards and a
guardrail cross the top of the frame.

### P03 — `DSC_0417.JPG`
**Taken:** 06/08/2026 10:31 · **Orientation:** landscape, correct
**Frame shows:** External. **East elevation**, facing brickwork beneath the
second-floor window to Plot 7. Dark vertical staining beneath the cill,
roughly 0.8 m long, similar in appearance to that in P02. A rainwater downpipe
runs down the right of the frame; the lowest visible bracket stands off the
wall with a gap of perhaps 15–20 mm behind it.

### P04 — `DSC_0421.JPG`
**Taken:** 06/08/2026 10:44 · **Orientation:** landscape, correct
**Frame shows:** Interior. Plot 3 stair core, internal blockwork wall, oblique
view from the foot of the stair. Stepped diagonal cracking runs through the bed
and perp joints from the door head towards the ceiling, approximately 1.5 m of
it visible in the frame. Blockwork unpainted. No scale rule in frame.

### P05 — `DSC_0422.JPG`
**Taken:** 06/08/2026 10:45 · **Orientation:** portrait, correct
**Frame shows:** Interior. The same stair core wall as P04, close view of the
upper part of the same crack, taken from the half-landing. A short pencil line
has been drawn across the crack with "24/7" written beside it in pencil. No
scale rule in frame.

### P06 — `IMG_2288.HEIC`
**Taken:** 06/08/2026 10:58 · **Orientation:** portrait image carrying a
landscape orientation flag — **displays rotated 90° anticlockwise** unless
corrected
**Frame shows:** Interior. Flat A2, ceiling void above the kitchen, first-fix
stage. Cables run in conduit between joists; one junction box is open with
three cores taped back and unterminated. Mineral wool insulation is installed
between joists across about two thirds of the visible area.

### P07 — `IMG_2291.HEIC`
**Taken:** 06/08/2026 11:04 · **Orientation:** landscape, correct
**Frame shows:** External. Block B south elevation, taken from the courtyard.
Windows are installed and glazed to ground and first floor across the visible
width. At second floor, the two left-hand openings are closed with polythene
sheeting stapled to timber battens; no frames are visible in those two
openings.

### P08 — `IMG_2295.HEIC`
**Taken:** 06/08/2026 11:11 · **Orientation:** landscape, correct
**Frame shows:** External/structure. Block B second-floor slab edge, north-east
corner. Edge protection is absent over approximately 4 m of the slab edge;
loose scaffold boards are stacked at the edge. One operative in hi-vis and
helmet stands roughly 1 m back from the open edge, looking down at the slab.
**The operative's face is clearly visible and identifiable in the frame.**

### P09 — `WhatsApp Image 2026-08-06 at 12.41.18.jpeg`
**Taken:** **date/time not recorded** — EXIF stripped. Received by WhatsApp
from the site manager at 12:41 on 6 August; the architect did not take this
photograph · **Orientation:** landscape, correct
**Frame shows:** Roof terrace to Block A, view across the deck towards the
rainwater outlet. Standing water of roughly 2–3 m² is pooled around and short
of the outlet, with debris and a cigarette end floating in it. Paving is laid
over the near half of the terrace only; the far half shows exposed membrane.

### P10 — `DSC_0428.JPG`
**Taken:** 06/08/2026 11:19 · **Orientation:** landscape, correct
**Frame shows:** Interior. Block B ground floor, ground-bearing slab. A stack
of rigid insulation boards, roughly chest height; the shrink wrap is split open
on two sides. The uppermost boards carry brown water marks across most of their
face and one corner is scuffed. No product label is legible.

### P11 — `DSC_0431.JPG`
**Taken:** 06/08/2026 11:26 · **Orientation:** landscape, correct
**Frame shows:** Interior, underexposed and slightly blurred. A tall vertical
opening — possibly a riser cupboard, possibly a service duct — containing what
may be pipework or ducting; the image is too dark to tell. A printed label is
visible on the left-hand side but the text is not legible. Nothing in the frame
identifies the block, level or plot.

### P12 — `DSC_0388.JPG`
**Taken:** **28/07/2026 14:02** · **Orientation:** landscape, correct
**Frame shows:** Interior. Plot 3 stair core — the same wall as P04 and P05 —
wider view taken from further back and to the other side of the stair.
Stepped diagonal cracking is visible, apparently stopping around 400 mm below
the ceiling. Blockwork unpainted; no pencil annotation visible on the wall.
Lighting in this frame is noticeably brighter than in P04/P05.

---

## Architect's notes

Dictated on the train back, 6 August 2026 — J. Marston, Ashgrove Bell
Architects. Unedited.

- Party wall Plots 1/2 — the staining at the bottom of the wall is the DPC
  failing, same as we had at the other block. Contractor to investigate.
- North elevation brickwork — mortar staining below the cill. Told Pentlow to
  clean a sample area and get it back to me before they touch the rest of it.
  Same again on the east elevation.
- Plot 3 stair core — the crack has definitely got worse since July. I told the
  contractor on site to take that panel down and rebuild it.
- Windows — Block B all installed and glazed now, good progress.
- First fix M&E — complete to all 8 flats in Block A, per Danny.
- Roof terrace — standing water by the outlet, the falls are wrong. MEP to
  confirm the drainage route.
- Slab edge at Block B second floor — edge protection off, mentioned it to
  Danny.
- Guarding to the stair at Plot 3 is well under the 1100 mm required by Part K,
  needs sorting.
- Danny said there's standing water in the lift pit, I didn't get down to look.
- Someone needs to chase the window supplier about the second-floor units.
- Sample panel to be up by the end of next week.
- Attendees: me and Danny Whitcombe (Pentlow). Wealdway's clerk of works was on
  site but I didn't catch his name.
