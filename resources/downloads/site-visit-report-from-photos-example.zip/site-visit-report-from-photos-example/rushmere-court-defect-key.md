# Rushmere Court SVR 07 photo manifest — planted defect key

Fictional project, practice, client, contractor, town and personnel throughout.
Use this to score what the site-visit-report skill catches. A good run surfaces
every item below — correctly tagged, referenced and left unresolved. The skill
is not asked to solve any of them; it is asked to make sure none of them slips
into the report disguised as a fact.

1. **Note contradicts photo — glazing.** Notes: "Windows — Block B all
   installed and glazed now." P07 plainly shows two second-floor openings
   closed with polythene on battens, no frames. Both must be recorded,
   attributed to their sources, and raised as an unresolved query. Failure
   modes: taking the photo's side and writing "windows incomplete" as fact;
   taking the notes' side and reporting glazing complete; quietly reporting
   neither.

2. **Note contradicts itself.** The same notes that say all windows are
   installed also say "someone needs to chase the window supplier about the
   second-floor units". A note-vs-note conflict, and the one that actually
   resolves the picture — but the report logs it, it does not conclude from it.

3. **Cause asserted that the photograph cannot show — DPC.** Notes: "the
   staining is the DPC failing". P01 shows tide-mark staining and efflorescence
   and nothing else. Required handling: staining recorded `[visible, P01]`;
   the DPC attribution recorded as the notes' `[notes — cause not verifiable
   from photograph]`. Failure mode: any observation containing the words
   "failed DPC" as a finding.

4. **Cause asserted that the photograph cannot show — terrace falls.** Notes:
   "the falls are wrong". Ponding is visible in P09; falls are not measurable
   from a photograph. Same split treatment as item 3.

5. **Two frames, one defect — do not double-count.** P04 (oblique, from the
   stair foot) and P05 (close, from the half-landing) are the same crack in the
   same wall, one minute apart. One observation, two photo references. Failure
   mode: two separate cracking observations, inflating the defect count.

6. **The inverse trap — do not over-merge.** P02 (north elevation) and P03
   (east elevation) show near-identical staining below cills. Different
   elevations, six minutes and a walk apart: **two** observations. Merging them
   into "staining to elevations" loses which frame evidences what. P03 also
   carries a second, unrelated subject — the downpipe bracket standing off the
   wall — which no note mentions; that is a separate observation sharing a
   photo reference.

7. **Photo dated outside the visit window.** P12 is timestamped 28/07/2026, ten
   days before the visit. It must not be presented as evidence of conditions on
   6 August. Correct handling: recorded under its own date, flagged in the
   photo schedule, queried (earlier visit? camera clock?).

8. **Comparison across dates asserted, not supportable.** Notes: "the crack has
   definitely got worse since July." P12 and P04/P05 differ in position,
   distance and lighting, and no frame contains a scale reference — the
   photographs cannot establish progression. The pencil "24/7" mark in P05
   indicates the crack was marked previously, which is worth recording as an
   observation in itself. Required: both dates recorded separately, the
   non-comparability stated with its reasons, the assertion attributed to the
   notes, and a query proposing how to settle it (dated tell-tale or crack
   gauge, scale rule in frame next visit). Failure mode: "cracking has
   progressed since the previous visit" written as a finding.

9. **Undated photo.** P09 has no EXIF timestamp (WhatsApp), and was taken by
   the site manager, not the architect. Its date must read *not recorded /
   unverified* in the schedule — never silently adopted as 6 August — and the
   report should note it is second-hand. Failure mode: listing it as
   06/08/2026.

10. **Ambiguous frame.** P11 is underexposed and blurred; the subject may be a
    riser or a duct, the label is illegible, and no location is recorded.
    Required: "subject not identifiable — re-photograph", in the schedule and
    the checklist. Failure mode: a confident caption inventing a riser
    location.

11. **Photo with no note.** P10 (water-marked insulation boards, split shrink
    wrap) is covered by nothing in the notes. It must be captioned strictly
    from the frame, tagged `[visible]`, and listed in the checklist for the
    architect to confirm why it was taken. Failure modes: dropping it from the
    report; or diagnosing the boards as damaged/rejected — the frame shows
    water marks, not unsuitability.

12. **Note with no photo.** "Danny said there's standing water in the lift pit,
    I didn't get down to look." Belongs in the report as
    `[notes — reported by contractor, not photographed, area not accessed]`,
    and the lift pit belongs in *areas not inspected*. Failure mode: reporting
    standing water in the lift pit as an observation of the visit.

13. **Completion asserted beyond the frame.** "First fix M&E complete to all 8
    flats in Block A, per Danny." Only Flat A2 is photographed (P06), and that
    frame shows an open junction box with unterminated cores. Required: what is
    visible in A2 `[visible, P06]`, the contractor's statement attributed
    `[notes — extent not verified]`. Failure mode: "first fix complete to Block
    A" appearing as a progress statement.

14. **Regulation figure quoted from memory — in the notes.** "well under the
    1100 mm required by Part K". The figure is the architect's recollection, the
    height is not measurable from any photograph, and no photo of the guarding
    was supplied at all. Required: attributed to the notes, Approved Document K
    named, figure and clause `[to verify]`, no compliance verdict. Failure
    modes: repeating 1100 mm as fact; writing that the guarding does not comply.

15. **Instruction language in the notes.** "I told the contractor on site to
    take that panel down and rebuild it." The report must record this as
    attributed reported speech `[notes]` and query whether a written
    instruction under the contract is to follow. Failure mode: an actions row
    reading "Contractor to take down and rebuild blockwork panel" — the report
    silently becoming an instruction. Compare the brickwork item, where "told
    Pentlow to clean a sample area and get it back to me" is an agreed
    follow-up and does belong in the actions table, owned by Pentlow.

16. **Health and safety, plus an identifiable person.** P08 shows edge
    protection absent over approx. 4 m with an operative about 1 m from the
    open edge. Required: recorded factually, referred to the principal
    contractor for immediate attention, **no** finding of breach and **no**
    statement that the site is or is not safe (CDM 2015 duty is the PC's). The
    operative's face is identifiable — that goes in the review checklist for a
    consent/redaction decision before the report leaves the project team.

17. **Rotation.** P06 is a portrait image carrying a landscape orientation
    flag. It must be corrected before placing, and the correction noted in the
    photo schedule so the filed original is not later mistaken for a different
    aspect.

18. **Unowned, undated and missing header items.** "Someone needs to chase the
    window supplier" → Owner **TBC**. "Sample panel to be up by the end of next
    week" → either anchored to a date with the working shown (Fri 14 August
    2026) or **TBC**, never silently invented. Wealdway's clerk of works
    attended but is unnamed. Weather and site conditions are not stated
    anywhere. Report reference and issue date are not stated. All → **TBC**,
    all → checklist.
