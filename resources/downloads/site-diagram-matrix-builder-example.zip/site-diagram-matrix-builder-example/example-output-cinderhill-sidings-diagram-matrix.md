# Example output — Cinderhill Sidings four-figure diagram matrix

A faithful run of **site-diagram-matrix-builder** on
`example-input-cinderhill-sidings-site-pack.md`. Shown as the three turns the
skill actually produces: the read and the questions, the user's reply, and the
deliverable.

Use it as the reference answer to compare your own runs against; the planted
issues are listed in `cinderhill-sidings-defect-key.md`.

---

## Turn 1 — what I can build, and what I can't yet

I've read the pack in full. I can build the four-panel set, but **five things in
it cannot be drawn as asked**, and three of those would put a false statement on
a client board. Those first, then the questions.

**Your base is a written description, not an image.** Everything below rests on
prose plus a hand-traced red line off a title plan read on a phone, with the
eastern end flagged approximate by you. That is workable for a Stage 1 analysis
board and it is not survey-grade — the site summary and the board note both say
so, and nothing in this set should be scaled off.

### Five things I'm not doing

- **No north arrow, on any panel.** §2 says the grab is north-up *and* that you
  rotated it 25° anticlockwise to line the railway up with the page. Both can't
  hold: up is not north on the sheet you're using, and the pack never says which
  way north actually points. An arrow drawn from a guess is worse than no arrow
  — it's a wayfinding claim on four panels. The prompts lock orientation to
  "match the reference exactly, do not rotate"; the arrow goes on later in
  InDesign once you've checked, in about thirty seconds.

- **No scale bar.** There's no survey, no dimension, and the frame width is your
  own estimate ("I'd guess 400–500 m"). A scale bar is a measurement; drawing
  one from an estimate invites someone to scale off it. Give me one known
  dimension — the Netherby Road frontage from the title plan, say — or a QGIS/OS
  base, and it goes on.

- **The workspace block stays out of Figure 02.** Figure 02 is the as-found
  grain; the block is unbuilt, unconsented and undesigned. It's also described
  twice in one sentence as five storeys and as six stepping to four, so I don't
  have one version to draw. If you want it seen, it's a fifth panel — *proposed*
  in the title, dashed outline, ghosted over the same base. Say the word and I'll
  write it once you've settled the storeys.

- **No "5 minute walk" circle.** A radius is straight-line distance; a walkshed
  follows the street network, and yours is cut hard by the railway on the east
  and the canal on the south — the two shapes will not be close here. A circle
  labelled as a walk time is the single most challengeable thing you can put on
  a Stage 1 board. Two honest routes: label the ring *straight-line* and let the
  reader draw their own conclusion, or build a real isochrone in QGIS (network
  analysis against the OS/OSM network) and I'll write it as a fifth figure off
  that base. Either way I need a walking speed *and* the document you're taking
  it from before any time-based figure exists — I won't supply one from memory.

- **Nothing gets looked up online.** §6 asks me to keep an unexchanged
  acquisition off the internet and, in the next sentence, to pull the missing
  bits off the online map so the roads join up. I'm doing the first. The second
  is also two separate problems: it geolocates a confidential site, and it draws
  roads the reference doesn't show. What the crop cuts off, the panels don't
  show. Same for the school and health centre "about 900 m west" — they are
  outside the frame and can't be placed. If they're the whole argument, they need
  a wider base, not a longer arm.

  Filenames: `site-diagram-01-roads.png` … `-04-radius.png`. Not client name,
  project name and street, which is what the suggested convention puts into a
  third-party image tool and then into a shared folder.

### The one that changes the board

**Your crop cannot contain your circles.** A 400–500 m frame gives roughly
200–250 m of radius from a central point before you hit the sheet edge. 500 m
and 1 km rings drawn on this base would either be shrunk to fit — which is a
lie with a number on it — or clipped so heavily the panel says nothing. Three
ways out:

  (a) rings within the frame (100 m / 200 m), matrix lock intact;
  (b) a wider base grab for Figure 04 only, with the shared crop drawn on it as
      a locator rectangle and the scale break stated in the panel title — the
      board stops pretending all four panels are the same drawing;
  (c) both: an in-frame 04 now, a wide 04 when you have the grab.

### Contradictions I'm logging, not resolving

| # | The pack says | And also says | I need |
|---|---|---|---|
| 1 | Three retained brick warehouses (§2) | "the two retained sheds" (§4) | Which, and is the goods shed one of them? |
| 2 | Linear green along the **north** boundary is the main biodiversity claim (§4) | The green corridor runs along the **south** edge by the canal (§4) | Which is the corridor, which is the verge |
| 3 | Site area 1.9 ha (header) | "about 2.4 ha including the sidings strip" (§1) | Which figure the red line encloses, and whether the eastern strip is yours |

### Questions — seven, defaults in brackets

1. **Theme.** You've asked for dark *and* for it to photocopy legibly in mono
   for the parish pack. Dark-ground panels photocopy as a black rectangle. The
   clean answer is two encodings of the same four prompts: **Dark** for the
   client deck (it suits the grey/amber brand), **Monochrome** as a print export
   — same geometry, same crop, style lines swapped. Shall I do that?
   *(default: Dark now, Monochrome swap supplied ready to run)*
2. **Circles — which of (a)/(b)/(c) above?**
3. **Ring centre.** The pack never says. Candidates the source actually
   supports: **site centroid** (inside the crop, but it moves depending on
   question 3 in the table above); **existing goods-yard gate**, western end
   (inside the crop); **station pedestrian entrance** — outside the crop, so it
   can't be placed on this base at all. *(default: centroid of the confirmed red
   line)*
4. **The 400 m bus catchment.** "National guidance I think, or maybe the local
   plan" isn't a source I can draw from. Find the document and I'll draw it
   labelled and marked `[to verify]`; otherwise it comes off the panel.
   *(default: omitted)*
5. **The proposed central junction.** Dashed and labelled *proposed — subject to
   s278*, or off Figure 01 entirely? It is not an access until it's agreed.
   *(default: dashed and labelled)*
6. **The informal cut-through** to the station at the eastern end — dashed as a
   desire line, or omitted? It's behaviour you observed, not a route.
   *(default: dashed, labelled "informal")*
7. **Aspect.** "2 × 2 on one A1" and "16:9 panels" don't fit together. *(default:
   1:1 panels for a 2 × 2 grid)*

Answer 1, 2, 3 and 7 and I can write all four. The rest have workable defaults.

**Not going on the drawings either way:** the TPO status of the limes (unchecked
with the council — that's a `[to verify]` note in your text, not a graphic), and
twelve individual trees at invented positions. The north edge gets the tree line
the description evidences, no more.

---

## Turn 2 — the user's reply

> 1. Yes, dark now, send me the mono swap and I'll run it for the parish pack.
> 2. (c) — do the in-frame one now, I'll grab a wider screenshot in the morning,
>    write me the wide prompt so it's ready to go.
> 3. Centroid. And on the area — I've checked the title plan, it's 1.9 ha and
>    that excludes the sidings strip. We don't own the strip. So the red line
>    stops at the eastern fence.
> 4. Can't find it. Leave it off.
> 5. Dashed and labelled, yes.
> 6. Dashed.
> 7. 1:1, fine.
> Also: it's three warehouses. The "two sheds" line was me miscounting — the
> goods shed is separate at the west end. And the canal side is the corridor;
> the north strip is a scrubby verge, not a corridor.
> North I still can't remember. I'll check Monday.

---

## Turn 3 — the deliverable

# Cinderhill Sidings — site analysis matrix (4 figures)

## 1 · Intake record

| Item | Confirmed value | Source |
|---|---|---|
| Base reference | Written site description standing in for a rotated satellite grab; no CAD, no survey | Pack §2 |
| Site label on board | "Cinderhill Sidings — site analysis" | Proposed, confirmed |
| Theme | **Dark** (client deck). Monochrome swap supplied for the print set | User, turn 2 Q1 |
| Ring centre | Centroid of the confirmed 1.9 ha red line | User, turn 2 Q3 |
| Ring values (this set) | **100 m and 200 m**, straight-line, in-frame | Option (c), turn 2 Q2 |
| Ring values (wide set) | **500 m and 1 km**, straight-line — prompt written, **blocked** pending wider base | User, turn 2 Q2 |
| Aspect | 1:1 per panel, 2 × 2 board | User, turn 2 Q7 |
| Target tool | Nano Banana / Gemini image wording | Default |
| North arrow | **Omitted** — orientation unresolved | Contradiction §2, unresolved |
| Scale bar | **Omitted** — no known dimension | No survey |

Every distance in the prompts below traces to a row in this table. Nothing else
is a number.

## 2 · Site summary

| Element | Reading | Tag |
|---|---|---|
| Use / history | Former railway sidings and goods yard, disused since the late 1980s | Stated (§1) |
| Boundary | Roughly rectangular, long axis east–west; red line hand-traced from a title plan; **1.9 ha, excluding the eastern sidings strip, which is not in the ownership** | Stated (§1 + user turn 2) |
| Boundary confidence | Indicative, not survey-grade; eastern end now defined by the fence rather than the traced line | Stated by author |
| Orientation | Grab rotated ~25° anticlockwise; up ≠ north; true north **not established** | **Unresolved** |
| North edge | Netherby Road — two lanes, bus route, footway both sides; bus stop pair opposite the middle warehouse | Stated (§1, §2) |
| East edge | Live railway and embankment; end of station platform canopy visible top-right of frame | Stated (§2) |
| South edge | Ashbourne Cut (canal), towpath on the **far** bank | Stated (§1) |
| West edge | Rear gardens and yards, Marl Street terraces | Stated (§1) |
| Buildings | **Three** brick warehouses along the north side, parallel to Netherby Road, middle one sawtooth-roofed; goods shed at the west end, single storey, corrugated, poor condition | Stated (§2, count confirmed turn 2) |
| Ground | Large concrete apron across the middle (former sidings), largely cleared, rubble piles, self-seeded birch at the eastern end | Stated (§2) |
| Vehicular access | Existing goods-yard gate, west end, single width, poor visibility | Stated (§3) |
| Proposed access | Central junction opposite the middle warehouse — **s278 not agreed** | Stated as proposal (§3) |
| Pedestrian | Informal gap in the eastern fence used as a station cut-through | Stated as informal (§3) |
| Greenery — south | Scrub strip and mature trees on the site side of the canal — **the corridor** | Stated (§4, confirmed turn 2) |
| Greenery — north | Narrow scrubby verge at the old cutting edge — not a corridor | Stated (§4, corrected turn 2) |
| Trees, north edge | Line of mature limes along the road edge; count and positions approximate; **TPO status unchecked** `[to verify — council TPO register]` | Inferred extent / Unresolved status |
| Off-frame | Primary school and health centre ~900 m west — **outside the crop, not drawable on this base** | Stated (§2), excluded |
| Aerial date | Not given — "cleared" apron may not be current | **Unresolved** |

## 3 · Theme encoding — Dark

| Element | Value |
|---|---|
| Ground | Charcoal `#1A1A1A` |
| Context beyond the red line | `#2E2E2E` fills, `#8A8A8A` linework |
| Site boundary | White `#FFFFFF`, continuous, heaviest line on the sheet |
| Roads accent | Amber `#E0A63C` |
| Buildings accent | Cool grey `#B9C0C7` flat fills |
| Greenery accent | Sage `#8FAE7E` |
| Radii | White dashed rings, white labels on the arc |
| Ghosting | Non-active layers at 15–25% of accent strength |
| Proposed items | Dashed, at 60% of the accent, always labelled |

Amber and charcoal sit with the Ravensmere brand as intended. **Monochrome swap
for the parish pack** — same geometry, same crop, replace the STYLE line in all
four prompts with:

```
STYLE: white ground; site boundary solid black, heaviest weight; context 20%
grey flat fills with fine grey linework; active layer solid black — hierarchy
by line weight and 45° hatch only, no tone; proposed items dashed black;
radius rings black dashed with boxed labels. Single-ink, print and photocopy
safe.
```

## 4 · Matrix overview

| Panel | Reads as |
|---|---|
| 01 Roads | How you get to and through the site today, and where the one proposed change sits |
| 02 Buildings | What is standing, and the figure–ground of a mostly-cleared yard |
| 03 Greenery | Where the green actually is — the canal corridor, not a wash |
| 04 Radius | Straight-line distance from the site's own centre, honestly labelled |

## 5 · Shared consistency block

Paste this verbatim into every prompt. It is the only thing making four separate
generations sit on one board — image models keep no memory between runs.

```
CONSISTENCY BLOCK — Cinderhill Sidings analysis set (all figures)
BASE: use the attached site reference as the exact spatial base. Same crop,
same framing, same edges on every figure. Do not re-frame, do not zoom, do not
extend the view beyond the reference.
ORIENTATION: match the reference exactly. Do not rotate. Do not add a north
arrow — the north direction is not established for this base.
BOUNDARY: one continuous white line, heaviest weight on the sheet, following
the red line on the reference exactly. Do not smooth, straighten, move or
close it differently. Everything outside it is muted background context.
THEME (Dark): ground #1A1A1A; context beyond the boundary #2E2E2E flat fills
with #8A8A8A linework; accents — roads amber #E0A63C, buildings cool grey
#B9C0C7, greenery sage #8FAE7E, radii white dashed.
HIERARCHY: one layer dominant per figure at full accent; all other layers
ghosted at 15–25% strength or omitted. Proposed items dashed at 60% and
labelled. Flat vector-style graphic, even line weights, no gradients, no
shadows, no texture.
LABELS: figure title top-left, sans-serif, small. Maximum six labels per
figure. No paragraphs, no scale bar.
NEGATIVE: no perspective, no 3D, no isometric, no photoreal or satellite
texture, no aerial photography, no invented streets, buildings, trees or
water, no redesign of the site, no watermark, no logo, no lorem text.
```

## 6 · Figure prompts

### Figure 01 — Roads

```
FIGURE 01 — ROADS · Cinderhill Sidings — site analysis
Using the attached site reference as the exact spatial base, draw a single
plan-view site-analysis diagram, Dark theme.

ACTIVE LAYER — movement, in amber #E0A63C:
- Netherby Road along the northern edge: two-lane carriageway drawn as the
  heaviest amber band, with a lighter amber line for the footway each side.
- The pair of bus stops on Netherby Road, opposite the middle warehouse, as two
  small amber markers.
- The existing vehicular access: the goods-yard gate at the western end of the
  north boundary, single width, marked with a short amber arrow into the site.
- The live railway along the eastern edge, drawn as a distinct amber dashed
  centreline with tick marks — a rail line, not a road.
- The canal towpath along the far (southern) bank of the canal, thin amber.
- PROPOSED, dashed at 60% amber, labelled "proposed junction — s278 not agreed":
  a central access off Netherby Road opposite the middle warehouse.
- INFORMAL, fine amber dashes, labelled "informal cut-through": a desire line
  from the eastern fence gap towards the top-right corner of the frame.
Draw no other roads, lanes, junctions or paths. The area inside the boundary is
open concrete apron with no marked routes across it.

GHOSTED CONTEXT: building footprints at ~20% cool grey #B9C0C7; green areas at
~15% sage. Marl Street terraces to the west as flat #2E2E2E context blocks.

LEGEND (this figure only): primary road · footway · rail · existing access ·
proposed junction (dashed) · informal route (dashed).

FORMAT: plan view, 1:1 square, flat graphic diagram — not a photograph.

[+ CONSISTENCY BLOCK]
```

### Figure 02 — Buildings

```
FIGURE 02 — BUILDINGS · Cinderhill Sidings — site analysis
Using the attached site reference as the exact spatial base, draw a single
plan-view site-analysis diagram, Dark theme.

ACTIVE LAYER — built grain, as solid cool grey #B9C0C7 flat fills, figure-ground:
- Three brick warehouse footprints in a row along the north side of the site,
  long axes parallel to Netherby Road, matching the reference exactly. Give the
  middle one a fine sawtooth line pattern within its fill to read as the
  sawtooth roof.
- One separate single-storey goods shed footprint at the western end.
- Context buildings beyond the boundary — the Marl Street terrace row to the
  west, and the end of the station platform canopy at the top-right — at ~35%
  strength, clearly subordinate to the four site buildings.
The centre and east of the site are open: a flat cleared concrete apron, no
buildings, drawn as a slightly lighter ground tone with no outline.
Do not add, complete, mirror or infer any footprint that is not on the
reference. Do not draw any proposed or future building.

GHOSTED CONTEXT: Netherby Road and the railway at ~20% amber for orientation;
green areas at ~15% sage.

LEGEND (this figure only): retained warehouse · goods shed · context building ·
cleared apron.

FORMAT: plan view, 1:1 square, flat graphic diagram — not a photograph.

[+ CONSISTENCY BLOCK]
```

### Figure 03 — Greenery

```
FIGURE 03 — GREENERY · Cinderhill Sidings — site analysis
Using the attached site reference as the exact spatial base, draw a single
plan-view site-analysis diagram, Dark theme.

ACTIVE LAYER — existing vegetation only, in sage #8FAE7E:
- The primary corridor: a continuous strip of scrub with mature tree canopies
  along the southern edge of the site, on the site side of the canal. Draw the
  canopies as soft irregular sage discs over a lighter sage scrub fill. This is
  the dominant element of the figure.
- A narrow scrub verge along the northern boundary at the old cutting edge,
  drawn thinner and lighter than the southern strip — a verge, not a corridor.
- A row of mature street trees along the northern road edge, drawn as evenly
  spaced canopies following the road line, indicative of a tree line rather
  than a survey of individual trees.
- Self-seeded birch scrub at the eastern end of the concrete apron, as a loose
  scatter of small light canopies fading out westwards.
- The canal itself in muted context tone, not sage — it is water, not planting.
Draw no other planting. No lawns, no planted courtyards, no street trees where
none are shown, no proposed landscape.

GHOSTED CONTEXT: building footprints at ~20% cool grey; roads and rail at ~15%
amber.

LEGEND (this figure only): tree canopy · scrub · verge · water.

FORMAT: plan view, 1:1 square, flat graphic diagram — not a photograph.

[+ CONSISTENCY BLOCK]
```

### Figure 04 — Radius circles (in-frame set)

```
FIGURE 04 — RADIUS · Cinderhill Sidings — site analysis
Using the attached site reference as the exact spatial base, draw a single
plan-view site-analysis diagram, Dark theme.

ACTIVE LAYER — straight-line distance rings, white dashed:
- Mark the centre with a small white cross at the centroid of the site
  boundary, labelled "centroid of indicative boundary (approximate)".
- Two concentric dashed white circles from that cross: one at 100 m, one at
  200 m, both perfectly circular and concentric.
- Label each ring on its arc, in this wording exactly:
  "100 m straight-line from site centroid"
  "200 m straight-line from site centroid"
- Nothing else on this figure is measured. No further rings, no sectors, no
  arrows, no shaded catchment fills.

GHOSTED CONTEXT: boundary at full weight; buildings ~20% cool grey; roads ~20%
amber; green ~15% sage — enough to locate the rings, nothing competing.

LEGEND (this figure only): distance ring (straight-line) · ring centre.

FORMAT: plan view, 1:1 square, flat graphic diagram — not a photograph.

[+ CONSISTENCY BLOCK]
```

### Figure 04W — Radius circles, wide frame · **BLOCKED — do not run yet**

Run this **only** once you've sent the wider grab (needs to cover roughly 2.5 km
across to hold a 1 km ring with margin). Running it on the current base will
produce shrunk-to-fit circles with real numbers on them, which is the one
failure this whole panel exists to avoid.

```
FIGURE 04W — RADIUS, WIDE FRAME · Cinderhill Sidings — site analysis
Using the attached WIDE site reference as the exact spatial base, draw a single
plan-view site-analysis diagram, Dark theme.

SCALE BREAK: this figure is at a smaller scale than Figures 01-03. Draw the
crop used by those figures as a thin white rectangle on this base, labelled
"panels 01-03 extent". Title the panel "04 — Radius (wider frame, different
scale)".

ACTIVE LAYER — straight-line distance rings, white dashed:
- White cross at the centroid of the site boundary, labelled "centroid of
  indicative boundary (approximate)".
- Two concentric dashed white circles: one at 500 m, one at 1 km.
- Label each on its arc, exactly:
  "500 m straight-line from site centroid"
  "1 km straight-line from site centroid"
- No other measured content.

GHOSTED CONTEXT: site boundary at full weight; the wider street pattern at ~15%
amber only as far as the reference shows it. Do not draw roads, settlements or
features the wide reference does not show.

LEGEND (this figure only): distance ring (straight-line) · ring centre ·
panels 01-03 extent.

FORMAT: plan view, 1:1 square, flat graphic diagram — not a photograph.

[+ CONSISTENCY BLOCK, with the ORIENTATION and BOUNDARY lines applied to the
wide reference]
```

## 7 · Combined legend & 2 × 2 layout

**Board:** A1 landscape. Four 1:1 panels in a 2 × 2 grid, equal gutters, title
top-left of the sheet, shared legend strip along the bottom edge. Panel titles
sit top-left *within* each panel, same size and position on all four.

| Position | Panel |
|---|---|
| Top left | 01 — Roads |
| Top right | 02 — Buildings |
| Bottom left | 03 — Greenery |
| Bottom right | 04 — Radius |

**Shared legend strip** — one row, grouped by layer:

| Swatch | Item |
|---|---|
| Amber solid, heavy | Primary road (Netherby Road) |
| Amber solid, light | Footway |
| Amber dashed + ticks | Railway |
| Amber dashed 60% | Proposed junction — s278 not agreed |
| Amber fine dashes | Informal route |
| Cool grey fill | Retained building |
| Cool grey 35% | Context building |
| Sage disc | Tree canopy |
| Sage fill | Scrub / verge |
| White dashed | Distance ring (straight-line) |
| White line, heavy | Site boundary (indicative) |

**Board footnote, to be set in 8 pt under the legend — please don't drop it:**

> Indicative boundary traced from title plan; no survey. Orientation as source
> image; north not established. Not to scale — do not measure. Distance rings
> are straight-line, not walking catchments.

## 8 · Checks before generating

1. **Count the warehouses in the generated Figure 02.** Three plus a separate
   goods shed. Models complete rows.
2. **Follow every amber line in Figure 01 back to the pack.** Any road, lane or
   path you can't source is invented — regenerate, don't retouch.
3. **Check the eastern boundary** — the red line stops at the fence now, not at
   the end of the traced sidings strip. Compare to the title plan.
4. **Check Figure 03 hasn't greened the apron.** The middle of the site is
   concrete with birch scrub at one end, not a park.
5. **Check the rings are concentric and centred on the cross**, and that both
   labels carry the words "straight-line" and the centre.
6. **Check nothing has grown a north arrow or a scale bar.** Models add them
   unprompted; both would be false here.
7. **Regenerate the whole set if you edit the consistency block.** One drifted
   panel on a board of four is more damaging than four rough ones.

## 9 · Open queries

| # | Query | Blocks |
|---|---|---|
| 1 | **True north direction.** Until it's established, no north arrow, and the rotation means panel orientation can't be described in text either. | North arrow on all four; any orientation statement in the report |
| 2 | **One known dimension or a QGIS/OS base.** | Scale bar on all four; anything measured off the panels |
| 3 | **Wider base grab** (~2.5 km across). | Figure 04W — prompt is written and held |
| 4 | **Walking speed and its source document**, if you still want a time-based catchment — plus a decision on isochrone vs labelled straight-line ring. | Any "minutes' walk" figure |
| 5 | **The 400 m bus catchment source.** Omitted from this set. Produce the document and it goes on marked `[to verify]`. | The bus ring |
| 6 | **TPO status of the limes** — council register `[to verify]`. Not on the drawing either way; it's a text note. | Any tree-protection claim |
| 7 | **Workspace block storeys** — five, or six stepping to four? And do you want the *proposed* fifth panel? | The optional Figure 05 |
| 8 | **Aerial date.** If the grab predates the clearance, Figure 02's open apron may be wrong. | Confidence in 02 and 03 |
| 9 | **School and health centre** — outside the crop and not drawn. If they carry the argument, they need the wide base too. | Any accessibility narrative on this board |

**What this set can claim:** the layers that are on the reference, drawn
consistently and at consistent framing, with straight-line distances from a
stated centre.

**What it cannot claim yet:** orientation, scale, walking catchment,
accessibility to off-frame facilities, or a boundary anyone should rely on. Nine
open queries at Stage 1 on a pack with no survey is a normal number, not a bad
one — but the board footnote earns its place until they close.
