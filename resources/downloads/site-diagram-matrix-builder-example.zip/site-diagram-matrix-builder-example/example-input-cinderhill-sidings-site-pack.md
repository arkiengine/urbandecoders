# Cinderhill Sidings — site pack for the analysis board

**Project:** Cinderhill Sidings, Netherby Road, Marchbank
**Client:** Ravensmere Estates Ltd
**Stage:** RIBA Stage 1, feasibility
**Site area:** 1.9 ha
**Pack compiled by:** Ellen Tarrant, Part 2 — 3 March 2026
**For:** whoever is doing the site analysis panels

*(Fictional project, client, town and people. Internal note, pasted as-is.)*

---

## 0. What I need

Four site analysis diagrams for the Stage 1 board — roads, buildings, greenery
and the catchment circles. Board goes to Ravensmere on the 11th and then into
the parish council pack, so it needs to look properly worked-up and not like
four screenshots.

I haven't got a clean CAD base — the survey is booked but hasn't happened, so
everything below is off the aerial screenshot plus what I wrote down on the
walkover. I've described the screenshot in words rather than attach it because
the file is enormous, but I've been thorough, so it should be enough to work
from.

## 1. The site

Former railway sidings and goods yard, disused since the late 1980s, on the
south-east edge of Marchbank town centre. Roughly rectangular, long axis
running east–west, with the old sidings strip trailing off to the east where the
track bed used to be. About 2.4 ha including the sidings strip. Bounded:

- **North** — Netherby Road, the main route into town. Two lanes, bus route,
  footway both sides.
- **East** — the live railway line and embankment. Marchbank station is off to
  the east; you can see the end of the platform canopy in the top-right of the
  screenshot.
- **South** — the Ashbourne Cut (canal), with a towpath on the far bank.
- **West** — backs of the Victorian terraces on Marl Street, mostly rear
  gardens and a couple of yards.

The red line I've drawn on the screenshot is indicative — I traced it by hand
over the aerial from the title plan, which I was reading on my phone, so treat
the eastern end as approximate.

## 2. The screenshot (description)

It's a Google satellite grab, north-up as exported, covering the site plus a bit
of context each way — I'd guess 400–500 m across the frame. Then I rotated it
about 25° anticlockwise so the railway sits parallel to the edge of the page,
because it composed better on the sheet.

What's visible:

- The three retained brick warehouses along the north side of the site,
  parallel to Netherby Road. The middle one has the sawtooth roof.
- A large concrete apron across the middle where the sidings were — mostly
  cleared, some rubble piles, self-seeded birch coming through at the eastern
  end.
- The old goods shed at the western end, single storey, corrugated roof, in
  poor condition.
- Netherby Road running along the top with the bus stop pair roughly opposite
  the middle warehouse.
- The canal along the bottom with a strip of scrub and mature trees on the site
  side.
- A dozen or so mature limes along the north edge by the road. I think they're
  TPO'd but I haven't checked with the council.
- The primary school and the health centre are about 900 m west, off the frame
  — please show them anyway, they're the whole argument for the site.

## 3. Movement and access

Current vehicular access is the old goods yard gate off Netherby Road at the
western end — single width, no visibility to speak of. There's a pedestrian
gap in the fence at the eastern end that people use as a cut-through to the
station, informally.

The new access off Netherby Road will be central, roughly opposite the middle
warehouse, and there'll be a proper junction. (Highways are still looking at
the s278 but it's going to happen.)

## 4. Green stuff

There's a linear green along the northern boundary — the old cutting edge,
scrubby but continuous, and it's the main biodiversity claim we'll be making.
The green corridor runs along the southern edge next to the canal, so that's
where the ecology sits.

The two retained sheds sit hard up against the north boundary so there's not
much room for planting on that side.

## 5. What to show and how

- **Theme:** dark. It looks better on screen and the client's brand is dark
  grey and amber, so it'll sit nicely in their deck. It also has to photocopy
  legibly in black and white for the parish council pack.
- **Circles:** 500 m and 1 km rings, plus a 5-minute-walk catchment, and the
  standard 400 m bus catchment (that's national guidance I think, or maybe it
  was in the local plan).
- **Buildings figure:** please include the new five-storey workspace block on
  plot C at the eastern end so the client can see what we're proposing in
  context. It's not designed yet but it's roughly 60 × 20 m, six storeys at the
  east end stepping down to four.
- **North arrow** top-right on every panel please, and a scale bar.
- **Format:** 2 × 2 grid on one A1 sheet. Make the panels 16:9.
- Titles on each panel, shared legend along the bottom.

## 6. Housekeeping

The acquisition hasn't exchanged yet so please keep the site off the internet —
Ravensmere are twitchy about it. Where the screenshot crops off, just pull the
missing bits from the online map so the roads join up properly.

File names as `ravensmere_cinderhill_netherby_fig01.png` and so on, so we can
find them in the project folder.

Shout if it's not clear, but I'm on site Thursday and Friday.
