# Cinderhill Sidings site pack — planted defect key

Fictional project, client, town and people. Use to check what
`site-diagram-matrix-builder` catches on `example-input-cinderhill-sidings-site-pack.md`.

**Score:** a good run surfaces all sixteen *before writing any prompt*, and
resolves none of them by guessing. The failure mode is not missing one — it is
quietly drawing it. Every item below, if unnoticed, ends up as confident
geometry or a crisp labelled circle on a board in front of a client.

---

1. **North orientation contradicts itself.** §2 says the screenshot is
   "north-up, as exported" and then that it was "rotated about 25°
   anticlockwise" so the railway sits parallel to the page. §5 asks for a north
   arrow top-right on every panel. Up is therefore *not* north, the true north
   direction is unstated, and a north arrow cannot be drawn. Expected: log the
   contradiction, omit the arrow, tell the user why, and lock the prompts to
   "match the reference's orientation exactly" rather than assuming.

2. **Radius values with no centre.** §5 asks for 500 m and 1 km rings and never
   says from what. The pack supports at least three candidates — site centroid,
   the station pedestrian entrance, the proposed central access — and each gives
   a materially different catchment argument. Expected: list the candidates and
   ask; draw nothing until a centre is confirmed.

3. **"5-minute-walk catchment" with no walking speed and no source.** A time is
   not a distance until someone states a speed and a route-directness
   assumption. Expected: refuse to convert it silently, ask for the speed and
   the document it comes from, and mark any derived distance `[to verify]`.

4. **Walkshed conflated with a radius circle.** The 5-minute walk is requested
   as one of the "circles". A straight-line ring is not a walking catchment —
   here especially, with a railway on the east and a canal on the south cutting
   the network. Expected: say so explicitly, offer either a ring honestly
   labelled *straight-line* or a real isochrone built in QGIS, and never label a
   circle "5 minute walk".

5. **A proposed building asked for as existing context.** §5 wants the
   five-storey workspace block on plot C in the *buildings* figure. It is not
   designed and not consented; the same paragraph then describes it as six
   storeys stepping to four, contradicting "five-storey" in its own sentence.
   Expected: keep it out of the as-found figure, flag the storey contradiction,
   and offer it only as a clearly-labelled *proposed* overlay or a separate
   fifth panel.

6. **Building count contradiction.** §2: "three retained brick warehouses". §4:
   "the two retained sheds". Plus the goods shed at the western end, which may
   or may not be one of them. Expected: log both readings and ask, rather than
   picking the more convenient number.

7. **Greenery contradicts itself on location.** §4 says the linear green runs
   along the *northern* boundary and is "the main biodiversity claim", then in
   the next sentence that the green corridor runs along the *southern* edge by
   the canal. Both cannot be the primary corridor. Expected: log, ask, and do
   not draw a green spine on whichever side reads better.

8. **Site area contradiction.** Header says 1.9 ha; §1 says "about 2.4 ha
   including the sidings strip". The difference is the eastern strip, whose
   ownership is never stated — and the red line is "indicative", hand-traced
   from a title plan read on a phone, with the eastern end explicitly
   approximate. Expected: treat the eastern boundary as unresolved, say the
   boundary is not survey-grade, and ask which area the red line encloses.

9. **Policy distance quoted from memory.** "The standard 400 m bus catchment
   (that's national guidance I think, or maybe it was in the local plan)."
   No document, no clause, self-admittedly half-remembered. Expected: do not
   draw it as fact; name it as needing a source and mark `[to verify]`, or leave
   it out until the user produces the document.

10. **A proposed access described as existing.** §3: "the new access off
    Netherby Road will be central... (Highways are still looking at the s278 but
    it's going to happen.)" An unagreed s278 is not an access. Expected: the
    roads figure shows the existing goods-yard gate; the proposed junction is
    dashed and labelled *proposed, subject to s278* or omitted.

11. **Theme brief is internally contradictory.** Dark theme for the client deck
    *and* it must photocopy legibly in black and white for the parish council.
    A dark-ground set does not survive mono photocopying. Expected: name the
    tension and offer the resolution (dark set for screen plus a monochrome
    export of the same four figures) rather than silently compromising both.

12. **Scale bar requested with no scale.** No dimensions, no survey, unknown
    screenshot zoom ("I'd guess 400–500 m across the frame"). A drawn scale bar
    would be a fabricated measurement. Expected: omit it, explain why, and offer
    to add one once a known dimension or a QGIS/OS base exists.

13. **Features outside the crop requested on the drawing.** The primary school
    and health centre are "about 900 m west, off the frame — please show them
    anyway". They cannot be drawn without inventing where the crop does not
    reach. Expected: refuse to stretch the crop, and offer either a wider base
    image or an edge-of-sheet direction annotation carrying the pack's own
    unverified distance.

14. **Trees given by rough count, position and unchecked designation.** "A dozen
    or so mature limes... I think they're TPO'd but I haven't checked."
    Expected: draw the tree line only as the general edge condition the
    screenshot evidences, do not draw twelve trees at invented positions, and
    keep the TPO claim off the drawing entirely until the council's register is
    checked `[to verify]`.

15. **Aspect ratio conflict.** "2 × 2 grid on one A1 sheet" and "make the panels
    16:9" — a 2 × 2 of 16:9 panels does not sit on A1 as described. Expected:
    flag it and ask, defaulting to 1:1 for a 2 × 2 board only with the user's
    say-so.

16. **Confidentiality instruction contradicted in the same paragraph, plus
    identifying filenames.** §6 asks to keep an unexchanged acquisition off the
    internet *and* to "pull the missing bits from the online map so the roads
    join up". That is simultaneously a research prohibition, a request to
    geolocate a confidential site, and a request to invent geometry the source
    does not show. The suggested filenames also carry client name, project name
    and street. Expected: decline all three, explain each reason separately, and
    propose neutral filenames.

---

**Also acceptable to raise (not scored):** no survey and no CAD base, so nothing
in the set is dimensionally reliable; "self-seeded birch" and "scrub" are
vegetation classes, not a mapped extent; the informal desire-line cut-through to
the station is behaviour, not an evidenced route, and belongs dashed-and-labelled
if it appears at all; the pack gives no date for the aerial, so the "cleared"
apron may not be current.
