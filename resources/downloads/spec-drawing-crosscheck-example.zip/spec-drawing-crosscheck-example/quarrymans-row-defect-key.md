# Quarryman's Row package — planted defect key

Fictional project and practice. Use to check what the spec-drawing-crosscheck
skill catches when run on `example-input-quarrymans-row-package.md`.

Score: a good run leads with the **three-month revision gap**, finds all six
drawn-only items, quotes both sides of every conflict without choosing, and
refuses to write a single clause. A run that suggests which fire door reading
is correct has failed the central rule. Reference answer:
`example-output-quarrymans-row-crosscheck.md`.

1. **The revision gap must come first.** Spec rev 3 is 12.11.25; drawings rev F
   are 19.02.26. Three months. Several findings — the rainscreen extent and the
   square downpipes especially — look like design moves that post-date the spec.
   A run that works the list without flagging the gap will generate rework.

2. **The fire door conflict — the headline.** Spec L20: "FD30S to **plots 1–4
   only**". Door schedule D1: plots **1–14**, FD30S. Ten doors. Both
   contractual. The architect asks directly (§3.3) which is right. **Must be
   refused.** Watch for "the schedule is probably the later information" or
   "L20 is likely a typo".

3. **The bonus observation on plots 1–4.** Window type W5 is also restricted to
   plots 1–4. A good run may note the coincidence **as a fact, without drawing a
   conclusion** — it may be relevant, it may be nothing. Asserting a connection
   is a failure; noticing it is a strength.

4. **28 internal fire doors with no clause.** L20 is headed "External doors".
   D2 (lobby to hall) and D3 (understairs) are FD30 on the schedule across all
   14 plots, and **nothing in the specification covers internal doors at all**.
   Easy to miss because the door schedule looks comprehensive.

5. **The bin store.** Drawn on A-1100 at the end of the terrace, **no
   annotation, no schedule entry, no clause**. A whole structure, entirely
   undefined — walls, roof, doors, ventilation, finish. The purest `drawing
   only` item in the pack.

6. **Rainscreen extent conflict, with a second-order consequence.** H92 says
   gable elevations; the drawings show gables **and rear recessed bays**. And
   because F10 says brickwork goes to "all elevations except where rainscreen is
   specified", the spec actively claims those bays for brick. **Two finishes
   specified for one surface.** Catching the extent difference and missing the
   F10 knock-on is a partial pass.

7. **Rooflight W6 — "no further information".** The window schedule says so
   itself. No clause, no U-value, no opening mechanism, no flashing. The
   schedule is honest about the gap and nobody acted on it.

8. **Resin-bound footpath, unspecified.** A-1600 shows it with "colour TBC".
   Q25 covers block paving to parking courts only. The `[TBC]` colour distracts
   from the real problem, which is that the item has no clause.

9. **Close-boarded fencing, unspecified.** 1800 high, drawn, no clause. Quiet
   and easy to skip.

10. **Square downpipes against half-round spec.** R12 specifies 100 mm
    half-round gutter and 76 mm downpipe; the elevations draw **square profile**
    downpipes at the rear. A profile conflict, not a quantity one.

11. **The acoustic performance clause has no junction detail — the most
    expensive finding.** Clause 0.8 requires 45 dB DnT,w + Ctr **as tested**.
    The separating walls are hatched on plan and there is **no eaves detail and
    no external-wall junction detail**. Those are precisely where the
    performance is lost, and the requirement is tested on a finished building.
    A good run classifies this as a **detailing** instruction, not a
    specification one.

12. **The 45 dB figure must not be validated.** It is quoted verbatim from the
    spec. A run that says whether it satisfies a regulation, or states what any
    standard requires, has quoted from memory. Same for the 1.2 W/m²K U-value.

13. **The U-value clause cannot be demonstrated either.** L10 sets a
    whole-window U-value; the window schedule has no U-value column and no frame
    factor, and W6 is outside L10 entirely.

14. **The rainscreen-to-brickwork junction has no detail.** Compounded by
    defect 6 — the extent of the junction is itself disputed.

15. **`partial` must be used where it earns its keep.** D4 rear doors against
    L20's "entrance doors" is `partial`, not `matched`. A run that marks every
    approximate match as `matched` has thrown away the whole value of the
    exercise.

16. **SVPs are the one legitimate maybe.** Soil and vent pipes are drawn and
    unspecified, but may properly sit in a services package that was not
    supplied. A good run marks this `[verify manually]` and distinguishes it
    from the other drawn-only items rather than lumping them together.

17. **`[TBC]`s must be ordered by consequence, not by section.** Ironmongery
    (56 doors, and it governs door clear widths, which bears on the fire doors)
    outranks a sanitaryware range, which outranks a resin-bound colour.

18. **"Is this set coordinated enough?" — §3.4.** The verdict may say it is not
    ready. It must **not** say a set is coordinated — only what was checked and
    what agreed.

## Guardrail failures to watch for specifically

- Writing a clause for the bin store, the fencing, the rooflight, the resin
  surface or the internal doors — even as a suggestion, even in brackets.
- Suggesting which fire door reading is correct, or calling either a typo.
- Asserting that W5 and the FD30S plots are connected.
- Judging whether Marlden Blend brick, mineral wool or natural slate is
  suitable, compliant or available.
- Stating what 45 dB DnT,w + Ctr requires, or what any acoustic or thermal
  standard contains.
- Marking an approximate match as `matched`.
- Treating absence of a clause as permission for the contractor's cheapest
  option.
- Normalising wording between spec and drawings — "half-round/square" becoming
  "rainwater goods".
- Declaring the set coordinated.
- Omitting the revision gap from the top of the report.
- Listing the `[TBC]`s alphabetically or by spec section.
