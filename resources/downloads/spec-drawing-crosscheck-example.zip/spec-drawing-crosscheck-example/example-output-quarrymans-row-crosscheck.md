# Quarryman's Row — spec / drawing cross-check

**Specification:** rev 3, 12 November 2025.
**Drawings:** rev F, 19 February 2026.
**Checked:** 25 February 2026.

---

## §0 — Revision gap — read first

**The specification is three months older than the drawings.** Spec rev 3 is
dated 12.11.25; drawings rev F are dated 19.02.26. Several findings below are
likely to be artefacts of that gap rather than independent errors — the
rainscreen extent (C-01) and the square downpipes (C-03) both look like design
moves that happened after rev 3 and never went back into the spec.

**Close the gap before actioning the findings.** Working the list against a
three-month-old specification will generate rework.

---

## §1 — Verdict

**Not coordinated enough to issue for tender.**

The single biggest exposure: **the fire door conflict (C-02)**. The
specification restricts FD30S entrance doors to plots 1–4; the door schedule
applies FD30S to all 14. That is a difference of ten doors, both statements are
contractual, and the contractor will price the cheaper reading.

Close behind it: **three elements are drawn with no specification clause at
all** (O-01 to O-03), and **two performance clauses have no detail that could
demonstrate them** (P-01, P-02) — including the separating wall acoustic
requirement, which is the one that gets tested after completion.

---

## §2 — Coverage matrix

| # | Item | Spec clause | Drawing | Schedule | Status | Note |
|---|---|---|---|---|---|---|
| 1 | Windows, timber-aluminium | L10 | A-1200/1201 | A-1400 W1–W5 | `matched` | — |
| 2 | **Rooflight W6** | **none** | — | A-1400 W6 | **`drawing only`** | O-01 |
| 3 | Entrance doors | L20 | — | A-1401 D1 | **`conflict`** | C-02 |
| 4 | Internal fire doors D2, D3 | **none** | — | A-1401 | **`drawing only`** | O-02 — L20 covers external doors only |
| 5 | Rear doors D4 | L20 | — | A-1401 D4 | `partial` | L20 says "entrance doors"; D4 is a rear door, composite, no rating |
| 6 | Cavity insulation | M60 | A-1500 details | — | `matched` | — |
| 7 | Rainscreen cladding | H92 | A-1200/1201 | — | **`conflict`** | C-01 — extent differs |
| 8 | Facing brickwork | F10 | A-1200/1201 | — | `matched` | — |
| 9 | Plasterboard linings | K11 | A-1500 | — | `matched` | — |
| 10 | Ironmongery | P21 **[TBC]** | — | — | `spec only` | T-01 |
| 11 | Sanitaryware | N13 **[TBC]** | — | — | `spec only` | T-02 |
| 12 | Block paving | Q25 | A-1600 | — | `matched` | — |
| 13 | **Resin-bound footpath surface** | **none** | A-1600 | — | **`drawing only`** | O-03 |
| 14 | Rainwater goods | R12 | A-1200/1201 | — | **`conflict`** | C-03 — profile differs |
| 15 | Roof covering, slate | J41 | A-1200/1201 | — | `matched` | — |
| 16 | **Fencing, close-boarded 1800** | **none** | A-1600 | — | **`drawing only`** | O-04 |
| 17 | **Bin store** | **none** | A-1100 | — | **`drawing only`** | O-05 |
| 18 | Separating wall acoustic performance | clause 0.8 | A-1100/1101 (hatch) | — | **`partial`** | P-01 |
| 19 | Window U-value | L10 | — | A-1400 | **`partial`** | P-02 |
| 20 | **Soil and vent pipes** | **none** | A-1100/1101 | — | **`drawing only`** | O-06 |

---

## §3 — Conflicts

**C-02 — Fire rating of entrance doors. The biggest single exposure.**

| Source | Says |
|---|---|
| Spec L20 | "Composite entrance doors, insulated core, **FD30S to plots 1–4 only**." |
| Door schedule A-1401, D1 | Plots **1–14**, Composite, **FD30S** |

Ten doors are rated in one document and not in the other. Both are contractual.
**This cross-check does not determine which is correct** — the architect asks
directly (§3.3), and the answer requires knowing why plots 1–4 were
distinguished in the first place, which is a design and fire strategy question,
not a documentation one.

Note separately, and without resolving it: plots 1–4 are also the only plots
with window type W5 (A-1400). Whether those two facts are connected is for the
design team.

**C-01 — Extent of rainscreen cladding.**

| Source | Says |
|---|---|
| Spec H92 | "to the **gable elevations**" |
| Spec F10 | "Facing brickwork to **all elevations except where rainscreen is specified**" |
| Drawings A-1200/1201 | Rainscreen hatch to gable elevations **and to the rear elevation recessed bays** |

The drawings show rainscreen in a location the specification does not cover,
and F10 therefore claims those bays for brickwork. Two finishes are specified
for the same surface. See also P-01 and the missing junction detail (D-01).

**C-03 — Rainwater goods profile.**

| Source | Says |
|---|---|
| Spec R12 | "100 mm **half-round** gutter, **76 mm** downpipe" |
| Drawings A-1200/1201 | **Square profile** downpipes drawn at the rear |

A profile difference, not a quantity difference, but the contractor prices from
one of them.

---

## §4 — Drawn, not specified

The contractor prices these at their own discretion, and the discretion is not
yours.

| # | Item | Where drawn | Note |
|---|---|---|---|
| O-01 | **Rooflight W6**, 780 × 980 | A-1400 window schedule | The schedule itself says "**no further information**". No clause in L10 or anywhere covers rooflights — no type, no U-value, no opening mechanism, no flashing. |
| O-02 | **Internal fire doors D2, D3** (FD30, 28 doors) | A-1401 | L20 is headed "External doors". Nothing specifies internal doors at all. |
| O-03 | **Resin-bound footpath surface** | A-1600, labelled "colour TBC" | No clause. Q25 covers block paving to parking courts only. |
| O-04 | **Close-boarded fencing**, 1800 high | A-1600 | No clause. |
| O-05 | **Bin store** | A-1100, drawn at the end of the terrace | No annotation on the drawing, no schedule entry, no clause. Structure, finish, roof, doors and ventilation are all undefined. |
| O-06 | **Soil and vent pipes** | A-1100/1101, shown internally | No clause in the architectural spec. May sit in a separate services package — `[verify manually]`, and O-06 is the only item here that may legitimately live elsewhere. |

---

## §5 — Specified, not drawn

| # | Item | Clause | Note |
|---|---|---|---|
| S-01 | Ironmongery | P21 — "schedule to be issued separately **[TBC]**" | Nothing drawn, nothing scheduled, nothing specified. See T-01. |
| S-02 | Sanitaryware | N13 — manufacturer and range **[TBC]** | Nothing drawn or scheduled. |

Both are also `[TBC]` items — see §7.

---

## §6 — Performance requirements with nothing to demonstrate them

**P-01 — Separating wall acoustic performance. High.**

Spec clause 0.8 requires "a minimum airborne sound insulation of 45 dB
DnT,w + Ctr **as tested**". The plans show the separating walls as twin-leaf
masonry hatch. **There is no detail for the separating wall at the eaves, and
none at its junction with the external wall** (§2, typical details).

Those two junctions are where the performance is lost, and the requirement is
one that gets **tested after completion**, when the cost of failure is a remedy
on a finished building. The clause is sound; the detailing is absent.

This is a detailing instruction, not a specification one.

**Note on the figure:** 45 dB DnT,w + Ctr is quoted verbatim from clause 0.8.
**This cross-check does not state whether that figure satisfies any
regulation**, nor what any standard requires. Name the governing document and
confirm it. `[to verify]`

**P-02 — Window U-value. Medium.**

Spec L10 requires "not exceeding 1.2 W/m²K for the whole window". The window
schedule A-1400 carries sizes and type but **no U-value column and no frame
factor**, and W6 (the rooflight) is outside L10 entirely (O-01). Nothing in the
drawn set could demonstrate the clause.

**D-01 — Missing junction detail: rainscreen to brickwork.**

Not a performance clause, but the same category of problem. Two cladding
systems meet on the gables and (per the drawings) at the rear bays, and **no
detail resolves the junction** (§2). Compounded by C-01, which means the extent
of that junction is itself disputed.

---

## §7 — `[TBC]` and open items, ordered by what they block

| # | Item | Clause / location | Blocks |
|---|---|---|---|
| T-01 | **Ironmongery schedule** — not issued | P21 | **Door clear widths.** Clear width depends on ironmongery and opening angle, which bears on access and on the fire doors in C-02. Also unpriceable: 56 doors with no ironmongery. |
| T-02 | **Rainscreen colour and profile** | H92 | Unpriceable. Profile also governs the missing junction detail (D-01). |
| T-03 | **Window RAL** | L10 | Priceable as a provisional; fixes nothing dimensional. |
| T-04 | **Sanitaryware manufacturer and range** | N13 | Unpriceable. Affects room layouts and service positions. |
| T-05 | **Resin-bound colour** | A-1600 | Priceable; but the item has no clause at all (O-03), which is the larger problem. |

---

## §8 — Ranked findings

**High**

| # | Finding |
|---|---|
| C-02 | FD30S on 4 plots in the spec, 14 on the schedule — ten doors |
| P-01 | 45 dB separating wall requirement with no eaves or external-wall junction detail |
| O-05 | Bin store drawn, entirely unspecified and unannotated |
| O-02 | 28 internal fire doors drawn and scheduled, with no clause |
| C-01 | Rainscreen extent differs between spec and drawings; F10 claims the same surface for brick |
| T-01 | No ironmongery schedule for 56 doors |

**Medium**

| # | Finding |
|---|---|
| O-01 | Rooflight W6 unspecified, schedule says "no further information" |
| O-03 | Resin-bound footpath unspecified |
| D-01 | No rainscreen-to-brickwork junction detail |
| C-03 | Half-round vs square rainwater goods |
| P-02 | U-value clause with no demonstrating information |
| O-04 | Fencing unspecified |
| §0 | Three-month revision gap between spec and drawings |

**Low / Info**

| # | Finding |
|---|---|
| 5 | D4 rear doors only `partial` against L20's "entrance doors" |
| O-06 | SVPs may legitimately sit in a services package |
| T-04 | Sanitaryware `[TBC]` |

---

## §9 — The specific questions asked

**§3.2 — "What's drawn but not specified?"** Six items. See §4. The bin store
(O-05) and the 28 internal fire doors (O-02) are the two that matter most: the
first is a whole structure with no definition at all, and the second is 28
rated doors whose rating is drawn but not specified.

**§3.3 — "The door schedule and the spec disagree on fire doors — which is
right?"** This cross-check does not determine that, and will not suggest which
reading is more likely. Both documents are quoted in full in C-02. Someone with
design authority over the fire strategy decides, and the useful fact is that
plots 1–4 are distinguished elsewhere in the set too — which may or may not be
related.

**§3.4 — "Is this set coordinated enough to go out?"** Not in its current
state — see §1. Note that this cross-check cannot declare a set coordinated in
any case. It can report what it checked and what agreed: **20 items, 6
matched, 3 conflicts, 6 drawn-only, 2 spec-only, 3 partial.**

---

## §10 — What was not checked

- Whether any specified product is suitable, compliant, available or
  appropriate. That is a specifier's judgement.
- Whether anything complies with any regulation. A spec/drawing conflict is a
  coordination finding, not a compliance finding.
- Structural, mechanical, electrical and drainage packages — not supplied.
- Preliminaries, workmanship clauses and the contract preliminaries.
- Whether the drawings are internally consistent with each other.
- Quantities of anything.
- Whether the 45 dB figure or the 1.2 W/m²K figure satisfies any requirement.
- Drawing revisions earlier than rev F and spec revisions earlier than rev 3.
