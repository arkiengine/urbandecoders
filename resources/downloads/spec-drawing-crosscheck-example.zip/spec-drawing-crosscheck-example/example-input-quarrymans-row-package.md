# Quarryman's Row — specification and drawing package

**Project:** Quarryman's Row, Marlden — 14 terraced dwellings
**Purpose:** pre-tender coordination check
**Specification:** rev 3, dated 12 November 2025
**Drawings:** planning-to-tender set, rev F, dated 19 February 2026

*Fictional project. Deliberately imperfect.*

---

## §1 — Specification extracts (rev 3, 12.11.25)

**L10 — Windows**
"Timber-aluminium composite windows. Factory-finished aluminium external
cladding, RAL to be confirmed. Softwood internal frames, factory primed.
Double glazed units, argon filled. **U-value not exceeding 1.2 W/m²K for the
whole window.**"

**L20 — External doors**
"Composite entrance doors, insulated core, **FD30S to plots 1–4 only**."

**M60 — External wall insulation**
"Proprietary mineral wool cavity insulation, 100 mm, full fill."

**H92 — Rainscreen cladding**
"Proprietary metal rainscreen system to the gable elevations.
Secret-fix cassettes. Colour and profile to be confirmed. **[TBC]**"

**F10 — Brickwork**
"Facing brickwork to all elevations except where rainscreen is specified.
Brick type: Marlden Blend, from the approved supplier list. Mortar: lime
mortar, natural colour, bucket handle joint."

**K11 — Plasterboard linings**
"12.5 mm plasterboard on dabs to masonry, taped and filled."

**P21 — Ironmongery**
"Ironmongery schedule to be issued separately. **[TBC]**"

**N13 — Sanitaryware**
"White vitreous china throughout. Manufacturer and range to be confirmed.
**[TBC]**"

**Q25 — Paving**
"Concrete block paving to parking courts, 80 mm, charcoal."

**R12 — Rainwater goods**
"Cast aluminium rainwater goods, 100 mm half-round gutter, 76 mm downpipe,
polyester powder coated."

**J41 — Roof covering**
"Natural slate, 500 × 250, on treated battens and breather membrane."

**Acoustic performance, clause 0.8**
"Separating walls between dwellings **shall achieve a minimum airborne sound
insulation of 45 dB DnT,w + Ctr** as tested."

---

## §2 — Drawing content (rev F, 19.02.26)

**Elevations (A-1200, A-1201)**
- Brickwork hatch to all street elevations.
- **Rainscreen hatch to the gable elevations AND to the rear elevation
  recessed bays.**
- Slate roof hatch.
- Rainwater goods shown, **square profile downpipes drawn at the rear**.
- Window types W1–W6 keyed.

**Door schedule (A-1401)**
| Ref | Plot | Location | Type | Fire rating |
|---|---|---|---|---|
| D1 | 1–14 | Entrance | Composite | **FD30S** |
| D2 | 1–14 | Lobby to hall | Timber | FD30 |
| D3 | 1–14 | Understairs | Timber | FD30 |
| D4 | 1–14 | Rear | Composite | — |

**Window schedule (A-1400)**
| Type | Plots | Size | Notes |
|---|---|---|---|
| W1 | all | 1200×1200 | Timber-aluminium |
| W2 | all | 600×1200 | Timber-aluminium |
| W3 | all | 1800×1200 | Timber-aluminium |
| W4 | all | 900×2100 | Timber-aluminium, **French door** |
| W5 | 1–4 | 1200×600 | Timber-aluminium |
| W6 | all | **rooflight, 780×980** | **No further information** |

**Typical details (A-1500, A-1501)**
- Eaves, verge, cill, head, jamb details for brickwork.
- Ground floor threshold detail.
- **No detail for the rainscreen-to-brickwork junction.**
- **No detail for the separating wall at eaves or at the external wall
  junction.**

**Plans (A-1100, A-1101)**
- Separating walls shown as twin-leaf masonry, hatched.
- Parking court shown with block paving hatch.
- **Bin store shown on plan at the end of the terrace, with no annotation and
  no entry in any schedule.**
- Soil and vent pipes shown internally.

**External works (A-1600)**
- Block paving to parking courts.
- **Resin-bound surface shown to the footpath, labelled "resin bound, colour
  TBC".**
- Timber close-boarded fencing to rear gardens, 1800 high.

---

## §3 — What the project architect has asked for

1. "Cross-check the spec against the drawings before tender."
2. "What's drawn but not specified?"
3. "The door schedule and the spec disagree on fire doors — which is right?"
4. "Is this set coordinated enough to go out?"
