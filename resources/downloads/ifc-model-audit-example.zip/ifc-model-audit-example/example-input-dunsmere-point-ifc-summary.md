# Dunsmere Point — IFC file summary

**File:** `DUN-ARC-ZZ-ZZ-M3-A-0001.ifc`
**Received from:** Carrow Dale Architects (outgoing architect)
**Received:** 2 March 2026
**Instruction:** "We're taking this over. Can we trust it? We want to federate
it with the structural model and import it into our twin over a GIS basemap."

*Fictional project and practice. A structural summary of the file's contents,
standing in for the .ifc itself. Deliberately imperfect.*

---

## §1 — Header and provenance

| Field | Value |
|---|---|
| Schema | `IFC4` |
| `FILE_DESCRIPTION` ViewDefinition | **`[CoordinationView]`** |
| Originating application | Autodesk Revit 2023 (ENU) |
| Exporter | IFC Exporter for Revit 23.2.0.0 |
| `FILE_NAME` timestamp | 2025-08-14T16:22:09 |
| `IfcProject` Name | `Dunsmere Point` |
| `IfcProject` LongName | **(empty)** |
| `IfcSite` Name | `Default` |
| `IfcBuilding` Name | `Dunsmere Point` |
| Author | `CD` |
| Organisation | `Carrow Dale Architects` |

**Note:** the project directory also contains
`DUN-ARC-ZZ-ZZ-M3-A-0001_rev03.ifc`, dated 2026-01-20, not yet examined.

---

## §2 — Units and precision

| Unit type | Value |
|---|---|
| `LENGTHUNIT` | `.MILLI.` `.METRE.` |
| `AREAUNIT` | `.SQUARE_METRE.` |
| `VOLUMEUNIT` | `.CUBIC_METRE.` |
| `PLANEANGLEUNIT` | `.DEGREE.` |
| `IfcGeometricRepresentationContext` Precision | `1.0E-5` |

---

## §3 — Georeferencing

| Entity | Present | Values |
|---|---|---|
| `IfcMapConversion` | **Yes** | `Eastings = 0.` · `Northings = 0.` · `OrthogonalHeight = 0.` · `XAxisAbscissa = 1.` · `XAxisOrdinate = 0.` · `Scale = 1.` |
| `IfcProjectedCRS` | **Yes** | `Name = 'EPSG:27700'` · `Description = $` · `GeodeticDatum = $` · `VerticalDatum = $` · `MapUnit = $` |
| `IfcSite` `RefLatitude` | No | `$` |
| `IfcSite` `RefLongitude` | No | `$` |
| `IfcSite` `RefElevation` | **Yes** | `0.` |
| `TrueNorth` on the model context | **Yes** | `(-0.27563736, 0.96126170)` |

**Element placement extents, model coordinates (mm):**

| Axis | Min | Max |
|---|---|---|
| X | −48,210 | 96,455 |
| Y | −31,880 | 72,140 |
| Z | −4,500 | 28,650 |

**Note from the sender's transmittal email:** "It's all set out on OS National
Grid, the site origin is the south-west corner of the building."

---

## §4 — Spatial structure

```
IfcProject "Dunsmere Point"
└── IfcSite "Default"
    └── IfcBuilding "Dunsmere Point"
        ├── IfcBuildingStorey "Level 00"   Elevation 0.
        ├── IfcBuildingStorey "Level 01"   Elevation 3600.
        ├── IfcBuildingStorey "Level 02"   Elevation 7200.
        ├── IfcBuildingStorey "Level 03"   Elevation 10800.
        ├── IfcBuildingStorey "Level 04"   Elevation 14400.
        ├── IfcBuildingStorey "Level 05"   Elevation 18000.
        ├── IfcBuildingStorey "Roof"       Elevation 21600.
        └── IfcBuildingStorey "T.O. Parapet" Elevation 22800.
```

**Elements not contained in any storey: 1,847**

| Class | Count not in a storey |
|---|---|
| `IfcBuildingElementProxy` | 912 |
| `IfcFurnishingElement` | 486 |
| `IfcFlowTerminal` | 212 |
| `IfcWall` | 141 |
| `IfcSlab` | 96 |

---

## §5 — Entity census

| Class | Occurrences | Types |
|---|---|---|
| `IfcWall` / `IfcWallStandardCase` | 2,418 | 34 |
| `IfcSlab` | 684 | 11 |
| `IfcColumn` | 312 | 6 |
| `IfcBeam` | 596 | 14 |
| `IfcDoor` | 1,284 | 22 |
| `IfcWindow` | 806 | 18 |
| `IfcStair` | 28 | 4 |
| `IfcRailing` | 164 | 7 |
| `IfcCovering` | 2,106 | 9 |
| `IfcSpace` | 418 | — |
| `IfcBuildingElementProxy` | **3,041** | **0** |
| `IfcFurnishingElement` | 486 | 31 |
| `IfcFlowTerminal` | 212 | 18 |
| `IfcCurtainWall` | 46 | 3 |
| `IfcPlate` | 1,890 | 12 |
| `IfcMember` | 2,204 | 15 |

---

## §6 — Classification and property coverage

**Classification systems present:** `Uniclass 2015` on 1,284 elements.
No other classification reference found.

| Class | Occurrences | With `Pset_*Common` | With `FireRating` | With `LoadBearing` | With `IsExternal` | With a classification reference |
|---|---|---|---|---|---|---|
| `IfcWall` | 2,418 | 2,410 | **1,106** | 2,410 | 2,410 | 884 |
| `IfcDoor` | 1,284 | 1,284 | **0** | — | 1,284 | 400 |
| `IfcWindow` | 806 | 806 | — | — | 806 | 0 |
| `IfcSlab` | 684 | 684 | 12 | 684 | 684 | 0 |
| `IfcBuildingElementProxy` | 3,041 | **0** | 0 | 0 | 0 | 0 |
| `IfcSpace` | 418 | 418 | — | — | — | 0 |

**Base quantities (`Qto_*`):**

| Class | With base quantities |
|---|---|
| `IfcWall` | 2,418 of 2,418 |
| `IfcSlab` | 684 of 684 |
| `IfcDoor` | 0 of 1,284 |
| `IfcSpace` | 418 of 418 |
| `IfcBuildingElementProxy` | 0 of 3,041 |

---

## §7 — Identity

| Check | Result |
|---|---|
| Total elements with a `GlobalId` | 16,781 |
| **Duplicate `GlobalId` values** | **24 (12 pairs)** |
| Null or malformed `GlobalId` | 0 |
| `GlobalId` persistence across exports | **Cannot be assessed — only one file examined** |

**The 12 duplicate pairs are all `IfcBuildingElementProxy`.**

---

## §8 — Geometry representation

| Representation type | Element count |
|---|---|
| `SweptSolid` | 7,106 |
| `Clipping` | 2,884 |
| `Brep` | **4,912** |
| `MappedRepresentation` | 1,804 |
| **No geometric representation at all** | **75** |

**The 75 with no geometry:** 61 `IfcBuildingElementProxy`, 14 `IfcSpace`.

**Largest single elements by triangle count on tessellation:** the top 40 are
all `IfcBuildingElementProxy` with `Brep` representations, named
`Assembly_01` through `Assembly_40`.

---

## §9 — What the receiving practice has asked for

1. "Audit it — can we trust it?"
2. "We want to federate with the structural model. Will it work?"
3. "Can we schedule doors and windows off it for the fire strategy?"
4. "We're importing to Unreal over a GIS basemap. Is the georeferencing OK?"
5. "The sender says it's on OS National Grid. Is it?"
