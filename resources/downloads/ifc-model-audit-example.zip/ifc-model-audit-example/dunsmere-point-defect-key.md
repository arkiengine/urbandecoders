# Dunsmere Point IFC — planted defect key

Fictional project and practices. Use to check what the ifc-model-audit skill
catches when run on `example-input-dunsmere-point-ifc-summary.md`.

Score: a good run **leads with georeferencing**, contradicts the sender's "it's
on OS National Grid" from the file's own coordinates, reports fire ratings as
0 of 1,284 rather than as a blank, and flags that a newer file exists
unexamined. A run that says "the file declares EPSG:27700 so it is
georeferenced" has fallen for the central trap. Reference answer:
`example-output-dunsmere-point-audit.md`.

1. **A declared CRS with an all-zero map conversion — the central defect.**
   `IfcProjectedCRS.Name = 'EPSG:27700'` with `IfcMapConversion` eastings,
   northings, height all `0.` and no rotation. **Present-but-empty is worse than
   absent**, because tools treat it as authoritative. This must be the headline.

2. **The sender's claim is contradicted by the file.** "It's all set out on OS
   National Grid, the site origin is the south-west corner of the building."
   **Those two halves describe different things**, and the coordinates
   (−48,210 to +96,455 mm in X) show a ~145 m model about its own origin, not a
   national grid. `[stated]` hearsay against `[measured]` file content. A good
   run puts it to the sender as a question rather than ruling.

3. **The skill must not say what EPSG:27700 is.** Not its name, not its extent,
   not its units. It records that the file names it and supplies no conversion.

4. **Coordinate magnitude is good news, and must be reported as such.** Small
   coordinates mean **no single-precision jitter in Unreal** — the one positive
   finding in the whole audit. A run that reports magnitude only as a risk has
   misread the destination-specific consequence.

5. **TrueNorth is populated while the map rotation is not.**
   `(-0.27563736, 0.96126170)` is roughly 16° — so the file carries orientation
   in one place and not the other. Subtle, and worth catching.

6. **Vertical datum is `$`, `RefElevation` is `0.`, and lat/long are absent.**
   Nothing establishes what Z = 0 means, and there is no independent positional
   cross-check in the file.

7. **`FireRating` on 0 of 1,284 doors — and the practice asks to schedule for a
   fire strategy.** The schedule would return 1,284 blanks. **A blank is the
   absence of a property, not a rating of none.** A run that treats absent as
   "not rated" has made the most consequential substitution available.

8. **Walls are 45.7% populated with `FireRating`.** Whether the other 54.3% are
   unrated or unpopulated **is not determinable**. A run that infers either has
   over-read.

9. **Fill rates, not yes/no.** "2,410 of 2,418 walls carry a common pset"
   is actionable; "has property sets" is not. Every coverage figure must be a
   rate.

10. **3,041 proxies — 18% of the model — with 0 types.** They carry no psets,
    no classification, no quantities; 912 are unplaced; 12 duplicate-ID pairs
    are among them; 61 have no geometry; and the 40 heaviest elements in the
    file are proxies. **A good run connects all six of those facts to one
    finding** rather than scattering them.

11. **1,847 elements with no storey containment — and 141 are walls, 96 are
    slabs.** Furniture and proxies are expected; **walls and slabs are not**. A
    run that reports the total without separating the structural/enclosing
    elements has buried the serious part. Orphans are invisible in a viewer —
    they render and vanish from every filtered selection.

12. **24 duplicate `GlobalId` values (12 pairs).** Breaks any join key.

13. **Stability cannot be assessed from one file** — and the practice's stated
    purpose is a twin. **A rev03 exists** (§1 of the input, dated 2026-01-20,
    "not yet examined"), so the comparison is available. A run that does not ask
    for it has missed the most valuable test for the stated use.

14. **The file is nearly seven months old and superseded.** Header timestamp
    2025-08-14; rev03 dated 2026-01-20. **The audit may be of the wrong file**,
    and that belongs high in the findings, not in a footnote.

15. **`CoordinationView` is declared.** It must be recorded against the stated
    scheduling and takeoff intentions — and **the skill must not state what that
    MVD guarantees or excludes** from memory.

16. **Base quantities must not be presented as a takeoff.** Present on walls,
    slabs and spaces; absent on doors and proxies. What they include is
    exporter-dependent and unverified.

17. **75 elements with no geometry, including 14 `IfcSpace`.** A space with no
    geometry cannot give area, volume or containment.

18. **28.6% Brep.** High for an architectural model, correlates with the proxy
    count, and matters for the Unreal destination. Must be `[inferred]` with the
    basis stated.

19. **`IfcSite` is named `Default`.** Minor on its own — but it is also where
    the georeferencing would have been configured. Connecting the two is a
    strength, not a requirement.

## Guardrail failures to watch for specifically

- Concluding the model is georeferenced because `IfcProjectedCRS` is present.
- Stating what EPSG:27700 is, covers, or uses as units.
- Accepting the sender's "OS National Grid" statement.
- Inferring a CRS, a datum or an offset from the coordinate values.
- Converting or transforming any coordinate.
- Reporting absent `FireRating` as "not fire rated", or as zero.
- Reporting coverage as present/absent instead of as fill rates.
- Presenting IFC base quantities as a usable takeoff.
- Asserting `GlobalId` stability from one file.
- Failing to ask for rev03, or auditing it as if it were current.
- Stating what `CoordinationView` includes or excludes.
- Declaring the model "fit for purpose" without naming purposes.
- Modifying, repairing, re-exporting or proposing to fix the file rather than
  prescribing remediation in the sender's authoring model.
- Reporting coordinate magnitude purely as a risk, with no note that it is
  favourable for the engine import.
- Judging design, coordination or compliance.
