# Dunsmere Point IFC — audit

**File:** `DUN-ARC-ZZ-ZZ-M3-A-0001.ifc` · **Audited:** 3 March 2026
**File unmodified.**

---

## §1 — Verdict

**The single biggest problem: the file declares a coordinate reference system
it does not use.** `IfcProjectedCRS` names `EPSG:27700`, and the accompanying
`IfcMapConversion` is **all zeros** — no eastings, no northings, no height, no
rotation. **A present-but-empty map conversion is worse than none at all**,
because tools treat it as authoritative. Any twin, GIS overlay or engine import
built on this will place the building at the projection origin and nothing will
warn you.

**Safe to use for as it stands:** visual review and design coordination within
the model's own local frame.

**Not safe for:** georeferenced work of any kind, placement over a GIS basemap,
federation where the other model is georeferenced, door and window scheduling
for a fire strategy, quantity takeoff, or anything joining on `GlobalId`.

---

## §2 — Georeferencing and units — read first

**H-01 — Declared CRS without a map conversion.**

| Entity | Value | Reading |
|---|---|---|
| `IfcProjectedCRS.Name` | `'EPSG:27700'` | `[measured]` — a CRS is **named** |
| `IfcProjectedCRS.GeodeticDatum` | `$` | Not declared |
| `IfcProjectedCRS.VerticalDatum` | `$` | **Not declared** |
| `IfcProjectedCRS.MapUnit` | `$` | **Not declared** |
| `IfcMapConversion.Eastings` | `0.` | **Zero** |
| `IfcMapConversion.Northings` | `0.` | **Zero** |
| `IfcMapConversion.OrthogonalHeight` | `0.` | **Zero** |
| `XAxisAbscissa` / `XAxisOrdinate` | `1.` / `0.` | **No rotation applied** |

**This audit does not state what EPSG:27700 is, what it covers, or what its
units are.** It states that the file names it and supplies no conversion to it.

**H-02 — The sender's statement is contradicted by the file.** The transmittal
says *"It's all set out on OS National Grid, the site origin is the south-west
corner of the building."* Those two halves describe different things: a model
**on** a national grid carries large coordinates; a model whose origin is **the
south-west corner of the building** is in a local frame. **The file shows the
second.** Element placements run from −48,210 to +96,455 mm in X — that is a
model about 145 m across, centred near its own origin, not a model on a
national grid.

The sender's statement is `[stated]` hearsay. The file's own content is
`[measured]`. **They disagree, and this audit does not resolve which was
intended** — but nothing in the file supports the claim as written.

**H-03 — TrueNorth is set and the map conversion is not.**
`TrueNorth = (-0.27563736, 0.96126170)` is a rotation of roughly 16° west of
the model Y axis `[measured]`. So the file **does** carry an orientation, in
the model context, while carrying **no** rotation in the map conversion
(`XAxisAbscissa = 1`, `XAxisOrdinate = 0`). Two places that describe
orientation, one populated and one empty.

**H-04 — Vertical datum not declared, and `RefElevation = 0.`**
`IfcSite.RefElevation` is zero and `VerticalDatum` is `$`. Level 00 is at
elevation 0. Nothing establishes whether that is a site datum, a floor level,
or any height above a vertical reference. **`RefLatitude` and `RefLongitude`
are both absent**, so there is no independent positional cross-check in the
file at all.

**Units** `[measured]`: `LENGTHUNIT` is **millimetre**; area m²; volume m³;
angle degrees; context precision `1.0E-5`. Storey elevations are consistent
with millimetres (3600 spacing).

**Coordinate magnitude** `[measured]`: X −48.2 m to +96.5 m, Y −31.9 m to
+72.1 m, Z −4.5 m to +28.7 m. **Small coordinates, close to origin.**

**Consequence for the stated destination (§9.4 — Unreal over a GIS basemap):**
the magnitude is *good* news — this model will not suffer single-precision
jitter. **But it has no georeference**, so it cannot be placed over a basemap
without an offset that does not exist in the file. The offset must be obtained
from the sender and recorded as data. `[verify manually]`

---

## §3 — Provenance and identity

| Field | Value | Note |
|---|---|---|
| Schema | `IFC4` | `[measured]` |
| ViewDefinition | **`CoordinationView`** | **See H-05** |
| Exporter | IFC Exporter for Revit 23.2.0.0 | `[measured]` |
| Authoring tool | Autodesk Revit 2023 | `[measured]` |
| File timestamp | **2025-08-14** | **See H-06** |
| `IfcProject.LongName` | **empty** | Minor |
| `IfcSite.Name` | **`Default`** | The site has never been named `[inferred]` |

**H-05 — The declared MVD is a coordination view.** `CoordinationView` is
declared in the file header. **This audit does not state what that MVD
guarantees or excludes** — that is defined in the MVD documentation, not from
memory. It is recorded because the receiving practice intends scheduling and
takeoff (§9.3), and the declared view definition is the first thing to check
against those intentions. `[verify manually]`

**H-06 — The file is nearly seven months old, and a newer one exists.** The
header timestamp is **2025-08-14**. The project directory contains
`..._rev03.ifc` dated **2026-01-20**, **not examined** (§1 of the input).
**This audit is of the older file.** Auditing a superseded export and acting on
it is a waste of the audit. Obtain rev03 and re-run.

**H-07 — 24 duplicate `GlobalId` values (12 pairs), all
`IfcBuildingElementProxy`.** `[measured]` A `GlobalId` is the join key for any
asset register, twin or change comparison. Duplicates break it.

**H-08 — `GlobalId` stability cannot be assessed.** Only one file was examined.
**Stability across exports is only visible across two**, and it is the single
most important test for the twin workflow the practice describes. rev03 exists
— compare them.

---

## §4 — Spatial structure

Eight storeys, consistent 3600 mm spacing to Roof, then 1200 mm to
`T.O. Parapet` `[measured]`.

**H-09 — 1,847 elements are not contained in any storey.** `[measured]`

| Class | Orphaned |
|---|---|
| `IfcBuildingElementProxy` | 912 |
| `IfcFurnishingElement` | 486 |
| `IfcFlowTerminal` | 212 |
| **`IfcWall`** | **141** |
| **`IfcSlab`** | **96** |

**141 walls and 96 slabs with no storey containment is the serious part.**
Furniture and proxies are expected offenders; structural and enclosing elements
are not. Orphaned elements break federation filtering and storey-based views,
and they are **invisible in a viewer** — they appear on screen and vanish from
every filtered selection.

**I-01 — `IfcSite` is named `Default`.** Harmless on its own, consistent with
a site that was never configured — which is also where the georeferencing would
have been set.

---

## §5 — Entity census and the proxy problem

**H-10 — 3,041 `IfcBuildingElementProxy` with 0 types.** `[measured]`

That is **18% of the 16,781 elements in the file**, carrying:

- **0 property sets**
- **0 classification references**
- **0 base quantities**
- **912 of them not in any storey** (H-09)
- **12 duplicate-`GlobalId` pairs** (H-07)
- **61 with no geometric representation at all** (H-12)
- **the 40 heaviest elements in the file** (H-13)

A proxy is what an exporter produces when it cannot map a Revit category to an
IFC class. **Nearly a fifth of this model is unclassified, unquantified,
unpropertied and partly unplaced.** Whatever those elements are, nothing
downstream can filter, schedule or reason about them.

**M-01 — Occurrences without types.** Beyond the proxies, the census shows
healthy type counts for walls, doors, windows and so on. The proxies alone
carry no types.

---

## §6 — Classification and property coverage

Reported as **fill rates**, because a yes/no is not actionable.

| Class | Occurrences | Common pset | **FireRating** | Classification ref |
|---|---|---|---|---|
| `IfcWall` | 2,418 | 2,410 (99.7%) | **1,106 (45.7%)** | 884 (36.6%) |
| `IfcDoor` | 1,284 | 1,284 (100%) | **0 (0%)** | 400 (31.2%) |
| `IfcWindow` | 806 | 806 (100%) | — | **0 (0%)** |
| `IfcSlab` | 684 | 684 (100%) | 12 (1.8%) | **0 (0%)** |
| `IfcSpace` | 418 | 418 (100%) | — | **0 (0%)** |
| `IfcBuildingElementProxy` | 3,041 | **0 (0%)** | 0 | 0 |

**H-11 — `FireRating` is absent on every door in the file.** `[measured]`
**0 of 1,284.**

The practice asks (§9.3) whether they can schedule doors and windows for the
fire strategy. **They cannot schedule fire ratings from this file, because
there are none in it.** A schedule run against it would return 1,284 blank
cells — and **a blank cell is the absence of a property, not a rating of
none.** That substitution is how a fire door schedule ends up understating the
rated doors in a building.

Walls carry `FireRating` on 45.7%. Whether the missing 54.3% are non-rated or
simply unpopulated **is not determinable from this file**. `[verify manually]`

**Classification:** `Uniclass 2015` on 1,284 elements — **7.7% of the model**.
Zero coverage on windows, slabs and spaces.

---

## §7 — Quantities

| Class | With base quantities |
|---|---|
| `IfcWall` | 2,418 / 2,418 (100%) |
| `IfcSlab` | 684 / 684 (100%) |
| `IfcSpace` | 418 / 418 (100%) |
| **`IfcDoor`** | **0 / 1,284 (0%)** |
| **`IfcBuildingElementProxy`** | **0 / 3,041 (0%)** |

**M-02 — Base quantities are present on walls, slabs and spaces and absent on
doors and proxies.**

**This audit does not present any of them as a reliable takeoff.** What a
base quantity includes depends on the exporter and on how the authoring model
was built, and neither has been verified here. If a takeoff is intended, what
would have to be established first is: the exporter's quantity basis, whether
wall quantities are gross or net of openings, and what the 3,041 proxies
represent — because they contribute nothing and may be substantial. `[verify
manually]`

---

## §8 — Geometry representation

| Representation | Count | Share |
|---|---|---|
| `SweptSolid` | 7,106 | 41.4% |
| **`Brep`** | **4,912** | **28.6%** |
| `Clipping` | 2,884 | 16.8% |
| `MappedRepresentation` | 1,804 | 10.5% |
| **None** | **75** | 0.4% |

**H-12 — 75 elements have no geometric representation.** 61 proxies and
**14 `IfcSpace`**. A space with no geometry cannot be used for area, volume or
containment, and 14 of 418 spaces are in that state.

**H-13 — The 40 heaviest elements in the file are all proxies.** Named
`Assembly_01` to `Assembly_40`, all `Brep`. `[measured]` For the stated Unreal
destination (§9.4), Brep geometry tessellates heavily and these 40 unclassified
objects will dominate the triangle budget. **What they are is unknown**, which
means they cannot be excluded or simplified on any informed basis.

**28.6% Brep overall** is high for an architectural model and suggests geometry
that did not map to parametric IFC forms. `[inferred]` — the basis is the
representation census, and the correlation with the proxy count.

---

## §9 — Ranked risks

**High**

| # | Finding | What it breaks |
|---|---|---|
| H-01 | `IfcProjectedCRS` names EPSG:27700 with an all-zero `IfcMapConversion` | **All georeferenced use.** Tools treat it as authoritative and place the model at the projection origin |
| H-02 | The sender's "on OS National Grid" is contradicted by the file's own coordinates | The receiving practice's entire placement assumption |
| H-11 | `FireRating` on 0 of 1,284 doors | **The stated purpose of scheduling for a fire strategy** |
| H-10 | 3,041 proxies (18% of the model), 0 types, 0 properties, 0 quantities, 0 classification | Filtering, scheduling, takeoff, twin binding, polygon budget |
| H-09 | 1,847 elements with no storey containment, including 141 walls and 96 slabs | Federation filtering and storey views. Invisible in a viewer |
| H-07 | 24 duplicate `GlobalId` values | Any join key, asset register or change comparison |
| H-06 | File is from 2025-08-14 and a rev03 dated 2026-01-20 exists unexamined | The audit itself may be of a superseded file |
| H-08 | `GlobalId` stability unassessable from one file | The twin workflow the practice describes |

**Medium**

| # | Finding |
|---|---|
| H-03 | TrueNorth populated while the map conversion rotation is not |
| H-04 | Vertical datum not declared; `RefElevation = 0.`; no lat/long |
| H-05 | `CoordinationView` declared, against stated scheduling and takeoff intentions |
| H-12 | 75 elements with no geometry, including 14 spaces |
| H-13 | The 40 heaviest elements are unidentified proxies |
| M-02 | Base quantities absent on doors and proxies; present elsewhere but unverified |
| — | Classification coverage 7.7% overall; zero on windows, slabs and spaces |

**Info**

| # | Finding |
|---|---|
| I-01 | `IfcSite` named `Default`; `IfcProject.LongName` empty |
| I-02 | 28.6% Brep representation, high for an architectural model |

---

## §10 — The specific questions asked

**§9.1 — "Can we trust it?"** For visual review and coordination in its own
local frame, yes. For everything else the practice has named, no — see §1.

**§9.2 — "Will it federate with the structural model?"** Geometrically it will
open alongside one. **Positionally it will only align if the structural model
is in the same local frame with the same origin** — and this file supplies no
georeference to align against (H-01). If the structural model *is*
georeferenced, the two will not coincide. **Establish the origin with both
authors before federating**, and note that 1,847 elements will drop out of any
storey-based filter (H-09).

**§9.3 — "Can we schedule doors and windows for the fire strategy?"**
**Not for fire ratings. There are none in the file** — 0 of 1,284 doors carry
`FireRating` (H-11). A schedule will return blanks, and **a blank is not a
rating of none**. Doors also carry no base quantities (M-02) and 31.2%
classification. The door count itself is reliable; the properties a fire
strategy needs are absent.

**§9.4 — "Is the georeferencing OK for Unreal over a GIS basemap?"** No.
The file names a CRS and supplies a zeroed map conversion (H-01), no vertical
datum (H-04), and no lat/long. The *one* piece of good news is the coordinate
magnitude: at roughly 145 × 104 m about its own origin, **this model will not
jitter in a single-precision engine**. But it cannot be placed over a basemap
until an offset is obtained from the sender and recorded as data outside the
file.

**§9.5 — "The sender says it's on OS National Grid. Is it?"** **The file does
not support that.** A model on a national grid carries large coordinates; this
one runs −48 m to +96 m about its own origin. The sender's own sentence also
says the origin is the south-west corner of the building, which describes a
local frame. `[stated]` against `[measured]`, and the measurement should be put
to the sender as a question.

---

## §11 — What was not checked

- **`..._rev03.ifc` dated 2026-01-20** — not examined. The newer file may
  differ in every respect above.
- `GlobalId` persistence across exports — needs two files.
- Whether the geometry is correct, coordinated, buildable or compliant.
- Clash detection of any kind.
- What the 3,041 proxies and the 40 `Assembly_*` elements represent.
- Whether base quantities are gross or net, and on what basis the exporter
  produced them.
- What `CoordinationView` guarantees — the MVD documentation was not consulted
  and nothing is stated from memory.
- What EPSG:27700 is or covers.
- Whether the 54.3% of walls without `FireRating` are unrated or unpopulated.
- Material assignments, layer structure and construction build-ups.
- The structural model, which was not supplied.

**The verdict is only as good as this list — and the first item on it may
invalidate the whole audit.**
