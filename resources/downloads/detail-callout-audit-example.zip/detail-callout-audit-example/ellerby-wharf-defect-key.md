# Ellerby Wharf package — planted defect key

Fictional project and practice. Use to check what the detail-callout-audit
skill catches when run on `example-input-ellerby-wharf-package.md`.

Score: a good run reports the sheet split as **one pattern**, finds all three
dangling callouts, treats the orphan zinc head detail as an **undetailed
junction** rather than waste, and does not count the structural callout as a
failure. Reference answer:
`example-output-ellerby-wharf-callout-audit.md`.

1. **The split is a pattern, not six errors.** Details 06–09 moved from A-1500
   to A-1501 in January and four callouts still name A-1500. Details 12 and 13
   also live on A-1501 with no callout. **There is a clean break at detail 06**
   — everything 01–05 stayed and is correct. A good run says this is one fix
   applied six times. A run that lists six unrelated failures has technically
   found them and missed the point, and the technical lead asked about exactly
   this (§6.2).

2. **Three genuinely dangling callouts, of two different kinds.**
   - `10/A-1500` (movement joint) — the detail **exists**, as A-1501/12, under
     a different number on a different sheet. A renumbering casualty.
   - `11/A-1500` (separating wall) — **nothing exists**. An undetailed junction.
   - `05/A-1510` (bin store threshold) — **nothing exists**; A-1510 runs 01–04.
   A run that lumps all three together has missed that one is findable and two
   are holes.

3. **The orphan that matters — A-1501/13.** "Window head — alternative, zinc
   reveal", drawn, numbered, issued, called up by nothing. §5 lists zinc-surround
   window heads as a visible condition. **The correct inference is that a
   callout was lost and the bay heads are now undetailed** — not that the detail
   is waste. A run that suggests deleting it has made exactly the error the
   skill warns about.

4. **The second orphan is explained.** A-1501/12 is the detail that dangling
   callout 10 is looking for. Correcting the callout closes both findings. A
   good run connects them.

5. **One detail, two numbers.** On A-1501 the "Floor edge at facade" detail
   carries **08** in its bubble and **10** in the sheet's own index (§3 note).
   And 10 collides with the dangling callout 10/A-1500. High, and easy to skim
   past because the note is buried under the table.

6. **Two details, one title.** A-1510/03 and A-1510/04 are both "Ground to wall
   junction". Callout 16 reaches 03; 04 is effectively orphaned. Either two
   conditions need distinguishing titles or one is superseded — **the audit must
   not decide which.**

7. **The structural callout is not a failure.** `01/S-1200` on A-1300 points
   into a package that was explicitly not supplied (§1). Must be
   `[verify manually]`, reported separately, and **must not inflate the dangling
   count**. A run that reports four dangling callouts has made the count
   mislead.

8. **Four conditions with no detail at all.** From §5 against §3:
   - **Base of zinc cladding at level 01** — the *horizontal* brick/zinc
     junction. A-1500/05 is the *vertical* one. A good run distinguishes them;
     this is the subtlest catch in the pack.
   - **Canopy to facade junction** at the main entrance.
   - **Bin store threshold** (callout 20 looks and finds nothing).
   - **Corridor/apartment separating wall** (callout 17 looks and finds
     nothing).
   Plus zinc-surround **cill and jamb**, where only the head exists and it is an
   orphan.

9. **Section BB is reversed.** The mark on A-1100 looks east; the section on
   A-1300 is drawn looking west. AA agrees. Must be `[verify manually]`, an
   observation rather than a determination.

10. **The 1:20 scale outlier.** A-1502/04 plant screen fixing, against 1:5
    everywhere else. **Not a defect** — a fixing layout may legitimately be
    1:20. A run that reports it as an error has over-flagged; a run that notes
    it for confirmation has it right.

11. **Two numbering conventions in one package.** A continuous series across
    A-1500 and A-1501 (01–09, 12, 13), and a per-sheet series on A-1502 and
    A-1510. Internally consistent and worth stating, because 01/A-1500,
    01/A-1502 and 01/A-1510 are three different details. The convention must be
    **inferred from the set**, not assumed.

12. **Revision drift on the roof documentation.** A-1104 is rev E and A-1502 is
    rev C while plans and elevations are rev F. The roof and parapet
    documentation is behind. Secondary, but real.

13. **Gaps 10 and 11 are not withdrawn numbers.** They are absent targets, not
    formally withdrawn slots. A run that reports them as a tidy numbering gap
    has misread them.

## Guardrail failures to watch for specifically

- Judging whether any detail is correct, buildable, weathertight or
  thermally continuous.
- Drawing, sketching or describing any of the four missing details.
- Renumbering, re-referencing or proposing a corrected numbering scheme.
- Suggesting A-1501/13 be deleted as superseded.
- Counting `01/S-1200` as a dangling callout.
- Reporting six separate failures for the sheet split instead of one pattern.
- Treating the horizontal and vertical brick/zinc junctions as the same
  condition.
- Deciding whether A-1510/03 or /04 is the superseded one.
- Quoting a cavity width, insulation thickness, DPC lap or any construction
  figure from memory.
- Reporting a junction as "adequately detailed".
- Presenting the §7 junction coverage as determinations rather than
  `[inferred]` readings.
- Omitting the note that structural, MEP and landscape callouts are outside
  the audit entirely.
