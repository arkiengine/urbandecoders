# Ellerby Wharf — detail callout audit

**Audited:** 26 February 2026. **Package purpose: issue for construction.**

---

## §1 — Verdict

**Not cross-referenced well enough to issue for construction.**

The single biggest problem is a **pattern, not a list**: the January split of
A-1500 into A-1500 and A-1501 moved six details and **the callouts were never
updated**. Six callouts on three different sheets still point at A-1500 for
details that now live on A-1501. That is one fix, applied six times — and it is
the thing the technical lead suspected (§6.2).

Beyond the pattern: **one callout points at a detail that does not exist
anywhere** (10/A-1500), **two details are called up by nothing**, **two details
on A-1510 share a title and a subject**, one detail carries **two different
numbers**, and **two junctions visible on the elevations have no detail at
all**.

---

## §2 — Callout map

| # | Callout | On sheet | At | Points to | Target found | Status |
|---|---|---|---|---|---|---|
| 1 | 01/A-1500 | A-1200 | Grid C, eaves | A-1500 | A-1500/01 Eaves detail | `[found]` |
| 2 | 02/A-1500 | A-1200 | Grid C, window head | A-1500 | A-1500/02 Window head | `[found]` |
| 3 | 03/A-1500 | A-1200 | Grid C, window cill | A-1500 | A-1500/03 Window cill | `[found]` |
| 4 | 04/A-1500 | A-1200 | Grid F, window jamb | A-1500 | A-1500/04 Window jamb | `[found]` |
| 5 | 05/A-1500 | A-1201 | Grid B, brick/zinc | A-1500 | A-1500/05 Brick to zinc | `[found]` |
| 6 | 06/A-1500 | A-1201 | Grid D, balcony edge | A-1500 | **on A-1501** | **`[wrong sheet]`** |
| 7 | 07/A-1500 | A-1201 | Grid G, bay reveal | A-1500 | **on A-1501** | **`[wrong sheet]`** |
| 8 | 08/A-1500 | A-1300 | AA, floor edge | A-1500 | **on A-1501** | **`[wrong sheet]`** + `[ambiguous]` — see H-03 |
| 9 | 09/A-1500 | A-1300 | AA, soffit | A-1500 | **on A-1501** | **`[wrong sheet]`** |
| 10 | 10/A-1500 | A-1300 | BB, movement joint | A-1500 | **no detail 10 on any sheet** | **`[not found]`** — see H-02 |
| 11 | 01/A-1502 | A-1104 | Parapet, north | A-1502 | A-1502/01 | `[found]` |
| 12 | 02/A-1502 | A-1104 | Parapet, corner | A-1502 | A-1502/02 | `[found]` |
| 13 | 03/A-1502 | A-1104 | Rooflight upstand | A-1502 | A-1502/03 | `[found]` |
| 14 | 01/A-1510 | A-1100 | Entrance threshold | A-1510 | A-1510/01 | `[found]` |
| 15 | 02/A-1510 | A-1100 | Terrace threshold | A-1510 | A-1510/02 | `[found]` |
| 16 | 03/A-1510 | A-1100 | Ground/wall junction | A-1510 | A-1510/03 **and /04** | **`[ambiguous]`** — see H-04 |
| 17 | 11/A-1500 | A-1101 | Separating wall | A-1500 | **no detail 11 on any sheet** | **`[not found]`** — see H-02 |
| 18 | 04/A-1502 | A-1104 | Plant screen fixing | A-1502 | A-1502/04 | `[found]` |
| 19 | 01/S-1200 | A-1300 | Transfer structure | **S-1200** | — | **`[verify manually]`** — see §6 |
| 20 | 05/A-1510 | A-1100 | Bin store threshold | A-1510 | **no detail 05 on A-1510** | **`[not found]`** — see H-02 |

**20 callouts: 11 `[found]`, 4 `[wrong sheet]`, 3 `[not found]`, 1
`[ambiguous]`, 1 `[verify manually]`.**

---

## §3 — The sheet split — a pattern, not six errors

**H-01.** Details 06, 07, 08 and 09 were on A-1500 and are now on A-1501
(§3 of the input). **Four callouts still name A-1500** — callouts 6, 7, 8 and
9, on sheets A-1201 and A-1300.

Details 12 and 13 are also on A-1501 and are called up by nothing (§5).

The technician's note says "most of the references were updated" (§1). The
audit confirms which were not: **everything numbered 06 and above that moved.**
Callouts 1–5, which point at details that stayed on A-1500, are all correct.
There is a clean break at detail 06.

**This is one change to make, in one place, six times** — and it is a different
problem from four unrelated dangling callouts. Fix the split consistently
rather than chasing individual references.

---

## §4 — Dangling callouts

**H-02 — Three callouts point at details that do not exist on any supplied
sheet.**

| Callout | On | Subject | What exists |
|---|---|---|---|
| **10/A-1500** | A-1300, section BB | Brick movement joint | A detail titled "Brick movement joint" exists — as **A-1501/12**. The callout names a number (10) that no detail carries, on a sheet (A-1500) that no longer holds it. |
| **11/A-1500** | A-1101, corridor/apartment separating wall | Separating wall | **No detail of a separating wall exists anywhere in the package.** See §7. |
| **05/A-1510** | A-1100, bin store threshold | Bin store threshold | **No detail 05 on A-1510.** The sheet runs 01 to 04. |

10/A-1500 is a renumbering casualty: the detail moved sheet *and* changed
number (10 → 12). 11/A-1500 and 05/A-1510 are different — there is nothing to
find.

---

## §5 — Orphan details

**M-01 — Two details are called up by nothing.**

| Detail | Title | Called up by |
|---|---|---|
| A-1501/12 | Brick movement joint | **Nothing.** Callout 10 names 10/A-1500 — see H-02 |
| A-1501/13 | Window head — alternative, zinc reveal | **Nothing at all** |

A-1501/12 is explained: it is the same detail the dangling callout 10 is
looking for, under a different number on a different sheet. Correcting callout
10 to `12/A-1501` closes both findings at once.

**A-1501/13 is the one to look at.** "Window head — alternative, zinc reveal"
is drawn, numbered and on an issued sheet, and **no drawing calls it up**.
§5 of the input lists "window heads, cills, jambs — zinc surround, recessed
bays" as a visible condition on the elevations. So either:

- a callout for the zinc window head was lost, and **the recessed bay window
  heads are now undetailed on the drawings**; or
- the detail is superseded and should be withdrawn.

**Do not assume the second.** On the evidence here the first is more consistent
with §5, and that makes this an undetailed junction rather than wasted effort.

---

## §6 — Duplicates, collisions and numbering

**H-03 — One detail, two numbers.** On A-1501, the detail titled "Floor edge at
facade" carries **08** in its bubble and is listed as **10** in the sheet's own
drawing index (§3 note). A contractor resolving callout 8 reaches it by bubble;
anyone reading the index reaches a number that also collides with the dangling
callout 10/A-1500 (H-02). **High.**

**H-04 — Two details, one subject.** A-1510/03 "Ground to wall junction" and
A-1510/04 "Ground to wall junction" are separately numbered with the **same
title**. Callout 16 names 03/A-1510, so 03 is reached and 04 is effectively an
orphan with a colliding title. Either they are different conditions that need
distinguishing titles, or one is superseded. **The audit does not determine
which.**

**Numbering convention `[inferred]`:** `<detail no.>/<sheet>`, details numbered
in a single series that runs **across** A-1500 and A-1501 (01–05 on 1500, 06–09
and 12–13 on A-1501), and restarts per sheet for A-1502 and A-1510. That is two
conventions in one package — a continuous series for the external wall sheets
and a per-sheet series for the others. It is internally consistent and worth
stating, because 01/A-1500, 01/A-1502 and 01/A-1510 are three different
details.

**Gaps in the external wall series: 10 and 11.** Both are callout targets that
do not exist (H-02). Neither is a withdrawn number with a register entry —
they are simply absent.

---

## §7 — Junction coverage

**`[inferred]` throughout.** This is a reading of the conditions visible on the
supplied drawings, not a determination of what this building needs. A technical
lead should treat it as a conversation, not a defect list.

| Condition (from §5) | Detail exists | Reached by a callout |
|---|---|---|
| Eaves at main roof | A-1500/01 | Yes |
| Parapet at roof terrace | A-1502/01 | Yes |
| Parapet at plant enclosure | A-1502/02 (corner) | **Unclear — 02 is titled "corner", not "plant enclosure"** |
| Window head/cill/jamb — brick | A-1500/02, 03, 04 | Yes |
| **Window head — zinc, recessed bays** | **A-1501/13** | **No — orphan (M-01)** |
| Window cill/jamb — zinc, recessed bays | **None** | — |
| Brick to zinc vertical junction | A-1500/05 | Yes |
| Brick movement joint | A-1501/12 | **No — callout dangles (H-02)** |
| Balcony edge | A-1501/06 | Yes, wrong sheet |
| Undercroft soffit | A-1501/09 | Yes, wrong sheet |
| Floor edge at facade | A-1501/08 | Yes, wrong sheet, two numbers |
| **Base of zinc cladding at level 01 — zinc meets brick horizontally** | **None found** | **— see M-02** |
| Main entrance threshold | A-1510/01 | Yes |
| Level threshold to terrace | A-1510/02 | Yes |
| Ground to wall junction | A-1510/03 and /04 | Ambiguous (H-04) |
| **Bin store threshold** | **None found** | Callout dangles (H-02) |
| Rooflight upstand | A-1502/03 | Yes |
| Plant screen fixing | A-1502/04 | Yes |
| **Canopy to facade junction, main entrance** | **None found** | **— see M-02** |
| **Corridor/apartment separating wall** | **None found** | Callout dangles (H-02) |

**M-02 — Four conditions visible on the drawings have no detail at all:**

1. **Base of zinc cladding at level 01** — a horizontal brick/zinc junction.
   A-1500/05 details the *vertical* junction; the horizontal one is a different
   condition and nothing covers it.
2. **Canopy to facade junction at the main entrance.**
3. **Bin store threshold** — callout 20 looks for it and finds nothing.
4. **Corridor/apartment separating wall** — callout 17 looks for it and finds
   nothing.

Plus: **zinc-surround cill and jamb** have no detail, while the zinc head
detail exists but is an orphan (M-01).

---

## §8 — Direction and scale

**M-03 — Section BB cut direction disagrees.** The mark on A-1100 is drawn
**looking east**; section BB on A-1300 is **drawn looking west** (§4 of the
input). Section AA agrees. `[verify manually]` — this is an observation worth
the author's eye, not a determination, but a reversed section in a construction
issue is read by someone eventually.

**I-01 — Scale outlier.** A-1502/04 "Plant screen fixing" is at **1:20**;
every other detail in the package is at 1:5. Not a defect in itself — a fixing
layout may legitimately be at 1:20 — but it is the only one, and it is worth
confirming it is deliberate. `[verify manually]`

---

## §9 — Consultant packages

**Callout 19 (01/S-1200, transfer structure at level 01, on A-1300) is not a
dangling callout.** The structural package was not supplied (§1). It is
`[verify manually]` and is reported here, separately, so it does not inflate
the failure count.

**One callout of twenty points into a package outside this audit.** Structural,
MEP and landscape packages were all excluded, so there may be further
architectural callouts into them that the supplied sheets do not show, and
there will certainly be consultant callouts into the architectural sheets that
this audit cannot see.

---

## §10 — Ranked findings

**High**

| # | Finding | What it breaks |
|---|---|---|
| H-01 | Four callouts still name A-1500 for details now on A-1501 | Contractor cannot find four details; one fix, six instances |
| H-02 | Three callouts point at details that do not exist | Two are undetailed junctions; one is a renumbering casualty |
| M-02 | Four visible conditions with no detail at all | Undetailed junctions in a construction issue |
| H-03 | A-1501 floor edge carries 08 in the bubble and 10 in the index | Ambiguous reference; collides with dangling callout 10 |
| H-04 | A-1510/03 and /04 share a title | Contractor may reach either |

**Medium**

| # | Finding |
|---|---|
| M-01 | Two orphan details; A-1501/13 points at a lost callout, not wasted effort |
| M-03 | Section BB cut direction reversed |
| M-04 | A-1104 is rev E and A-1502 is rev C, while the plans and elevations are rev F — the roof and parapet documentation is two revisions behind |

**Info**

| # | Finding |
|---|---|
| I-01 | A-1502/04 at 1:20 against 1:5 everywhere else |
| I-02 | Two numbering conventions in one package — continuous for A-1500/1501, per-sheet for A-1502/A-1510 |
| I-03 | One callout into the unsupplied structural package |

---

## §11 — The specific questions asked

**§6.2 — "Did the references survive the split?"** Partly. Everything numbered
01–05 stayed on A-1500 and its callouts are correct. **Everything from 06
upward moved, and none of those callouts were updated** — four point at the
wrong sheet, and details 12 and 13 ended up with no callout at all. There is a
clean break at detail 06, which makes it one fix rather than six.

**§6.3 — "Which details does nothing call up?"** Two: A-1501/12 (brick movement
joint) and A-1501/13 (zinc window head alternative). A-1510/04 is effectively a
third. **A-1501/13 is the one to look at** — see M-01.

**§6.4 — "Which junctions have no detail at all?"** Four, plus the zinc cill
and jamb. See M-02 and §7. The zinc horizontal base junction and the entrance
canopy are the two that nothing in the package even gestures at.

---

## §12 — What was not checked

- **Whether any detail is correct, buildable, weathertight, thermally
  continuous, fire-stopped or compliant.** This audit resolves references and
  surveys coverage. It does not review design.
- Whether the details match the specification.
- Structural, MEP and landscape packages, and every callout between them and
  these sheets.
- Whether A-1104 and A-1502 at their lower revisions are superseded.
- Whether the conditions listed in §5 are the complete set this building has —
  that list is itself read from the supplied drawings.
- Drawing content, dimensions and annotation beyond the callouts and titles.
