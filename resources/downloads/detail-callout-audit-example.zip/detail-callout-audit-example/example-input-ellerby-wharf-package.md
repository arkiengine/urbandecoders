# Ellerby Wharf — technical package, callout and detail listing

**Project:** Ellerby Wharf, Marlden — 5-storey mixed-use, brick and zinc
**Package:** architectural technical package, issue for construction
**Date:** 26 February 2026

*Fictional project. Deliberately imperfect.*

---

## §1 — Sheets supplied

| Sheet | Title | Rev |
|---|---|---|
| A-1100 | Ground floor plan | F |
| A-1101 | Typical upper floor plan | F |
| A-1104 | Roof plan | E |
| A-1200 | Elevations — north, east | F |
| A-1201 | Elevations — south, west | F |
| A-1300 | Sections AA, BB | E |
| A-1500 | Details — external wall sheet 1 | D |
| A-1501 | Details — external wall sheet 2 | D |
| A-1502 | Details — roof and parapet | C |
| A-1510 | Details — thresholds and ground | B |

**Not supplied:** structural package (S-series), MEP package (M-series),
landscape package (L-series).

**Note from the technician:** "We split the old A-1500 into 1500 and 1501 in
January. Most of the references were updated."

---

## §2 — Callouts harvested from the drawings

| # | Callout ref | On sheet | At location | Points to |
|---|---|---|---|---|
| 1 | 01/A-1500 | A-1200 | Grid C, eaves | A-1500 |
| 2 | 02/A-1500 | A-1200 | Grid C, window head | A-1500 |
| 3 | 03/A-1500 | A-1200 | Grid C, window cill | A-1500 |
| 4 | 04/A-1500 | A-1200 | Grid F, window jamb | A-1500 |
| 5 | 05/A-1500 | A-1201 | Grid B, brick/zinc junction | A-1500 |
| 6 | 06/A-1500 | A-1201 | Grid D, balcony edge | A-1500 |
| 7 | 07/A-1500 | A-1201 | Grid G, recessed bay reveal | A-1500 |
| 8 | 08/A-1500 | A-1300 | Section AA, floor edge | A-1500 |
| 9 | 09/A-1500 | A-1300 | Section AA, soffit | A-1500 |
| 10 | 10/A-1500 | A-1300 | Section BB, movement joint | A-1500 |
| 11 | 01/A-1502 | A-1104 | Parapet, north | A-1502 |
| 12 | 02/A-1502 | A-1104 | Parapet, corner | A-1502 |
| 13 | 03/A-1502 | A-1104 | Rooflight upstand | A-1502 |
| 14 | 01/A-1510 | A-1100 | Main entrance threshold | A-1510 |
| 15 | 02/A-1510 | A-1100 | Level threshold to terrace | A-1510 |
| 16 | 03/A-1510 | A-1100 | Ground/wall junction | A-1510 |
| 17 | 11/A-1500 | A-1101 | Corridor/apartment separating wall | A-1500 |
| 18 | 04/A-1502 | A-1104 | Plant screen fixing | A-1502 |
| 19 | 01/S-1200 | A-1300 | Transfer structure at level 01 | **S-1200** |
| 20 | 05/A-1510 | A-1100 | Bin store threshold | A-1510 |

---

## §3 — Details found on the detail sheets

| Sheet | Detail no. in bubble | Title as drawn | Stated scale |
|---|---|---|---|
| A-1500 | 01 | Eaves detail | 1:5 |
| A-1500 | 02 | Window head | 1:5 |
| A-1500 | 03 | Window cill | 1:5 |
| A-1500 | 04 | Window jamb | 1:5 |
| A-1500 | 05 | Brick to zinc junction | 1:5 |
| A-1501 | 06 | Balcony edge | 1:5 |
| A-1501 | 07 | Recessed bay reveal | 1:5 |
| A-1501 | 08 | Floor edge at facade | 1:5 |
| A-1501 | 09 | Soffit at undercroft | 1:5 |
| A-1501 | 12 | Brick movement joint | 1:5 |
| A-1501 | 13 | Window head — alternative, zinc reveal | 1:5 |
| A-1502 | 01 | Parapet — typical | 1:5 |
| A-1502 | 02 | Parapet — corner | 1:5 |
| A-1502 | 03 | Rooflight upstand | 1:5 |
| A-1502 | 04 | Plant screen fixing | **1:20** |
| A-1510 | 01 | Main entrance threshold | 1:5 |
| A-1510 | 02 | Level threshold to terrace | 1:5 |
| A-1510 | 03 | Ground to wall junction | 1:5 |
| A-1510 | 04 | **Ground to wall junction** | 1:5 |

**Title block note on A-1501:** the sheet title block reads "Details —
external wall sheet 2", and the detail bubble for the item titled "Floor edge
at facade" reads **08**, while the **drawing index on A-1501 lists it as 10**.

---

## §4 — Section marks

| Mark | On sheet | Cut direction as drawn | Section reached |
|---|---|---|---|
| AA | A-1100 | Looking **north** | A-1300 section AA, drawn looking north |
| BB | A-1100 | Looking **east** | A-1300 section BB, **drawn looking west** |

---

## §5 — Conditions visible on the elevations and sections

From A-1200, A-1201, A-1300:

- Eaves at the main roof
- Parapet at the roof terrace
- Parapet at the plant enclosure
- Window heads, cills, jambs — brick surround
- Window heads, cills, jambs — **zinc surround, recessed bays**
- Brick to zinc vertical junction
- Brick movement joints
- Balcony edge and soffit
- Undercroft soffit
- Floor edge at facade
- **Base of zinc cladding at level 01 — where zinc meets brick horizontally**
- Main entrance threshold
- Level threshold to terrace
- Ground to wall junction
- Bin store threshold
- Rooflight upstand
- Plant screen fixing
- **Canopy to facade junction at the main entrance**

---

## §6 — What the technical lead has asked for

1. "Audit the callouts before this goes out for construction."
2. "We split 1500 into 1500 and 1501 in January. Did the references survive?"
3. "Which details does nothing call up?"
4. "Which junctions have no detail at all?"
