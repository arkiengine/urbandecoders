# Garnett Street — RFIs received, week commencing 16 February 2026

**Project:** Garnett Street, Marlden — 22 apartments over retail
**Contractor:** Pellow Construction Ltd
**Contract administrator:** Vale & Hartnoll Architects

*Fictional project and contractor. Deliberately imperfect.*

---

## §1 — RFIs as received

### PCL-RFI-0041
**Subject:** Clarification — apartment entrance door ironmongery
**Received:** 16.02.26 · **Response required:** 20.02.26
> Please confirm the ironmongery set for apartment entrance doors. The door
> schedule A-1401 rev C refers to "IM set 2" but we do not have an ironmongery
> schedule. Please issue.

### PCL-RFI-0042
**Subject:** Query — level 03 bathroom layout
**Received:** 16.02.26 · **Response required:** 19.02.26
> Drawing A-1102 rev E shows the level 03 bathroom with the WC against the
> party wall. The SVP is shown on A-1102 in the opposite corner. Please confirm
> the intended position.

### PCL-RFI-0043
**Subject:** Clarification — window cill material
**Received:** 17.02.26 · **Response required:** 21.02.26
> Spec L10 clause 340 states precast concrete cills. Drawing A-1500 detail 03
> shows a brick soldier course cill. Please confirm which applies.

### PCL-RFI-0044
**Subject:** Clarification — rainwater goods
**Received:** 17.02.26 · **Response required:** 24.02.26
> The specified cast aluminium rainwater goods have a 14-week lead time which
> will not meet the programme. We propose extruded aluminium to the same
> profile and colour, available in 3 weeks. **Please confirm acceptability.**

### PCL-RFI-0045
**Subject:** Clarification — retail unit shopfront setting out
**Received:** 18.02.26 · **Response required:** 20.02.26
> Please confirm the setting out dimension from grid A to the shopfront
> centre line. This is dimensioned 4,250 on A-1100 rev F and 4,500 on A-1200
> rev F.

### PCL-RFI-0046
**Subject:** Clarification — balcony soffit finish
**Received:** 18.02.26 · **Response required:** 20.02.26
> The balcony soffit finish is not specified. We have assumed painted render
> to match the main soffit and have priced accordingly. **Please confirm we
> should proceed on that basis.**

### PCL-RFI-0047
**Subject:** Query — level 02 riser access
**Received:** 19.02.26 · **Response required:** 21.02.26
> Further to our letter of 3 February regarding the late issue of the MEP
> coordination drawings, we note that the level 02 riser as shown on A-1101
> rev F does not accommodate the services shown on M-2101 rev C, which was
> issued on 30 January, four weeks after the date required by the information
> release schedule. Please advise how to proceed. We reserve our position in
> respect of time and cost.

### PCL-RFI-0048
**Subject:** Clarification — kitchen worktop
**Received:** 19.02.26 · **Response required:** 25.02.26
> Spec N10 clause 120 states "laminate worktop, 40 mm, supplier's standard
> range". Please confirm colour.

### PCL-RFI-0049
**Subject:** Clarification — external wall insulation
**Received:** 20.02.26 · **Response required:** 24.02.26
> Spec M60 states 100 mm full fill mineral wool. Detail A-1500/01 shows a
> 100 mm cavity with 100 mm insulation. Detail A-1500/05 shows a 150 mm cavity
> with 100 mm insulation and a 50 mm clear cavity. Please confirm which applies
> at the brick/zinc junction.

### PCL-RFI-0050
**Subject:** Clarification — stair nosing
**Received:** 20.02.26 · **Response required:** 26.02.26
> Please confirm the stair nosing detail and contrast requirement for the
> common stair.

### PCL-RFI-0051
**Subject:** Query — retail unit floor level
**Received:** 20.02.26 · **Response required:** 21.02.26
> Further to the above, the retail unit floor level is shown as 24.150 on
> A-1100 rev F and 24.100 on A-1300 rev E. We have set out to 24.150. Please
> confirm.

### PCL-RFI-0052
**Subject:** Clarification — balcony balustrade fixing
**Received:** 20.02.26 · **Response required:** 27.02.26
> Detail A-1501/06 shows the balustrade fixed to the slab edge. There is no
> detail for the fixing at the balcony to facade junction. Please issue.

---

## §2 — Issued documents available to the CA

| Ref | Document | Rev | Issued |
|---|---|---|---|
| A-1100 | Ground floor plan | F | 06.02.26 |
| A-1101 | Typical upper floor plan | F | 06.02.26 |
| A-1102 | Level 03 plan | E | 28.01.26 |
| A-1200 | Elevations | F | 06.02.26 |
| A-1300 | Sections | E | 28.01.26 |
| A-1401 | Door schedule | C | 06.02.26 |
| A-1500 | Details sheet 1 | D | 06.02.26 |
| A-1501 | Details sheet 2 | D | 06.02.26 |
| SPEC | Specification | rev 4 | 15.01.26 |

**Relevant contents, verified:**
- A-1100 rev F: grid A to shopfront centre line dimensioned **4,250**. Retail
  floor level **24.150**.
- A-1200 rev F: grid A to shopfront centre line dimensioned **4,500**.
- A-1300 rev E: retail floor level **24.100**.
- A-1102 rev E: level 03 bathroom WC against party wall; SVP shown opposite
  corner.
- Spec L10 cl.340: "Precast concrete cills, 150 × 90, throated."
- A-1500/03: brick soldier course cill.
- Spec M60: "100 mm full fill mineral wool."
- A-1500/01: 100 mm cavity, 100 mm insulation.
- A-1500/05: 150 mm cavity, 100 mm insulation, 50 mm clear cavity.
- Spec N10 cl.120: "Laminate worktop, 40 mm, supplier's standard range.
  **Colour: Marlden Grey.**"
- **No ironmongery schedule has been issued.**
- **No balcony soffit finish is specified anywhere.**
- **No stair nosing detail exists; spec contains no nosing clause.**
- **No balcony-to-facade balustrade fixing detail exists.**

---

## §3 — What the CA has asked for

1. "Log and triage this week's RFIs."
2. "Draft responses for anything already answered."
3. "Which of these are variations or substitutions? Don't draft those."
4. "Six RFIs about junctions — is there an underlying problem?"
