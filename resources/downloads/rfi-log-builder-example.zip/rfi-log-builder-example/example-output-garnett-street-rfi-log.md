# Garnett Street — RFI log and draft response pack

**Week commencing:** 16 February 2026. **Prepared:** 20 February 2026.
**12 RFIs received (PCL-RFI-0041 to 0052).**

> **Contractor references are preserved exactly as received.** Nothing has been
> renumbered.

---

## §1 — Triage summary

| Type | Count | Refs |
|---|---|---|
| `information` — drafted | **4** | 0045, 0048, 0049, 0051 |
| `design gap` — routed, not drafted | **5** | 0041, 0046, 0050, 0052, and 0042 |
| `substitution` — **not drafted** | **1** | 0044 |
| `instruction sought` — **not drafted** | **1** | 0046 (also a design gap — see §3) |
| `record building` — **not drafted** | **1** | 0047 |
| `conflict in issued documents` | **3** | 0043, 0045, 0049, 0051 (see note) |

### Must not be answered without a human decision — read these first

| Ref | Why |
|---|---|
| **0044** | **Substitution.** "Please confirm acceptability" of extruded aluminium in place of specified cast aluminium. Answering "yes" is an approval with specifier consequences. |
| **0046** | **Instruction sought.** "Please confirm we should proceed on that basis." A prose answer may constitute an instruction for an unspecified finish the contractor has already priced. |
| **0047** | **Record building.** Asserts late issue of MEP drawings against the information release schedule, and expressly reserves position on time and cost. |
| **0043** | Spec and drawing give two different cills. Both contractual. Design decision. |

---

## §2 — The log

| Ref | Date | Subject | Type | Element | Document referenced | Owner | Status | Required | Days out | Exposure |
|---|---|---|---|---|---|---|---|---|---|---|
| PCL-RFI-0041 | 16.02 | Apartment door ironmongery | `design gap` | Doors | A-1401 rev C | Architect | Routed | 20.02 | **0** | Scope — no schedule exists |
| PCL-RFI-0042 | 16.02 | L03 bathroom / SVP | `design gap` | Drainage | A-1102 rev E | Architect + MEP | Routed | 19.02 | **1 overdue** | Coordination |
| PCL-RFI-0043 | 17.02 | Window cill material | `design gap` | Facade | Spec L10 cl.340 / A-1500/03 | Architect | Routed | 21.02 | — | **Conflict in issued documents** |
| PCL-RFI-0044 | 17.02 | Rainwater goods | **`substitution`** | RWG | Spec R12 | **Specifier + CA** | **Not drafted** | 24.02 | — | **Approval · programme · cost** |
| PCL-RFI-0045 | 18.02 | Shopfront setting out | `information` | Setting out | A-1100 F / A-1200 F | Architect | **Drafted** | 20.02 | **0** | **Conflict in issued documents** |
| PCL-RFI-0046 | 18.02 | Balcony soffit finish | **`instruction sought`** + `design gap` | Finishes | — | **CA** | **Not drafted** | 20.02 | **0** | **Instruction · cost · already priced** |
| PCL-RFI-0047 | 19.02 | L02 riser access | **`record building`** | Services | A-1101 F / M-2101 C | **CA** | **Not drafted** | 21.02 | — | **Time · cost · position reserved** |
| PCL-RFI-0048 | 19.02 | Kitchen worktop colour | `information` | Fit-out | Spec N10 cl.120 | Architect | **Drafted** | 25.02 | — | — |
| PCL-RFI-0049 | 20.02 | External wall insulation | `information` | Facade | Spec M60 / A-1500/01, /05 | Architect | **Drafted** | 24.02 | — | — |
| PCL-RFI-0050 | 20.02 | Stair nosing | `design gap` | Stairs | — | Architect | Routed | 26.02 | — | Scope — nothing specified |
| PCL-RFI-0051 | 20.02 | Retail floor level | `information` | Levels | A-1100 F / A-1300 E | Architect | **Drafted** | 21.02 | — | **Conflict in issued documents · work already set out** |
| PCL-RFI-0052 | 20.02 | Balustrade fixing | `design gap` | Balconies | A-1501/06 | Architect | Routed | 27.02 | — | Scope — no detail exists |

**Oldest outstanding: PCL-RFI-0042, one day overdue.** Two further items
(0041, 0045, 0046) fall due today.

---

## §3 — Classification notes, with the triggering wording

Every classification quotes the sentence that produced it.

**0044 — `substitution`.** *"We propose extruded aluminium to the same profile
and colour… **Please confirm acceptability.**"* The subject line says
"Clarification"; the body is a proposal. Confirming acceptability is an
approval of an alternative product, with consequences for the specifier. It
also carries a programme assertion (14-week lead time) which is a second,
separate matter.

**0046 — `instruction sought`, and also a `design gap`.** *"We have assumed
painted render… and have priced accordingly. **Please confirm we should proceed
on that basis.**"* Two things at once: the balcony soffit finish is genuinely
unspecified (confirmed — nothing in the issued documents covers it), **and**
the contractor has priced an assumption and is asking to be told to proceed.
**The higher-consequence type governs**, so this is handled as an instruction
sought. A prose confirmation here may operate as an instruction for a finish
nobody specified.

**0047 — `record building`.** *"Further to our letter of 3 February regarding
the late issue of the MEP coordination drawings… issued on 30 January, four
weeks after the date required by the information release schedule… **We reserve
our position in respect of time and cost.**"* The question ("please advise how
to proceed") is real, but the RFI's substance is a dated record of late
information. It is routed to the contract administrator the day it arrived.

**0051 — `information`, with a flag.** The answer is in the issued documents,
so it is drafted. But *"We have set out to 24.150"* means **work has already
been executed to one of two conflicting figures**. That is noted in the
exposure column and raised with the CA separately from the draft.

**0042 — `design gap`, not `information`.** A-1102 rev E does show the WC
against the party wall and the SVP in the opposite corner, as the contractor
says. **The issued documents confirm the problem rather than resolving it.**
There is no document that states the intended position, so this is a gap, not
a question with an answer on file.

---

## §4 — Draft responses

**Drafted only where the issued documents already answer the question.** Each
cites its source. Each is a draft.

---

### PCL-RFI-0045 — Shopfront setting out

**Question:** setting out dimension from grid A to shopfront centre line;
A-1100 rev F says 4,250 and A-1200 rev F says 4,500.

**Answer:** The two issued drawings carry different dimensions. A-1100 rev F
(issued 06.02.26) dimensions 4,250 from grid A to the shopfront centre line.
A-1200 rev F (issued 06.02.26) dimensions 4,500.

**Source:** A-1100 rev F, issued 06.02.26; A-1200 rev F, issued 06.02.26.

**Status: draft for review — not issued.**

> **Note to the CA, not for issue.** This draft confirms the conflict and does
> **not** resolve it. Both drawings are at rev F and were issued on the same
> date. Which dimension governs is a design decision, and a response that
> simply states one figure would be an instruction. **Do not issue this draft
> without deciding which applies.**

---

### PCL-RFI-0048 — Kitchen worktop colour

**Question:** confirm worktop colour.

**Answer:** Marlden Grey.

**Source:** Specification rev 4, clause N10/120, issued 15.01.26:
*"Laminate worktop, 40 mm, supplier's standard range. Colour: Marlden Grey."*

**Status: draft for review — not issued.**

> **Note.** The information was issued on 15 January. The clause the contractor
> quotes in the RFI stops one sentence short of the colour.

---

### PCL-RFI-0049 — External wall insulation

**Question:** which build-up applies at the brick/zinc junction; A-1500/01 and
A-1500/05 differ.

**Answer:** A-1500 detail 05 is the brick-to-zinc junction and shows a 150 mm
cavity with 100 mm insulation and a 50 mm clear cavity. A-1500 detail 01 is
the eaves detail and shows a 100 mm cavity with 100 mm insulation. Detail 05
applies at the brick/zinc junction. Specification M60 (rev 4) requires 100 mm
full fill mineral wool, which both details show.

**Source:** A-1500 rev D details 01 and 05, issued 06.02.26; Specification
rev 4 clause M60, issued 15.01.26.

**Status: draft for review — not issued.**

> **Note.** The two details are not in conflict — they are different
> conditions. The 50 mm clear cavity in detail 05 is additional to the 100 mm
> full fill, not instead of it. **This draft states what the documents show and
> makes no claim about whether the build-up performs as required** — any
> thermal or weathertightness question is separate.

---

### PCL-RFI-0051 — Retail unit floor level

**Question:** retail floor level; A-1100 rev F says 24.150 and A-1300 rev E
says 24.100.

**Answer:** The two issued drawings carry different levels. A-1100 rev F
(issued 06.02.26) shows 24.150. A-1300 rev E (issued 28.01.26) shows 24.100.
A-1100 is the later issue.

**Source:** A-1100 rev F, issued 06.02.26; A-1300 rev E, issued 28.01.26.

**Status: draft for review — not issued.**

> **Note to the CA, not for issue. Urgent.** The contractor states *"We have
> set out to 24.150"*. **Work has been executed to one of two conflicting
> figures before the conflict was resolved.** This draft states which drawing
> is later; it does **not** confirm that 24.150 is correct. If 24.100 is the
> intended level, there is already executed work affected. This needs a
> decision today, not a drafted response.

---

## §5 — Routed, not drafted

| Ref | Routed to | Why no draft |
|---|---|---|
| 0041 | Architect | **No ironmongery schedule has been issued.** A-1401 rev C refers to "IM set 2" and the schedule it refers to does not exist. Nothing to cite. |
| 0042 | Architect + MEP | The issued drawing confirms the WC/SVP mismatch. No document states the intended position. |
| 0043 | Architect | Spec L10 cl.340 says precast concrete cills; A-1500/03 shows brick soldier course. **Both are issued and contractual.** Not a documentation error to be explained away — a design decision. |
| 0050 | Architect | **No stair nosing detail exists and the specification contains no nosing clause.** Note that the RFI also raises a contrast requirement, which engages access requirements — the governing document must be named by whoever answers; it is not stated here. |
| 0052 | Architect | **No balcony-to-facade balustrade fixing detail exists.** A-1501/06 details the slab edge only. |

---

## §6 — Exposure register

Consequences named. **Not quantified, and no view taken on entitlement.**

| Ref | Exposure | Note |
|---|---|---|
| 0047 | **Time and cost. Position expressly reserved.** | Asserts MEP drawings issued 30.01.26, four weeks after the information release schedule date. This is a dated record. Whether any entitlement follows is a contractual question for the CA and the client's advisers — **not assessed here**. |
| 0044 | **Approval, programme, cost.** | A substitution proposal citing a 14-week lead time. Approving it is a specifier's decision; declining it engages the programme assertion. Both halves need a decision. |
| 0046 | **Instruction, cost.** | The contractor has priced an assumed finish and asks to be told to proceed. Answering in prose may instruct an unspecified finish. |
| 0051 | **Executed work.** | Setting out already done to one of two conflicting levels. |
| 0045 | **Setting out.** | Same conflict pattern, not yet executed as far as the RFI states. |
| 0043 | **Facade scope.** | Two issued documents specify different cills across the whole building. |
| 0041, 0050, 0052 | **Scope.** | Three items where nothing has been issued at all. |

---

## §7 — Pattern note

**Three distinct patterns this week, and they are worth more than any
individual response.**

**P-01 — Four RFIs are conflicts between two issued documents.** 0043 (spec vs
detail), 0045 (plan vs elevation), 0049 (detail vs detail — resolved on
inspection), 0051 (plan vs section). **Three of the four are real conflicts.**
Two of them concern dimensions or levels, and one has already been built to.
A spec/drawing and drawing/drawing cross-check of the issued set would find the
rest of these before the contractor does.

**P-02 — Four RFIs are things that were never issued.** 0041 (ironmongery
schedule), 0046 (balcony soffit finish), 0050 (stair nosing), 0052 (balustrade
fixing at the facade junction). **Three of the four are junction or
component details at the interface between packages.** This is not four
questions; it is an incomplete package.

**P-03 — The CA asked about "six RFIs about junctions".** The count across
0043, 0046, 0049, 0052 and arguably 0042 is five, not six. **The underlying
issue is P-02**: the balcony, the balustrade, the soffit and the nosing are all
items at an interface where nobody owned the detail. 0049 looks like the same
problem and is not — the two details are different conditions and the issued
documents do answer it.

---

## §8 — Queries

| Ref | What is needed |
|---|---|
| 0045 | Which dimension governs — 4,250 or 4,500. Decision, then issue. |
| 0051 | Which level governs — 24.150 or 24.100 — and whether executed work is affected. **Today.** |
| 0043 | Which cill. Decision, then issue. |
| 0050 | The governing document for the contrast requirement must be named by whoever responds. **No standard or figure is stated in this log.** |
| 0047 | The information release schedule itself, and the letter of 3 February, are referred to and were not supplied to this log. |

---

## §9 — Shape of this week

**12 RFIs. 4 drafted. 8 not drafted — 5 design gaps, 1 substitution, 1
instruction sought, 1 record building.**

**One overdue (0042, by a day). Three fall due today (0041, 0045, 0046).**

**Most urgent, regardless of due date: PCL-RFI-0051.** Work has been set out to
one of two conflicting levels, and the conflict is still open.
