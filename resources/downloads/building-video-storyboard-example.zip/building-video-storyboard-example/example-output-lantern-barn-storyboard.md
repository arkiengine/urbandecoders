# Lantern Barn — 30-second film storyboard

| | |
|---|---|
| **Project** | Lantern Barn (Moorline Architects) |
| **Source** | `example-input-lantern-barn-film-pack.md` — film pack, H. Voss, 14 Jul 2026 |
| **References cited** | V1, V2, V4, V5, V7 (V8 supplied, unused in this cut; V3 excluded — see Q5) |
| **Structure** | 30s = 3 × 10s clips, 7 unique keyframes, 2 shared joins |
| **Primary format** | 16:9 (website header). 9:16 is a separate framing pass — see Q3 |
| **Frame status** | 4 Relit/transformed · 1 Composed (+ relit) · **2 Placeholder** · 0 Reference-matched as-shot |

> **Draft storyboard for the architect to direct — not a locked edit.**
> Two of seven frames cannot be written until reference material for the snug
> arrives (Q1). Timings, camera moves and transitions are fixed and unaffected:
> the snug frames are a drop-in once the material exists. Every generated frame
> is a **declared relight** of overcast-midday source photography — see the
> source map before this goes to a client or an award submission.

---

## 0. Query round (what was asked before storyboarding, and what came back)

Answered by H. Voss, 16 Jul 2026. Questions 1, 4, 8, 9, 10 remain open; the
storyboard is built around them rather than over them.

| # | Question | Answer |
|---|---|---|
| Q2 | 25s divides into neither 2×10s nor 3×10s. Clean options: 20s (2 clips) or 30s (3 clips). Which? | **30s**, 3×10s — "no more than 30" satisfied |
| Q3 | Website header (16:9) and Instagram reels (9:16) cannot share one set of framings. Which is primary? | **16:9 primary.** 9:16 as a later framing pass, not a crop |
| Q5 | V3 (tender CGI) shows untreated larch; s1 and V5 say charred. Which governs? | **Charred larch governs. Do not build any frame from V3** |
| Q6 | No V6 in the list — withdrawn view or missing attachment? | Numbering error only; no V6 exists |
| Q7 | Every photo is overcast midday; the brief wants golden hour into dusk. Relight is a departure — confirm? | **Confirmed.** Tag every affected frame `Relit` |
| Q11 | Ruth and David walking to the door — the storyboard does not depict real, identifiable people. Anonymous incidental figures instead, or none? | **None.** Idea dropped |
| Q12 | Smoke from the flue: the flue is evidenced (V1, west gable); smoke is an added element, not a condition any reference shows. Include as a declared atmospheric addition? | **Yes**, light wisp only. Declared, not evidenced |
| Q13 | The old sales-listing photos are not ours to take and this is confidential client material — not searched. Supply them into the pack if wanted? | Not pursued for this cut |

**Still open — carried into the storyboard as placeholders and flags:**

| # | Open query | Blocks |
|---|---|---|
| Q1 | **No supplied view shows the snug** — the stated hero moment. V4 is the kitchen, V7 the link. A photograph, or a render from the model at the camera position below, unlocks it | F6, F7 (Clip C content) |
| Q4 | **Roof materials contradict**: V2's caption puts zinc standing-seam "over the main range"; s1 says the main range is reclaimed clay pantiles and zinc roofs only the link | Roof-reading framings; F3 written to avoid adjudicating |
| Q8 | **No landscape scheme supplied** — "make the garden and meadow look established" has nothing behind it. Ground is site mud and hardcore in every photo | Foreground treatment, F1/F2 |
| Q9 | **Logo lock-up and music track "to follow"** — neither received | End card, audio |
| Q10 | **Kling 30-second single generations** — not confirmable from memory; check against the tool's current documentation `[to verify]` | Nothing: the 3×10s structure works either way |

---

## 1. Concept

A golden-hour walk up the farm track: the barn reads as one long stone form,
the eye is pulled to the light at the glazed link, and the camera steps through
into the kitchen under the trusses — settling, finally, in the snug.

The last beat is the one the pack cares most about and the one we have no
picture of. It is storyboarded as a placeholder, not invented.

## 2. Shot-list overview

| Clip | Time | Location | Camera move | Transition out |
|---|---|---|---|---|
| A | 0–10s | Exterior — farm track, south-west | Slow push-in along the track | Match cut at the glazed link (F3 shared) |
| B | 10–20s | Glazed entrance link → kitchen | Continuous forward track through the link | Continuous move (F5 shared) |
| C | 20–30s | Kitchen → snug, west end of main range | Slow track west, settling to rest | Hold on F7 → end card in the edit |

Timeline: 10 + 10 + 10 = **30s**. **Clip C's frames are placeholders pending Q1**
— its timing, move and hand-off are fixed and will not change when the material
arrives.

## 3. Global Style & Continuity Block

Appended to **every** keyframe prompt below.

```
Consistency: this is the same building shown in the supplied reference
photographs — same geometry, same materials, same palette across every frame.
Coursed lime-pointed stone to the main range; charred (shou sugi ban) larch
boarding on a stone plinth to the byre; reclaimed clay pantile roof to the
main range; glazed entrance link between the two. Match the references
exactly; do not redesign, re-clad or re-colour any element.
Photorealistic architectural photography, neutral 35mm-equivalent lens,
physically accurate light. APPROVED RELIGHT: late golden hour into early
dusk, low warm raking sun, warm interior lamplight visible through glazing —
the source photographs are overcast midday; lighting is the only permitted
departure from them.
Aspect ratio 16:9, identical on every frame.
No text, no logos, no watermarks, no people.
```

## 4. Clips

### CLIP A — 0–10s — Exterior approach *(one idea: slow push-in)*

**`F1 — Start`**
```
Exterior of the barn from Image V1 — the full building seen from the farm
track to the south-west, main range to the left, byre to the right, flue on
the west gable. Wide establishing framing, whole building in frame with sky
above. Materials exactly as V1: coursed stone to the main range, charred
larch on a stone plinth to the byre. Foreground ground surface as in the
reference — bare site ground and hardcore, no planting added. Low golden-hour
sun raking across the stone from the west; long shadows; first warmth in the
window reveals. Neutral 35mm lens, camera at eye height on the track.
[+ Global Style & Continuity Block] [+ Geometry/Style Lock]
```
> Landscape is unresolved (Q8). Ground is held as photographed rather than
> dressed. **Do not add lawn, meadow or specimen planting to this frame.**

**`F2 — Mid`**
```
The same barn from Image V1, camera advanced along the track to roughly half
the original distance: the byre flank now dominant in frame, charred larch
boarding and its stone plinth reading as in Image V5 (detail reference for
the material only — same char texture, same board rhythm, same plinth
junction). Main range and flue still in frame to the left. Golden-hour sun
low and warm across the boarding. Neutral 35mm lens, eye height.
[+ Global Style & Continuity Block] [+ Geometry/Style Lock]
```

**`F3 — End`  — = Start of Clip B. Render once, reuse the identical file.**
```
Tight framing on the glazed entrance link between the main range and the byre,
as in Image V2 but seen from the south-west approach: the glazing lit warm
from within against the cooling dusk sky, stone to the left, charred larch to
the right, camera on the threshold about to enter. Frame the link and the
adjoining wall planes only — crop above the eaves line, roof not in shot.
Neutral 35mm lens.
[+ Global Style & Continuity Block] [+ Geometry/Style Lock]
```
> **Framed to avoid Q4.** V2's caption and the scheme description disagree about
> which roof is zinc and which is pantile; this frame crops below the eaves so
> the storyboard does not adjudicate. Once Q4 is answered the crop can open up.

**Motion & Camera Direction (Clip A)**
```
Camera: slow steady push-in along the farm track toward the glazed link — one
continuous forward move, no orbit, no crane. Speed: slow, walking pace or
slower, easing slightly as it arrives.
Moving elements: warm golden-hour light strengthening across the stone;
interior lamplight rising in the glazing; a light wisp of smoke drifting from
the west-gable flue (declared atmospheric addition, see Q12).
Locked: building geometry stable — no warping walls, no morphing materials,
no added or removed openings, no added planting or landscape.
Start on F1, end on F3. Duration 10s, 16:9.
```
**Transition out:** match cut at the threshold — F3 is reused, unaltered, as
Clip B's first frame.

---

### CLIP B — 10–20s — Through the link into the kitchen *(one idea: continuous forward track)*

**`F3 — Start`** — shared with Clip A. Same still, same file. Do not re-describe
or re-render.

**`F4 — Mid`**
```
Interior of the glazed entrance link from Image V7, camera moving forward
through it, looking through the glazing toward the garden side as in the
reference. Polished concrete floor, stone wall to one side, glazed structure
as V7 shows it. Golden-hour light entering low and warm from the west; warm
lamplight beyond. Framing as V7 but from a walking-forward camera position.
Neutral 35mm lens.
[+ Global Style & Continuity Block] [+ Geometry/Style Lock]
```

**`F5 — End`  — = Start of Clip C. Render once, reuse the identical file.**
```
Interior of the kitchen in the main range from Image V4, wide framing as the
camera arrives: the reglazed cart opening as a full-height window, exposed and
repaired kingpost trusses overhead, polished concrete floor. All joinery,
fittings and materials exactly as V4 — nothing added, nothing restyled.
Golden-hour light entering through the cart opening low and warm, with lamps
lit in the room (relight of V4's flat overcast daylight).
Neutral 35mm lens, camera at eye height on entering the room.
[+ Global Style & Continuity Block] [+ Geometry/Style Lock]
```

**Motion & Camera Direction (Clip B)**
```
Camera: continuous forward tracking from the threshold, through the glazed
link, arriving in the kitchen — the same forward move as Clip A, uninterrupted.
Speed: slow and steady, no acceleration at the join.
Moving elements: light only — low sun tracking across the concrete floor,
warm lamplight strengthening ahead.
Locked: walls, glazing, trusses and layout stable; no warping, no furniture
appearing or disappearing.
Start on F3, end on F5. Duration 10s, 16:9.
```
**Transition out:** continuous move — F5 is reused, unaltered, as Clip C's first
frame.

---

### CLIP C — 20–30s — To the snug *(one idea: slow track west, settling)*

> **Clip C is storyboarded but not yet renderable. Q1 is open: no supplied
> reference shows the snug, and the western end of the main range interior is
> not photographed at all.** The structure below is fixed. The frame content is
> written from the reference material when it arrives — not before.

**`F5 — Start`** — shared with Clip B. Same still, same file.

**`F6 — Mid`**
```
F6 — transit through the main range, kitchen toward the west end.
[PLACEHOLDER — awaiting reference, see Q1. Composition intent: camera
continues west from the kitchen at eye height, trusses passing overhead,
warm light ahead from the snug. Camera position, movement hand-off and
duration are fixed as storyboarded; visual content will be written from the
supplied reference. Do not generate this frame from imagination — the
interior between the kitchen and the west end is unphotographed and its
openings, levels and finishes are unknown to this storyboard.]
```

**`F7 — End (hero)`**
```
F7 — the snug: double-height, under the retained kingpost truss, corner
woodburner alight. The film's final beat and the pack's stated money shot.
[PLACEHOLDER — awaiting reference, see Q1. Composition intent: camera comes
to rest on the hero framing, warm firelight and lamplight, dusk beyond the
glazing. Camera position, movement and duration are fixed as storyboarded.
The snug is described in the pack (s1) but shown in no supplied view;
mentioned is not evidenced, so no frame is written for it here.]
```

**Motion & Camera Direction (Clip C)**
```
Camera: slow track west through the main range, decelerating to rest on the
hero framing — one move, easing to a stop. No orbit, no crane.
Speed: slow, settling; fully at rest by roughly 28s.
Moving elements: firelight flicker, warm lamplight, subtle dusk gradient
beyond the glazing.
Locked: geometry, trusses, joinery and layout stable; no warping, no added
elements.
Start on F5, end on F7. Duration 10s, 16:9.
[Frame content pending Q1 — this direction is issuable as written once F6 and
F7 exist.]
```
**Transition out:** hold on F7 for the final beat, then cut to the end card in
the edit.

**To unlock Clip C (in order of preference):**
1. A photograph of the snug at the composition described — the honest option.
2. **A render from the model at the storyboarded camera position.** If the
   scheme is in Rhino/Revit/SketchUp, or a real-time renderer, set a camera at
   the kitchen's west end at 1.6m eye height, target the woodburner corner,
   35mm equivalent, 16:9, and issue two viewport renders (F6 transit, F7 hero).
   That is a ten-minute job and it produces evidence.
3. **Fallback if neither is possible:** re-plan as a 20-second, two-clip film
   ending on the kitchen (F5 becomes the hero, Clip B's move extended and
   re-settled). Say the word and this comes back re-cut — it is a decision, not
   a default.

## 5. Frame checklist

| Frame | What it is | Render / reuse |
|---|---|---|
| **F1** | Exterior wide, farm track SW, golden hour | Render |
| **F2** | Exterior mid, byre flank, charred larch | Render |
| **F3** | Glazed link, threshold — **A end = B start** | **Render once, reuse both sides** |
| **F4** | Interior of the glazed link, moving through | Render |
| **F5** | Kitchen arrival, cart opening + trusses — **B end = C start** | **Render once, reuse both sides** |
| **F6** | Transit to the west end | **Blocked — Q1** |
| **F7** | Snug hero, woodburner | **Blocked — Q1** |
| F8 | *(hold frame)* | **Not generated.** End card is an edit-stage plate — see below |

5 unique frames renderable now; 2 blocked. Render F3 and F5 **once each** and
feed the identical file to both adjoining generations.

## 6. Stitching & export notes

- Generate each clip with its two bounding keyframes as first and last frame.
  F3 and F5 are the shared joins, so the cuts are invisible — **straight cuts,
  no dissolves.** If a join flickers, the frame reuse has broken; fix the reuse
  rather than dissolving over it.
- Assemble A → B → C: 10 + 10 + 10 = **30s**, confirmed against the pack's
  "no more than 30".
- **The 3×10s structure is deliberately tool-agnostic.** Whether a single
  30-second generation is available in the named tool is `[to verify]` against
  its current documentation (Q10); if it is, this storyboard still works — the
  keyframes become waypoints in one generation rather than three.
- **Overlays are edit-stage tasks. No text or logo in any generated frame.**
  End card after F7, built in the editor from the practice logo lock-up **when
  supplied (Q9)**. Captions, if used, as supplied by the practice and verbatim:
  "Planning approved unanimously, March 2026" `[to verify]`, "RIBA Yorkshire
  Awards longlist 2026" `[to verify]`. **The storyboard makes no planning,
  award or compliance claim of its own** — check both with the practice before
  they go on the film.
- Audio: a slow, sparse ambient bed suits the pace. This is a suggestion only —
  the track and its licence are the practice's to confirm (Q9).
- Export 16:9 at 1080p or 4K, 24–30 fps, constant frame rate.
- **9:16 is a separate framing pass, not a crop** (Q3). F1 and F5 lose their
  subject at 9:16 — the wide exterior and the room-width kitchen arrival both
  depend on horizontal information. Budget a second set of keyframe prompts for
  the vertical cut; it is a different film, not an export setting.
- Sending these references to a third-party image or video service discloses
  them to that service. Whether that is acceptable for the Calloways' house is
  the practice's call, not this storyboard's.

## 7. Source map

| Frame | Built from | Provenance |
|---|---|---|
| F1 | V1 (exterior SW, photo Jun 2026) | **Relit/transformed** — overcast midday → golden hour. Ground as photographed; no landscape added (Q8) |
| F2 | V1 (camera advanced along the track), V5 (charred larch material only) | **Composed + Relit/transformed** — camera position between references; no feature introduced that V1/V5 do not show |
| F3 | V2 (glazed link, photo Jun 2026), cropped below the eaves | **Relit/transformed** — crop avoids the unresolved roof reading (Q4) |
| F4 | V7 (interior of link, photo Jun 2026) | **Relit/transformed** |
| F5 | V4 (kitchen, photo Jun 2026) | **Relit/transformed** — lamps lit; no fittings added |
| F6 | — | **Placeholder** — Q1 |
| F7 | — | **Placeholder** — Q1 |
| Smoke from flue (motion, Clip A) | Flue evidenced in V1; smoke is not | **Declared addition** — approved Q12, not evidenced |
| V3 (tender CGI, Nov 2024) | Not used | **Excluded** — superseded cladding; charred larch governs (Q5). It was the only dusk asset in the pack, which is exactly why it was tempting |
| V8 (drone aerial, Jun 2026) | Not used in this cut | Available if an aerial opening is preferred — that is a different Clip A, not an addition to this one |

**Every generated frame in this film is a relight of overcast-midday
photography.** None of them is a photograph of the barn at golden hour. Say so
if the film is submitted anywhere the distinction matters.

## 8. Queries & placeholders log

| # | Query | Status | Frames touched |
|---|---|---|---|
| Q1 | No reference shows the snug — the stated hero moment | **OPEN — blocking** | F6, F7 |
| Q2 | 25s divides into no clean clip structure | Resolved — 30s, 3×10s | All |
| Q3 | 16:9 and 9:16 double-booked | Resolved — 16:9 primary; 9:16 a separate pass | All |
| Q4 | Roof contradiction, V2 caption vs scheme text | **OPEN** — not adjudicated | F3 (crop avoids it) |
| Q5 | V3 shows superseded untreated larch | Resolved — charred governs, V3 excluded | — |
| Q6 | No V6 in the reference list | Resolved — numbering error | — |
| Q7 | Brief wants dusk; all photos overcast midday | Resolved — relight approved and declared | F1–F5 |
| Q8 | "Make the garden look established" — no landscape scheme supplied | **OPEN** | F1, F2 (ground held as photographed) |
| Q9 | Logo lock-up and music track to follow | **OPEN** | End card, audio |
| Q10 | 30-second single generation claim for a named tool | **OPEN — `[to verify]`** | None — structure is tool-agnostic |
| Q11 | Clients walking to the door | Resolved — no people | F1 |
| Q12 | Smoke from the flue | Resolved — approved as a declared addition | Clip A motion |
| Q13 | Interior photos on the old sales listing | Resolved — not searched; supply into the pack if wanted | — |

**Five queries open, two of them blocking.** Answer Q1 and Clip C becomes
renderable with no change to the timings, the moves or the joins.
