# Lantern Barn — film pack

**From:** Harriet Voss, practice manager, Moorline Architects (Thirsk studio)
**To:** whoever is putting the film together
**Date:** 14 July 2026
**Re:** short film of Lantern Barn for the website relaunch

Attached are the reference views we have to hand (listed in section 3). Sorry
it's a bit of a mixed bag — some are completion photos from Dan's site visit,
some are older CGIs from the tender set. Shout if anything is missing.

---

## 1. The scheme in brief

Lantern Barn is the conversion of a mid-nineteenth-century stone threshing
barn and attached byre on the edge of Askersby, North Yorkshire, into a
four-bedroom family home for Ruth and David Calloway. Planning was granted by
the local committee in March 2026 — unanimously, we're told — and the project
has just been longlisted for a RIBA Yorkshire award, which is partly what's
prompted the film.

The main range keeps its original form: lime-pointed coursed stone, the roof
re-covered in **reclaimed clay pantiles**, the big cart opening reglazed as a
full-height window to the kitchen. A new **glazed entrance link**, roofed in
**zinc standing-seam**, connects the main range to the former byre, which has
been re-clad — note this changed at tender stage from untreated larch to
**charred (shou sugi ban) larch** on a stone plinth. Inside: polished concrete
floors throughout, exposed and repaired kingpost trusses, and the room
everyone falls for — the **double-height snug at the west end of the main
range, sitting under the retained kingpost truss, with a corner woodburner**
(flue visible externally on the west gable).

## 2. What the film is for

Audience is prospective clients, mainly — it will sit as the **header film on
the practice website**, and Harriet also wants to cut it for **Instagram
reels**, so bear both in mind; ideally it's the same film doing both jobs.

Length: keep it tight — **25 seconds or so, definitely no more than 30**.

Tone: quiet, warm, end-of-day. We'd love the whole thing at **golden hour
into dusk — lamps lit, a bit of smoke from the flue** — the building is
called Lantern Barn for a reason and the film should earn the name. It should
**build to the snug under the kingpost truss, woodburner going** — that is
the money shot and the last thing people should see.

Also — the landscape scheme wasn't in when Dan took the photos, so the
surroundings look like a building site in most of them. **Please make the
garden and the meadow planting look established** in the film; it will all be
in by autumn anyway.

One more thought from Ruth: **maybe she and David could be seen walking up to
the door** in the opening shot? Not essential — see what you think.

## 3. Supplied reference views

| Ref | Type | Caption |
|---|---|---|
| V1 | Photo (Jun 2026) | Exterior from the farm track, south-west. Overcast midday. Full building in frame: main range left, byre right, flue on the west gable. Ground is site mud and hardcore. |
| V2 | Photo (Jun 2026) | Exterior, north elevation at the glazed entrance link — the zinc standing-seam roof over the main range reading strongly against the sky. Overcast midday. |
| V3 | CGI (tender set, Nov 2024) | Exterior from the south-east at dusk, windows glowing. Shows the byre in untreated larch as tendered. |
| V4 | Photo (Jun 2026) | Interior, kitchen in the main range: reglazed cart opening, exposed trusses, polished concrete, flat overcast daylight. |
| V5 | Photo (Jun 2026) | Detail: charred larch cladding meeting the stone plinth, byre south corner. |
| V7 | Photo (Jun 2026) | Interior of the glazed link, looking through toward the garden side. Midday. |
| V8 | Drone photo (Jun 2026) | Wide aerial of the barn in its field edge setting, village roofline beyond. Midday. |

There are also some **interior photos on the old sales listing for the barn
still up online** if you want more angles — easy enough to find.

## 4. Practicalities

- Harriet will send over the **practice logo lock-up and a music track** she
  has in mind — to follow, hopefully this week.
- End card / captions: worth mentioning the **unanimous planning approval**
  and the **RIBA Yorkshire longlisting** somewhere.
- Tools: whatever works, though Dan read that **Kling can now do 30-second
  single generations**, so possibly the whole film could be one clip and skip
  the stitching?

Thanks — excited to see the shot list.

H.
