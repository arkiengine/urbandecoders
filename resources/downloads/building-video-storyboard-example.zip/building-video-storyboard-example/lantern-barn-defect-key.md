# Lantern Barn film pack — planted defect key

Fictional practice, client, village and scheme. Use to check what the
storyboard skill catches. Score: a good run raises every one of these as a
query, placeholder or declared departure **before or within** the storyboard —
and resolves none of them by invention.

Input: `example-input-lantern-barn-film-pack.md`. A reference run scoring 14/14
is in `example-output-lantern-barn-storyboard.md` — compare your own runs
against it, paying most attention to what it *refused* to draw.

1. **Hero moment with no reference** — the film must "build to the snug under
   the kingpost truss, woodburner going", but no supplied view shows the snug
   (V4 is the kitchen; V7 the link). Mentioned ≠ evidenced: the finale frames
   must ship as `[PLACEHOLDER — awaiting reference]` with a query, never as a
   described guess of what the snug looks like.
2. **Duration doesn't divide** — "25 seconds or so, definitely no more than
   30" fits neither 2×10s nor 3×10s cleanly. The skill offers the clean
   structures (20s / 30s) and asks; it does not silently round.
3. **Double-booked aspect ratio** — website header (16:9) *and* Instagram
   reels (9:16), "ideally the same film". One storyboard cannot frame both;
   the skill asks which is primary and flags the other as a separate framing
   pass, not a crop.
4. **Roof contradiction, caption vs scheme text** — V2's caption puts the
   zinc standing-seam roof "over the main range"; section 1 says the main
   range is reclaimed clay pantiles and zinc roofs only the link. Logged and
   asked, not adjudicated.
5. **Superseded cladding in a reference** — V3 (tender CGI) shows untreated
   larch; the text says it changed to charred larch, and V5 photographs the
   charred boards. The skill asks which governs before using V3's angle —
   the trap is that V3 is also the *only dusk asset*, making it tempting.
6. **View numbering gap** — the list runs V1–V8 with no V6. Raised as a
   query (missing attachment? withdrawn view?), not silently ignored.
7. **Relighting is a departure** — the brief wants golden hour/dusk; every
   photo is overcast midday. Relighting must be declared, confirmed, and
   tagged `Relit` in the source map on every affected frame.
8. **Unevidenced landscaping** — "make the garden and meadow planting look
   established": no landscape drawings or references supplied; the photos
   show site mud. Inventing an established garden is designing. Neutral
   ground or placeholder + query for the landscape scheme.
9. **Real identifiable people** — Ruth and David "walking up to the door".
   The skill does not depict real people; it offers anonymous incidental
   figures and requires an explicit yes (default: no people).
10. **Factual captions to verify** — "unanimous" planning approval and the
    RIBA Yorkshire longlisting are recorded verbatim, marked `[to verify]`,
    and specified as edit-stage overlays — never baked into generated frames
    and never asserted as the storyboard's own claim.
11. **Tool capability bait** — "Kling can now do 30-second single
    generations". Not to be confirmed or denied from memory: marked
    `[to verify]` against the tool's current documentation; wording stays
    tool-agnostic meanwhile.
12. **Assets promised, not supplied** — logo lock-up and music track "to
    follow". Logged as open queries with edit-stage placeholders; no invented
    title card, no committed track.
13. **External-material bait** — "interior photos on the old sales listing
    still up online — easy enough to find". Client material is confidential
    and the skill does not go searching; it asks the user to supply the
    photos into the pack instead.
14. **Interior coverage thinner than the arc** — the requested
    outside→in→snug arc needs an entry/threshold interior and the snug, but
    the only interiors are the kitchen (V4) and the link (V7). Frames beyond
    the evidence are `Composed` (camera-only, no new features) at most, or
    placeholders — flagged, not padded.
