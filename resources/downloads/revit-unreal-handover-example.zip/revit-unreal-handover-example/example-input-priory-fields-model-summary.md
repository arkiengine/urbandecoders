# Priory Fields — model summary for Unreal handover

**Project:** Priory Fields, Marlden — secondary school, 14,200 m² GIA
**Purpose stated by the client:** "An operational twin. We want to click a
classroom and see its booking status, CO₂ and heating setpoint live from the
BMS. And a walkthrough for the opening."
**Target:** Unreal Engine 5, desktop and a touchscreen in reception
**Model:** Revit 2024, central file, rev 22

*Fictional project. Deliberately imperfect.*

---

## §1 — Model placement

| Item | Value |
|---|---|
| Project Base Point | E 0, N 0, Elev 0 |
| **Survey Point** | **E 441,882.350, N 388,104.900, Elev 74.250** |
| Shared coordinates | Acquired from the site survey link |
| Project North to True North | **Rotated 31.5°** |
| **Element extents from the internal origin** | **X 441,760,000 to 442,010,000 mm · Y 387,985,000 to 388,225,000 mm · Z 73,100 to 92,400 mm** |
| Building footprint implied by those extents | 250 m × 240 m |

**Note from the technician:** "Someone moved the model to shared coordinates
about a year ago so it lines up with the civils. Everything's been modelled
there since."

---

## §2 — Category census and element counts

| Revit category | Elements | Est. triangles |
|---|---|---|
| Walls | 4,820 | 186,000 |
| Floors | 612 | 44,000 |
| Roofs | 96 | 31,000 |
| Ceilings | 1,104 | 62,000 |
| Doors | 1,462 | **1,870,000** |
| Windows | 988 | 410,000 |
| Curtain Panels | 2,240 | 188,000 |
| Curtain Wall Mullions | 3,106 | 496,000 |
| Structural Columns | 388 | 41,000 |
| Structural Framing | 1,204 | 158,000 |
| Stairs | 34 | 212,000 |
| Railings | 286 | **1,240,000** |
| **Casework** | **2,918** | **2,460,000** |
| **Furniture** | **6,140** | **4,920,000** |
| **Lighting Fixtures** | **3,284** | **2,180,000** |
| **Plumbing Fixtures** | 742 | **1,410,000** |
| Mechanical Equipment | 318 | 890,000 |
| **Pipe Fittings** | **8,960** | **3,640,000** |
| **Pipe Accessories** | 1,210 | 720,000 |
| Ducts and fittings | 4,420 | 1,120,000 |
| Specialty Equipment | 206 | 164,000 |
| Generic Models | 1,840 | 980,000 |
| Site / Topography | 1 | 86,000 |

**Triangle estimates are the technician's, from a test FBX export of a single
level extrapolated to the whole model.**

---

## §3 — Rooms and identity

| Item | Value |
|---|---|
| Rooms placed | **412** |
| Rooms with a Name | 412 |
| Rooms with a **Number** | **412** |
| **Rooms with a unique Number** | **389** |
| Rooms with the `BMS_AssetTag` shared parameter | **96** |
| Rooms bounding correctly (no unenclosed warnings) | 404 |

**Classrooms specifically:** 68 rooms named `Classroom`, of which **22 carry a
`BMS_AssetTag`**.

**Shared parameters in the model:** `BMS_AssetTag`, `FM_Category`,
`Asset_Ref`.

| Parameter | Applied to | Populated |
|---|---|---|
| `BMS_AssetTag` | Rooms, Mechanical Equipment | 96 rooms, 318 equipment |
| `FM_Category` | All model categories | **1,204 of 46,000 elements** |
| `Asset_Ref` | Doors, Windows, Casework | **0** |

---

## §4 — Levels and worksets

**Levels:** 00, 01, 02, Roof, plus **9 further levels** named `Level 03`,
`Datum 1`, `Datum 2`, `TOS 01`, `TOS 02`, `Ceiling GF`, `Ceiling L1`,
`WORKING`, `DO NOT USE`.

**Worksets:** `Shared Levels and Grids`, `Architecture`, `Structure`, `MEP`,
`Landscape`, `Workset1`, **`TEMP - delete before issue`**.

**Elements on `TEMP - delete before issue`:** 1,886.

---

## §5 — Materials

| Item | Value |
|---|---|
| Materials in the model | 214 |
| **Elements with no material assigned** | **3,412** |
| Materials named `Default` or `Default Wall` etc. | **38** |
| Materials with a surface pattern but **no appearance asset** | **61** |
| Elements with transparency > 0 | 3,228 (curtain panels, windows, railings) |
| **Elements requiring tiled texture mapping with no UV data in the export** | **`[not known — needs a test export]`** |

---

## §6 — Hygiene

| Check | Result |
|---|---|
| Revit warnings, total | 1,842 |
| — of which "Elements have duplicate instances" | **318** |
| — of which "Highlighted elements are joined but do not intersect" | 406 |
| — of which "Room is not in a properly enclosed region" | 8 |
| Elements hidden in all views | **2,104** |
| Design options present | **Yes — 2 option sets, 5 options, not yet accepted** |
| Linked models | Structural (own file), MEP (own file), Site survey (dwg) |

---

## §7 — What has been asked

1. "Check it before we export."
2. "Why does our test scene jitter?"
3. "Where's the polygon budget going? We can't just decimate everything."
4. "Will the twin work — can we click a classroom and get live data?"
5. "What's our triangle budget for the reception touchscreen?"
