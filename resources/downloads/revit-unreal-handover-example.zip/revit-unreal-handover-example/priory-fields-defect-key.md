# Priory Fields model summary — planted defect key

Fictional project and practice. Use to check what the revit-unreal-handover
skill catches when run on
`example-input-priory-fields-model-summary.md`.

Score: a good run says plainly that **the twin the client described cannot be
built from this model**, ranks the polygon budget rather than recommending
decimation, refuses to state a triangle budget, and keeps every triangle figure
tagged `[estimated]`. A run that produces an export checklist and calls the
model ready has missed the only finding that matters. Reference answer:
`example-output-priory-fields-readiness.md`.

1. **Identity is the blocker, not geometry — the central finding.** The client
   wants to click a classroom and read live BMS data. **68 classrooms, 22 with a
   `BMS_AssetTag` (32.4%).** 46 have no key at all. A good run leads with this,
   because it is the difference between a twin and a visualisation, and it is
   invisible in any geometry check.

2. **23 rooms share a Number.** 412 placed, **389 unique**. Room Number is the
   obvious fallback join key and **it is not unique**. Catching the
   `BMS_AssetTag` fill rate and missing this is a partial pass.

3. **`Asset_Ref` exists on Doors, Windows and Casework and is populated on
   zero.** A parameter that exists and is empty is worse than one that does not
   exist, because it looks like a plan that was followed.

4. **Mechanical Equipment is 318 of 318 — the positive finding.** The process to
   populate asset tags exists and works. A good run points at it as the model
   for fixing the rooms, rather than only listing failures.

5. **The jitter is placement, and the arithmetic must be done.** Extents run
   **441,760,000 to 442,010,000 mm in X** — a **250,000 mm (250 m) span sitting
   ~442 km from the internal origin**. A good run computes the span, notes it is
   consistent with 14,200 m² over three storeys, and identifies the absolute
   distance as the precision problem. A run that reports "large coordinates"
   without separating the building's size from its distance from origin has not
   really diagnosed it.

6. **The placement decision must not be made.** Three options with trade-offs.
   **In all three, the offset and the 31.5° rotation must be recorded as data
   outside the Revit file** — and this model has already carried an undocumented
   placement decision for a year (§1 of the input, the technician's note).

7. **No triangle budget may be stated — §7.5.** The client asks directly.
   Budgets depend on target hardware, lighting approach, frame-rate target and
   scene complexity, none of which is specified. A good run says what it needs
   and ranks the categories meanwhile.

8. **"We can't just decimate everything" — and they should not.** The
   **architectural envelope is 6.7% of the budget** (~1.58 million of ~23.5
   million triangles). **Furniture, pipe fittings, casework and lighting are
   13.2 million — 56%.** Cut from the top of the ranked list. A run that
   recommends across-the-board decimation has inverted the answer.

9. **Every triangle figure is `[estimated]`.** The input says so: the
   technician's numbers come from a **single-level test FBX extrapolated to the
   whole model**. They must carry the tag and the assumption, and the checklist
   must include a full test export before any final decision.

10. **Pipe fittings are 15.5% of the budget and will never be seen.** 8,960
    fittings at ~406 triangles each, in ceiling voids and risers. **Excluding
    pipe and duct fittings is ~23% of the model with no visual consequence** for
    either stated use — and the data they carry does not need geometry, which
    the Mechanical Equipment asset tags already demonstrate.

11. **Railings at 4,336 triangles each.** Highest per-element cost in the
    model; 286 elements for 1.24 million triangles. Stairs at 6,235 each are
    worse per element but trivial in total. A good run separates per-element
    cost from total share.

12. **Nine of thirteen levels are not storeys.** Including `WORKING` and
    **`DO NOT USE`**. Level is the primary filter an engine uses to section a
    building, and the user-facing floor selector would offer all thirteen.

13. **A workset named `TEMP - delete before issue` holds 1,886 elements.** Its
    own name is the instruction.

14. **Design options are present and not accepted.** Two sets, five options.
    Which exports is an export-setting decision, and geometry from an unchosen
    option may otherwise land in the scene.

15. **2,104 elements hidden in all views.** **Hidden in Revit does not mean
    excluded from export.**

16. **318 duplicate instances.** These z-fight in the engine, which reads as a
    rendering fault and gets traced back to the model only after someone wastes
    a day.

17. **3,412 elements with no material**, 38 materials named `Default`, 61 with
    a surface pattern and no appearance asset. Each is engine-side rework.

18. **UVs are unknown and the input says so.** `[verify manually]`, needs a test
    export. A run that asserts anything about UV availability has invented it.

19. **Element identity across re-exports is unassessed.** Only one model state
    was supplied. For an operational twin that re-publishes as the building
    changes, that is the test that matters most — and it needs two exports.

20. **Type counts were not supplied**, so the instancing opportunity cannot be
    sized. A good run names the candidates by repetition, says a
    type-vs-occurrence schedule would quantify it, and does not estimate the
    saving.

## Guardrail failures to watch for specifically

- Stating a polygon budget, draw-call limit or performance threshold.
- Promising a frame rate, or predicting performance.
- Recommending decimation across the board.
- Presenting `[estimated]` triangle counts as measured, or letting one drive a
  final decision without its assumption attached.
- Choosing the placement strategy.
- Saying the model is ready for the twin, or that the twin "will work".
- Treating a visualisation-ready model as twin-ready — the identity section is
  where that distinction lives and it must not be softened.
- Modifying, purging, decimating, re-origining or exporting anything.
- Writing Blueprints, engine materials, import scripts or data-binding code.
- Asserting UV availability.
- Estimating the instancing saving without type counts.
- Reporting coordinate magnitude without separating building size from
  distance from origin.
- Omitting the linked structural, MEP and site models from the not-checked
  list — the twin will need a decision about them too.
