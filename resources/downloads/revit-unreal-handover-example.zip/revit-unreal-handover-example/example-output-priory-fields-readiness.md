# Priory Fields — Unreal handover readiness report

**Assessed:** 5 March 2026 · **Model rev 22** · **Stated purpose: operational
twin with live BMS data, plus a walkthrough.**
**No model file has been modified and no export has been run.**

---

## §1 — Verdict

**Not ready to export, and the twin as described cannot be built from this
model.**

**The single biggest blocker is identity, not geometry.** The client wants to
click a classroom and read live BMS data. There are **68 classrooms and 22 of
them carry a `BMS_AssetTag`** — the only parameter in the model that could
join to a BMS. **23 rooms share a Number with another room.** Without a stable,
unique, populated key on the rooms the twin will bind to, there is nothing for
live data to attach to, and no amount of engine-side work creates one.

Second: **the model sits at shared coordinates** (§2), which is why the test
scene jitters, and which must be decided before any export rather than fixed
after one.

Third: **the polygon budget is going almost entirely to things nobody will
look at** — furniture, pipe fittings, casework and lighting fixtures are
**13.2 million of 23.5 million triangles, 56% of the model** (§5).

---

## §2 — Placement and coordinates

| Item | Value | Tag |
|---|---|---|
| Project Base Point | 0, 0, 0 | `[measured]` |
| Survey Point | E 441,882.350 · N 388,104.900 · Elev 74.250 | `[measured]` |
| Project North to True North | 31.5° | `[measured]` |
| **Element extents from the internal origin** | **X 441,760,000 to 442,010,000 mm · Y 387,985,000 to 388,225,000 mm** | `[measured]` |
| Units | millimetres | `[measured]` |

**B-01 — The model is authored at shared coordinates, roughly 442 km and 388 km
from its internal origin.**

The arithmetic matters here, so it is written out. The X extents span
**250,000 mm — 250 m**, and the Y extents span **240,000 mm — 240 m**. So the
building is about **250 m × 240 m**, which is consistent with 14,200 m² over
three storeys. But it sits at an absolute distance of roughly **442 km** from
the model's internal origin.

**A 250 m object held 442 km from the origin is a precision problem**, and it
is the jitter (§7.2). Geometry at that distance from the origin
exceeds single-precision resolution: surfaces shimmer, the camera stutters,
snapping and line-trace behaviour degrade. **It is a placement decision made a
year ago in the authoring model, not an engine fault.**

**Options, with trade-offs. This report does not choose.**

| Option | What it does | Protects | Costs |
|---|---|---|---|
| **A — Export about a project origin** | Shift to the Project Base Point (already at 0,0,0) and **record the 441,882.350 / 388,104.900 / 74.250 offset as project data** | No jitter. Comfortable authoring | The offset must live in a file that travels. **If it is lost, the twin cannot be re-placed against GIS** |
| **B — Keep shared coordinates, enable large world coordinates in Unreal** | Georeferenced throughout | GIS and Cesium alignment is native | Larger engine overhead; every downstream tool must support it; does not help other consumers |
| **C — Dual** | Export local, hold the transformation as versioned project data | Both | Discipline, and an owner for the transformation |

**Whichever is chosen: the offset and the 31.5° rotation must be recorded as
data, outside the Revit file.** An undocumented offset is what breaks the
twin's relationship to GIS six months later, and this model has already carried
an undocumented placement decision for a year (§1 of the input).

---

## §3 — Structure

**Levels: 13.** Four are real building levels (00, 01, 02, Roof). The other
nine are `Level 03`, `Datum 1`, `Datum 2`, `TOS 01`, `TOS 02`, `Ceiling GF`,
`Ceiling L1`, `WORKING`, **`DO NOT USE`**.

**M-01 — Nine of thirteen levels are not building storeys.** Level is the
primary filter an engine uses to section a building. Exported as-is, the level
filter will offer thirteen options, two of which are called `WORKING` and
`DO NOT USE`, and the user-facing floor selector will be unusable without
remapping.

**M-02 — A workset called `TEMP - delete before issue` holds 1,886
elements.** Its own name is an instruction. `[measured]`

**M-03 — Design options are present and not accepted.** Two option sets, five
options. **Which option exports is an export-setting decision**, and if it is
not taken deliberately the scene may contain geometry from an option nobody
chose. `[verify manually]`

---

## §4 — Identity and binding readiness

**This is the section that decides whether this is a twin or a picture.**

| Target | Count | With a usable key | Fill rate |
|---|---|---|---|
| **Classrooms** | **68** | **22 with `BMS_AssetTag`** | **32.4%** |
| All rooms | 412 | 96 with `BMS_AssetTag` | 23.3% |
| **Rooms with a unique Number** | — | **389 of 412** | **94.4% — 23 duplicates** |
| Mechanical Equipment | 318 | 318 with `BMS_AssetTag` | **100%** |
| All elements | ~46,000 | 1,204 with `FM_Category` | **2.6%** |
| Doors / Windows / Casework | — | **0 with `Asset_Ref`** | **0%** |

**H-01 — 46 of 68 classrooms have no BMS key.** The client's stated
interaction — click a classroom, read booking status, CO₂ and heating setpoint
— works for 22 classrooms and fails for 46. `[measured]`

**H-02 — 23 rooms share a Number with another room.** Room Number is the
obvious fallback key. **It is not unique**, so it cannot serve as a join key
without being made so. `[measured]`

**H-03 — `Asset_Ref` exists on Doors, Windows and Casework and is populated on
zero elements.** A parameter that exists and is empty is worse than one that
does not exist, because it looks like a plan that was followed.

**M-04 — Mechanical Equipment is the one well-prepared category.** 318 of 318
carry `BMS_AssetTag`. **Whatever process produced that should be applied to
rooms.** `[inferred]` — the basis is the fill rate contrast.

**M-05 — Element identity across re-exports is unassessed.** Only one model
state was supplied. **Whether element identity persists across re-exports is
only visible across two**, and for an operational twin that is re-published as
the building changes, it is the test that matters most. `[verify manually]`

**The honest position:** this model can produce an excellent walkthrough today.
**It cannot produce the twin the client described**, and the gap is cheaper to
close in Revit — by populating `BMS_AssetTag` on the remaining 46 classrooms
and making Room Numbers unique — than by building a matching layer engine-side.
That choice should be made knowingly.

---

## §5 — Geometry census, ranked by weight

**Total estimated: ~23.5 million triangles.** `[estimated]` — the technician's
figures, extrapolated from a single-level test FBX export (§2 of the input).
**A full test export would settle them**, and nothing below should drive a
final decision without one.

| Rank | Category | Elements | Triangles | Share | Cumulative |
|---|---|---|---|---|---|
| 1 | **Furniture** | 6,140 | **4,920,000** | 20.9% | 20.9% |
| 2 | **Pipe Fittings** | 8,960 | **3,640,000** | 15.5% | 36.4% |
| 3 | **Casework** | 2,918 | **2,460,000** | 10.5% | 46.9% |
| 4 | **Lighting Fixtures** | 3,284 | **2,180,000** | 9.3% | 56.2% |
| 5 | Doors | 1,462 | 1,870,000 | 8.0% | 64.1% |
| 6 | Plumbing Fixtures | 742 | 1,410,000 | 6.0% | 70.1% |
| 7 | Railings | 286 | 1,240,000 | 5.3% | 75.4% |
| 8 | Ducts and fittings | 4,420 | 1,120,000 | 4.8% | 80.1% |
| 9 | Generic Models | 1,840 | 980,000 | 4.2% | 84.3% |
| 10 | Mechanical Equipment | 318 | 890,000 | 3.8% | 88.1% |
| 11 | Pipe Accessories | 1,210 | 720,000 | 3.1% | 91.2% |
| 12 | Curtain Wall Mullions | 3,106 | 496,000 | 2.1% | 93.3% |
| — | **Everything else (11 categories)** | — | **1,583,000** | **6.7%** | 100% |

**H-04 — The entire architectural envelope is 6.7% of the budget.** Walls,
floors, roofs, ceilings, curtain panels, columns, framing, windows, stairs,
specialty equipment and topography together are **~1.58 million triangles**.

**The top four categories — furniture, pipe fittings, casework and lighting —
are 13.2 million triangles, 56% of the model.**

**M-06 — Pipe fittings are 15.5% of the budget and will not be seen.** 8,960
fittings at ~406 triangles each, inside ceiling voids and risers. For a
walkthrough and a reception touchscreen they are invisible. For an operational
twin they may matter as *data*, and data does not need geometry — **the
`BMS_AssetTag` on Mechanical Equipment is the model for that.**

**M-07 — Railings at 4,336 triangles each.** 286 elements, 1.24 million
triangles. Balusters modelled as individual swept solids is the usual cause,
and it is the single highest per-element cost in the model.

**M-08 — Stairs at 6,235 triangles each.** 34 elements, 212,000 triangles.
Small in total, extreme per element.

---

## §6 — Instancing

**Strong candidates, by repetition.** Instanced geometry is the cheapest large
win available and it is usually left on the table because nobody lists the
candidates.

| Category | Elements | Likely distinct types | Note |
|---|---|---|---|
| **Furniture** | **6,140** | A school's furniture is typically a handful of chair, table and storage types | **The largest single opportunity in the model** |
| **Pipe Fittings** | **8,960** | Bends, tees, reducers in a few sizes | Alternatively excluded entirely — see §8 |
| **Lighting Fixtures** | **3,284** | Likely very few types | — |
| Casework | 2,918 | Repeated classroom units | — |
| Doors | 1,462 | Door types | — |
| Curtain Wall Mullions | 3,106 | One or two profiles | — |

**Type counts were not supplied**, so the opportunity cannot be sized here.
`[verify manually]` — a type-vs-occurrence schedule would quantify it, and it
is the single most useful extra piece of information for this exercise.

---

## §7 — Materials and UVs

| Finding | Detail |
|---|---|
| **H-05 — 3,412 elements with no material assigned** | Each becomes engine-side rework. They will import with a default material and must be identified and reassigned by hand |
| **M-09 — 38 materials named `Default`** | Over-shared: visually distinct things will arrive sharing one material |
| **M-10 — 61 materials have a surface pattern but no appearance asset** | They carry drafting information and no render appearance |
| M-11 — 3,228 transparent elements | Curtain panels, windows, railings. Transparency ordering and shadow behaviour need engine-side attention, and railings are also the per-element weight problem (M-07) |
| **UVs** | **`[verify manually]` — the input records this as unknown and needing a test export.** Any surface needing a tiled or mapped texture without usable UVs is rework |

---

## §8 — Hygiene and exclusions

**Hygiene**

| Finding | Count |
|---|---|
| **H-06 — Duplicate instances** | **318** — these z-fight in the engine, which reads as a rendering fault and is traced back to the model only after someone wastes a day |
| M-12 — Joined but not intersecting | 406 |
| M-13 — Rooms not properly enclosed | 8 — bears on §4, since an unenclosed room may not export as a bindable volume |
| **H-07 — Elements hidden in all views** | **2,104 — hidden in Revit does not mean excluded from export** |
| M-02 | 1,886 on `TEMP - delete before issue` |

**Exclusion list — for the author to action in Revit, with reasons**

| # | Exclude | Reason | Saves (est.) |
|---|---|---|---|
| E-01 | `TEMP - delete before issue` workset | Its name is an instruction | — |
| E-02 | Unaccepted design option geometry | M-03 | — |
| E-03 | Elements hidden in all views, after review | H-07 | — |
| E-04 | **Pipe Fittings and Pipe Accessories** | Never seen; carry data, not geometry (M-06) | **~4,360,000 (18.5%)** |
| E-05 | **Ducts and fittings**, above ceiling | Never seen | ~1,120,000 (4.8%) |
| E-06 | Duplicate instances | H-06 | — |
| E-07 | Levels `WORKING`, `DO NOT USE`, `Datum 1/2`, `TOS 01/02` from the level filter | M-01 | — |

**E-04 and E-05 together are ~5.5 million triangles, 23% of the model, with no
visual consequence for either stated use.**

---

## §9 — Export checklist

In order. **The author performs each; this report performs none of them.**

1. **Decide the placement option** (§2) and **record the offset and 31.5°
   rotation as project data in a file that travels.**
2. Decide the design option set to export (M-03).
3. Purge or exclude `TEMP - delete before issue` (E-01).
4. Review and resolve the 2,104 elements hidden in all views (E-03).
5. Resolve the 318 duplicate instances (E-06).
6. **Populate `BMS_AssetTag` on the remaining 46 classrooms** (H-01).
7. **Make the 23 duplicate Room Numbers unique** (H-02).
8. Decide whether `Asset_Ref` is used; populate it or remove it (H-03).
9. Assign materials to the 3,412 unassigned elements (H-05).
10. Rename or remap the 38 `Default` materials (M-09).
11. Exclude pipe and duct fittings (E-04, E-05).
12. Review railing and stair tessellation (M-07, M-08).
13. **Run a full test export** and replace every `[estimated]` figure in §5
    with a measured one.
14. **Export twice and compare element identity** (M-05) before anything binds
    live data.

---

## §10 — The specific questions asked

**§7.2 — "Why does our test scene jitter?"** B-01. The model is authored at
shared coordinates roughly 441 km and 388 km from its internal origin, in a
single-precision engine. A placement decision made a year ago, not an engine
fault.

**§7.3 — "Where's the polygon budget going? We can't just decimate
everything."** You should not decimate everything, and §5 is why. **The
architectural envelope is 6.7% of the budget.** Four categories nobody will
look at are 56%. Cut from the top of the ranked list — excluding pipe and duct
fittings alone is 23% of the model with no visual consequence — and leave the
envelope alone.

**§7.4 — "Will the twin work — can we click a classroom and get live data?"**
**For 22 of 68 classrooms.** See §4. The fix is in Revit, not in Unreal: 46
classrooms need `BMS_AssetTag` and 23 Room Numbers need to be made unique.
Mechanical Equipment is already at 100%, which shows the process exists.

**§7.5 — "What's our triangle budget for the reception touchscreen?"**
**Not stated here.** A budget depends on the target hardware, the lighting
approach, the frame-rate target and the scene complexity — none of which has
been specified, and a remembered figure would be wrong in an unknown direction.

**Tell this report the target hardware and the frame-rate target and §5 can be
ranked against it.** Until then §5 ranks the categories and names the four that
dominate, which is what the cutting decision actually needs.

---

## §11 — What was not checked

- **Nothing was modified, purged, decimated, re-origined or exported.**
- Triangle counts are `[estimated]` from a single-level extrapolation. **A full
  test export would settle them** and no final decision should rest on them.
- Type-vs-occurrence counts — not supplied, so the instancing opportunity (§6)
  could not be sized.
- UV availability — needs a test export.
- Linked structural, MEP and site survey models — their contents, placement and
  weight are outside this report, and the twin will need a decision about
  whether they export too.
- Engine-side work: materials, Blueprints, data binding, level streaming,
  lighting.
- Whether the geometry is correct, coordinated or buildable.
