# Shawfield Depot — fee enquiry and practice data

**Enquiry received:** 2 March 2026
**From:** Tarnside Developments Ltd
**To:** Hallam & Roe Architects

*Fictional client, project and practice. Deliberately imperfect.*

---

## §1 — The enquiry email

> Hi,
>
> We've acquired the old Shawfield Depot site and need an architect. It's about
> 1.2 ha, we're thinking 90–110 units plus some commercial at ground floor,
> and there are two existing buildings we'd like to keep if we can.
>
> We need full architectural services through to completion. The site's in a
> conservation area so there'll be a bit of back and forth with planning.
>
> Our board wants to see a fee by 13 March. We've had one other number in
> already which was 4.5%, so that's the benchmark.
>
> Attached is the ER document from the last scheme we did at Brantwood — we'd
> want you to work to the same standard.
>
> Can you also give us a view on whether the buildings are worth keeping?
>
> Tom

---

## §2 — Attachment: Brantwood Employer's Requirements (extracts)

§2.1 "The Architect shall provide full architectural services from inception
to completion, including all design development and **reasonable amendments**
as required by the Employer."

§2.2 "The Architect shall attend all design team meetings, client meetings and
site meetings as required."

§2.3 "The Architect shall be novated to the Contractor at the commencement of
the construction phase."

§2.4 "The Architect shall produce all information required for the planning
submission, building control submission and construction, including coordinated
information from all consultants."

§2.5 "The Architect shall provide BIM services to the Employer's BIM Execution
Plan." *(BEP not attached.)*

§2.6 "The Architect's appointment shall include a 12-year collateral warranty
to the Employer, the Funder and any purchaser."

---

## §3 — What the enquiry does and does not establish

**Stated:** site area 1.2 ha; 90–110 units; commercial at ground floor
("some"); two existing buildings to be retained "if we can"; conservation area;
full services to completion; novation contemplated (per the attached ER); board
deadline 13 March.

**Not stated:** the contract; the procurement route; the construction budget;
the number of planning submissions expected; whether a pre-application is
expected; whether a resubmission is included; the number of design team
meetings; the number of client meetings; who appoints the other consultants;
whether there is an existing survey of the retained buildings; whether the
buildings are listed; the BIM standard; the required start date; the programme.

---

## §4 — Practice rate card (Hallam & Roe, effective 1 January 2026)

| Grade | Hourly rate |
|---|---|
| Director | £165 |
| Associate | £125 |
| Architect | £95 |
| Architectural assistant | £68 |
| Technologist | £88 |

**Expenses policy:** "Travel and printing at cost, recharged monthly.
Mileage at the practice rate."

**Note on the rate card:** "Rates reviewed annually each January."

---

## §5 — Practice resource data

The practice holds resource figures for the following stages, from its own
records on comparable residential schemes:

| Stage | Director | Associate | Architect | Assistant | Technologist |
|---|---|---|---|---|---|
| Stage 2 | 4 days | 12 days | 25 days | 15 days | — |
| Stage 3 | 6 days | 20 days | 45 days | 20 days | 10 days |
| Stage 4 | 8 days | 30 days | 70 days | 15 days | 60 days |

**No resource data is held for Stage 1, Stage 5, Stage 6 or Stage 7.**

---

## §6 — Practice standard terms (extracts held by the practice)

§6.1 "Fees are invoiced monthly in arrears against percentage completion of the
stage."
§6.2 "Payment terms: 30 days from date of invoice."
§6.3 "The practice's professional indemnity insurance is £5m each and every
claim."
§6.4 "Copyright in the design remains with the practice; a licence to use is
granted on payment of fees."

---

## §7 — What the practice director has asked for

1. "Draft the fee proposal."
2. "Use our rate card."
3. "What do we need to decide before this goes out?"
4. "They've given us 4.5% as a benchmark — are we competitive at that?"
5. "And give them the view on the retained buildings, it'll help us win it."
