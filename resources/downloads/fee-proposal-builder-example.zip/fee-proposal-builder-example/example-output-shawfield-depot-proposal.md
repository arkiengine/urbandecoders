# Shawfield Depot — fee proposal

**To:** Tarnside Developments Ltd
**From:** Hallam & Roe Architects
**Date:** 4 March 2026
**Status: draft. §9 is internal and must be deleted before issue.**

---

## §1 — Our understanding of the commission

A residential-led mixed-use development at the former Shawfield Depot,
approximately **1.2 ha**, comprising **90–110 dwellings** and commercial
accommodation at ground floor, within a **conservation area**, retaining
**two existing buildings** where feasible. Full architectural services from
inception to completion, with **novation to the contractor** at the
commencement of the construction phase.

The following are not established by the enquiry and are carried as
assumptions in §4 rather than assumed silently:

| Item | Status |
|---|---|
| Form of contract and procurement route | `[TBC]` |
| Construction budget | `[TBC]` |
| Commercial floor area — "some commercial at ground floor" | `[TBC]` |
| Whether the retained buildings are listed | `[TBC]` |
| Whether a measured survey of the retained buildings exists | `[TBC]` |
| Number of planning submissions; pre-application; resubmission | `[TBC]` |
| Programme and required start date | `[TBC]` |
| BIM Execution Plan (referred to at ER §2.5, not attached) | `[TBC]` |
| Who appoints the other consultants | `[TBC]` |

---

## §2 — Scope of services by stage

Stated in deliverables and counts. **Where the enquiry does not establish a
count, it is `[TBC]` and appears in §4 — it has not been defaulted to a
plausible number.**

### Stage 1 — Preparation and brief
- Review of site information provided by the Client
- Preparation of a written brief for the Client's approval
- Initial appraisal of the two existing buildings **based on information
  supplied by the Client** (see Exclusion E-11)
- `[TBC]` Client meetings
- **Information required from the Client before this stage can commence:** site
  survey, title information, measured survey of the retained buildings,
  ground investigation, the Client's accommodation requirements

### Stage 2 — Concept design
- Site layout options and preferred option at 1:500
- Concept plans, sections and elevations at 1:200
- Schedule of accommodation and area schedule
- Design and Access Statement contribution
- `[TBC]` design team meetings, `[TBC]` Client meetings
- One Client presentation
- **Information required from others:** consultant appointments in place;
  transport, ecology, heritage and drainage inputs

### Stage 3 — Spatial coordination
- General arrangement plans, sections and elevations at 1:100
- Typical unit plans at 1:50
- Outline specification
- Coordination with `[TBC]` consultants
- Planning submission drawings and documents
- **`[TBC]` pre-application meetings · one planning submission · response to
  `[TBC]` rounds of officer comments**
- **Resubmission: `[TBC]` — see Assumption A-04**
- `[TBC]` design team meetings, `[TBC]` Client meetings

### Stage 4 — Technical design
- Technical drawings and details to building control and construction standard
- Full specification
- Schedules (doors, windows, ironmongery, finishes)
- Building control submission
- Coordination of consultant information
- `[TBC]` design team meetings
- **Services conclude at novation** — see Assumption A-01

### Stage 5 — Manufacturing and construction
- **Scope to be agreed following confirmation of the novation position.**
  Post-novation the Architect's client is the Contractor, and the services,
  the fee basis and the Employer-side role (if any) are different questions.
  `[TBC]` — see Assumption A-01

### Stages 6 and 7 — Handover and use
- `[TBC]` — not defined by the enquiry

---

## §3 — Exclusions

**Itemised. A silent exclusion is not an exclusion.**

| # | Item | Status |
|---|---|---|
| E-01 | Topographical, measured and condition surveys | Excluded |
| E-02 | Ground investigation and contamination assessment | Excluded |
| E-03 | Structural, civil, MEP, acoustic, fire and facade engineering | Excluded |
| E-04 | Heritage consultancy and Heritage Impact Assessment | **Excluded — likely required in a conservation area with retained buildings** |
| E-05 | Planning consultancy | Excluded |
| E-06 | Transport, ecology, arboriculture, drainage and flood risk | Excluded |
| E-07 | CDM Principal Designer duties | **Excluded — the Client must appoint** |
| E-08 | Building control fees, planning fees and statutory charges | Excluded |
| E-09 | Verified views, AVRs and photomontage | Excluded |
| E-10 | 3D visualisation, marketing material and sales imagery | Excluded |
| E-11 | **Structural, condition or feasibility assessment of the retained buildings** | **Excluded — see §8** |
| E-12 | Value engineering rounds beyond `[TBC]` | `[TBC]` |
| E-13 | Resubmission of a refused or withdrawn planning application | `[TBC]` — see A-04 |
| E-14 | Party wall, rights of light and neighbourly matters | Excluded |
| E-15 | BIM services beyond the practice's standard output | **`[TBC]` — the BEP referred to at ER §2.5 was not supplied** |
| E-16 | Post-novation Employer-side monitoring | `[TBC]` — see A-01 |
| E-17 | Post-completion services, defects inspections and O&M input | `[TBC]` |

---

## §4 — Assumptions on which this fee depends

**Numbered, so they can be referred to by number. If any ceases to be true,
the fee is affected.**

| # | Assumption |
|---|---|
| **A-01** | The Architect is novated to the Contractor at the commencement of the construction phase (ER §2.3). **The fee covers Stages 1–4 only.** Stage 5 onward is a separate appointment with a different client and is `[TBC]`. |
| **A-02** | The unit number is `[TBC]` within the stated 90–110 range. The fee is built on `[TBC]` units; a change in unit number changes the fee. |
| **A-03** | The commercial floor area is `[TBC]`. "Some commercial at ground floor" does not establish a quantum. |
| **A-04** | **The fee assumes one planning submission. A resubmission following refusal or withdrawal would be an additional service.** |
| **A-05** | The fee assumes `[TBC]` pre-application meetings and `[TBC]` rounds of response to officer comments. |
| **A-06** | The fee assumes `[TBC]` design team meetings and `[TBC]` Client meetings per stage. |
| **A-07** | A measured survey of the two retained buildings is provided by the Client before Stage 2 commences. |
| **A-08** | The retained buildings are **not listed**. If either is listed, the scope, the consents required and the fee all change. |
| **A-09** | The Client appoints all other consultants directly. |
| **A-10** | Consultant information is provided to the dates agreed in the information release schedule. |
| **A-11** | The project proceeds without suspension. A suspension exceeding `[TBC]` months would be an additional service. |
| **A-12** | The BIM requirement is the practice's standard output. The Employer's BEP (ER §2.5) has not been supplied. |
| **A-13** | **"Reasonable amendments" (ER §2.1) is not accepted as a scope definition.** The design development included is that described in §2; amendments arising from a change of brief, a change of unit number, or a change of planning strategy are additional services. |

---

## §5 — Fee build-up

**Built from the practice's own rate card (effective 1 January 2026) and the
practice's own resource records. No rate, percentage or hours figure has been
supplied from any other source.**

### Rates applied

| Grade | Rate |
|---|---|
| Director | £165 |
| Associate | £125 |
| Architect | £95 |
| Assistant | £68 |
| Technologist | £88 |

### Stage 2 — Concept design

| Grade | Days | Rate | Hours @ 7.5 | Amount |
|---|---|---|---|---|
| Director | 4 | £165 | 30 | £4,950 |
| Associate | 12 | £125 | 90 | £11,250 |
| Architect | 25 | £95 | 187.5 | £17,812.50 |
| Assistant | 15 | £68 | 112.5 | £7,650 |
| **Stage 2 total** | **56 days** | | **420 hrs** | **£41,662.50** |

### Stage 3 — Spatial coordination

| Grade | Days | Rate | Hours @ 7.5 | Amount |
|---|---|---|---|---|
| Director | 6 | £165 | 45 | £7,425 |
| Associate | 20 | £125 | 150 | £18,750 |
| Architect | 45 | £95 | 337.5 | £32,062.50 |
| Assistant | 20 | £68 | 150 | £10,200 |
| Technologist | 10 | £88 | 75 | £6,600 |
| **Stage 3 total** | **101 days** | | **757.5 hrs** | **£75,037.50** |

### Stage 4 — Technical design

| Grade | Days | Rate | Hours @ 7.5 | Amount |
|---|---|---|---|---|
| Director | 8 | £165 | 60 | £9,900 |
| Associate | 30 | £125 | 225 | £28,125 |
| Architect | 70 | £95 | 525 | £49,875 |
| Assistant | 15 | £68 | 112.5 | £7,650 |
| Technologist | 60 | £88 | 450 | £39,600 |
| **Stage 4 total** | **183 days** | | **1,372.5 hrs** | **£135,150** |

### Stages 1, 5, 6 and 7

| Stage | Fee |
|---|---|
| Stage 1 — Preparation and brief | **`[TBC]`** |
| Stage 5 — Construction | **`[TBC]`** — see A-01 |
| Stage 6 — Handover | **`[TBC]`** |
| Stage 7 — Use | **`[TBC]`** |

**The practice holds no resource data for these stages** (§5 of the enquiry
pack). They cannot be built up from the information available and are not
estimated.

### Summary

| Stage | Fee |
|---|---|
| Stage 1 | `[TBC]` |
| Stage 2 | £41,662.50 |
| Stage 3 | £75,037.50 |
| Stage 4 | £135,150.00 |
| **Stages 2–4 subtotal** | **£251,850.00** |
| Stages 5–7 | `[TBC]` |
| **Total** | **Cannot be stated — four of seven stages are `[TBC]`** |

**Basis of the arithmetic:** days × 7.5 hours × the practice rate card.
**Source of the days: the practice's own resource records** (§5 of the enquiry
pack), which are stated to be drawn from comparable residential schemes.

**Not included in the above and requiring a decision before issue:** overhead
and profit treatment, expenses (the practice's policy is "at cost, recharged
monthly" — no allowance is made here), and any adjustment for the conservation
area context or the retained buildings. See §9.

---

## §6 — Additional services

Charged separately. **Bases are the practice's own; no new basis has been
invented.**

| Service | Basis |
|---|---|
| Resubmission of a planning application | Time charge at the rates in §5 |
| Design changes arising from a change of brief or unit number | Time charge |
| Value engineering beyond `[TBC]` rounds | Time charge |
| Attendance beyond the meeting counts in A-05 and A-06 | Time charge |
| Services following any suspension exceeding `[TBC]` months | Time charge |
| Post-novation Employer-side services | `[TBC]` |
| Any service listed as excluded in §3, if subsequently instructed | Time charge |

---

## §7 — Programme and commercial terms

**Programme:** the fee assumes a continuous programme through Stages 1–4. **No
duration is stated in the enquiry** (§3), so no duration is assumed here.
Assumption A-11 covers suspension.

**Commercial terms** — the practice's own standard terms:

- Fees invoiced monthly in arrears against percentage completion of the stage.
- Payment terms 30 days from date of invoice.
- Professional indemnity insurance £5m each and every claim.
- Copyright remains with the practice; licence to use granted on payment.
- Expenses: travel and printing at cost, recharged monthly; mileage at the
  practice rate.

**Rate card note:** rates are reviewed annually each January. The rates in §5
are effective 1 January 2026.

---

## §8 — The retained buildings

The enquiry asks for "a view on whether the buildings are worth keeping".

**This proposal does not give that view**, and no fee has been built for the
work that would produce it. Such a view requires a measured survey, a
structural appraisal, and — in a conservation area, with the listing status
unconfirmed (A-08) — heritage input. None of those exists.

**Scope of work that would answer it** can be proposed separately as a Stage 0
/ feasibility commission. It is excluded from this proposal at E-11.

---

## §9 — INTERNAL — delete before issue

### `[TBC]` items blocking issue

| # | Decision needed | Blocks |
|---|---|---|
| 1 | **Overhead and profit treatment.** The build-up in §5 is resource cost at rate-card rates only. **Issuing it as a fee would issue a cost, not a fee.** | The entire §5 total |
| 2 | **Expenses allowance.** Policy is "at cost"; no sum is included. | §5, §7 |
| 3 | Stage 1, 5, 6 and 7 fees — no resource data held | Four of seven stages |
| 4 | Unit number to build on (A-02) | §5 |
| 5 | Commercial quantum (A-03) | §5 |
| 6 | Meeting counts (A-05, A-06) | §2, §5 |
| 7 | Whether a resubmission is included (A-04) | §2, §3, §6 |
| 8 | Value engineering rounds (E-12) | §3, §6 |
| 9 | Suspension period (A-11) | A-11, §6 |
| 10 | BIM scope — BEP not supplied (A-12, E-15) | §3 |

### Director decisions

| # | Issue |
|---|---|
| 11 | **ER §2.1 "reasonable amendments"** — A-13 expressly rejects it as a scope definition. **The client may not accept that.** It is the single largest open-ended exposure in the enquiry and it needs a position, not a drafting fix. |
| 12 | **ER §2.6 — 12-year collateral warranty to Employer, Funder and any purchaser.** The practice's PI is £5m each and every claim. **Warranty terms, liability caps and net contribution are for the practice's own advisers, not this proposal.** No position is taken here. |
| 13 | **ER §2.4 — "coordinated information from all consultants"** against A-09 (Client appoints consultants directly). Coordinating information the practice does not procure is a scope and risk question. |
| 14 | **ER §2.2 — "all design team meetings, client meetings and site meetings as required".** Open-ended. A-05 and A-06 substitute counts; the client may push back. |
| 15 | Novation (A-01) — confirm Stages 1–4 is the intended commission, and whether an Employer-side role post-novation is wanted. |
| 16 | Whether the retained buildings are listed (A-08). This is checkable before 13 March and materially changes the scope. |

### Claims not evidenced by supplied material

None. **No practice experience, accreditation, capability or project reference
is asserted anywhere in this proposal**, because no practice credentials were
supplied with the enquiry. If a capability section is wanted, the material must
be provided.

### On the 4.5% benchmark

**Not addressed in the proposal, and no view is offered here.** This builder
does not benchmark against market fees and does not assess whether a fee is
competitive. Two factual observations for the director only:

- The §5 subtotal covers **Stages 2–4 only** and is a resource cost before
  overhead, profit and expenses. It is not comparable to a percentage of
  construction cost.
- **No construction budget has been stated** (§3), so 4.5% does not resolve to
  a number from anything in the enquiry.

### Before issue

1. **Delete this section.**
2. Close items 1 and 2, or the proposal states a cost as a fee.
3. Decide items 11 and 12 at director level.
4. Confirm the §5 arithmetic against the practice's own records.
