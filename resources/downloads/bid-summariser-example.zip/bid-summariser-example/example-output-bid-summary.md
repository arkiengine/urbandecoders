# Internal bid summary — ITT ref BR/FLQ/2026/04

**Source:** Invitation to Tender, "Foundry Lane Quarter, Aldenwick — Architectural Services", issued 10 August 2026 (single .docx, Appendices A–C summarised within it). **Not supplied with this pack:** Pricing Schedule, Appendix B response template, Form of Tender, 2024 capacity study, topographical survey, ground conditions desk study, draft Aldenwick Design Code (all referenced — see §9). **No internal fee material attached** — fee section is TBC by rule.

**Summary prepared:** 11 August 2026. Draft for the bid team's review — verify all dates against the pack before diarising.

---

## 1. At-a-glance

- **Client / project:** Bellmere Regeneration LLP (Bellmere Estates + Wharfdale Homes JV) — Foundry Lane Quarter, Aldenwick. ~3.1 ha former ironworks/sidings site, canal-side, locally listed Engine Shed retained [stated §1.1].
- **The ask:** Single architect appointment, RIBA Stages 2–3, lead designer for Phase 1 planning application — plus a masterplan role whose seniority the ITT contradicts itself on (see C2) and Stage 4+ deliverables that leak past the stated appointment (see §5).
- **Submission deadline: CONFLICT — three versions.** Safe planning assumption is the earliest: **12:00 noon, Friday 25 September 2026** via Delta e-sourcing portal [stated §6.2]. Cover page says 17:00 same day; timetable says Monday 28 September. Clarify (C1).
- **Fit for us: High** — residential-led mixed-use regeneration with a masterplan dimension and heritage setting; squarely the practice's core ground.
- **Decision needed:** Go/no-go **by Thursday 20 August 2026** — the mandatory site-visit booking closes 12:00 Friday 21 August [stated §1, footnote]. Clarification questions close 4 September [stated §6.4].

## 2. The opportunity

- Residential-led mixed-use regeneration: ~350 homes (but see C5 — the pack also says 400 and 315), flexible commercial/community ground floor, new public square, canal towpath connections [stated §1.2, §3.1].
- Landscape-led public realm and tenure-blind design ambitions align with the practice's portfolio [stated §3.2].
- Masterplan involvement in the wider Foundry Lane area — role to be clarified, but potentially a framework-leading position [stated §1.3 vs §4.1].
- Grant-funded Phase 1 with a strong affordable component — 35% or ≥50% depending on which clause governs (C6) [stated §1.2 vs §3.3].
- Lead-designer role coordinating a client-appointed multidisciplinary team [stated §4.1].

## 3. Key dates

| Event | Date | Source |
|---|---|---|
| ITT issued | Mon 10 Aug 2026 | §2.1 |
| **Site-visit booking deadline** | **12:00 Fri 21 Aug 2026** | §1 footnote |
| Mandatory accompanied site visit | 26–27 Aug 2026 | §1 footnote |
| **Clarification questions close** | **17:00 Fri 4 Sep 2026** | §6.4 (timetable row says only "See Section 6") |
| Submission deadline — `CONFLICT` | 12:00 noon Fri 25 Sep 2026 | §6.2 — **earliest; plan to this** |
| Submission deadline — `CONFLICT` | 17:00 Fri 25 Sep 2026 | Cover page |
| Submission deadline — `CONFLICT` | Mon 28 Sep 2026 | §2.1 timetable |
| Evaluation / interviews (if held) | w/c 5 Oct / w/c 12 Oct 2026 | §2.1 |
| Award; Stage 2 start | Late Oct; Nov 2026 | §2.1 |
| Planning submission (Phase 1) | Autumn 2027 | §2.1 |
| Tender validity | 90 days from deadline | §6.3 |

**Watch:** the site visit is mandatory and appears only in a small-print note at the end of §1 — not in the timetable. Non-attendance "may be rejected". Book before go/no-go is formally minuted if necessary.

## 4. Submission requirements

- **Channel: CONFLICT.** §6.2: Delta e-sourcing portal only (ref BR/FLQ/2026/04); "email, post or hand will not be accepted". Appendix C.3: forms "should be returned by email to procurement@…". Clarify (C4); until answered, prepare for portal-only and allow upload time. Register on the portal now if not already.
- **Quality submission:** max **20 A4 pages** excluding covers [stated §6.1] — but the required contents don't fit: MS1–MS8 at up to 2pp each (16pp) + ≥6 one-page CVs (6pp) + ≥3 project sheets (3pp+) = 25pp+ (C3). Named project architect CV required [stated §6.1].
- **Format: CONFLICT.** A4 limit in §6.1 vs Appendix B template "formatted at A3 landscape", use encouraged (C3).
- **Pricing Schedule:** separate document [stated §6.1]. Not supplied in this pack — request.
- **Mandatory forms (Appendix A):** form of tender, non-collusion, conflicts of interest, PI confirmation, equality declaration — signed by a director/authorised signatory; **unsigned forms invalidate the tender** [stated App A].
- **Non-contact rule:** no approaches to the Borough, members, officers or client team [stated §6.4].

## 5. Likely scope & deliverables by stage

| Stage | Scope | Tag |
|---|---|---|
| Stage 1 (residual) | Site appraisal; review of surveys and 2024 capacity study | [stated §4.2] |
| Stage 2 | Concept design: massing options, unit mix/typology studies, typical plans, tenure diagrams, coordinated DT drawings | [stated §4.2] |
| Stage 2–3 | Masterplan role — "support and input" (§1.3) **or** "lead and coordinate" (§4.1): `CONFLICT`, fee-defining | [stated, contradictory] |
| Stage 3 | Spatial coordination; Phase 1 planning pack; DAS input; support through determination; design code compliance statements | [stated §4.2] |
| **Stage 4 — leak** | "Tender-ready technical drawings and outline specification" despite appointment being Stages 2–3 only (§3.4) | [stated §4.2 — outside stated appointment; do not absorb unpriced] |
| **Stage 5+ — leak** | "Site support during construction as reasonably required" — unbounded | [stated §4.2 — clarify/cap] |
| Throughout | Fortnightly DTMs, client reviews, up to 4 public/stakeholder events | [stated §4.2 — assumption base for resourcing] |
| Throughout | ISO 19650 information management per Appendix C; **EIR "to follow"** — unpriceable as issued | [stated App C.1] |

**Residential-specific asks:** tenure-blind design; family housing at lower levels; "all relevant national and local space standards" — none named: check the Nationally Described Space Standard and Aldenwick local plan policy `[to verify]`; compliance with the **draft** Aldenwick Design Code (consultation draft, June 2026 — unadopted, unissued) [stated §3.2, App C.4]. Sustainability targets deferred to Stage 2, i.e. unpriced [stated §3.2].

## 6. Evaluation

70% quality / 30% price headline [stated §5.1] — **but the sub-criteria don't sum**: quality rows total 80% (15+20+10+10+15+10), giving 110% overall (C7). MS7 (information management) and MS8 (social value) are required submissions [§6.1] yet absent from the evaluation table — scored or not? (C8). Interview "may be held" and "will inform the final quality score" — mechanism and weighting unstated [stated §5.2].

## 7. Risks & easy misses

- **Site-visit booking closes 21 August** — footnote-only; the single most time-critical line in the pack [§1].
- **PI mismatch:** £10m each-and-every, 12 years (§8.2) vs £5m on the Appendix A form (C9). At £10m/12yr, check with broker before committing.
- Bespoke appointment; draft issued only to the *successful* tenderer — terms unseen at tender [§1.4]. Collateral warranties to funder and Borough, form unseen [§8.3].
- BIM/ISO 19650 lives only in Appendix C — easy to miss in scoping and in MS7 [App C.1].
- Prior-involvement conflicts: the 2024 capacity study author — declare if relevant [App A].
- Page-limit arithmetic (C3) means the submission design must start from the clarification answer, not the template.
- No parent company guarantee mentioned — worth one line, not a query.

## 8. Conflicts & clarifications

Submit via portal messaging **before 17:00 Fri 4 September 2026** [§6.4]. Drafted questions:

1. **C1 — Deadline.** "The cover page states 17:00 on 25 September, §6.2 states 12:00 noon on 25 September, and the §2.1 timetable states 28 September as the submission deadline. Please confirm the definitive date and time." *(Planning to 12:00, 25 Sep meanwhile.)*
2. **C2 — Masterplan role.** "§1.3 describes the architect as supporting a framework masterplan prepared by others; §4.1 states the architect will lead and coordinate the framework masterplan. Please confirm the intended role and its deliverables."
3. **C3 — Page limit & format.** "§6.1's required contents (MS1–MS8 at up to 2pp, ≥6 CVs, ≥3 project sheets) exceed the 20-page limit; please confirm what counts toward the limit, and how A3 sheets per the Appendix B template are counted against an A4 limit."
4. **C4 — Channel.** "§6.2 requires portal-only submission; Appendix C.3 asks for forms by email. Please confirm whether any element is to be submitted outside the portal."
5. **C5 — Quantum.** "§1.2 (circa 350), §3.1 (up to 400) and the 2024 capacity study (315) give different home numbers. Please confirm the basis tenderers should assume for resourcing and fee."
6. **C6 — Affordable.** "§1.2 states 35% affordable; §3.3 states not less than 50% across Phase 1 as a funding condition. Please confirm the governing figure and the metric (units or habitable rooms)."
7. **C7/C8 — Evaluation.** "The quality sub-criteria at §5 sum to 80% against a 70% headline weighting; please confirm the weightings, and whether MS7 and MS8 are scored."
8. **C9 — PI.** "§8.2 requires £10m each-and-every PI; the Appendix A form certifies £5m. Please confirm the required level."
9. **C10 — Fee basis.** "§7.1 requires a percentage of construction cost and §7.3 a fixed lump sum; the construction cost is not stated. Please confirm the fee basis and the assumed construction cost or budget."
10. **C11 — Scope.** "§4.2 includes tender-ready technical drawings and construction-period site support within a Stage 2–3 appointment (§3.4). Please confirm whether these are within the tendered fee or subject to a future appointment."

*None of these are resolved in this summary — the answers govern, not our reading.*

## 9. Fee position — **Fee: TBC**

No internal fee benchmarks, rate cards or comparable bids were attached, and the ITT's own fee basis is contradictory (C10): a percentage of a construction cost that is never stated — only "total project value in the order of £68m including land" [§3.4] — and simultaneously a fixed lump sum [§7.1 vs §7.3]. An indicative range now would be invented; declined by rule.

**To price, we need:** (a) answer to C10 including the construction budget; (b) answers to C2, C5, C6 and C11 — role, quantum, tenure and scope boundary each move the fee materially; (c) internal benchmarks for Stage 2–3 residential-led regeneration at this scale + current rate card; (d) the Pricing Schedule itself; (e) the "available on request" documents: 2024 capacity study, topo survey, ground desk study, draft Design Code [App C.4]; (f) broker view on £10m/12-year PI; (g) meeting-load assumptions confirmed (fortnightly DTMs, 4 events).

**Information still needed (non-fee):** Appendix B template; Form of Tender; draft appointment terms (only issued post-award — flag to director); EIR (post-award — price the risk, not the document).

---

**Headline caveats (also said in chat):** earliest hard date is the **site-visit booking, 12:00 Fri 21 Aug**; **11 unresolved conflicts/clarifications** drafted above, none adjudicated; **fee is TBC** — nothing attached could evidence a range. This summary informs the go/no-go; it does not make it.
