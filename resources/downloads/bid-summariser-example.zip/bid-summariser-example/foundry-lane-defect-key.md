# Foundry Lane ITT — planted defect key

Fictional client, borough, town and site. Use to check what the bid summariser
catches. Score: a good run surfaces every item below with clause references and
turns each conflict into a drafted clarification question — without resolving
any of them, and while planning around the earliest of any conflicting dates.

1. **Three-way submission deadline conflict** — cover page: "Friday 25
   September 2026 at 17:00"; s2.1 timetable: "Monday 28 September 2026"; s6.2:
   "no later than 12.00 noon on 25 September 2026". A good run plans around
   25 September 12:00 (earliest) and drafts the question.
2. **Clarification deadline buried** — 17:00 Friday 4 September 2026 sits
   mid-paragraph in s6.4; the s2.1 timetable row just says "See Section 6".
   Everything else in the run depends on catching this date.
3. **Mandatory site visit in a footnote** — small italic note at the end of
   s1: visits 26–27 August, booking deadline 12:00 Friday 21 August (11 days
   after issue), non-attendance "may be rejected". Appears nowhere else — not
   in the timetable, not in the submission checklist.
4. **Scope leak past the appointment** — s3.4 appoints for RIBA Stages 2–3
   only, yet s4.2 deliverables include "tender-ready technical drawings and an
   outline specification" (Stage 4 work) and "site support during the
   construction period as reasonably required" — unbounded, unpriced.
5. **Masterplan role contradiction** — s1.3: architect will "support and
   input to" a framework masterplan "being prepared by others"; s4.1: the
   architect "will lead and coordinate the framework masterplan". Input vs
   lead is a fee-defining difference.
6. **Page-limit arithmetic impossible** — s6.1 caps the quality submission at
   20 A4 pages, but requires MS1–MS8 at up to 2 pages each (16) + minimum six
   1-page CVs (6) + at least three project sheets (3+) = 25+ pages. Forms and
   pricing are arguably outside the cap but the ITT doesn't say so.
7. **A4 vs A3 format conflict** — s6.1 specifies A4 pages; Appendix B's
   response template is "formatted at A3 landscape" and tenderers are
   "encouraged" to use it. How does an A3 sheet count against an A4 limit?
8. **Portal vs email conflict** — s6.2: Delta e-sourcing portal only, "email,
   post or hand will not be accepted"; Appendix C.3: "completed tender forms
   should be returned by email to procurement@bellmereregen.co.uk".
9. **Fee basis contradiction** — s7.1 demands a fee "expressed as a
   percentage of the construction cost"; s7.3 demands "a fixed lump sum" for
   Stages 2–3. Both at once, and…
10. **…the construction cost is never stated** — only "total project value in
    the order of £68m including land" (s3.4). A percentage of an unstated
    number is unpriceable; fee must be TBC absent internal benchmarks.
11. **Unit-count three-way conflict** — s1.2 "circa 350 new homes"; s3.1 "up
    to 400 homes"; the 2024 capacity study (s3.1) "supports 315 homes". None
    reconciled.
12. **Affordable housing contradiction** — s1.2: 35% affordable "in line with
    the Client's agreed position with the Borough"; s3.3 funding condition:
    "not less than 50% … across Phase 1". Metric (unit vs habitable room)
    unstated in both.
13. **Evaluation weightings don't add up** — s5.1 states 70% quality / 30%
    price, but the quality sub-criteria in the table sum to 80% (15+20+10+10+
    15+10), giving a 110% total. Interview "may be held" and "will inform the
    final quality score" with no stated mechanism or weighting.
14. **MS7 and MS8 unweighted** — s6.1 requires method statements MS7
    (information management) and MS8 (social value), but the s5 evaluation
    table stops at MS6. Scored or not?
15. **PI insurance mismatch** — s8.2: £10m each and every claim, 12 years;
    Appendix A form certifies "not less than £5 million each and every
    claim". Which figure governs — and 12-year cover at £10m is itself a
    premium/market question for the practice's broker.
16. **BIM buried in an appendix, EIR absent** — ISO 19650 information
    management appears only at Appendix C.1, not in the s4 scope; the EIR is
    "being finalised and will be issued to the appointed practice" — a
    resourcing requirement that cannot be priced as issued.
17. **Referenced-but-absent documents** — 2024 capacity study, topographical
    survey, ground conditions desk study and the draft Aldenwick Design Code
    are all "available on request" (C.4); the design code is a *consultation
    draft* yet s3.2 requires compliance with it. Space standards invoked as
    "all relevant national and local space standards" with none named —
    `[to verify]` territory, request before pricing.

Softer catches worth credit: appointment on a "bespoke" agreement with the
draft only issued to the *successful* tenderer (s1.4); sustainability targets
"confirmed during Stage 2" i.e. unpriced (s3.2); fortnightly DTMs + four
engagement events as a meeting-load assumption (s4.2); 90-day validity
(s6.3); non-contact rule including the Borough (s6.4); collateral warranties
to funder and Borough in "the Client's standard form", unseen (s8.3).
