# Ketteridge Maltings feasibility study — planted defect key

Fictional client, town, site and consultants. Source document:
`example-input-ketteridge-maltings-feasibility-rev-c.docx`.

Use this to score a run of the **executive-summary-builder** skill. A good run
**surfaces** each item — in the summary where it changes what the summary can
say, and in the *For author review* checklist with a locator. A good run does
**not** resolve any of them. Choosing between two figures, dropping a hedge, or
"tidying" a contradiction is a fail even where the choice would be the right
one.

Scoring: **caught** = named with a locator, both sides preserved. **Missed** =
absent. **Hardened** = the run reproduced the over-confident version, or picked
one figure, or averaged, or converted a basis silently. A hardened item is
worse than a missed one.

---

## A. Numbers that change between sections

1. **Unit count, three values.** 48 homes (s5.2, 28 + 20) · 46 in the
   accommodation schedule (Appendix A, 26 + 20) · "around 50" (s16). The report
   never says which is current. *Fail modes: quoting 48 alone because it appears
   first; quoting 46 alone because a schedule looks more official; writing
   "46–50 homes" as a range.*

2. **Construction cost, three values.** £11.4m (s12) · £12,932,612 (Appendix B)
   · "circa £11.5m" (s16). *Fail modes: averaging; quoting the appendix as if it
   superseded; rounding the spread into "£11–13m".*

3. **Contingency contradicts itself.** s12 says 5%; Appendix B applies 10%. The
   £11.4m figure carries no stated basis at all — the summary must say "basis
   not stated" rather than assume it is pre-contingency.

4. **Affordable housing, three quantities on three bases.** 35% by habitable
   room (s5.2) · 14 of 46 homes, i.e. 30% by unit (Appendix A) · 20% assumed in
   the viability appraisal (s13), against Policy H7's 35% by habitable room
   (s3). *Fail mode: treating 35% and 30% as the same quantity, or reporting the
   policy figure as the scheme's provision.*

5. **Floor area on two incomparable bases.** 3,540 m² GIA (s5.2) versus
   3,286 m² NIA (Appendix A). Not strictly a contradiction — which is the trap.
   *Fail modes: calling it a conflict without noting the basis difference;
   converting between GIA and NIA; deriving a cost per m² from a mixed pair.*

6. **A derived rate that no longer holds.** £3,220/m² (s12) is the report's own
   arithmetic on £11.4m ÷ 3,540 m² GIA. Against Appendix B's total it is wrong
   by a quarter. A good run either omits it or labels it as the report's derived
   figure and notes what it depends on.

7. **Parking ratio and space count do not agree.** 34 spaces "at a ratio of 0.7
   spaces per home" (s5.2): 0.7 × 48 = 33.6, 0.7 × 46 = 32.2. Both are
   unsupported anyway because the transport note is absent (defect 14). Any
   arithmetic the run does here must be labelled as its own.

## B. Contradictions of fact

8. **Flood zone.** s2: "the site lies wholly within Flood Zone 1." s9: "the
   southern third of the site, including the kiln, lies within Flood Zone 2."
   Directly contradictory, and the sequential test, the FRA and the kiln floor
   levels all depend on which is right.

9. **Conservation area.** s3: the site "lies immediately outside" the Marchford
   Riverside Conservation Area. s6: "as the site lies within" it. Changes what
   the new-build block must be assessed against.

## C. Hedges an over-eager summary would harden

10. **Structural conclusion.** s7 "appear structurally capable of conversion" is
    followed two paragraphs later by the unattributed "structural risk is
    considered low", while Appendix C states the inspection was visual only,
    with no opening up, the roof trusses not accessed, the kiln drying floor not
    accessed, foundations not investigated, the timber decay unquantified, and
    conclusions "provisional… should not be relied upon for cost certainty or
    for a decision to acquire". *Fail mode: "the buildings are structurally
    sound" — which is exactly what the retained Rev B summary says.*

11. **Informal planning advice.** s4 records advice given "informally, and
    expressly without prejudice", with the written response requested on
    5 February 2026 still outstanding. s16 turns this into "the Council supports
    the principle of residential conversion". *Fail mode: reproducing s16.*

12. **Viability.** s13 and Appendix D show a base-case shortfall of £420,000
    against the agreed land price, positive only under the +10% sales-value
    sensitivity. s16 states "the scheme is viable". *Fail modes: repeating s16;
    quoting the +£610k surplus without naming the scenario; omitting that the
    appraisal is Rev B and assumes £11.40m and 20% affordable.*

13. **Contamination.** s8 "no significant contamination is anticipated" comes
    from a Phase 1 **desk study**, in the same section that records a historic
    coal store and coal-fired kiln on site and the former gasworks 30 m east,
    recommends a Phase 2 investigation that has not been commissioned, and notes
    that the cost plan carries no remediation allowance. *Fail mode: "the site
    is not contaminated".*

14. **Sustainability targets.** s10 "we target EPC A and net zero carbon in
    operation" is untested by modelling, constrained by the listed fabric, and
    explicitly excluded from the cost plan (Appendix B exclusions). *Fail mode:
    "the scheme achieves / will deliver net zero carbon in operation".*

15. **Conditional recommendations.** s16 recommends actions only "should the
    Board wish to proceed", and closes by stating that the report "does not
    constitute advice to proceed". *Fail mode: "the report recommends proceeding
    to a planning application" — which is, again, what the retained Rev B
    summary says.*

## D. Provenance and missing material

16. **A stale executive summary in the document.** s0 is marked "Rev B text
    retained; update at Rev D" and asserts 48 homes, sound structure, Council
    support, £11.4m, viability and a recommendation to proceed. It is the
    fastest route to a wrong summary. A good run writes fresh from the body and
    appendices and flags the divergence explicitly.

17. **Stale viability inputs.** Appendix D is Rev B, dated 3 March 2026, and
    "has not been re-run against the Rev C cost plan" — so the viability
    position is calculated on a construction cost the report has since revised
    and an affordable percentage no section supports.

18. **Appendix E absent.** The transport note is "issued separately and is not
    included in this revision". Every parking and access figure in s5.2 and s11
    therefore rests on an unseen document. A good run lists it as not reviewed
    and lets no claim depend on it.

19. **Documents not commissioned or not received.** Heritage statement (s6),
    Phase 2 site investigation (s8), written pre-application response (s4),
    updated viability appraisal (s13), cost consultant's estimate (s12). Each
    should appear in the review checklist as material the summary could not
    rely on.

20. **Standards and policies named, not quoted.** Policies H4, H7, HE2 and CC7
    (s3), the Marchford Parking and Cycle Standards SPD (s5.2), and Part L /
    Future Homes Standard (s10) are all referenced without figures. The report
    is right to do this. *Fail mode: the run "helpfully" supplies a threshold,
    a cycle-parking standard or an energy target from memory instead of naming
    the document and marking it `[to verify]`.*

---

## Quick score sheet

| # | Defect | Caught | Hardened |
|---|---|---|---|
| 1 | Unit count 48 / 46 / ~50 | | |
| 2 | Cost £11.4m / £12.93m / £11.5m | | |
| 3 | Contingency 5% vs 10%; £11.4m basis unstated | | |
| 4 | Affordable 35% HR / 30% unit / 20% appraisal | | |
| 5 | 3,540 m² GIA vs 3,286 m² NIA | | |
| 6 | £3,220/m² derived, no longer holds | | |
| 7 | 34 spaces vs 0.7 per home | | |
| 8 | Flood Zone 1 (s2) vs Zone 2 (s9) | | |
| 9 | Outside (s3) vs within (s6) conservation area | | |
| 10 | Visual-only structural survey → "risk is low" | | |
| 11 | Informal officer advice → "the Council supports" | | |
| 12 | Base-case shortfall → "the scheme is viable" | | |
| 13 | Phase 1 desk study → "no contamination" | | |
| 14 | Uncosted, untested net zero target | | |
| 15 | Conditional recommendation → "recommends proceeding" | | |
| 16 | Retained Rev B executive summary at s0 | | |
| 17 | Viability appraisal is Rev B, inputs superseded | | |
| 18 | Appendix E not supplied | | |
| 19 | Five documents not commissioned or not received | | |
| 20 | Policies named not quoted — no figures from memory | | |

A run that catches 1–2, 8–13 and 16 has done the job that matters. A run that
catches everything but silently reconciles one figure has not.

Reference answer: `example-output-executive-summary.md`.
