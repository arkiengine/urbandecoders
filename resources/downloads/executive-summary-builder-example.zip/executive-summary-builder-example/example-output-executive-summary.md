# Executive summary — worked output

*Reference run of the `executive-summary-builder` skill on
`example-input-ketteridge-maltings-feasibility-rev-c.docx`. This is the whole
deliverable as it is returned in chat: framing line, summary, review checklist.
Draft for the report author — not a sign-off.*

---

**Framing:** Ketteridge Maltings, Marchford — Feasibility Study and Options
Appraisal, Rev C, 14 May 2026 (Calder & Vane Architects for Harrowgate Estates
Ltd). Subject: whether a conversion-led residential scheme on the listed
maltings site is worth taking to a planning application. Audience: the Client's
board. Length: standard (300–500 words) requested; this runs to about 690,
because six quantities in the report have more than one value and reporting a
conflict costs more words than reporting a fact — see item 16, and tell me
which findings to drop if you want the page. Section 0 carries a retained Rev B
executive summary; I have written fresh from the body and appendices, and
flagged where the two diverge.

---

## Executive summary — Ketteridge Maltings, Marchford (Rev C)

**Purpose and scope**

We tested the capacity of the 0.84 ha Ketteridge Maltings site for
residential-led redevelopment, appraised three options, and set out an
order-of-cost, programme and viability position for the Board's decision on
whether to proceed to a planning application. The work sits at RIBA Stage 1
with elements of Stage 2 on the preferred option only, and is not a design
(s1). It rests on two site visits, a measured survey, a Phase 1 desk study and
a visual structural inspection. No intrusive investigation of any kind has been
carried out, no cost consultant is appointed, and no heritage statement has
been commissioned (s1, s6, s12). Appendix E, the transport note, is issued
separately and we have not reviewed it.

**Key findings**

- **Capacity is not settled in the report.** Option B is described as 48 homes
  (s5.2), the accommodation schedule totals 46 (Appendix A), and the
  conclusions say around 50 (s16). The three figures are unreconciled. Floor
  area is given on two bases that are not comparable: 3,540 m² GIA (s5.2) and
  3,286 m² NIA (Appendix A).
- **Affordable provision is stated three ways.** 35% by habitable room (s5.2),
  14 of 46 homes — 30% by unit — in the schedule (Appendix A), and 20% in the
  viability appraisal (s13). Policy H7 requires 35% by habitable room subject
  to viability (s3).
- **Cost carries three figures and no stated basis.** £11.4m with a 5%
  contingency (s12), £12,932,612 with contingency at 10% plus 5.5% inflation
  (Appendix B), and circa £11.5m (s16). The report does not say which
  supersedes. Appendix B excludes fees, VAT, remediation, the low-carbon energy
  strategy, underpinning, s106 and CIL.
- **On the base case the scheme does not support the agreed land price** — a
  £420,000 shortfall — and turns positive only under the +10% sales-value
  sensitivity (s13, Appendix D). That appraisal is Rev B, dated 3 March 2026,
  and assumes £11.40m of construction cost and 20% affordable housing; it has
  not been re-run against the Rev C cost plan or the policy affordable figure.
- **The Council's position is informal and unwritten.** The case officer
  indicated informally and without prejudice that the principle of residential
  conversion is likely to be acceptable, subject to heritage, flood risk and
  affordable housing. The written pre-application response requested on
  5 February 2026 has not been received (s4).
- **Heritage risk is live.** Listed building consent for demolition of the
  1960s link block should be achievable, but the Conservation Officer's
  reservations about new openings to the kiln are unresolved, and up to four
  homes depend on openings not yet agreed (s6).
- **The structural conclusion is provisional.** The buildings appear
  structurally capable of conversion, on a visual inspection only: no opening
  up, roof trusses viewed from below, the kiln drying floor not accessed,
  foundations not investigated, and the timber decay at the north wall plate
  not quantified (s7, Appendix C).
- **Flood zone, contamination and energy targets are all open.** The report
  places the site wholly in Flood Zone 1 (s2) and the southern third including
  the kiln in Flood Zone 2 (s9). A Phase 1 desk study anticipates no
  significant contamination but recommends a Phase 2 investigation, which is
  not commissioned and not allowed for in the cost plan (s8, Appendix B). EPC A
  and net zero carbon in operation are targets, untested by modelling and
  excluded from the cost plan (s10, Appendix B).

**Recommendations**

The report recommends nothing about proceeding. Should the Board wish to
proceed, it recommends seven steps first (s16): intrusive structural
investigation; the Phase 2 site investigation; a site-specific flood risk
assessment confirming the extent of Flood Zone 2; a cost consultant's estimate;
the written pre-application response; a heritage statement resolving the kiln
openings; and a viability appraisal re-run against the Rev C cost plan and the
policy affordable requirement. The indicative programme — start on site Q2
2027, completion Q4 2028 — assumes no environmental statement, a s106 agreed in
parallel, concurrent listed building consent and no call-in, and excludes time
for any of those steps (s14).

**Closing**

In the report's own words, it is issued for the Board's consideration and does
not constitute advice to proceed (s16).

---

## For author review

Locators refer to the Rev C report. Items 1–5 change what the summary can say;
the rest are checks before issue.

1. **Section 0 diverges from the body and is marked "Rev B text retained".** It
   states 48 homes, sound structure, Council support, £11.4m and "the scheme is
   viable" — four claims the Rev C body and appendices do not support. Either
   update it at Rev D or remove it; a reader who stops at page 3 currently gets
   a different report from the one you have written.
2. **Unit count, unreconciled: 48 (s5.2) / 46 (Appendix A) / around 50 (s16).**
   I have quoted all three rather than choosing. Confirm the number and correct
   the report — the parking ratio, the cost per m² and the viability run all
   sit on it.
3. **Cost, unreconciled: £11.4m (s12) / £12,932,612 (Appendix B) / circa £11.5m
   (s16).** The report does not state which supersedes, and s12's "5%
   contingency" contradicts Appendix B's 10%. Confirm whether £11.4m is
   pre-contingency and pre-inflation; if so, say so in s12.
4. **"The scheme is viable" (s16) is not supported by Appendix D on the base
   case,** which shows a £420,000 shortfall. It holds only under the +10%
   sales-value sensitivity. I have reported the base case and named the
   scenario. This is the sentence most likely to be quoted back at the
   practice.
5. **"The Council supports the principle of residential conversion" (s16)
   hardens informal, without-prejudice verbal advice (s4) into a planning
   position.** I have kept it as informal advice. Recommend the same correction
   in the body.
6. **Conservation area status contradicts itself:** outside it (s3), within it
   (s6). Both quoted; unreconciled. This changes what the new-build block must
   be assessed against.
7. **Flood zone contradicts itself:** wholly Flood Zone 1 (s2) versus southern
   third including the kiln in Flood Zone 2 (s9). Both quoted; unreconciled.
   The sequential test, the FRA and the kiln floor levels turn on it.
8. **"Structural risk is considered low" (s7) is not attributed and is not
   supported by Appendix C,** which is explicitly provisional and lists the
   drying floor, roof trusses and foundations as not inspected. I have carried
   the survey status with the conclusion; consider whether s7 should say the
   same.
9. **Floor areas are on different bases** — 3,540 m² GIA (s5.2) against
   3,286 m² NIA (Appendix A). Not a contradiction, but not comparable either. I
   have not converted between them and have not derived any rate from them.
10. **£3,220/m² (s12) is the report's own derived figure,** from £11.4m over
    3,540 m² GIA. It changes materially against Appendix B's total. I have not
    reproduced it in the summary.
11. **Affordable provision: 35% by habitable room (s5.2) against 30% by unit
    (Appendix A) against 20% in the appraisal (s13).** Three quantities on
    three bases. Confirm which is the scheme's position before the summary goes
    to the funder.
12. **Appendix E (transport note) is not in this revision.** The 34 spaces and
    the 0.7 spaces-per-home ratio (s5.2) are therefore unsupported; I have left
    both out of the summary. Note that 0.7 × 48 is 33.6 and 0.7 × 46 is 32.2 —
    neither gives 34, so the ratio and the count do not agree on any of the
    stated unit figures.
13. **Cycle parking "one space per bedroom" (s5.2) is stated as "understood to
    be" the local standard.** The Marchford Parking and Cycle Standards SPD
    should be checked and the clause cited `[to verify]`; I have not reproduced
    the figure.
14. **Policy references are named but not quoted** (H4, H7, HE2, CC7, and the
    energy standard at s10). The report is right not to reproduce them; the
    application team should confirm each against the adopted plan `[to verify]`
    before anything in the summary is repeated in a planning document.
15. **Documents referenced but not seen by me:** Appendix E; the heritage
    statement (not commissioned); the Phase 2 site investigation (not
    commissioned); the written pre-application response (not received); the
    Rev C-updated viability appraisal (not run). No claim in the summary
    depends on any of them.
16. **Length:** the summary runs to about 690 words against the 300–500-word
    standard, and the overrun is entirely the unreconciled figures — each one
    costs two locators and a basis. I can cut to one page, but the cut comes
    out of the findings, not out of this list: tell me which conflicts the
    Board can be told about verbally instead. Once the report reconciles its
    own numbers, the summary fits the page on its own.

---

*Summary drafted from the Rev C document only. Nothing has been added from
outside it, no figure has been reconciled, and no hedge has been removed.
Confirm the framing line names the revision you are about to issue.*
