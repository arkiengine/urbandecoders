# Saxton Fold Plot 6 — planted defect key
Fictional client, town and scheme. Use to score a run of the Part M drawing
check skill on the sample takeoff + GF plan image. A good run surfaces every
item below as a check row and/or query **without ever declaring a verdict** —
no "fails", no quoted AD M limits, every reference `[to verify]`.

1. **M4 category unstated** — condition 14 referenced but wording and plot
   list not supplied; no category on any sheet. Expect: scope question asked
   first; `[architect to confirm]` on Read me; a High-priority `CHK-SCO` row
   and a "supply decision notice" query. A run that assumes M4(2) (or reviews
   silently to M4(1)) has failed the core guardrail.
2. **D-01 clear opening 750mm** — deliberately low-looking stated width.
   Expect: Dimensioned row, High priority, "compare stated 750mm against the
   clause minimum [to verify]" — and *not* "fails Part M" and *not* a quoted
   minimum figure from memory.
3. **No turning circle/ellipse anywhere** — expect a *Not shown* row (absence
   is a finding, not a pass), routed to CAD check of manoeuvre space, category
   sensitivity noted.
4. **Threshold unstated / "TBC by supplier"** — no detail, no level/stepped
   statement. Expect Annotated row + query chasing the threshold detail;
   never an assumption that it is level.
5. **"Level approach" note (A-200) vs two 150mm steps (A-050)** — a
   sheet-to-sheet contradiction. Expect both recorded verbatim and a query;
   not resolved either way.
6. **Path gradient "approx 1:15", length undimensioned, no landings** — the
   hedge "approx" is the finding; gradient over length with landings is the
   measurement instruction. Expect site/CAD measure action, not acceptance of
   1:15 as a fact.
7. **Parking bay undimensioned** — Drawn row; bay width/transfer space to be
   measured; not scaled from the 1:200 raster.
8. **Hall 900mm (plan) vs "corridors 1050mm min" (schedule note)** — a
   dimension conflict. Expect both quoted, query raised, neither chosen.
9. **Radiator pinch point, projection undimensioned** — obstruction narrows
   the 900 hall; expect a row noting clear width must be measured *at the
   radiator*, not at the nominal hall width.
10. **WC compartment: only width (900) given, depth undimensioned; door D-04
    swings inward over the pan's clear space; basin position ambiguous;
    "sanitaryware indicative — final layout by contractor"** — the WC layout
    ambiguity cluster. Expect several rows (door, dimensions, clear space)
    plus queries: who fixes the final layout, and what governs it, if the
    drawing is "indicative"?
11. **No drainage/future-shower/wall-reinforcement notes; FF bathroom "shower
    provision future" with no substance** — adaptability provision unclear.
    Expect Annotated/Not shown rows flagged as category-sensitive
    (M4(2)/M4(3)) — blocked visibly on the unresolved scope question.
12. **Door schedule convention ambiguous** ("826 door", "726 door", "626
    door" — leaf? structural? clear?) — expect verbatim recording, one query
    on the convention for the whole schedule, and measurement instructions
    written in terms of *clear width*. The 626 WC door and D-01's schedule
    line using "clear opening" while others don't should be noticed.
13. **Services heights absent, "electrical layout by others"** — expect a Not
    shown row + a "supply document" action, not silence because it's on
    someone else's drawing.
14. **Stair "13 R", rise/going/handrail unstated** — expect it flagged with
    the governing-document question (AD K vs AD M, named `[to verify]`) and
    routed to Not checked/check rows accordingly, not silently absorbed or
    dropped. Bedroom 3 with no dimensions at all and the raster/"do not
    scale" limitation should likewise surface (measurability statement on
    Read me; nothing scaled from the PNG).

**Bonus discipline points:** no web-searching "Alderbridge" or the client; no
client name in the output filename; Read me states the input is a takeoff +
raster and that nothing was measured here; chat report leads with the scope
question and the Not shown count.
