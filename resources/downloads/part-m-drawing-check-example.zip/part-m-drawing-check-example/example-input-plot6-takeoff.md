# Drawing takeoff — Saxton Fold, Plot 6 (House Type H3)

**Prepared by:** JD (Part 2 assistant), transcribed from the issued PDF set for
the access review. Annotations quoted verbatim; where I could not read or find
something I have said so rather than guessed.
**Date:** 04-08-2026
**Project:** Saxton Fold, Chapel Brow, Alderbridge, Greater Manchester
**Client:** Arden Croft Homes Ltd
**Unit:** Plot 6 — House Type H3, 3B5P, two storeys, private driveway parking
**Planning:** ref 24/01187/FUL granted. Condition 14 apparently relates to
"accessible and adaptable dwellings" on specified plots — I don't have the
decision notice to hand, so I can't say whether Plot 6 is one of them or quote
the wording.

## Sheets issued (all flattened PDF, no scale bar on any sheet)

| Sheet | Rev | Title | Scale (title block) | Notes |
|---|---|---|---|---|
| ACH-SF-A-050 | P1 | Plot 6 — site plan | 1:200 @ A3 | "Do not scale" note bottom right |
| ACH-SF-A-100 | P2 | House Type H3 — ground floor plan | 1:50 @ A2 | includes door schedule extract |
| ACH-SF-A-101 | P1 | House Type H3 — first floor plan | 1:50 @ A2 | |
| ACH-SF-A-200 | P1 | House Type H3 — elevations | 1:100 @ A2 | |

A simple raster export of the GF plan is attached alongside this takeoff
(`example-input-plot6-gf-plan.png`). No CAD/native files were issued to me.

## A-050 — site plan

- Driveway parking bay drawn beside the plot, forward of the front door. **No
  bay dimensions given** — it's just drawn and labelled "parking".
- Footpath from the back of the driveway to the front door. Annotated
  "**path gradient approx 1:15**". Path length not dimensioned; no landings
  shown; surface material not noted.
- At the plot boundary where the path leaves the adopted footway, the plan
  shows **two steps** (drawn as two lines with "150" against them — I read
  this as 2 no. 150mm risers but it isn't labelled as such).
- Elevation sheet A-200 carries a general note "**level approach to entrance**"
  — this appears to contradict the steps on A-050.

## A-100 — ground floor plan

Rooms: hall with stair, WC off the hall, living room, kitchen/dining.

**Entrance (D-01):**
- Front door tagged D-01. Door schedule extract on this sheet lists
  "**D-01 — entrance door — clear opening width 750mm**".
- Threshold: no detail referenced. Door schedule remarks column says
  "**threshold TBC by door supplier**". Nothing on plan or elevations states
  whether the threshold is level or stepped. External landing outside D-01 is
  drawn but not dimensioned.

**Hall / circulation:**
- Hall width dimensioned **900mm** on plan.
- The door schedule extract, however, has a general note: "**hall and landing
  corridors 1050mm min**". 900 (plan) vs 1050 (note) — I can't tell which is
  current; the plan is Rev P2 and the note may be carried over.
- A radiator is drawn on the hall wall opposite the stair string. Its
  projection isn't dimensioned; scaling is prohibited, but it visibly narrows
  the 900 hall at that point.
- No turning circle / turning ellipse is shown anywhere on either floor plan —
  not in the hall, living room, or kitchen/dining. Furniture is drawn in the
  living room (sofa pair + media wall) but no manoeuvre space is indicated.

**Ground-floor WC:**
- Compartment off the hall containing WC pan and a small basin. Only one
  dimension given: "**900**" across the width. Depth not dimensioned.
- Door D-04 swings **inward**, over the space in front of the pan.
- Basin is drawn on the side wall — hard to tell if it sits beside the pan or
  partly in front of it; the print is coarse at this size.
- General note on the sanitary layout: "**sanitaryware indicative — final
  layout by contractor**".
- No note about drainage provision, future shower, or wall reinforcement.

**Internal doors (schedule extract):**
- Listed as "**D-02 living 826 door; D-03 kitchen/dining 826 door; D-04 WC 626
  door; D-05 bathroom 726 door; D-06/07/08 bedrooms 726 door**". The schedule
  doesn't say whether these are leaf sizes, structural openings, or clear
  widths. No clear-opening column.

**Stair:**
- Straight flight, "**13 R**" noted. Rise and going not dimensioned. No
  handrail note on plan.

**Services:**
- No electrical layout issued. A-100 general notes: "**electrical layout by
  others**". No switch/socket/consumer-unit heights anywhere in the set.

## A-101 — first floor plan

- Three bedrooms + bathroom. Bedroom 3 has **no dimensions at all**.
- Bathroom: bath, WC, basin drawn. Note: "**shower provision future**" — with
  no detail of what provision is actually being made (drainage? wall
  reinforcement? layout?).
- Landing width not dimensioned.

## A-200 — elevations

- "Level approach to entrance" note (see contradiction above).
- Nothing else access-relevant that I could see; window cill/handle heights
  not noted.

## Nowhere in the set

- No statement of the M4 category anywhere on any sheet or in the title
  blocks.
- No accessibility/adaptability notes, no Part M reference, no threshold
  detail, no bay dimensions, no turning provision.
