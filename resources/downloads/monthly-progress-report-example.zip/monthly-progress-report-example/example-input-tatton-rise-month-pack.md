# Tatton Rise — March 2026 reporting pack

**Project:** Tatton Rise, Marlden — 48 dwellings, two blocks
**Reporting period:** 1–31 March 2026
**Report due:** 7 April 2026, to the client and the funder

*Fictional project. Deliberately imperfect.*

---

## §1 — Material available for the period

| Ref | Item | Date | Note |
|---|---|---|---|
| M-01 | Design team meeting DTM-19 minutes | 05.03.26 | — |
| M-02 | Design team meeting DTM-20 minutes | 26.03.26 | — |
| M-03 | Site visit record SV-14 | 12.03.26 | Architect's visit |
| M-04 | Contractor's progress report, March | 31.03.26 | Pellow Construction |
| M-05 | RFI log export | 31.03.26 | — |
| M-06 | Instruction log export | 31.03.26 | — |
| M-07 | Site photographs (22 no.) | **various — see §6** | — |
| M-08 | Programme, rev 7 | 14.01.26 | **Not reissued since** |
| M-09 | February monthly report | 07.03.26 | Last month's report |
| M-10 | Email, client to CA | 19.03.26 | — |

**Not available:** contractor's own programme update, valuation, any
record of the client's cladding decision.

---

## §2 — Extracts from M-04 (contractor's March progress report)

§2.1 "Block A: superstructure complete to level 03. Roof covering commenced."
§2.2 "Block B: superstructure complete to level 02."
§2.3 "Block A is approximately 65% complete overall."
§2.4 "Groundworks and drainage complete across the site."
§2.5 "The roof is watertight to Block A."
§2.6 "We confirm the project remains on programme for practical completion."
§2.7 "Window installation to Block A commenced 23 March."

---

## §3 — Extracts from M-03 (site visit record SV-14, 12 March)

§3.1 "Block A observed: superstructure complete to level 02, level 03
blockwork in progress."
§3.2 "Block B observed: superstructure to level 01, level 02 in progress."
§3.3 "Scaffold erected to Block A north and east elevations."
§3.4 "Standing water observed in the Block B basement excavation."
§3.5 "No roof covering observed to Block A at the date of visit."

---

## §4 — Extracts from M-01 (DTM-19, 5 March)

§4.1 "The cladding specification remains outstanding. The client undertook to
confirm the cladding selection by 20 February. This is now two weeks overdue
and is holding the facade package."
§4.2 "Action: client to confirm cladding by 12 March. Owner: client."
§4.3 "The contractor raised the lead time on windows. Agreed that the
architect will confirm the window schedule by 10 March."
§4.4 "Risk register reviewed. No changes."

---

## §5 — Extracts from M-02 (DTM-20, 26 March)

§5.1 "Window schedule issued 09 March. Closed."
§5.2 "Cladding: the client has now reviewed three options and expects to
confirm in April."
§5.3 "The contractor reported that the Block B basement has been pumped and
the excavation is dry."
§5.4 "Action: architect to issue balcony balustrade details. Owner: architect.
Date: 17 April."
§5.5 "Risk register: not reviewed this meeting — ran out of time."

---

## §6 — Photographs (M-07)

| Group | Count | Date taken |
|---|---|---|
| Block A elevations | 8 | 12.03.26 |
| Block B basement | 4 | 12.03.26 |
| Site compound | 4 | 12.03.26 |
| **Block A roof** | **6** | **24.02.26** |

---

## §7 — February report (M-09) — risk register as reported last month

| # | Risk | Status | Owner | Mitigation |
|---|---|---|---|---|
| R-01 | Cladding selection outstanding, holding facade package | Open | Client | Decision requested by 20 Feb |
| R-02 | Window lead times | Open | Contractor | Schedule to be confirmed |
| R-03 | Groundwater in Block B basement | Open | Contractor | Pumping in place, monitoring |
| R-04 | Archaeology watching brief on the north plot | Open | Client | Awaiting programme from county archaeologist |
| R-05 | Substation adoption agreement | Open | Client | With the DNO |

**February report also stated:** "Decisions outstanding: cladding selection
(client, outstanding since 14 January)."

---

## §8 — Extract from M-10 (client email, 19 March)

> "Please keep the report short this month — the funder just wants to know we
> are on track. If you could put a percentage complete against each block that
> would help. And please don't dwell on the basement water, it's dealt with."

---

## §9 — Logs

**M-05 RFI log, March:** raised 14, answered 9, outstanding 11 (including
carried forward). Oldest outstanding: PCL-RFI-0038, raised 04.02.26, 56 days.

**M-06 Instruction log, March:** 3 instructions issued (AI-012, AI-013,
AI-014). AI-014 relates to drainage re-routing around the archaeology area.

---

## §10 — What the CA has asked for

1. "Draft the March report."
2. "The client wants percentages — can you work them out from the photos?"
3. "What changed since February?"
