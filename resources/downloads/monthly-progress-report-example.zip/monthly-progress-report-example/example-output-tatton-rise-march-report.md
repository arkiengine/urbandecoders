# Tatton Rise — monthly progress report

**Reporting period:** 1–31 March 2026
**Prepared:** 2 April 2026
**For:** the client and the funder
**Status: draft for the contract administrator's review and signature.**

---

## §1 — Basis of this report

| Source | Ref | Date | Within period |
|---|---|---|---|
| DTM-19 minutes | M-01 | 05.03.26 | Yes |
| DTM-20 minutes | M-02 | 26.03.26 | Yes |
| Site visit record SV-14 | M-03 | 12.03.26 | Yes |
| Contractor's progress report | M-04 | 31.03.26 | Yes |
| RFI log export | M-05 | 31.03.26 | Yes |
| Instruction log export | M-06 | 31.03.26 | Yes |
| Site photographs, 18 no. | M-07 | 12.03.26 | Yes |
| **Site photographs, Block A roof, 6 no.** | M-07 | **24.02.26** | **No — outside the period** |
| **Programme rev 7** | M-08 | **14.01.26** | **No — not reissued for 11 weeks** |
| February monthly report | M-09 | 07.03.26 | Comparison basis |

**One site visit took place in the period, on 12 March.** Everything observed
in this report is observed as at that date. The contractor's report (M-04) is
dated 31 March and covers the full month.

**Not available for this period:** the contractor's own programme update, any
valuation, and any record of the client's cladding decision.

---

## §2 — Headline

Superstructure progressed on both blocks during March. Roof covering to Block A
and window installation to Block A are reported by the contractor as having
commenced; neither was observed, as both post-date the site visit. **The
cladding selection remains outstanding and has now been so since 14 January —
ten and a half weeks.** The programme has not been reissued since 14 January,
so no programme position can be reported against a current baseline.

---

## §3 — Progress

Reported in each source's own terms. `[observed]` and `[reported]` are
different statements and are not merged.

| Element | Position | Source |
|---|---|---|
| Groundworks and drainage | Complete across the site | `[reported]` M-04 §2.4, 31.03 |
| Block A superstructure | Complete to level 02, level 03 blockwork in progress | `[observed]` M-03 §3.1, **12.03** |
| Block A superstructure | Complete to level 03 | `[reported]` M-04 §2.1, 31.03 |
| Block A roof covering | None observed at the date of visit | `[observed]` M-03 §3.5, **12.03** |
| Block A roof covering | Commenced | `[reported]` M-04 §2.1, 31.03 |
| **Block A roof** | **Watertight** | **`[reported]` M-04 §2.5, 31.03 — not observed** |
| Block A windows | Installation commenced 23 March | `[reported]` M-04 §2.7 |
| Block A scaffold | Erected to north and east elevations | `[observed]` M-03 §3.3, 12.03 |
| Block B superstructure | Complete to level 01, level 02 in progress | `[observed]` M-03 §3.2, **12.03** |
| Block B superstructure | Complete to level 02 | `[reported]` M-04 §2.2, 31.03 |

**The contractor's and the architect's positions are consistent with each
other**, given the nineteen days between the visit and the report — in each
case the contractor reports one level further on than was observed mid-month.
Both are recorded.

**"The roof is watertight to Block A"** (M-04 §2.5) is a statement by the
contractor, dated 31 March. **No roof covering was observed on 12 March**
(M-03 §3.5), and the only roof photographs available are dated 24 February
(§6 of the pack), outside this period. This report does not state that the roof
is watertight; it records that the contractor reports it.

### Percentage complete

**No percentage complete is stated in this report.**

The contractor states "approximately 65%" for Block A (M-04 §2.3) — that figure
is quoted below, attributed. **No figure is stated for Block B by any source,
and none is derived here.**

| Element | Percentage | Source |
|---|---|---|
| Block A overall | "approximately 65%" | `[reported]` M-04 §2.3, contractor |
| Block B overall | **Not stated by any source** | — |

See §9 for the response to the request to derive percentages from the
photographs.

---

## §4 — Programme position

**Programme rev 7, dated 14 January 2026. Not reissued in eleven weeks.**
No contractor programme update was available for this period.

| Milestone | Per programme rev 7 | Reported status |
|---|---|---|
| — | **No milestone dates are extractable from the supplied material** | — |

The programme itself was not supplied to this report in a form that allows
milestone dates to be reported — only its revision and date are known.
`[not evidenced]`

**The contractor states: "We confirm the project remains on programme for
practical completion"** (M-04 §2.6). That is recorded as the contractor's
statement, attributed and dated. **This report does not assess delay,
criticality or float, does not forecast a completion date, and takes no view
on whether that statement is correct.**

**The absence of a reissued programme is itself the most significant
programme fact this month.**

---

## §5 — Decisions

### Taken in the period

| Decision | By | When | Unblocks |
|---|---|---|---|
| Window schedule issued | Architect | 09.03.26 | Window procurement. Action from DTM-19 §4.3, closed at DTM-20 §5.1, one day ahead of the 10 March date |

### Outstanding

| Decision | Owner | Outstanding since | Age | Blocks |
|---|---|---|---|---|
| **Cladding selection** | **Client** | **14.01.26** (per M-09) | **77 days** | Facade package. Named as holding it at DTM-19 §4.1 |
| Balcony balustrade details | Architect | 26.03.26 | 7 days | Balcony package. DTM-20 §5.4, due 17.04.26 |

**On the cladding.** The February report recorded it as outstanding since
14 January. DTM-19 (05.03) recorded that the client had undertaken to confirm
by 20 February, that this was "now two weeks overdue", and set a new date of
12 March (M-01 §4.1, §4.2). DTM-20 (26.03) records that the client "has now
reviewed three options and expects to confirm in April" (M-02 §5.2).

**The 12 March date was not met and no new committed date exists** — "expects
to confirm in April" is not a date. The item has now moved twice.

---

## §6 — Risks and issues

Carried forward from the February report (M-09 §7). **Movement is stated for
every risk, including those not discussed this month.**

| # | Risk | Status | **Movement** | Owner | Mitigation as stated by its owner |
|---|---|---|---|---|---|
| R-01 | Cladding selection outstanding, holding facade package | **Open** | **Worsened** | Client | "Has reviewed three options and expects to confirm in April" (M-02 §5.2). The 20 Feb and 12 Mar dates both passed |
| R-02 | Window lead times | **Closed** | **Improved → closed** | Contractor | Window schedule issued 09.03; closed at DTM-20 §5.1. Installation commenced 23.03 (`[reported]` M-04 §2.7) |
| R-03 | Groundwater in Block B basement | **Open** | **Improved** | Contractor | Standing water observed 12.03 (`[observed]` M-03 §3.4). Contractor reported at DTM-20 that the basement "has been pumped and the excavation is dry" (`[reported]` M-02 §5.3) — **reported, not observed; the site visit preceded the pumping** |
| R-04 | Archaeology watching brief, north plot | **Open** | **Unchanged — not reviewed this period** | Client | Mitigation unchanged from February: awaiting programme from the county archaeologist. **See note below** |
| R-05 | Substation adoption agreement | **Open** | **Unchanged — not reviewed this period** | Client | Mitigation unchanged from February: with the DNO |

**Note on R-04 and R-05.** The risk register was reviewed at DTM-19 with no
changes (M-01 §4.4) and **was not reviewed at DTM-20 — "ran out of time"**
(M-02 §5.5). R-04 and R-05 are carried forward unchanged and flagged as not
reviewed. **Neither has been closed, and the absence of discussion is not
evidence of improvement.**

**Note on R-04 specifically.** Instruction AI-014 was issued in the period and
relates to drainage re-routing around the archaeology area (M-06). That is
activity against a risk the register records as "awaiting programme from the
county archaeologist", and the two have not been reconciled in any supplied
source. `[logged]`

---

## §7 — Information flow

| Metric | March | Source |
|---|---|---|
| RFIs raised | 14 | `[logged]` M-05 |
| RFIs answered | 9 | `[logged]` M-05 |
| RFIs outstanding at month end | 11 | `[logged]` M-05 |
| **Oldest outstanding RFI** | **PCL-RFI-0038, raised 04.02.26 — 56 days** | `[logged]` M-05 |
| Instructions issued | 3 (AI-012, AI-013, AI-014) | `[logged]` M-06 |

**RFIs are accumulating**: 14 raised against 9 answered in the month. The
oldest outstanding item has been open for 56 days.

---

## §8 — Photographic record

18 photographs dated 12 March 2026: Block A elevations (8), Block B basement
(4), site compound (4).

**6 photographs of the Block A roof are dated 24 February 2026 and are outside
this reporting period. They are not included in this report.** Including them
would represent February's condition as March's, and the roof is precisely the
element whose current state is reported but not observed (§3).

---

## §9 — Gaps

What this report could not cover, and why.

| Gap | Why |
|---|---|
| **Any percentage complete for Block B** | No source states one |
| **Milestone positions against programme** | Programme rev 7 (14.01.26) not reissued; no milestone dates extractable from the supplied material; no contractor programme update |
| **Valuation and cost position** | No valuation available for the period |
| **Condition of Block A roof and windows** | Both post-date the 12 March site visit; `[reported]` only |
| **Block B basement condition after pumping** | `[reported]` at DTM-20; not observed |
| **R-04 and R-05 current status** | Risk register not reviewed at DTM-20 |
| **The cladding decision itself** | No record of a decision exists |

---

## §10 — Notes to the contract administrator — not for issue

**On the client's email of 19 March (M-10).** Three requests, handled as
follows.

1. *"Keep the report short."* The report is as long as the evidence requires.
   Where there is nothing to say, §9 says so.

2. *"Put a percentage complete against each block."* **Not done, and it cannot
   be done from this material.** The contractor states "approximately 65%" for
   Block A and that is quoted and attributed. **No source states a figure for
   Block B, and none has been derived.** The CA's own question (§10.2 of the
   pack) asks whether percentages can be worked out from the photographs: they
   cannot. A percentage derived from photographs is an estimate presented as a
   measurement, in a document going to a funder, and it is the single most
   likely sentence in a monthly report to be quoted back at you.

3. *"Please don't dwell on the basement water, it's dealt with."* R-03 is
   reported as **improved** and the contractor's statement that the basement is
   dry is recorded. **It is not closed**, because standing water was observed by
   the architect on 12 March and the "dry" statement is reported, not observed.
   Silently dropping it would misrepresent the register and would remove an
   item the funder saw last month.

**Before issue:** delete this section, confirm the contractor's percentage
figure is one you are content to pass on attributed, and decide whether to
state in §4 that no current programme exists — this draft does.

---

## §11 — Evidence base

**22 statements of fact in this report. 7 `[observed]`, 9 `[reported]`, 5
`[logged]`, 1 `[not evidenced]`.**

**Last month's report was available**, so risk movement and decision ages are
real rather than reconstructed.

**The single biggest gap is the programme**: rev 7 is eleven weeks old, no
update was issued, and no milestone position can be reported. The contractor's
assurance that the project "remains on programme" is recorded, attributed, and
cannot be checked against anything.
