# Re: images for Thursday — can you sort these out

**From:** Priya Nandakumar (Associate)
**To:** Visualisation team
**Sent:** 14 September 2026, 18:52
**Subject:** Re: images for Thursday — can you sort these out

*(Pasted from email. Fictional project, client, borough and people.)*

---

Hi both,

Sorry, this is going to be rushed. **Marlowe Fields Health & Wellbeing Hub** (Kestrel Road, Brantham Cross, LB Wexbury) — client is **Northlight Care Partnerships LLP** and they've moved the design review to Thursday morning. Adam is on site all week so I'm afraid it's over to you. Internal project code is **NCP-214**, construction budget £11.4m if anyone asks.

We're at the end of Stage 3 and the planning application goes in mid-October, so these images will be in the DAS as well. Please make them count.

## 1. The entrance courtyard image (the important one)

I've dropped an Enscape screenshot in the shared folder — `NCP214_courtyard_ENSCAPE_v3.png`, it's whatever Enscape spits out by default (1280 × 720 I think). It's the view from the courtyard looking at the main entrance — the brick block on the left, the glazed link in the middle, timber-clad wing on the right. Fair warning: I had a section plane on when I grabbed it so the roof is sliced off on the right-hand side, the sun path widget is sitting over the sky, and there's an Enscape watermark bottom-right. Also a stray dimension tag floating in the middle from where I was checking the canopy height. Hopefully the AI just ignores all that.

What I want:

- Make it **photoreal, cinematic, golden hour, really dramatic** — 4k, ultra HD, masterpiece, hyperreal, unreal engine 5 quality. It needs to look like a proper CGI, not a model.
- But also the brick has to read true because the planners will look at the brick, so bright overcast is probably safer? Your call.
- Swap the brick for the one in that Copenhagen housing scheme I sent you last week — that lovely warm one. I've written a description of the reference photo in the other file since I can't find the original at the moment.
- Add people — busy, a proper mix, kids, a wheelchair user, someone with a pram.
- Add some trees. The courtyard reads a bit bare in the model.
- Also please **add a canopy over the entrance** — it's very exposed in the model and we've all said it needs one, we just haven't drawn it yet.
- The windows in the timber wing look a bit stubby to me. Can you **make them taller** in the image so it reads better? We'll catch up the drawings later.
- **Lose the substation** on the left. It's ugly and it's probably moving anyway.
- The ramp needs to obviously read as **Part M compliant** — the planners are hot on accessibility on this one.
- The frontage is 22 m so make sure it looks like a real 22 m across.
- Signage above the door please: "Marlowe Fields Health & Wellbeing Hub".
- We're calling it a **verified view** in the DAS since it's from the actual model, so it needs to be dimensionally right.
- Square for the client's Instagram, but we also want it full-bleed on the A1 board. Whatever works.

## 2. The waiting space interior

Nothing modelled for this one yet, so from scratch please. It's the double-height waiting space off the entrance. Something calm and Scandi — wood, soft, a bit of greenery. Morning light through the clerestory would be lovely. Or dusk with the lights on, whichever looks better honestly.

Make it look like a **Grafton Architects** interior — that heavy, beautiful thing they do. Use your judgement on the materials, you know the palette we're going for.

## 3. While you're in there

- Can you also do the **six hero shots** for the DAS — the full set, approach, aerial, courtyard, street, interior, dusk? The plan's in the folder.
- And the **five brick options** side by side for the material board? Same view, just the brick changing.
- Rough sketchy diagram of the site strategy would be handy too if there's time.

Thanks both, sorry again for the turnaround. Shout if anything's unclear but I'm in workshops all day tomorrow.

Priya
