# Reference image — written description (the "Copenhagen brick" one)

**Note by:** Priya Nandakumar
**Date:** 14 September 2026
**Status:** description only — I can't find the original file, so I've written down what I remember of it. Photo was a phone shot from a study trip, no photographer credit.

*(Fictional. Provided in place of the image itself.)*

---

**What the photo shows.** A five- or six-storey housing block on a canal-side street in Copenhagen, shot from across the water, late evening. Long low sun coming from the left, the whole facade lit warm, deep shadows in the reveals, water reflecting the sky. A few people on the quayside, some bikes leaning on railings, a couple of small trees in planters.

**The brick — this is the bit I want.** Warm, soft red-brown, quite varied from brick to brick — some almost orange, some nearly grey-purple. Handmade look, irregular edges, a bit of tumbling. Recessed mortar joints, and the mortar is a warm sandy colour rather than grey, which I think is what makes it glow. Stretcher bond as far as I could tell. Slightly rough, matte, no glaze.

I'm fairly sure it's a Petersen D48 or something in that family — worth checking with the rep before we specify anything, I'm going off memory.

**Other things I liked** (not necessarily for the render, but while I'm writing it down):

- Deep window reveals, maybe 200 mm, which is what gives it all the shadow.
- The balconies are lovely — slim steel, quite delicate against the heavy brick. Could we get something like that on the timber wing? Might be worth showing in the image so people can see the idea.
- Big precast lintels over the ground-floor openings.
- Evening light is doing a lot of the work here, to be honest. The whole thing looks completely different in the daylight shots I took.

**How I'd use it.** Basically: our building, their brick. Though the mood in this photo is exactly the feeling we want for the courtyard image too, so maybe take the light from it as well? See what looks best.
