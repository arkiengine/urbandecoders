# Example output — Marlowe Fields image request

A faithful run of **nano-banana-prompt-builder** on
`example-input-image-request.md` plus
`example-input-reference-image-description.md`. Shown as the three turns the
skill actually produces: the read and the interview, the user's reply, and the
prompt deliverable.

Use it as the reference answer to compare your own runs against; the planted
issues are listed in `marlowe-fields-defect-key.md`.

---

## Turn 1 — what I've got, and what I need to ask

**Two images to build, in two different modes.**

- **Image A — entrance courtyard.** *Transform* mode: your Enscape screenshot is
  the base and its geometry is locked. Not composite mode — the Copenhagen
  reference is a written description, not an attached image, so the brick has to
  be written into the prompt as words. I have not seen that photo.
- **Image B — waiting space.** *Generate* mode: nothing modelled, so everything
  in it comes from you or from a default I declare.

**Four things I'm not doing, before we go further.** These aren't defaults I can
apply for you — they're decisions or corrections:

- **The canopy, the taller windows, the deleted substation, and the reference
  note's balconies are design changes**, not rendering instructions. If they go
  in the image, the image shows a building that isn't in the drawings going to
  planning — and it's the image people remember. Drawn first, rendered after.
- **"Reads as Part M compliant" can't be prompted.** The model doesn't know the
  regulation and an image can't evidence compliance. I'll describe the ramp as
  it is in the model; the accessibility question needs checking against Approved
  Document M `[to verify]` by someone with the drawings.
- **This can't be a Verified View.** A verified view is a surveyed photographic
  methodology — camera positions, survey control, an accompanying method
  statement. A generated image is illustrative however good the model was. If
  the DAS needs verified views, that's a separate commission, and it's worth
  raising this week rather than in October.
- **"Make it look like a real 22 m across"** — same reason. Nothing here is
  dimensionally reliable.

**I've stripped the identifiers.** The client name, the address, the borough, the
project code and the budget carry no visual information and the prompt goes to a
third-party service, so none of them appear below — the building is described
generically. Same for filenames: `courtyard-transform-s1.png`, not the project
code.

**I've stripped the keyword spam too** — "4k, ultra HD, masterpiece, hyperreal,
unreal engine 5" does nothing for this model. The specific material and light
language below is what actually moves the image.

**Handing three items over:** the six-shot hero set is
`hero-perspective-prompt-builder` (it builds a defensible shot brief from the
plan first, which is what the DAS needs); the five-brick comparison is
`facade-maker` (one locked consistency block so the options are genuinely
comparable — a general prompt run five times isn't); the site strategy diagrams
are `site-diagram-matrix-builder` for a four-figure analysis board or
`site-matrix-diagram-builder` for a six-frame evolution sequence. Say which and
I'll start whichever you need.

### Questions — six, defaults in brackets, "use defaults" is a fine answer

**Subject**

1. The trees: the courtyard "reads bare" — do you mean planting in beds or
   planters that are already in the landscape GA, or new trees in what is
   currently paving? The first is entourage, the second is a landscape design
   decision. *(default: planting only where the model already shows a bed or
   planter)*
2. Storeys, window count per elevation, and anything else I should name in the
   geometry lock? A named lock ("keep all four storeys, the nine bays") holds
   far better than a generic one. *(default: generic lock, which drifts more)*

**Design language**

3. Light: you've asked for golden hour, then said overcast so the brick reads
   true, and the reference photo is warm evening. One choice, please — the brick
   is the thing planners will look at. *(default: bright overcast, soft even
   light, true material colour)*
4. The Copenhagen reference — brick only, or brick plus the evening light and
   mood? *(default: brick only; your own note says the light is doing most of the
   work in that photo, which is exactly why it shouldn't come along)*
5. "A Grafton Architects interior" — I won't prompt in a living practice's name
   (the model produces a caricature, and it puts someone else's identity in your
   DAS). Which qualities do you mean: material weight and heavy soffits, top
   light, deep reveals, restricted palette? *(default: all four, translated into
   plain attributes)*

**Technical specs**

6. Square for Instagram *and* full-bleed A1 are different ratios. I'd generate
   3:2 with generous margin and crop the square from it — never re-roll for the
   crop, because a re-roll is a different building. *(default: 3:2, crop after)*

**One more thing on the source file.** Please re-export before we run anything:
2× resolution, section plane off, sun-path widget off, dimension tags off,
watermark off. The model won't ignore them — it will faithfully render a sliced
roof and a floating tag. Artefacts in, artefacts out.

---

## Turn 2 — reply received

> No time, sorry — use defaults. Overcast agreed, brick only. Adam says drop the
> canopy from the image, and windows stay as drawn. Substation: can you at least
> make it less noticeable? Trees — the landscape GA has three planters along the
> east side, use those, nothing new. Building is 3 storeys to the brick block, 2
> to the timber wing, 7 windows per upper floor on the timber wing. Re-exported
> the screenshot properly, it's in the folder. A1 board is the priority.

**On the substation.** Choosing a viewpoint is a photographer's decision and
entirely yours — if a different camera angle puts it out of frame, that's
legitimate and I'll write the prompt for that view. Softening or hiding
something that is in the model and in the drawings is a different thing: the
image then says the courtyard is tidier than it is, and that's the image that
ends up in the consultation boards. It stays as drawn in the prompts below, and
it's on the flagged list. If it's genuinely moving, that's a drawing change and
the render follows it.

---

## Turn 3 — the prompts

### Image A — entrance courtyard (transform, staged)

Three passes, one variable each, every pass using the **previous output** as its
base image. Running them merged is the single commonest cause of geometry drift —
the model given four jobs does none of them carefully.

**Stage 1 — brickwork only**

```
Base image: the supplied courtyard view of a new community health building.
Change only the brickwork of the left-hand block. Replace it with a warm
handmade red-brown brick: soft tonal variation from orange through to
grey-purple across the wall, irregular tumbled edges, matte unglazed surface,
stretcher bond, joints recessed and struck in a warm sandy mortar rather than
grey. Keep the timber cladding, the glazed link, the paving, the entrance ramp
and handrails, the substation enclosure, the planters and the sky exactly as
they are. Match the existing lighting exactly — same direction, same softness,
same shadow length. Architectural photography, controlled perspective, neutral
lens, physically accurate sunlight, realistic materials and reflections.

Preserve the original architectural geometry exactly. Do not change walls,
openings, ceiling heights, proportions, camera position, or spatial layout. No
redesign, no deformation, no added or removed architectural elements. Only
refine materials, lighting, atmosphere, and realism. Keep all 3 storeys of the
brick block and 2 of the timber wing, the 7 windows per upper floor on the
timber wing and their exact positions, the entrance ramp and handrails as
drawn, and the substation enclosure at the left of the courtyard. Keep the
exact camera lens and perspective.

Negative: No redesign. No warped geometry. No changing camera perspective. No
painterly style. No exaggerated cinematic effects. No heavy fog or smoke. No
grain or noise. No added canopies, balconies, brise-soleil or roof elements. No
legible text or signage.

Aspect ratio 3:2.
```

**Stage 2 — light only** *(base image: the Stage 1 result)*

```
Base image: the previous result. Change only the lighting. Bright overcast
daylight, soft even illumination, no strong cast shadows, true material colour
so the brick tone and the timber tone both read accurately. Cool neutral white
balance, bright but not blown-out sky, damp-looking paving with subtle sheen.
Keep every material exactly as it is in this image — the brick, the timber
cladding, the glazing, the paving, the handrails. Architectural photography,
controlled perspective, neutral lens, physically accurate diffuse daylight.

Preserve the original architectural geometry exactly. Do not change walls,
openings, ceiling heights, proportions, camera position, or spatial layout. No
redesign, no deformation, no added or removed architectural elements. Keep all
3 storeys of the brick block and 2 of the timber wing, the 7 windows per upper
floor and their exact positions, the ramp and handrails, and the substation
enclosure. Keep the exact camera lens and perspective.

Negative: No redesign. No warped geometry. No changing camera perspective. No
golden hour, no sunset, no warm colour grade. No painterly style. No
exaggerated cinematic effects. No heavy fog or smoke. No grain or noise. No
added canopies, balconies or roof elements. No legible text or signage.

Aspect ratio 3:2.
```

**Stage 3 — people and planting only** *(base image: the Stage 2 result)*

```
Base image: the previous result. Add people and planting only. A moderate,
believable number of people using the courtyard on an ordinary weekday morning
— mixed ages and ethnicities, one person using a wheelchair, one pushing a
pram, two children — walking, waiting and sitting, dressed for cool overcast
weather, natural postures, some partly motion-blurred. Plant the three existing
planters along the east side with small multi-stem trees and low shrub planting
appropriate to a temperate climate. Add nothing anywhere else: no new trees in
the paving, no new furniture, no bicycles, no vehicles.

Preserve the original architectural geometry exactly. Do not change walls,
openings, ceiling heights, proportions, camera position, spatial layout,
materials or lighting. No redesign, no deformation, no added or removed
architectural elements. Keep the ramp and handrails and the substation
enclosure exactly as they are, unobscured. Change nothing else.

Negative: No redesign. No warped geometry. No changing camera perspective. No
added canopies, balconies or roof elements. No new planting outside the three
existing planters. No crowds. No distorted faces or hands. No legible text or
signage. No painterly style. No exaggerated cinematic effects. No grain or
noise.

Aspect ratio 3:2.
```

### Image B — double-height waiting space (generate)

Nothing is modelled, so this image is **indicative of an intent, not of a
design**. It should be captioned that way if it travels.

```
A calm double-height waiting space in a new community health building. Board-
marked in-situ concrete to the main walls and a heavy exposed concrete soffit,
warm oak-veneered joinery and oak-slatted acoustic linings to the lower walls,
pale terrazzo-look floor, simple upholstered bench seating in muted tones, a
few large planted pots. A continuous clerestory at high level bringing soft
morning daylight deep into the room, deep reveals casting long soft shadows
down the concrete, restrained material palette of three tones only. Quiet,
generous, unfussy — a public room rather than a lobby. Interior architectural
photography, eye-level view at standing height, 24mm lens, verticals corrected,
controlled perspective, physically accurate daylight, realistic materials, high
resolution. Blank signage panels, no lettering anywhere.

Negative: No redesign. No warped geometry. No painterly style. No exaggerated
cinematic effects. No heavy fog or smoke. No grain or noise. No legible text or
signage. No reception desks with branding. No clutter.

Aspect ratio 3:2.
```

### Notes

- **3:2, generated large, cropped after.** Full-bleed A1 is close to 3:2 but not
  identical — keep margin at the edges and crop for the board; take the 1:1
  Instagram crop from the same file. Re-rolling at a different ratio gives you a
  different building.
- **Regular mode for the re-rolls, Pro for the final pass on each stage.** Lock
  a stage before moving to the next one; if Stage 2 goes wrong, go back to the
  Stage 1 file rather than patching forward.
- **Re-export at 2× if you touch the model again**, aids hidden. The prompts
  assume the clean export you've now put in the folder.
- **No text is generated anywhere by design.** Add the signage in InDesign over
  the finished image — the model misspells lettering, and the name shouldn't be
  in the prompt in any case.

### Assumptions declared

Applied because you said "use defaults", not because you specified them:

- Bright overcast daylight for Image A (you'd offered golden hour as an
  alternative and left the call to me).
- Copenhagen reference used for **brick appearance only** — not its evening
  light or mood.
- 3:2 aspect ratio, generated once, cropped for both uses.
- Image B materials: board-marked concrete, oak, terrazzo-look floor, muted
  upholstery. These are **my translation of the qualities you described**
  (material weight, top light, deep reveals, restricted palette), not a palette
  you gave me and not the specification. If the real palette differs, this image
  will quietly start arguing with the drawings.
- Image B lighting: morning clerestory light, not dusk (you offered both).
- Weekday-morning entourage, moderate density, cool-weather clothing.

`[to verify]` — the brick in your reference note is recalled as "a Petersen D48
or something in that family". That has not travelled into the prompt as a
specification; the prompt describes the appearance only. Confirm the actual
product with the supplier before it appears anywhere near a materials schedule.

### Flagged — for the architect, not the model

Design decisions found in the request and deliberately left undone:

| # | Asked for | Why it isn't in the prompt |
|---|---|---|
| 1 | Canopy over the entrance | Not drawn. Adam has confirmed it's out of the image — noted here so the trail is visible. |
| 2 | Taller windows on the timber wing | A design change to be made on the drawings, not in a render. Confirmed staying as drawn. |
| 3 | Remove / soften the substation | It exists in the model and the drawings. Choosing a viewpoint that excludes it is your call and I'll rewrite for it; erasing it from this viewpoint isn't. |
| 4 | Balconies "like the Copenhagen ones" | From the reference note. Not designed, not drawn, not rendered. |
| 5 | Ramp reading as "Part M compliant" | An image can't evidence compliance. Check the ramp against Approved Document M `[to verify]` — I've quoted no figures. |
| 6 | "Verified view", "dimensionally right" | Not achievable by this route. A verified view is a surveyed methodology and a separate commission — worth flagging to the client this week, not in October. |
| 7 | New trees in the paved courtyard | Resolved to the three existing planters. If new trees are wanted, that's the landscape drawing first. |
| 8 | Project name over the door | Confidentiality plus rendered-text misspelling. Signage stays blank; add it in InDesign. |

### Handed to sibling skills

| Request | Skill |
|---|---|
| Six hero shots for the DAS | `hero-perspective-prompt-builder` |
| Five brick options, same view | `facade-maker` |
| Site strategy diagrams (four-figure analysis board) | `site-diagram-matrix-builder` |
| Site strategy diagrams (six-frame concept evolution) | `site-matrix-diagram-builder` |

---

**Both images are illustrative.** They visualise a prompt, not the drawings.
Before either leaves the office, check them against the design information —
count the storeys and windows, check nothing has appeared that isn't designed —
and caption them as indicative visualisations. That matters more than usual
here: at Stage 3, heading into a planning submission and public consultation, an
image acquires a very long life and gets quoted back at you.
