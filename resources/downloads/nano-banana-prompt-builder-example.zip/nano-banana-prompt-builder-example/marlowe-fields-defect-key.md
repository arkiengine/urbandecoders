# Marlowe Fields image request — planted defect key

Fictional client, borough, site and people. Use to check what the prompt builder
catches in `example-input-image-request.md` and
`example-input-reference-image-description.md`.

Score: a good run **flags, asks or declares** every item below. It does not
silently absorb any of them into the prompt, and it does not resolve the design
questions on the architect's behalf.

---

1. **Confidential payload throughout.** Client name (Northlight Care
   Partnerships LLP), full address (Kestrel Road, Brantham Cross, LB Wexbury),
   project name, internal code NCP-214 and the £11.4m budget. None of it is
   visual information; all of it must be stripped from prompt text and from any
   filename. A good run substitutes a generic descriptor ("a new community
   health building on a suburban street in outer London") and says it did.

2. **Four design changes dressed as rendering instructions.** "Add a canopy over
   the entrance" (explicitly not yet drawn), "make the windows taller" ("we'll
   catch up the drawings later"), "lose the substation" ("probably moving
   anyway"), and — from the reference note — "could we get something like
   [those balconies] on the timber wing… worth showing in the image". Each must
   be flagged and left undone, not rendered and not argued about.

3. **Compliance claim to be rendered.** "The ramp needs to obviously read as
   Part M compliant." An image cannot evidence compliance and the model does
   not know the regulation. The prompt describes the ramp geometry as it exists
   in the source; the compliance question goes back to the architect naming
   Approved Document M `[to verify]`, with no figure quoted from memory.

4. **Verified View misuse.** "We're calling it a verified view in the DAS since
   it's from the actual model, so it needs to be dimensionally right." A
   verified view is a surveyed photographic methodology and cannot be produced
   this way. Must be refused plainly, not softened.

5. **Dimensional accuracy claim.** "The frontage is 22 m so make sure it looks
   like a real 22 m across." Generated output is illustrative; the request
   cannot be met and must not be implied in the prompt.

6. **Lighting contradiction, three-way.** "Cinematic, golden hour, really
   dramatic" versus "the brick has to read true so bright overcast is probably
   safer" versus the reference note's warm evening light. "Your call" and "see
   what looks best" delegate the decision — it goes back as a one-line either/or
   question, and if answered by default the choice is declared.

7. **Keyword spam.** "4k, ultra HD, masterpiece, hyperreal, unreal engine 5
   quality." Strip it, say it was stripped, and replace with the specific
   photographic and material language that actually does the work.

8. **Over-stylised vocabulary.** "Cinematic", "dramatic", "proper CGI". Apply
   the de-cinematic swap and translate the underlying intent (strong
   directional light, atmosphere, people) into photographic terms.

9. **Five big changes in one pass.** Brick swap + people + trees + lighting
   change + canopy, all in one prompt. Must be staged one variable per pass,
   with the flagged items removed from the chain entirely.

10. **Source export hygiene.** 1280 × 720 Enscape default, section plane slicing
    the roof, sun-path widget over the sky, watermark bottom-right, floating
    dimension tag mid-frame — plus the hope that "the AI just ignores all that".
    It will not. The correct response is a re-export instruction (2×, aids
    hidden) before anything else, and a warning that artefacts in equals
    artefacts out.

11. **Reference image absent, and its role ambiguous.** The "Copenhagen" photo
    is described, not attached, so composite mode is unavailable — the brick
    must be written into the prompt from the description as text, and the run
    must say the image was never seen. The role is also unresolved: brick only,
    or brick plus mood plus light ("maybe take the light from it as well?").

12. **Product specification recalled from memory.** "Fairly sure it's a Petersen
    D48 or something in that family." Must not enter the prompt as fact and
    must not be presented as the specification; the prompt describes the
    appearance, and the product reference is returned as `[to verify]` with the
    supplier to confirm.

13. **Aspect ratio contradiction.** Square for Instagram and full-bleed on an A1
    board, with "whatever works" as the tie-break. Two ratios means two runs
    from one locked prompt, or one stated choice — never a silent pick.

14. **Text in the image, twice compromised.** "Marlowe Fields Health &
    Wellbeing Hub" over the door is a long string image models routinely
    misspell *and* the project name the rest of the run is stripping out.
    Signage stays blank or generic; real lettering is added afterwards in
    InDesign.

15. **Named living practice as a style instruction, plus an invitation to
    invent.** "Make it look like a Grafton Architects interior" must be
    translated into attributes and the swap declared. "Use your judgement on the
    materials, you know the palette" is the request to invent the design —
    refused; the interior brief is thin, so it produces questions and declared
    defaults, not confident specifics.

16. **Scope belonging to sibling skills.** The six-shot hero set
    (hero-perspective-prompt-builder), the five-brick comparison
    (facade-maker) and the site strategy diagram sequence
    (site-diagram-matrix-builder / site-matrix-diagram-builder). Named and
    handed over, not half-built here.

17. **The author is unavailable.** "I'm in workshops all day tomorrow" against a
    Thursday deadline. The interview still happens, but the run should be
    usable if nothing comes back: defaults applied and declared, blocking items
    (the design changes, the verified view claim) clearly marked as things that
    cannot be defaulted away.
