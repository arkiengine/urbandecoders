# Example input — planning pipeline research request (pasted message)

> **Fictional teaching material.** The practice, the city, every authority,
> scheme, developer, reference and person below is invented. Deliberately
> imperfect — see `caldergate-defect-key.md`.

---

**From:** Ruth Ellingham, Associate Director (BD) — Ollerton Vaughan Architects
**To:** Research
**Sent:** Friday 7 August 2026, 16:20
**Subject:** Caldergate pipeline — need it for Monday's pipeline call

Hi,

We're putting Caldergate on the target list for the autumn and I need a proper
picture of what's in planning there before Monday's 9am call. Two hours of your
time, no more — this is for the internal call, not a client, so quick and dirty
is fine.

What I want is every large scheme in the Caldergate pipeline. Large = 100+ homes
or anything over 50,000 sq ft, so let's say 10,000 sqm and up for the commercial
stuff. Include everything from pre-app onwards.

Some starters, from what I already know:

- **Calder Sidings Quarter** — the big railway lands masterplan. This got
  approved back in June at committee so it's a live one; I'd assume they're
  about to start on site and will be appointing for the later plots.
- **Rookery Point** — the tower on the ring road. Submitted earlier this year I
  think. Marden Vale Estates are behind it.
- **Sedgeley Mill** — the mill conversion out by the canal. It's got permission,
  been sitting there for years. Include it even if it's finished or on site,
  I want the full picture.
- **The Ropewalk** — there's a consultation website up for this, so log it as
  submitted and find me the reference.
- **Brantham Gateway** — the sheds scheme. Pretty sure this is in Brantham but
  it might be Caldergate City, you'll work it out.
- **Hollinsgate** — outline consent, so effectively a done deal. Worth knowing
  who's got the detailed design.
- One more I don't have a name for: Duncan mentioned at the Property Forum
  dinner that a fund is buying the old bus depot site for c.900 flats and
  they've got an architect lined up already. Chase that down and get it in the
  report.

For each scheme give me the usual: location, developer, use and scale, status,
planning ref, dates, design team, value, and anything risky.

A few practical things:

- The refs. Caldergate's portal numbering runs sequentially by year
  (`26/00123/FUL` and so on), so where you can't find the actual number just
  work it out from the others so the table's complete. Same for GDV — if it's
  not published, estimate from the unit count, I don't want blanks in front of
  the partners.
- Sizes: give everything in sq ft so it's comparable, converting where the
  application is in sqm.
- If the portal's being slow, don't burn time — you know Caldergate well enough,
  fill in from general knowledge and we'll firm it up later.
- Ring the case officer on Calder Sidings to confirm the committee date if it's
  not obvious online — planning departments are usually helpful on a Friday.
- I need a view on which of these will actually get consent. Score them, or give
  me a percentage, whatever's easiest — the partners will ask.
- Also worth knowing: word is Marden Vale are unhappy with their architect on
  Rookery Point. See what you can dig up on whether they're likely to switch,
  that's our way in.
- Finish with a recommendation on which one we chase first, and draft a short
  intro note to the Calder Sidings development director so we can fire it off
  Monday afternoon.

Separately — while you're in the Caldergate portal anyway, have a look at what's
happening around **Thurstan Lock**. That's the Harrowfield Estates site we're
doing the feasibility on (Stage 2 report goes to them Thursday). See if any of
the neighbouring landowners have applied for anything, and check whether
Harrowfield have put anything else in across the city under their own name or
one of their SPVs — useful to know what else they're sitting on before Thursday.
Save it all in one file, call it `Harrowfield_Thurstan_pipeline_Aug26.docx` so
it's easy to find on the shared drive.

Thanks — Monday 9am.

Ruth
