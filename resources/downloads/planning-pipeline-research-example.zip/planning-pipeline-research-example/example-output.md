# Planning pipeline — Caldergate conurbation

Suggested filename: `caldergate-pipeline-2026-08-08.md`
Prepared for: Ollerton Vaughan Architects, BD
Request received: 7 August 2026 · Compiled: 8 August 2026 · **Status as-at: 8 August 2026**

---

> ## ⚠ Read this before anything else — teaching example
>
> **This is a worked reference answer, not real research.** Caldergate,
> Brantham and Marle Vale are invented authorities. Every scheme, applicant,
> practice, person, planning reference, appeal reference, date and figure below
> is fictional and does not correspond to any real application anywhere.
>
> The `[register: …]`, `[app docs: …]`, `[committee: …]` and `[press: …]` tags
> are **fictional stand-ins that show what a real citation slot looks like** —
> the authority, the reference, the document, and the date the page was
> accessed. In a genuine run every one of them would name a page actually
> opened in that session, and anything not opened would stay `[not found]` or
> `[to verify]`. No live retrieval was performed to produce this file.
>
> Use it to see the *shape* of a good run: how the scope note corrects a
> loosely-worded request, how the status ladder is written out longhand, how
> much of an honest profile legitimately comes back `[not found]`, and what
> gets declined and why. Do not use any figure in it for any purpose.

---

## 1. Scope note

**Geography → authorities.** "Caldergate" was used in the request for both the
city and the wider conurbation. Covered here, and stated so it can be corrected
in one line:

| Authority | Covered | Note |
|---|---|---|
| Caldergate City Council | Yes | The city administrative area |
| Brantham Borough Council | Yes | Contiguous; contains the canal corridor |
| Marle Vale District Council | Yes | Contains the Gateway and Hollinsgate sites |
| Wyre Rural District | **No** | Outside the built-up area; say the word and it is added |

The Caldergate & Wyre Combined Authority has a strategic role in the
regeneration frameworks cited below but is not the determining authority for
any scheme here `[to verify]` — confirm against the authority's own scheme of
delegation before repeating.

**"Large" — a contradiction in the request, not resolved silently.** The brief
gave "100+ homes or anything over 50,000 sq ft, so let's say 10,000 sqm and
up". 50,000 sq ft is c.4,645 sqm, not 10,000 sqm — those are two different
searches and the second is roughly twice as exclusive.

Applied for this run, pending your call: **100+ homes, or 5,000+ sqm commercial
floorspace, or a multi-building masterplan/regeneration scheme.** The lower
commercial threshold was taken because it is the closer reading of "50,000 sq
ft" and because a too-tight filter silently hides schemes. Schemes between
5,000 and 10,000 sqm are marked **[below 10,000 sqm]** in the comparison table
so the stricter list can be read off directly.

**Stages included:** pre-application where publicly evidenced, submitted,
validated/under consideration, resolution to grant, permitted-not-started,
reserved matters, and refused-under-appeal. **Excluded:** schemes on site or
complete — see *Declined items* for the Sedgeley Mill instruction.

**Purpose:** BD pipeline sweep, internal. Note that "internal" is not a lower
evidential standard here; internal pipeline material is precisely what ends up
pasted into a credentials deck six weeks later.

### Clarifications and corrections to the request

These are recorded rather than absorbed, because the wording in a request tends
to survive into the deck.

| As put in the request | Corrected position | Why it matters |
|---|---|---|
| Calder Sidings "got approved in June" | **Resolution to grant subject to s106**, 11 June 2026; decision notice not issued as at 8 Aug 2026 `[register: Caldergate CC, 25/01188/OUT, accessed 8 Aug 2026]` | A resolution is a minded-to position. Schemes change materially, or die, between resolution and notice. |
| "About to start on site" | s106 unsigned; no discharge-of-conditions applications on the register | Even once issued, an outline permission with an unsigned s106 is not implementable. |
| Sedgeley Mill "has permission, been sitting there for years" | Granted 14 Sep 2021; commencement status `[not found]`; whether extant `[to verify]` against the time limit on the decision notice | Permissions lapse if not lawfully commenced within the period the notice states. An assumed-live consent is a bad basis for an approach. |
| Hollinsgate "outline consent, so effectively a done deal" | Outline granted 3 Oct 2024; RM for Phase 1 submitted Apr 2026 and undetermined; Phases 2–3 RM outstanding | Outline is not buildable, and the later phases are exactly where an appointment might still be live. |
| The Ropewalk "log it as submitted" | **Consulting ahead of an intended submission.** No application found on the Caldergate register as at 8 Aug 2026 | Logging a consultation website as a submission invents a stage — and then invites inventing a reference to match. |
| Brantham Gateway "pretty sure this is in Brantham" | **Marle Vale District Council.** The site is in Marle Vale despite the scheme name `[register: Marle Vale DC, MV/26/0093/FUL, accessed 8 Aug 2026]` | Scheme names routinely borrow the nearest recognisable place. |
| "Give everything in sq ft" | Floorspace reported **as given in the application documents**, with the GIA/GEA/NIA basis carried | Converting silently loses the basis and injects rounding into figures that get quoted. A converted column can be added on request, basis intact. |

---

## 2. Method note

*What was searched, so the run can be repeated or challenged. In a real run
every line below records an actual search; here they illustrate the level of
detail the note needs.*

| Source | Searched | Terms / filters | Result |
|---|---|---|---|
| Caldergate CC public register | 8 Aug 2026 | Major applications, validated 1 Aug 2024 – 8 Aug 2026; ward filter: all | 4 qualifying schemes |
| Caldergate CC weekly lists | 8 Aug 2026 | Last 12 months, majors only | Cross-check; 1 scheme added |
| Caldergate CC committee agendas | 8 Aug 2026 | Planning Committee, Jan–Aug 2026 | Resolution and objection detail for 2 schemes |
| Brantham BC public register | 8 Aug 2026 | Majors, 2019–2026 (extended window to catch older consents) | 1 qualifying scheme |
| Marle Vale DC public register | 8 Aug 2026 | Majors, 2022–2026; also applicant search: "Pellow", "Kilnmoor", "Sable" | 3 qualifying schemes |
| Planning Inspectorate casework search | 8 Aug 2026 | LPA = Marle Vale, s78 appeals, 2025–2026 | 1 live appeal |
| Caldergate Local Plan / allocations | 8 Aug 2026 | Site allocations schedule; Tall Buildings SPD | Policy context only; figures `[to verify]` |
| Industry and local press | 8 Aug 2026 | Scheme names, applicant names, "Caldergate" + "planning" | 2 leads, 1 confirmed on the register, 1 not |
| Agent/applicant searches | 8 Aug 2026 | Agent name searches on each register | Design-team credits for 3 schemes |

**Not reached / limited:**

- Brantham BC document viewer returned an error on the Sedgeley Mill decision
  notice; status taken from the register summary line only. Re-check needed —
  the time limit condition is on the notice, and that is the whole question for
  this scheme.
- Marle Vale's register date filter caps results at 100; the 2022–2026 sweep
  was run in two windows to avoid a silent truncation.
- Pre-application discussions are not published by any of the three
  authorities. Any pre-app scheme here is evidenced indirectly (EIA screening
  requests, consultation websites, press) and tagged as such. Absence of
  pre-app schemes is **not** evidence of an absence of pre-app activity.

---

## 3. Pipeline summary

- **Seven qualifying schemes** across three authorities, plus one unverified
  lead and one scheme excluded as sub-threshold. Register-verified: 6.
  Press/developer-only: 1 (The Ropewalk).
- **By status:** 1 resolution to grant (s106 outstanding) · 1 under
  consideration · 1 validated/pending · 1 outline with RM part-submitted ·
  1 permitted, extant status unknown · 1 refused and under appeal ·
  1 pre-application (consultation stage).
- **Dominant uses:** city-centre residential and mixed-use in Caldergate;
  logistics and edge-of-settlement residential in Marle Vale. Brantham's only
  qualifying entry is a heritage conversion.
- **Busiest authority:** Marle Vale DC by count (3), Caldergate CC by quantum.
- **Design-team pattern:** architects are named in the DAS on five of six
  register-verified schemes; two schemes show no landscape architect credited
  in the public documents `[not found]` — an empty slot, which is BD
  information in itself, not a research failure.
- **Two schemes are at the stage where later-phase or reserved-matters
  appointments may still be unmade** (Calder Sidings plots 4–7, Hollinsgate
  phases 2–3), on the face of the published documents. Whether they are live
  opportunities is your call, not this report's.

---

## 4. Project profiles

Ordered by scale. Every line carries a tag; an untagged fact would mean an
unsourced fact, and there are none.

### 4.1 Calder Sidings Quarter — Caldergate

1. **Location.** Former railway lands, Calder Sidings, between Wharfeside Road
   and the Caldergate–Wyre line; Riverside ward, Caldergate City Council
   `[register: Caldergate CC, 25/01188/OUT, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Calder Sidings LLP — a joint venture between
   Vennard Regeneration Ltd and Caldergate City Council as landowner
   `[app docs: Planning Statement s1.2, 25/01188/OUT]`. Promoted publicly as
   "Calder Sidings Quarter" by Vennard `[developer: Vennard project page, accessed 8 Aug 2026]`;
   the applicant entity and the marketing brand differ — use the LLP for any
   register search.
3. **Use & scale.** Outline, mixed-use: up to 1,180 homes, 18,400 sqm (GIA)
   commercial/workspace, 2,100 sqm (GIA) retail and community, across seven
   development plots; heights 4–21 storeys as parameter maxima
   `[app docs: Development Specification, Table 3.1, 25/01188/OUT]`. Basis
   reported as given (GIA); not converted.
4. **Planning status.** **Resolution to grant subject to completion of a s106
   agreement**, Planning Committee 11 June 2026. **Decision notice not issued
   as at 8 August 2026.** s106 in negotiation; no signature recorded on the
   register `[committee: Caldergate CC Planning Committee, 11 Jun 2026]`
   `[register: 25/01188/OUT, accessed 8 Aug 2026]`.
5. **Reference & authority.** `25/01188/OUT`, Caldergate City Council. Related:
   `25/01188/EIA` screening/scoping under the same site
   `[register: accessed 8 Aug 2026]`. Transcribed from the register entry.
6. **Key dates.** Validated 4 Nov 2025; consultation closed 19 Dec 2025;
   committee 11 Jun 2026; decision notice `TBC`; any commencement date
   `[not found]` `[register: 25/01188/OUT, accessed 8 Aug 2026]`.
7. **Design team.** Architect and masterplanner: Whitcombe Ash Architects;
   planning: Loxley Perrin; landscape: Fernbank Studio; transport: Adderley
   Mobility `[app docs: Design and Access Statement, cover sheet, 25/01188/OUT]`.
   Plot architects for later phases `[not found]` — the outline does not name
   them and no reserved matters have been submitted.
8. **Strategic context.** Allocated in the Caldergate Local Plan (adopted 2021)
   as a strategic regeneration site, policy reference and indicative capacity
   `[to verify]` against the adopted plan; within the Calder Corridor
   Regeneration Framework area `[app docs: Planning Statement s4, 25/01188/OUT]`.
   Tall-building status assessed against the Caldergate Tall Buildings SPD
   (2023); the SPD's threshold height `[to verify]` — do not quote a figure
   from this report.
9. **Stated value / funding.** No GDV stated in the application documents. Press
   reported "a £400m regeneration" `[press: Caldergate Business Journal, 12 Jun 2026]`
   — a press figure, not an applicant statement, and reported as such. No
   estimate has been produced; see *Declined items*.
10. **Risks & signals.** 214 objections and 31 letters of support recorded;
    principal objection themes: height at the western plots, daylight to
    Wharfeside Road, and construction traffic. The Environment Agency withdrew
    an initial holding objection following submission of a revised FRA. Officer
    recommendation was approval subject to s106 heads of terms covering
    affordable housing (offer below policy on stated viability grounds),
    highways and open space `[committee: Caldergate CC, 11 Jun 2026, officer report and minutes]`.
    The affordable offer and viability review mechanism are the live issues
    between resolution and notice `[committee: as above]`.

### 4.2 Rookery Point — Caldergate

1. **Location.** 1–9 Rookery Point, junction of Ringway North and Sedgeley
   Road; Northgate ward, Caldergate City Council
   `[register: Caldergate CC, 26/00214/FUL, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Marden Vale Estates (Northgate) Ltd, an SPV;
   parent named in the ownership certificate as Marden Vale Estates Ltd
   `[app docs: Application form, certificate B, 26/00214/FUL]`.
3. **Use & scale.** Full application: 312 build-to-rent homes and 640 sqm (GIA)
   ground-floor commercial in a single 27-storey tower with a 6-storey podium
   `[app docs: Planning Statement s2.1, 26/00214/FUL]`.
4. **Planning status.** **Validated and under consideration.** Consultation
   period closed; not yet reported to committee; no officer recommendation
   published as at 8 Aug 2026 `[register: 26/00214/FUL, accessed 8 Aug 2026]`.
5. **Reference & authority.** `26/00214/FUL`, Caldergate City Council
   `[register: accessed 8 Aug 2026]`.
6. **Key dates.** Validated 26 Feb 2026; consultation closed 3 Apr 2026;
   statutory determination period expired, extension of time agreed to 30 Sep
   2026; committee date `TBC` `[register: 26/00214/FUL, accessed 8 Aug 2026]`.
   The length of the statutory period for a major application is `[to verify]`
   against the relevant Order.
7. **Design team.** Architect: Deacon Reid; planning: Loxley Perrin; structures:
   Halloway Ince `[app docs: Design and Access Statement, cover sheet, 26/00214/FUL]`.
   Landscape architect not credited in the public documents `[not found]`.
8. **Strategic context.** Within the Northgate Opportunity Area; the site is
   identified in the Tall Buildings SPD (2023) as within an area where tall
   buildings may be appropriate in principle, subject to criteria — criteria
   and any height parameter `[to verify]` at the SPD itself
   `[app docs: Planning Statement s5, 26/00214/FUL]`. Not within a conservation
   area; the Grade II Northgate Assembly Rooms lie c.120m south and a heritage
   statement is on the file `[register: document list, 26/00214/FUL, accessed 8 Aug 2026]`.
9. **Stated value / funding.** `[not found]` — no GDV, capex or funding
   arrangement stated in any retrieved document.
10. **Risks & signals.** 96 objections recorded; themes: height, wind
    microclimate and loss of daylight to Sedgeley Road. Historic England
    response on the file — a consultee response, not a recommendation; read it
    directly rather than relying on this summary
    `[register: consultee responses, 26/00214/FUL, accessed 8 Aug 2026]`. The
    extension of time is normal for a major of this scale and is not by itself
    a signal of difficulty. **No view is offered on the likely outcome** — see
    *Declined items*.

### 4.3 Hollinsgate — Marle Vale

1. **Location.** Land north of Hollinsgate Lane, Marle Vale District Council
   `[register: Marle Vale DC, MV/23/0771/OUT, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Pellow Homes Ltd
   `[register: MV/23/0771/OUT, accessed 8 Aug 2026]`.
3. **Use & scale.** Outline with all matters reserved except access: up to 640
   homes, 1,400 sqm (GIA) local centre, primary school reserve
   `[app docs: Development Framework Plan, MV/23/0771/OUT]`.
4. **Planning status.** **Outline permission granted 3 Oct 2024.** Reserved
   matters for **Phase 1 (218 homes) submitted 22 Apr 2026 and undetermined**;
   reserved matters for Phases 2 and 3 **not yet submitted**. This is not a
   buildable consent for the whole site `[register: MV/23/0771/OUT and MV/26/0142/RM, accessed 8 Aug 2026]`.
5. **Reference & authority.** Outline `MV/23/0771/OUT`; reserved matters
   `MV/26/0142/RM`, Marle Vale District Council. Both transcribed from the
   register `[register: accessed 8 Aug 2026]`.
6. **Key dates.** Outline granted 3 Oct 2024; time limit for submission of
   reserved matters as stated on the decision notice `[to verify]`; Phase 1 RM
   validated 22 Apr 2026; determination `TBC`
   `[register: accessed 8 Aug 2026]`.
7. **Design team.** Outline stage — masterplanner: Fernbank Studio; planning:
   Ordell Carew. **Phase 1 reserved matters architect: Pryor Sandys** — a
   different practice from the outline masterplanner
   `[app docs: DAS cover sheets, MV/23/0771/OUT and MV/26/0142/RM]`. That change
   is recorded because it is visible on the documents; no inference is offered
   as to why, and none should be drawn from this line.
8. **Strategic context.** Strategic housing allocation in the Marle Vale Local
   Plan; policy reference and allocated capacity `[to verify]` against the
   adopted plan `[app docs: Planning Statement s3, MV/23/0771/OUT]`.
9. **Stated value / funding.** `[not found]`.
10. **Risks & signals.** s106 completed at outline stage covering education,
    highways and open space contributions
    `[register: MV/23/0771/OUT decision documents, accessed 8 Aug 2026]`. Phase 1
    RM attracted 41 objections, principally on drainage and the Hollinsgate Lane
    junction `[register: MV/26/0142/RM, accessed 8 Aug 2026]`. Lead Local Flood
    Authority response on file; read it directly.

### 4.4 Brantham Gateway — Marle Vale (not Brantham)

1. **Location.** Land at Junction 4, Brantham Road, Marle Vale District — the
   scheme name refers to the road, not the authority
   `[register: Marle Vale DC, MV/26/0093/FUL, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Kilnmoor Logistics Ltd
   `[register: MV/26/0093/FUL, accessed 8 Aug 2026]`.
3. **Use & scale.** Full: three units totalling 46,800 sqm (GEA) storage and
   distribution, with ancillary offices
   `[app docs: Planning Statement s2, MV/26/0093/FUL]`. **Basis is GEA as
   stated** — not comparable line-for-line with the GIA figures elsewhere in
   this report, and not converted.
4. **Planning status.** **Validated, pending consideration.** Consultation live
   at the access date `[register: MV/26/0093/FUL, accessed 8 Aug 2026]`.
5. **Reference & authority.** `MV/26/0093/FUL`, Marle Vale District Council; EIA
   screening opinion issued under `MV/25/0884/SCR`
   `[register: accessed 8 Aug 2026]`.
6. **Key dates.** Validated 17 Jun 2026; consultation closes 21 Aug 2026;
   committee `TBC` `[register: accessed 8 Aug 2026]`.
7. **Design team.** Architect: Halloway Ince; planning: Ordell Carew
   `[app docs: DAS cover sheet, MV/26/0093/FUL]`. Engineers `[not found]` in the
   public document set.
8. **Strategic context.** Employment allocation in the Marle Vale Local Plan;
   policy reference `[to verify]`. Part of the site lies within Flood Zone 2 per
   the submitted FRA `[app docs: Flood Risk Assessment s3, MV/26/0093/FUL]` —
   the FRA is the applicant's document; the EA response is the position that
   matters and was not published at the access date `[not found]`.
9. **Stated value / funding.** `[not found]`.
10. **Risks & signals.** 12 objections at the access date, early in the
    consultation; themes: HGV movements and light spill. National Highways
    holding response on file `[register: consultee responses, MV/26/0093/FUL, accessed 8 Aug 2026]`.

### 4.5 Sedgeley Mill — Brantham

1. **Location.** Sedgeley Mill, Canal Street, Brantham Borough Council
   `[register: Brantham BC, BR/2021/0417/FUL, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Ravenscourt Living Ltd
   `[register: BR/2021/0417/FUL, accessed 8 Aug 2026]`.
3. **Use & scale.** Conversion of the Grade II listed mill and new-build
   flanking blocks: 164 homes, 900 sqm (NIA) commercial
   `[app docs: Planning Statement s2, BR/2021/0417/FUL]`. **NIA as given** —
   a different basis again; do not add it to the GIA totals.
4. **Planning status.** **Full permission granted 14 September 2021**, with
   listed building consent under a separate reference. **Commencement status
   `[not found]`** — no discharge-of-conditions or commencement notice
   applications appear on the register. **Whether the permission remains extant
   is `[to verify]`** against the time limit condition on the decision notice,
   which could not be opened (see method note). It is *not* recorded here as
   live, and it is not recorded here as lapsed
   `[register: BR/2021/0417/FUL, accessed 8 Aug 2026]`.
5. **Reference & authority.** `BR/2021/0417/FUL` and listed building consent
   `BR/2021/0418/LBC`, Brantham Borough Council
   `[register: accessed 8 Aug 2026]`.
6. **Key dates.** Validated 2 Mar 2021; granted 14 Sep 2021; time limit
   condition `[to verify]`; any commencement `[not found]`.
7. **Design team.** Architect: Whitcombe Ash Architects; heritage: Sallow &
   Tate `[app docs: DAS and Heritage Statement cover sheets, BR/2021/0417/FUL]`.
   Whether the team remains appointed five years on is `[not found]` and not
   inferable.
8. **Strategic context.** Grade II listed; within the Canal Street Conservation
   Area `[app docs: Heritage Statement s2, BR/2021/0417/FUL]`. Listing grade
   and conservation area designation should be confirmed on the national list
   and the authority's own mapping `[to verify]`.
9. **Stated value / funding.** `[not found]`.
10. **Risks & signals.** The dormancy is the signal: a 2021 consent with no
    visible discharge activity. Whether that reflects viability, funding,
    ownership change or a quiet lawful start is **not established** and is not
    speculated on here. If this scheme matters to the pipeline, the next step
    is to open the decision notice and check the time limit and any
    commencement evidence — a 20-minute job with the document viewer working.

### 4.6 Lindow Green — Marle Vale *(found by the sweep; not on the request list)*

1. **Location.** Land off Lindow Green Road, Marle Vale District Council
   `[register: Marle Vale DC, MV/25/0508/FUL, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Sable Land Ltd
   `[register: accessed 8 Aug 2026]`.
3. **Use & scale.** 186 homes with associated open space
   `[app docs: Planning Statement s2, MV/25/0508/FUL]`.
4. **Planning status.** **Refused 27 November 2025**; **appeal lodged** under
   s78 and in progress at the access date, inquiry procedure
   `[register: MV/25/0508/FUL, accessed 8 Aug 2026]`
   `[appeal: PINS APP/Z9999/W/26/3412907, accessed 8 Aug 2026]`.
5. **Reference & authority.** LPA `MV/25/0508/FUL`, Marle Vale DC; appeal
   `APP/Z9999/W/26/3412907`, Planning Inspectorate. Two separate references for
   the same scheme — quote both.
6. **Key dates.** Validated 11 Apr 2025; refused 27 Nov 2025; appeal validated
   19 Mar 2026; inquiry date `TBC` `[appeal: PINS casework, accessed 8 Aug 2026]`.
7. **Design team.** Architect: Pryor Sandys; planning: Loxley Perrin
   `[app docs: DAS cover sheet, MV/25/0508/FUL]`. Appeal advocate `[not found]`
   in the published casework documents at the access date.
8. **Strategic context.** Outside the settlement boundary in the adopted Marle
   Vale Local Plan; refusal reasons cite landscape character and prematurity to
   the emerging plan review `[register: decision notice, MV/25/0508/FUL, accessed 8 Aug 2026]`.
   The weight to be given to an emerging plan is a policy judgement `[to verify]`.
9. **Stated value / funding.** `[not found]`.
10. **Risks & signals.** The refusal reasons and the appeal are the substance
    here; read the decision notice and, when published, the statements of case.
    **No prediction of the appeal outcome is offered.**

### 4.7 The Ropewalk — Caldergate *(pre-application; not an application)*

1. **Location.** The Ropewalk, off Wharfeside Road, Caldergate — site extent as
   shown on the consultation website only
   `[developer: theropewalk-consultation website, accessed 8 Aug 2026]`.
2. **Applicant / developer.** Tarnbrook Property Ltd, per the consultation
   material `[developer: as above]`. No applicant of record — there is no
   application.
3. **Use & scale.** "Around 400 homes and new workspace" per the consultation
   boards `[developer: as above]`. **A pre-submission figure from promotional
   material.** Quantum at consultation routinely differs from quantum at
   submission; this figure should not be tabulated alongside register figures
   without the caveat travelling with it.
4. **Planning status.** **Consulting ahead of an intended submission.** No
   application, and no EIA screening or scoping request, found on the
   Caldergate register as at 8 Aug 2026 `[register: Caldergate CC search by
   site address and by applicant name, accessed 8 Aug 2026]`.
5. **Reference & authority.** **`[not found]` — none exists.** The request asked
   for a reference to be found for this scheme; there is nothing to find, and
   nothing has been constructed. Caldergate CC is the prospective authority.
6. **Key dates.** Consultation events advertised for September 2026; intended
   submission "later this year" `[developer: consultation website, accessed 8 Aug 2026]`.
   Both are the promoter's statements of intent.
7. **Design team.** Architect credited on the consultation boards: Deacon Reid
   `[developer: consultation website, accessed 8 Aug 2026]`. Consultation-board
   credits are not application-document credits and teams change before
   submission.
8. **Strategic context.** Within the Calder Corridor Regeneration Framework area
   `[press: Caldergate Business Journal, 3 Jul 2026]`. Framework policy status
   `[to verify]`.
9. **Stated value / funding.** `[not found]`.
10. **Risks & signals.** None on record — there is no case file, no consultee
    responses and no objections to count. The absence of risk information here
    is an absence of *information*, not an absence of risk.

---

## 5. Comparison table

Every cell traces to a tagged line in the profile above. Status wording is the
ladder wording, not a shorthand.

| Scheme | LPA | Reference | Use | Scale (as given) | Status (as-at 8 Aug 2026) | Architect |
|---|---|---|---|---|---|---|
| Calder Sidings Quarter | Caldergate CC | 25/01188/OUT | Mixed-use masterplan | 1,180 homes; 18,400 sqm GIA commercial; 2,100 sqm GIA retail/community | Resolution to grant subject to s106 (11 Jun 2026); decision notice not issued | Whitcombe Ash |
| Hollinsgate | Marle Vale DC | MV/23/0771/OUT · MV/26/0142/RM | Residential-led urban extension | Up to 640 homes; 1,400 sqm GIA local centre **[below 10,000 sqm]** | Outline granted 3 Oct 2024; Phase 1 RM undetermined; Phases 2–3 RM not submitted | Fernbank (outline) · Pryor Sandys (Ph1 RM) |
| Brantham Gateway | **Marle Vale DC** | MV/26/0093/FUL | Logistics | 46,800 sqm **GEA** | Validated 17 Jun 2026; pending consideration | Halloway Ince |
| Rookery Point | Caldergate CC | 26/00214/FUL | BTR residential + commercial | 312 homes; 640 sqm GIA commercial **[below 10,000 sqm]** | Validated 26 Feb 2026; under consideration; EoT to 30 Sep 2026 | Deacon Reid |
| Lindow Green | Marle Vale DC | MV/25/0508/FUL · APP/Z9999/W/26/3412907 | Residential | 186 homes | Refused 27 Nov 2025; s78 appeal in progress | Pryor Sandys |
| Sedgeley Mill | Brantham BC | BR/2021/0417/FUL · BR/2021/0418/LBC | Listed conversion + new build | 164 homes; 900 sqm **NIA** commercial **[below 10,000 sqm]** | Granted 14 Sep 2021; commencement `[not found]`; extant `[to verify]` | Whitcombe Ash |
| The Ropewalk | Caldergate CC (prospective) | **`[not found]` — no application** | Mixed-use *(promoter's description)* | c.400 homes *(consultation material)* | Consulting ahead of an intended submission | Deacon Reid *(consultation boards)* |

**Floorspace figures are not comparable across rows** — GIA, GEA and NIA appear
above exactly as each application states them. Any total struck across this
column would be meaningless.

---

## 6. Gaps & caveats

- **Re-verify before use.** Every status above was correct on the register at
  the access date, 8 August 2026, and not one hour later. Before any of this is
  spoken to a client or put in a deck, re-open the register entry.
- **The bus depot lead is not in this report.** The Property Forum conversation
  ("a fund buying the old bus depot for c.900 flats, architect appointed") was
  searched: Caldergate CC register by address for the three former depot sites
  identifiable from mapping, by keyword, and press over 12 months. **Nothing
  found.** It is logged here as an unverified lead so it isn't lost, and it
  appears nowhere else in this document. Hearsay is not a source, and a
  900-home scheme in a comparison table on the strength of a dinner
  conversation is precisely how a pipeline becomes fiction.
- **The Ropewalk is promoter-sourced throughout.** Nothing about it has been
  verified against a register because there is nothing on a register.
- **Sedgeley Mill's decision notice could not be opened.** Whether the
  permission is extant is the single most important fact about that scheme and
  it is currently unknown. Re-check when the Brantham document viewer is up.
- **Pre-application activity is largely invisible.** None of the three
  authorities publishes pre-app. Expect schemes to exist that this sweep cannot
  see; a thin pre-app section is a limit of the public record, not of the
  search.
- **Sub-threshold and excluded.** Dovecote Street, Caldergate (60 homes,
  `26/00341/FUL`) was found and excluded as below the 100-home threshold. It is
  named so the exclusion is visible rather than invisible.
- **Marle Vale's 100-result cap** could still be hiding schemes at the edges of
  the date windows. If Marle Vale matters to the target list, a third narrower
  sweep is worth 20 minutes.
- **Policy figures are unverified by design.** Every tall-building threshold,
  determination period, reserved-matters time limit and lapse period above is
  marked `[to verify]`. None of them has been quoted from memory and none
  should be repeated from this document without checking the named source.

---

## 7. Declined items

Stated openly rather than quietly dropped, so you can commission them properly
if you disagree.

| Requested | Not done | Why, and what was done instead |
|---|---|---|
| Construct missing planning references from the sequential numbering | Declined | Reference formats are per-authority and not guessable; a constructed ref points at somebody else's application and survives into a deck. Where no reference exists, the row says `[not found]` and says why. |
| Estimate GDV from unit counts where not published | Declined | An estimate becomes a quoted fact within a week. Values are stated only where a retrieved source states them; five of seven schemes are `[not found]`. |
| Fill gaps from general knowledge if the portal is slow | Declined | Training data is out of date by definition, and a half-right pipeline is worse than a short one because nobody can tell which half. Everything here was retrieved or is tagged as not retrieved. |
| Convert all floorspace to sq ft | Not done as asked | Figures are reported in the basis and unit each application uses; silent conversion loses GIA/GEA/NIA and adds rounding. A converted column with the basis carried through can be added on request. |
| Ring the case officer to confirm the committee date | Declined | This is desk research on public records — no calls, emails, FOI or pre-app enquiries on the practice's behalf. The committee date is `TBC` on the register; if you want it, the call is yours to make. |
| Score each scheme's likelihood of consent / give a percentage | Declined | Outcome prediction is not research. What is reported instead: objection counts, consultee positions, officer recommendations, refusal reasons and committee history, each cited. The judgement is the practice's. |
| Investigate whether Marden Vale are unhappy with their architect | Declined | Not researchable from public records, and speculating about a named practice's client relationship risks defaming a competitor. Only an observable fact is reported — at **Hollinsgate**, a different architect appears on the Phase 1 RM from the outline masterplanner, as shown on the documents, with no inference as to why. |
| Recommend which scheme to chase first | Declined | Ordering the table by scale, stage or authority is a formatting request and will be done on request. Choosing the target is a BD decision the research exists to inform. |
| Draft an intro note to the Calder Sidings development director | Declined | This skill researches; it never drafts or sends outreach. Named-contact and company-level research (who they are, who they usually appoint, published contacts) is the `bd-market-research` skill's job — commission that separately and it will come back cited. |
| Include Sedgeley Mill even if complete or on site | Partly | It is included because its status is *unresolved*, not because completed schemes are in scope. Had the register shown it complete it would have been listed in Gaps & caveats and excluded. Say the word and the stage range widens explicitly. |
| Research Harrowfield Estates' other applications and SPV holdings | **Declined — confidentiality** | Harrowfield are a live client, mid-feasibility at Thurstan Lock with a Stage 2 report due this week. Portal-sweeping a client's landholdings under their own name and their SPVs is researching the client behind their back; it is also the kind of query that leaves a trail. If Harrowfield want it, they can ask for it and it becomes a commissioned piece of work. |
| Neighbouring applications around Thurstan Lock | Deferred, not refused | Legitimate and useful **site-context** research — but it belongs to the Harrowfield feasibility, not to a BD sweep that will circulate internally. Commission it as a separate run and it will be delivered as a separate, neutrally named file. |
| Save as `Harrowfield_Thurstan_pipeline_Aug26.docx` | Declined | Client name and site in a filename on a shared drive travels further than the file's contents. This report is `caldergate-pipeline-2026-08-08.md` — place and date. |
| Two hours, "quick and dirty" | Not accepted as framed | Delivered instead: a smaller, fully verified report. Six register-verified schemes with transcribed references beats twelve with three invented ones, and "internal only" is not a lower standard — internal pipeline notes are what get pasted into credentials decks. |

---

## What to say in chat when handing this over

*(The report is not the whole deliverable — the caveats are said out loud, not
buried in section 6.)*

> Seven schemes, six register-verified, one promoter-only. Three corrections
> worth knowing before Monday: **Calder Sidings is not approved** — it is a
> resolution to grant with the s106 unsigned and no decision notice, so nobody
> is about to start on site; **Hollinsgate is outline only** with two phases of
> reserved matters not yet submitted, which is arguably the more interesting
> fact for BD; and **Brantham Gateway is in Marle Vale**, not Brantham.
> **Sedgeley Mill's consent may have lapsed** — the decision notice wouldn't
> open and that is the one thing worth re-checking before the call. The bus
> depot lead didn't survive a search and isn't in the report. I haven't scored
> consent likelihood, estimated any GDVs, or looked at Harrowfield — all
> explained in section 7, all reversible if you want to talk it through.
