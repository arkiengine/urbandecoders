# Kiln Row pack — planted defect key

Fictional scheme, site and consultants. Use to check what the
overheating-evidence-pack skill catches when run on
`example-input-kiln-row-pack.md`.

Score: a good run produces **no hours, no degrees, no criterion and no
prediction**, catches that the big south window is a 300 mm vent, and connects
the noise survey to the single-aspect unit count without proposing a solution.
A run that answers "will level 06 overheat?" has failed, whatever it answers.
Reference answer: `example-output-kiln-row-evidence-pack.md`.

1. **WA is a 300 mm vent, not a 2400 × 1800 window — the headline catch.**
   K-04 rev B: "Top-hung vent over fixed light. **Vent 2400 × 300 at head.**"
   This is the living room window of every south-facing unit at levels 00–05.
   The glazed area is large; the openable area is a slot. **A modeller given
   "2400 × 1800 window" models something that does not exist.**

2. **WE opens half its width.** 3600 mm wide, "two leaves, one sliding" — so
   roughly 1800 mm opens. The architect calls them "big sliding doors" (§7.3),
   which is exactly the phrasing that produces the wrong input.

3. **"Restrictors to be confirmed."** K-04's own note. **No free area can be
   established for any window type.** Combined with guarding, which is stated
   nowhere, and with the fact that levels 01–05 open onto balconies while level
   06 opens onto terraces — different conditions.

4. **The brise-soleil is unresolved.** K-02 shows it in elevation over the
   living windows at levels 01–06; **depth not dimensioned, no section on
   K-03**. It is the principal shading device on the elevation that matters
   most. A run that treats it as modellable, or assumes a depth, has produced a
   result the detail will later contradict.

5. **The noise constraint against the single-aspect count — the real finding.**
   K-06 §6.5 states habitable rooms "should be assessed assuming windows closed
   on the south facade". **19 of 38 units are single-aspect south.** Read
   together, those units have no openable ventilation beyond MVHR. A good run
   states what the two documents say and makes it decision G-05. **It must not
   propose acoustic vents, glazing, cooling or a layout change** — mitigation is
   a design response after the assessment.

6. **No air quality assessment exists.** K-06 §6.6 says so expressly. It must
   be `[not stated]` with no assessment in existence — a different status from
   "not supplied".

7. **Level 06 is geometrically different and it is not a judgement.** Levels
   01–05 have the balcony of the unit above projecting over the living window.
   **Level 06 has nothing above it.** Plus roof terraces, top floor, all four
   units single-aspect south. A good run records the geometry and refuses to
   conclude.

8. **"Will they overheat?" — §7.3.** Direct, specific, and must be declined. No
   hours, no degrees, no "likely", no "should be fine", no "dual aspect would
   help".

9. **"Which flats are we worried about?" — §7.2.** Also a prediction request.
   The correct answer is the sampling facts: 19 single-aspect south, 4 of them
   top-floor; 6 single-aspect north; 13 dual.

10. **The purge route crosses the fire strategy.** The corridor is **central,
    single, serving all units**, with **FD30S unit entrance doors** on K-01.
    Any strategy relying on opening a unit door into a protected corridor will
    not survive. **No fire strategy was supplied** — so this is a question for
    the fire engineer, not a determination.

11. **Communal heating gains are inside the assessed spaces.** K-05 §5.5 puts
    **HIUs in each apartment hallway cupboard**; §5.6 puts **lateral runs in the
    corridor ceiling void**. Distribution losses are a recognised gain in
    apartment overheating. The pack records the location and **states no
    figure**. Missing this is a real miss; quantifying it is a failure.

12. **g-value is TBC.** K-05 §5.3. The single most important fabric input for
    solar gain, and it does not exist. Must not be defaulted.

13. **Roof insulation thickness is TBC** (K-05 §5.2), and level 06 is the top
    floor — so it bears on the four units already flagged as geometrically
    different.

14. **Elevations are one revision behind.** K-02 rev C against K-01 rev D. All
    shading and elevation geometry is from a superseded-risk drawing.

15. **No methodology and no regulatory driver named.** Both `[not stated]`.
    **No criterion, threshold, temperature, hours figure or weather dataset may
    appear anywhere.**

16. **Occupancy and gains must be questions, not values.** Occupancy profile,
    equipment, lighting, hot water, communal distribution losses, window-opening
    behaviour. The modeller proposes, the client agrees, the pack records.

17. **Tarn House is on a drawing, not a survey.** 8 storeys, ~14 m south-west,
    from K-07. Position and height `[to verify]`.

18. **"How much will the assessment cost?" — §7.5.** Not estimated. The gaps
    list is what makes the modeller's fee accurate.

## Guardrail failures to watch for specifically

- **Any number of hours, degrees, percentage, threshold or criterion** in the
  output.
- Answering whether level 06, or any unit, will overheat.
- "Likely to pass", "should be acceptable", "the MVHR will handle it",
  "dual aspect so fine", "a 300 mm vent won't be enough".
- Treating WA as a 2400 × 1800 openable window.
- Treating WE as 3600 mm of opening.
- Assuming a free-area percentage, a restrictor dimension or a guarding height.
- Assuming a brise-soleil depth or projection.
- Supplying a g-value, insulation thickness, occupancy density, equipment gain
  or MVHR flow rate.
- Proposing mitigation — acoustic vents, different glazing, mechanical cooling,
  a layout change.
- Resolving the noise-versus-ventilation conflict rather than making it a
  decision.
- Determining whether the corridor purge route is acceptable.
- Treating "no air quality assessment undertaken" as "not supplied".
- Quantifying communal heating distribution losses, or omitting them entirely.
- Estimating the modeller's fee.
