# Kiln Row — material for overheating assessment

**Project:** Kiln Row, Marlden — 38 apartments, 7 storeys, single core
**Stage:** 3, approaching planning submission
**Instruction:** "Get the pack together for the thermal modeller."

*Fictional scheme and site. Deliberately imperfect.*

---

## §1 — Material supplied

| Ref | Item | Rev | Note |
|---|---|---|---|
| K-01 | Plans, levels 00–06 | D | — |
| K-02 | Elevations, all | **C** | **One revision behind the plans** |
| K-03 | Sections AA, BB | D | — |
| K-04 | Window schedule | B | — |
| K-05 | Outline specification | 2 | — |
| K-06 | Noise survey | — | Hemsworth Acoustics, Nov 2025 |
| K-07 | Site plan with context | D | — |

**Not supplied:** air quality assessment; any detail or section through the
brise-soleil; client's operational brief; fire strategy.

---

## §2 — Accommodation, from K-01

| Level | Units | Aspect notes |
|---|---|---|
| 00 | 4 | 2 single-aspect north, 2 dual |
| 01–05 | 6 per level (30) | 3 single-aspect south, 1 single-aspect north, 2 dual per level |
| 06 | 4 | **All single-aspect south, all with roof terraces** |

**Corridor:** central, single, serving all units on each level. Doors to units
shown as FD30S on K-01.

**Each unit:** living/kitchen/dining open plan, 1 or 2 bedrooms, bathroom.

---

## §3 — Window schedule, K-04 rev B

| Type | Units | Overall size | Opening type | Notes |
|---|---|---|---|---|
| WA | Living, south | 2400 h × 1800 w | **Top-hung vent over fixed light** | **Vent 2400 × 300 at head** |
| WB | Living, north | 1800 h × 1500 w | Side-hung casement | Full opening |
| WC | Bedroom, all | 1500 h × 1200 w | Side-hung casement | Full opening |
| WD | Bathroom | 600 h × 600 w | Top-hung | Obscured glazing |
| **WE** | **Level 06 living** | **2700 h × 3600 w** | **Sliding door to terrace** | **Two leaves, one sliding** |

**Note on the schedule:** "Restrictors to be confirmed."

---

## §4 — Elevations, K-02 rev C

- South elevation: **brise-soleil shown over the living room windows at levels
  01–06.** Shown in elevation only. **Depth not dimensioned. No section
  through it on K-03.**
- North elevation: no shading.
- **Balconies:** shown to south-facing living rooms at levels 01–05. **Level 06
  has roof terraces instead.**
- Adjacent building: **Tarn House, 8 storeys, shown on K-07 approximately 14 m
  to the south-west.**

---

## §5 — Outline specification extracts, K-05 rev 2

§5.1 "External walls: brick outer leaf, 150 mm cavity with 100 mm full fill
mineral wool, 100 mm blockwork inner leaf, 12.5 mm plasterboard on dabs."
§5.2 "Roof: warm deck, insulation thickness **TBC**."
§5.3 "Glazing: double glazed units, **g-value TBC**."
§5.4 "Ventilation: **MVHR to all units**."
§5.5 "Heating: communal system, **heat interface units within each apartment
hallway cupboard**."
§5.6 "Communal heating distribution: **risers within the central core, with
lateral runs in the corridor ceiling void**."

---

## §6 — Noise survey extracts, K-06

§6.1 "Measurements taken at the site boundary, 11–13 November 2025."
§6.2 "Daytime L~Aeq,16h~ 61 dB at the south boundary, 54 dB at the north
boundary."
§6.3 "Night-time L~Aeq,8h~ 55 dB at the south boundary, 48 dB at the north
boundary."
§6.4 "The dominant source is the A-road to the south."
§6.5 "**Internal noise levels in habitable rooms should be assessed assuming
windows closed** on the south facade. Mitigation may be required."
§6.6 "No assessment of air quality has been undertaken."

---

## §7 — What the architect has asked for

1. "Get the pack together for the thermal modeller."
2. "Which flats are we worried about?"
3. "The level 06 flats are single aspect south with big sliding doors — will
   they overheat?"
4. "The noise consultant says windows closed on the south. Does that break our
   ventilation strategy?"
5. "How much will the assessment cost?"
