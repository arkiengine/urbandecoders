# Kiln Row — overheating assessment evidence pack

**Prepared:** 27 February 2026 · **Stage 3** · For the thermal modeller's
appointment.

> **This pack contains no results, no criteria and no predictions.** It is the
> geometry, the constraints and the decisions a modeller needs so that their
> first run is the real one. It does not say whether anything will overheat.

---

## §1 — Basis

| Item | Status |
|---|---|
| **Assessment methodology** | **`[not stated]`** — not named by the architect |
| **Regulatory driver** | **`[not stated]`** — not named |
| Building type / tenure | Residential apartments, tenure `[not stated]` |
| Stage | 3 |
| Plans K-01 | rev D |
| **Elevations K-02** | **rev C — one revision behind the plans** |
| Sections K-03 | rev D |
| Window schedule K-04 | rev B |
| Specification K-05 | rev 2 |
| Noise survey K-06 | Nov 2025 |

**No criterion, threshold, temperature limit or weather dataset appears
anywhere in this pack**, because the methodology that defines them has not been
stated. Naming it is the first action in §9.

**K-02 is one revision behind K-01.** All shading and elevation geometry below
is taken from a superseded-risk drawing and must be re-checked against rev D.

---

## §2 — Room schedule

38 units. Aspect and storey recorded as facts, **not as risk judgements**.

| Level | Units | Aspect | Terrace / balcony | Notes |
|---|---|---|---|---|
| 00 | 2 | Single-aspect **north** | — | — |
| 00 | 2 | Dual | — | — |
| 01–05 | 15 (3/level) | **Single-aspect south** | Balcony | Brise-soleil over living window |
| 01–05 | 5 (1/level) | Single-aspect north | — | — |
| 01–05 | 10 (2/level) | Dual | — | — |
| **06** | **4** | **Single-aspect south** | **Roof terrace** | **Top floor. No balcony above. Brise-soleil per K-02** |

**Each unit:** open-plan living/kitchen/dining, 1–2 bedrooms, bathroom.
Room-by-room areas are not stated on K-01 and are **`[not stated]`** — the
modeller will need them (G-09).

**Population for sampling:** the modeller selects a sample; the facts that bear
on selection are that 19 of 38 units are single-aspect south, 4 of those are
top-floor with roof terraces and no balcony above, and 6 are single-aspect
north.

---

## §3 — Glazing and opening schedule

**The openable area is the critical input and it is largely unresolved.**

| Type | Location | Overall | **Openable as drawn** | Restrictor | Guarding | Tag |
|---|---|---|---|---|---|---|
| **WA** | Living, south (levels 00–05) | 2400 × 1800 | **Top-hung vent 2400 × 300 at head, over a fixed light** | **`[decision needed]`** — K-04 says "restrictors to be confirmed" | `[not stated]` | `[as drawn]` |
| WB | Living, north | 1800 × 1500 | Side-hung casement, full opening | `[decision needed]` | `[not stated]` | `[as drawn]` |
| WC | Bedroom, all | 1500 × 1200 | Side-hung casement, full opening | `[decision needed]` | `[not stated]` | `[as drawn]` |
| WD | Bathroom | 600 × 600 | Top-hung, obscured | `[decision needed]` | — | `[as drawn]` |
| **WE** | **Level 06 living** | **2700 × 3600** | **Sliding door, two leaves, one sliding — so the openable leaf is approximately half the width** | **`[decision needed]`** | `[not stated]` | `[as drawn]` |

**O-01 — WA is a 300 mm vent, not a 2400 × 1800 window.** The living room
window to every south-facing unit at levels 00–05 is a **fixed light with a
top-hung vent 2400 × 300 at the head**. The glazed area is large; the openable
area is the vent. **A modeller given "2400 × 1800 window" will model something
that does not exist.** This is recorded explicitly because it is the single
most common input error in this type of assessment.

**O-02 — WE's openable area is half its width.** A 3600 mm wide sliding door
with two leaves, one sliding, opens approximately 1800 mm. **Not 3600.**

**O-03 — No restrictor is confirmed anywhere.** K-04 says "restrictors to be
confirmed". Free area cannot be established for any window until it is. This
interacts with guarding, which is `[not stated]` throughout — and the level 06
units open onto terraces while levels 01–05 open onto balconies, which are
different conditions.

**No free-area percentage, restrictor dimension or guarding height is stated
in this pack.** Each is `[to verify]` against a named document the modeller or
the architect supplies.

---

## §4 — Shading

| Element | Where | Resolved? | Tag |
|---|---|---|---|
| **Brise-soleil** | South elevation, living windows, levels 01–06 | **NO — shown in elevation only. Depth not dimensioned. No section through it on K-03** | **`[not resolved]`** |
| Balconies | South, levels 01–05 | Shown in plan and elevation; depth `[to verify]` from K-01 rev D | `[as drawn]` |
| **Level 06 — no balcony above** | South, level 06 | Levels 01–05 are shaded from above by the balcony of the unit above. **Level 06 has nothing above it** | `[as drawn]` |
| Roof terraces | Level 06 | Shown; no overhead structure indicated | `[as drawn]` |
| **Tarn House, 8 storeys** | ~14 m to the south-west (K-07) | Position and height from K-07; **not surveyed** | `[to verify]` |

**S-01 — The brise-soleil cannot be modelled.** It is the principal shading
device on the elevation that matters most, and **nothing establishes its depth,
projection, blade angle, spacing or extent in section.** A modeller will either
ask, or assume — and an assumed depth produces a result the detail later
contradicts.

**S-02 — Level 06 is shaded differently from levels 01–05 and this is
geometric, not a judgement.** Units at 01–05 have the balcony of the unit above
projecting over their living window. Level 06 has nothing above it. The pack
records the difference; whether it matters is the modeller's.

---

## §5 — Ventilation strategy and routes

**Stated strategy:** MVHR to all units (K-05 §5.4).

**V-01 — Cross-ventilation is not available to 25 of 38 units.** 19 units are
single-aspect south and 6 single-aspect north (§2). A single-aspect unit has
one facade and cannot cross-ventilate. **13 dual-aspect units could, subject to
internal layout, which K-01 does not establish.**

**V-02 — Any purge route through the corridor crosses the fire strategy.**
The corridor is **central, single, serving all units**, and the unit entrance
doors are **FD30S on K-01**. A ventilation strategy that relies on opening a
unit door to a protected corridor will not survive the fire strategy. **No fire
strategy was supplied.** This is recorded as a question for the fire engineer,
not as a determination.

**V-03 — Heat gains from the communal heating system are inside the
assessed spaces and the corridor.** K-05 §5.5 places **heat interface units in
each apartment hallway cupboard**, and §5.6 puts **lateral distribution runs in
the corridor ceiling void** off risers in the core. Distribution losses from
communal heating are a recognised gain in apartment overheating assessment.
**The pack records their location; it states no figure** — pipework insulation
and operating temperatures are a services input (G-11).

---

## §6 — External constraint register

**The constraint that most often invalidates an overheating study is whether
the windows can actually be opened.**

| # | Constraint | Source | Restricts opening? | Decided? |
|---|---|---|---|---|
| **C-01** | **Noise: daytime 61 dB and night-time 55 dB at the south boundary; dominant source the A-road to the south** | K-06 §6.2, §6.3, §6.4 | **The survey itself states habitable rooms "should be assessed assuming windows closed on the south facade"** (§6.5) | **NO — `[decision needed]`** |
| C-02 | Noise, north boundary: 54 dB day, 48 dB night | K-06 §6.2, §6.3 | `[to verify]` | No |
| **C-03** | **Air quality** | **K-06 §6.6: "No assessment of air quality has been undertaken"** | Unknown | **`[not stated]` — no assessment exists** |
| C-04 | Security / guarding at height | — | `[to verify]` | **No — guarding is `[not stated]` throughout** |
| C-05 | Restrictors | K-04 | Yes, necessarily | **`[decision needed]` — "to be confirmed"** |
| C-06 | Privacy / overlooking to Tarn House at ~14 m | K-07 | `[to verify]` | No |

**C-01 is the central issue in this pack.** The noise survey recommends
assessing the south facade **windows closed**. Nineteen of thirty-eight units
are single-aspect south. If the south windows are modelled closed, those units
have **no openable ventilation at all** beyond MVHR.

**That is not a prediction — it is what the two documents say when read
together.** Whether it is resolved by acoustic glazing, acoustic vents, a
different window type, mechanical cooling or a layout change is a design
decision, and this pack does not propose one.

---

## §7 — Fabric and gains

**Fabric as specified (K-05 rev 2)**

| Element | As specified | Gap |
|---|---|---|
| External wall | Brick / 150 cavity, 100 full fill mineral wool / 100 blockwork / 12.5 plasterboard on dabs | — |
| Roof | Warm deck | **Insulation thickness TBC** (§5.2) |
| **Glazing** | Double glazed units | **g-value TBC (§5.3) — the single most important fabric input for solar gain** |
| Ventilation | MVHR | Flow rates `[not stated]` |
| Heating | Communal, HIU in hallway cupboard | §5.5 |

**Occupancy and internal gains — assumptions to be agreed, not values**

| # | Input | Status |
|---|---|---|
| A-01 | Occupancy profile and density | **To be proposed by the modeller, agreed by the client. No value stated here** |
| A-02 | Equipment gains | As above |
| A-03 | Lighting gains | As above |
| A-04 | Hot water distribution losses | As above |
| A-05 | **Communal heating distribution losses through the HIU cupboard and corridor void** | As above — see V-03 |
| A-06 | Window opening behaviour | As above, and dependent on C-01 |

**No occupancy, gain or flow rate figure is stated in this pack.** The modeller
proposes, the client agrees, and this pack records who decided what.

---

## §8 — Gaps and decisions

| # | Needed | From whom |
|---|---|---|
| G-01 | **Assessment methodology and regulatory driver** | Architect / client |
| G-02 | **Brise-soleil section: depth, projection, blade angle, spacing, extent** | Architect |
| G-03 | **Glazing g-value** (K-05 §5.3 TBC) | Architect / specifier |
| G-04 | **Restrictor specification and guarding requirement for every window type** | Architect, with the fire and access leads |
| G-05 | **Decision on C-01: can the south windows be opened, and when?** | Client, architect, acoustic consultant |
| G-06 | **Air quality assessment** — none exists (C-03) | Client |
| G-07 | **Fire strategy**, to resolve V-02 | Fire engineer |
| G-08 | **K-02 re-issued at rev D** to match the plans | Architect |
| G-09 | Room-by-room areas and dimensions | Architect |
| G-10 | MVHR flow rates and control strategy | Services engineer |
| G-11 | **Communal heating pipework insulation and operating temperatures** | Services engineer |
| G-12 | Balcony soffit depths at levels 01–05, from K-01 rev D | Architect |
| G-13 | Surveyed height and position of Tarn House | Architect / surveyor |
| G-14 | Roof insulation thickness (K-05 §5.2 TBC) | Architect |

**First actions, in order:** G-01, then G-05 (with G-06), then G-02, then G-04.
The rest can follow.

---

## §9 — The specific questions asked

**§7.2 — "Which flats are we worried about?"** This pack does not identify
units at risk, because that is the assessment's output. It records the facts
that bear on sampling: 19 single-aspect south, of which 4 are top-floor with no
balcony above; 6 single-aspect north; 13 dual-aspect.

**§7.3 — "The level 06 flats are single aspect south with big sliding doors —
will they overheat?"** **Not answered, and deliberately not estimated.** Three
factual points, all geometric:
- The WE sliding door's **openable** area is approximately half its 3600 mm
  width, not the full width (O-02).
- Level 06 has **no balcony above** to shade it, unlike levels 01–05 (S-02).
- The brise-soleil over those windows is **unresolved** (S-01).
Those are inputs, not an answer. "Big sliding doors" in particular is the kind
of description that leads to the wrong openable area being modelled.

**§7.4 — "Does the noise constraint break our ventilation strategy?"** This
pack does not determine that. What the documents say, read together: the noise
survey recommends assessing the south facade windows closed (K-06 §6.5), and
19 of 38 units are single-aspect south. **The implication is visible and the
decision is G-05** — a decision for the client, the architect and the acoustic
consultant, before the model runs rather than after.

**§7.5 — "How much will the assessment cost?"** Not estimated. §8 is the list
that makes a modeller's fee accurate rather than provisional; send it with the
enquiry.

---

## §10 — Shape of this pack

**38 units. 5 window types.**

**Openings: 5 of 5 types have `[decision needed]` restrictors. 2 types have an
openable area materially smaller than their overall size (WA, WE).**

**Shading: 1 of 5 elements `[not resolved]` — and it is the principal device on
the critical elevation.**

**Constraints: 6 registered, 2 `[decision needed]`, 1 with no assessment in
existence at all.**

**14 gaps.**

**The single thing most likely to force a re-run** is C-01 / G-05: whether the
south-facing windows can be opened, and when. Nineteen of thirty-eight units
depend on the answer, and it is not a thermal question.
