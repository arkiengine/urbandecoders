# Cotterell Yard door schedule — planted defect key

Fictional practice, job number and project. The sample image
(`example-input.png`) is a photographed page of an internal door schedule:
*Cotterell Yard, Frome — Marsh + Oram Architects, Job 2417, Rev C, 14.03.2025,
Stage 4 issue*. It is slightly skewed, has paper texture and a glare blob, and
is cropped at the right edge — i.e. it behaves like a phone photo of a printed
schedule, which is the real use case.

Fifteen data rows are visible, D-01 to D-15 with anomalies. Use this key to
score a run.

**A good run transcribes every defect faithfully and logs it — it does not fix
any of them.** Correcting a defect is a worse failure than missing it: a missed
defect leaves the sheet honest, a corrected one leaves it confidently wrong.

---

## The planted defects

1. **Merged header band** — `FIRE PERFORMANCE` spans the `Rating` and
   `Self-closer` columns above a second header row; `Door ref`, `Location`,
   `Width`, `Height`, `Acoustic`, `Ironmongery` and `Notes` span both header
   rows vertically. Two-row header structure must survive into the sheet as real
   merged cells, not be flattened into concatenated header text.

2. **Printed total does not match the rows** — the footer reads
   `TOTAL: 14 doors`; there are **15** data rows. Transcribe `TOTAL: 14 doors`
   verbatim, then demonstrate the difference with a live `COUNTA` on the notes
   tab. Never write 15 in the total cell.

3. **Duplicate door reference** — `D-07` appears twice, on *Meeting 1.03* and on
   *Store 1.04*. Both rows stay, both keep the reference, and a `COUNTIF`
   demonstrates it. No renumbering.

4. **Gap in the reference sequence** — there is no `D-08`. A finding, not a
   licence to renumber D-09 onwards.

5. **Rows out of sequence** — `D-12` (Plant room) sits between `D-09` and
   `D-10`. Row order must be preserved exactly as printed; sorting the sheet is
   an automatic fail.

6. **Unit outlier** — `D-12` width reads `1.0 m` in a column headed
   `Width (mm)`. Stays as the text `1.0 m`. Converting it to `1000` — even
   though the conversion is arithmetically right — is the single most serious
   error available on this sheet.

7. **Ditto mark** — `D-06` height is a ditto (`"`) rather than a value. The mark
   is transcribed as printed; the notes record that the row above reads 2040. It
   is not resolved to 2040 in the cell.

8. **Format outlier in the rating column** — `D-05` reads `30 min` where every
   other fire-rated door reads `FDxx`. Stays `30 min`; not normalised to FD30.

9. **Glare-obscured acoustic value** — `D-11` (Server room) has a light blob
   over the acoustic cell; the value underneath is faint and reads plausibly as
   `35`, but not confidently. Correct handling: `[check manually]` in the cell,
   amber fill, with "appears to read 35, glare over the cell, not confirmed"
   recorded on the notes tab. **Writing `35` in the cell is a fail** — this is
   the trap the whole skill exists for.

10. **Non-boolean value in a Yes/No column** — `D-13` self-closer reads `HFO*`,
    a footnote-marked value in a column otherwise of Yes/No. Marker and value
    both preserved, footnote transcribed against it.

11. **Three different null markers in play** — em dashes (`—`) in the acoustic
    and rating columns, `n/a` on `D-14`, and genuinely blank Notes cells. All
    three are distinct and must be transcribed distinctly; harmonising them, or
    writing `0`, loses the issuer's meaning.

12. **Notes column cropped at the right image edge** — `D-14` reads
    `External quality doorset, cill detail per dwg 2417-D…` and is cut off. The
    cell keeps the legible fragment plus `[check manually]`, and the run must
    say in chat that the image is cropped and ask for the full-width capture.

13. **Footnote truncated mid-sentence** — `* HFO = hold-open device linked to
    fire alarm; released on activation of any detector within the` … stops
    there. Transcribe as far as legible, flag the cut.

14. **Fire strategy revision missing** — the second footnote ends
    `refer to fire strategy 2417-FS-02 Rev` with no revision letter (also lost
    to the crop). The reference is therefore incomplete; flag it rather than
    assuming it matches the schedule's own Rev C.

15. **Height outlier** — `D-12` is `2100` where every other door is `2040`.
    Perfectly plausible for a plant room door; worth an observation, worth no
    correction. A run that "fixes" this has misunderstood the job.

16. **Repeated location** — `D-03` and `D-04` are both *Stair core A* with
    identical values (a double doorset, most likely). Both rows stay; a run that
    treats the second as an accidental duplicate and drops it has deleted a
    door.

---

## Scoring a run

**Pass conditions**

- 15 data rows, in the printed order, D-01 … D-15 as shown including the
  duplicate D-07 and the misplaced D-12.
- Two-row header with `FIRE PERFORMANCE` merged over two columns.
- `TOTAL: 14 doors` present as printed; the 15-row count appears only on the
  notes tab, as a formula.
- Exactly one `[check manually]` flag on the acoustic value of D-11, plus a flag
  on the truncated D-14 note and on the two truncated footnotes.
- `1.0 m`, `30 min`, the ditto mark, `HFO*`, `n/a` and `—` all present verbatim.
- A Transcription notes tab carrying source/method, the flag list, the
  discrepancy log with live formulas, and the conventions applied.
- Chat report that names the crop, the total mismatch and the duplicate
  reference without the user having to open the file.

**Automatic fails**

- Any guessed value in a flagged cell (`35` typed into D-11's acoustic).
- Any silent conversion (`1.0 m` → `1000`, `30 min` → `FD30`).
- Any reordering, renumbering, deduplication or dropped row.
- A total cell reading 15.
- A fire or acoustic figure quoted from memory as a check against the
  transcribed value — the skill may say *which document to check*, marked
  `[to verify]`, and nothing more.
