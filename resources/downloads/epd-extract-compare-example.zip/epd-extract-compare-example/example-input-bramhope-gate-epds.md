# Bramhope Gate — insulation EPDs for comparison

**Project:** Bramhope Gate, Marlden
**Instruction:** "Compare these three. The Thermacore rep says theirs is the
lowest carbon by a mile and we need to decide the spec this week."

*Fictional products, manufacturers and programme operators. Deliberately
imperfect. Figures as printed on each declaration.*

---

## §1 — EPD A — "Thermacore PIR-X"

| Field | As printed |
|---|---|
| Programme operator | Northfield EPD Programme |
| EPD registration no. | NFE-2021-0418 |
| Standard | EN 15804+A1 |
| PCR | PCR 2019:14 Thermal insulation |
| Manufacturer | Thermacore Insulation Ltd |
| EPD type | **Product-specific** |
| Publication date | 14 June 2021 |
| **Validity** | **14 June 2021 to 14 June 2026** |
| **Declared unit** | **1 m² of insulation with a thermal resistance R = 1 m²K/W** |
| Modules declared | **A1–A3 only** |
| Reference service life | Not declared |
| Geographical scope | UK |

**Declared impacts, per declared unit:**

| Indicator | A1–A3 | A4 | A5 | C3 | C4 | D |
|---|---|---|---|---|---|---|
| GWP (kg CO₂ eq) | **1.24** | ND | ND | ND | ND | ND |
| ODP | 2.1E-08 | ND | ND | ND | ND | ND |

*"ND = not declared."*

---

## §2 — EPD B — "Rockfell Slab 100"

| Field | As printed |
|---|---|
| Programme operator | Caldermoor Environdec |
| EPD registration no. | CME-2024-1177 |
| Standard | **EN 15804+A2** |
| PCR | **PCR 2022:03 Mineral wool products** |
| Manufacturer | Rockfell Mineral Products |
| EPD type | **Product-specific** |
| Publication date | 3 September 2024 |
| **Validity** | **3 September 2024 to 3 September 2029** |
| **Declared unit** | **1 m² of product at 100 mm thickness** |
| Modules declared | **A1–A3, A4, A5, C1–C4, D** |
| Reference service life | **60 years** |
| Geographical scope | Europe |

**Declared impacts, per declared unit:**

| Indicator | A1–A3 | A4 | A5 | C1 | C2 | C3 | C4 | D |
|---|---|---|---|---|---|---|---|---|
| GWP-total (kg CO₂ eq) | **4.86** | 0.21 | 0.14 | 0.00 | 0.09 | 0.00 | 0.07 | **−0.62** |
| GWP-fossil | 4.84 | 0.21 | 0.14 | 0.00 | 0.09 | 0.00 | 0.07 | −0.62 |
| **GWP-biogenic** | **0.02** | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

---

## §3 — EPD C — "Econafib Wood Fibre Board"

| Field | As printed |
|---|---|
| Programme operator | Caldermoor Environdec |
| EPD registration no. | CME-2023-0904 |
| Standard | **EN 15804+A2** |
| PCR | **PCR 2022:03 Mineral wool products** |
| Manufacturer | Econafib GmbH |
| EPD type | **Industry average (4 participating plants)** |
| Publication date | 11 April 2023 |
| **Validity** | **11 April 2023 to 11 April 2028** |
| **Declared unit** | **1 kg of product** |
| Modules declared | **A1–A3, C1–C4, D** |
| Reference service life | 50 years |
| Geographical scope | Germany, Austria |

**Declared impacts, per declared unit:**

| Indicator | A1–A3 | C1 | C2 | C3 | C4 | D |
|---|---|---|---|---|---|---|
| GWP-total (kg CO₂ eq) | **−0.89** | 0.00 | 0.01 | **1.46** | 0.00 | −0.11 |
| GWP-fossil | 0.71 | 0.00 | 0.01 | 0.04 | 0.00 | −0.11 |
| **GWP-biogenic** | **−1.60** | 0.00 | 0.00 | **1.42** | 0.00 | 0.00 |

*Note on the declaration: "Density 160 kg/m³."*

---

## §4 — Supplier claim (email, 24 February 2026)

> "Our PIR-X is 1.24 kgCO2e against the mineral wool at 4.86 and the wood
> fibre at minus 0.89. We're a quarter of the mineral wool. Happy to send the
> EPDs over — the numbers speak for themselves."
> — Thermacore sales

---

## §5 — What the architect has asked for

1. "Extract the data into a table for the spec."
2. "Which has the lowest embodied carbon?"
3. "Is the Thermacore rep right?"
4. "Are these even comparable?"
