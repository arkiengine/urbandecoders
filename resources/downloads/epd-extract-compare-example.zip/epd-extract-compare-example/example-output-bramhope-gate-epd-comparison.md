# Bramhope Gate — EPD extraction and comparability assessment

**Prepared:** 26 February 2026. **Three EPDs supplied.**

---

## §1 — Comparability verdict — read before any number

| Pair | Verdict | Reason |
|---|---|---|
| **A ↔ B** | **NOT COMPARABLE** | Different declared units (R = 1 m²K/W vs 1 m² at 100 mm); different standard (A1 vs A2); different module scope (A1–A3 vs cradle to grave) |
| **A ↔ C** | **NOT COMPARABLE** | Different declared units (R = 1 m²K/W vs 1 kg); different standard; different module scope; different EPD type (product-specific vs industry average) |
| **B ↔ C** | **NOT COMPARABLE** | Different declared units (1 m² at 100 mm vs 1 kg); different EPD type; different geographical scope; C does not declare A4/A5 |

**No pair in this set can be fairly compared as supplied.**

There is no like-for-like table in this report, because there is nothing to put
in one. §5 states exactly what would be needed to build one.

---

## §2 — Extraction table

All values **as printed**, with the units and precision each declaration uses.

| Field | **A — Thermacore PIR-X** | **B — Rockfell Slab 100** | **C — Econafib Wood Fibre** |
|---|---|---|---|
| Programme operator | Northfield EPD Programme | Caldermoor Environdec | Caldermoor Environdec |
| Registration no. | NFE-2021-0418 | CME-2024-1177 | CME-2023-0904 |
| **Standard** | **EN 15804+A1** | **EN 15804+A2** | **EN 15804+A2** |
| **PCR** | PCR 2019:14 Thermal insulation | PCR 2022:03 Mineral wool products | **PCR 2022:03 Mineral wool products** — see §6 |
| Manufacturer | Thermacore Insulation Ltd | Rockfell Mineral Products | Econafib GmbH |
| **EPD type** | Product-specific | Product-specific | **Industry average (4 plants)** |
| Published | 14 Jun 2021 | 3 Sep 2024 | 11 Apr 2023 |
| **Valid to** | **14 Jun 2026** | 3 Sep 2029 | 11 Apr 2028 |
| **Declared unit** | **1 m² at R = 1 m²K/W** | **1 m² at 100 mm thickness** | **1 kg of product** |
| **Modules declared** | **A1–A3 only** | A1–A3, A4, A5, C1–C4, D | A1–A3, C1–C4, D |
| Reference service life | **`[not declared]`** | 60 years | 50 years |
| Geographical scope | UK | Europe | Germany, Austria |
| Density | `[not declared]` | `[not declared]` | 160 kg/m³ |

### GWP as printed

| Module | **A** | **B** | **C** |
|---|---|---|---|
| A1–A3 | **1.24** | **4.86** (GWP-total) | **−0.89** (GWP-total) |
| — of which fossil | `[not declared]` | 4.84 | 0.71 |
| — of which biogenic | `[not declared]` | 0.02 | **−1.60** |
| A4 | `[not declared]` | 0.21 | **`[not declared]`** |
| A5 | `[not declared]` | 0.14 | **`[not declared]`** |
| C1 | `[not declared]` | 0.00 | 0.00 |
| C2 | `[not declared]` | 0.09 | 0.01 |
| C3 | `[not declared]` | 0.00 | **1.46** (of which biogenic **1.42**) |
| C4 | `[not declared]` | 0.07 | 0.00 |
| D | `[not declared]` | −0.62 | −0.11 |

**`[not declared]` is not zero.** A declares A1–A3 only; its blanks are modules
nobody assessed, not modules with no impact. The same applies to C's A4 and A5.

**No module sums appear in this table.** B and C both present modules
separately and neither presents a cradle-to-grave total, so none is computed
here.

**Biogenic carbon is kept separate throughout**, because B and C both separate
it. Merging it into GWP changes the answer materially — see §4.

---

## §3 — Validity

| EPD | Status |
|---|---|
| A — Thermacore PIR-X | **Valid, expires 14 June 2026 — under four months away.** Published 2021 |
| B — Rockfell Slab 100 | Valid to 3 September 2029 |
| C — Econafib | Valid to 11 April 2028 |

**A expires within the likely construction period of this project.** If it is
specified on the strength of this declaration, the declaration will lapse
before the product is installed, and a renewed EPD may carry different figures.

---

## §4 — Why these numbers cannot be put side by side

**The declared units are three different quantities.**

- **A: 1 m² at R = 1 m²K/W.** A *performance-normalised* unit. The physical
  thickness of PIR-X delivering R = 1 is not stated on the declaration.
- **B: 1 m² at 100 mm.** A *thickness* unit. What R-value 100 mm of Rockfell
  delivers is not stated on the declaration.
- **C: 1 kg.** A *mass* unit. Converting it to either of the above needs the
  thickness and the density — the density is given (160 kg/m³), the thickness
  is not.

**A's value is per unit of thermal performance; B's is per unit of thickness;
C's is per unit of mass. Comparing 1.24, 4.86 and −0.89 compares three
different things.**

**The module scopes are also three different things.** A declares A1–A3 only.
B declares cradle to grave plus D. C declares A1–A3 and C1–C4 plus D, with no
A4 or A5. Setting A's 1.24 against B's 4.86 sets a product stage against a
product stage — but only if you read the table correctly, and B's cradle-to-
grave story includes a **+0.51 across A4, A5 and C**, and a **−0.62 in D**.

**C's headline is a biogenic artefact.** C's A1–A3 GWP-total of **−0.89** is
composed of **+0.71 fossil and −1.60 biogenic**. At end of life, **C3 carries
+1.46, of which +1.42 is biogenic** — the stored carbon returning. A comparison
that quotes C's −0.89 and stops has quoted half a cycle.

**And they are on different standards.** A is EN 15804+A1; B and C are +A2. The
indicator sets and the calculation rules differ between them, which is why
A reports "GWP" and B and C report "GWP-total / fossil / biogenic".

**C is an industry average of four plants.** It does not describe the product
that would be delivered to site.

---

## §5 — What would be needed to compare them

**This report does not normalise.** Normalising needs product data that is a
specification decision, not an arithmetic one. To build a like-for-like
comparison, supply:

| # | Required | For |
|---|---|---|
| N-01 | **The specified thickness of each product** in the actual build-up | All three |
| N-02 | **The thermal conductivity (λ) of each**, so thickness and R-value can be related | All three |
| N-03 | The physical thickness of PIR-X delivering R = 1 m²K/W | A |
| N-04 | The R-value delivered by 100 mm of Rockfell | B |
| N-05 | Density of A and B | A, B |
| N-06 | **An agreed functional unit** — most usefully 1 m² of build-up at the specified R-value | All three |
| N-07 | **An agreed module scope.** A cannot go beyond A1–A3 as declared | All three |
| N-08 | **An agreed reference service life.** A declares none; B says 60 years; C says 50 | All three |
| N-09 | **Treatment of biogenic carbon** — reported separately or included | B, C |

**With N-01, N-02 and N-06 settled, the arithmetic can be run and the inputs
attributed to whoever supplied them.** Until then there is no fair comparison
to make.

---

## §6 — Caveats for the specification

| # | Caveat |
|---|---|
| CV-01 | **C is an industry average of four plants.** It does not describe the product delivered. |
| CV-02 | **A expires 14 June 2026.** See §3. |
| CV-03 | **A declares A1–A3 only.** Its construction, use and end-of-life impacts are unassessed, not zero. |
| CV-04 | **C declares no A4 or A5.** Transport from Germany/Austria is unassessed. |
| CV-05 | **C's PCR is "Mineral wool products"** while the product is wood fibre. That is what the declaration states. **`[to verify]`** with the programme operator — this report records the discrepancy and does not interpret it. |
| CV-06 | **A and B/C are on different versions of the standard.** |
| CV-07 | Geographical scopes differ: UK, Europe, Germany/Austria. |
| CV-08 | **These are product declarations, not building results.** For a building-level answer the assessor needs the build-ups, not the headline figures. |
| CV-09 | None of these declarations addresses fire performance, moisture behaviour, durability, buildability, availability or cost — all of which bear on an insulation choice. |

---

## §7 — The specific questions asked

**§5.2 — "Which has the lowest embodied carbon?"**

**Not answered.** No pair in this set is comparable (§1), so there is no
ranking to give. Even if there were, this skill does not declare a winner:
insulation is selected on thermal performance, fire behaviour, moisture
tolerance, compressive strength, availability, buildability and cost as well
as carbon, and none of those is in an EPD.

**§5.3 — "Is the Thermacore rep right?"**

The supplier's email (§4) sets **1.24 against 4.86 and −0.89** and concludes
"we're a quarter of the mineral wool".

Those three figures are quoted accurately from the three declarations. **The
comparison drawn from them is not valid**, for four reasons, each independently
sufficient:

1. **Different declared units** — per R = 1 m²K/W, per 100 mm, per kg (§4).
2. **Different module scopes** — A1–A3 against cradle to grave against
   A1–A3 + C + D.
3. **Different standard versions** — +A1 against +A2.
4. **The −0.89 is a biogenic figure** whose +1.42 counterpart appears at C3.

Whether PIR-X is in fact lower than the alternatives **in this build-up** is a
real question, and §5 lists what would settle it. On the material supplied, the
claim is not demonstrated.

**§5.4 — "Are these even comparable?"** No. See §1.

---

## §8 — Shape of this extraction

**3 EPDs. 0 comparable pairs. 0 expired, 1 expiring within four months.**

**Three different declared units, three different module scopes, two standard
versions, two programme operators, one industry average, and one PCR that does
not obviously match its product.**

**The single reason every pair fails the gate is the declared unit.** Settle
N-01, N-02 and N-06 and the comparison becomes possible.
