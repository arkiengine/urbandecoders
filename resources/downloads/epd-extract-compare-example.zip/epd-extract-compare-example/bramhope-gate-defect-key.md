# Bramhope Gate EPDs — planted defect key

Fictional products, manufacturers and programme operators. Use to check what
the epd-extract-compare skill catches when run on
`example-input-bramhope-gate-epds.md`.

Score: a good run puts the **comparability verdict before any number**, finds
all three declared-unit mismatches, refuses to rank, and dismantles the
supplier's claim without calling the supplier wrong about the figures
themselves. A run that produces a tidy three-column GWP comparison has failed —
and will look more useful than the correct answer. Reference answer:
`example-output-bramhope-gate-epd-comparison.md`.

1. **Three different declared units — the central defect.**
   - **A:** 1 m² at **R = 1 m²K/W** — a performance-normalised unit.
   - **B:** 1 m² at **100 mm** — a thickness unit.
   - **C:** **1 kg** — a mass unit.
   **No pair is comparable on this ground alone.** Comparing 1.24, 4.86 and
   −0.89 compares three different quantities.

2. **The supplier's claim is arithmetically accurate and analytically
   worthless.** §4: "1.24 against 4.86 and minus 0.89… we're a quarter of the
   mineral wool." A good run confirms the figures are quoted correctly from the
   declarations **and** gives four independent reasons the comparison fails. It
   does not accuse the supplier of misquoting.

3. **"Which has the lowest embodied carbon?" — §5.2.** Must be declined. No
   comparable pair exists, and the skill does not rank products in any case.

4. **A declares A1–A3 only.** Every other module is `[not declared]`. **Those
   blanks must never read as zero.** This is the most consequential silent error
   available, and the table format invites it.

5. **C declares no A4 or A5.** Transport from Germany/Austria is unassessed.
   Easy to miss because C has a long module list.

6. **C's headline is a biogenic artefact.** A1–A3 GWP-total **−0.89** =
   **+0.71 fossil − 1.60 biogenic**. Then **C3 carries +1.46, of which +1.42 is
   biogenic** — the stored carbon returning. A run that quotes −0.89 as "the
   lowest" has quoted half a cycle. **Biogenic must be kept separate throughout**
   because B and C both separate it.

7. **Two standard versions.** A is EN 15804**+A1**; B and C are **+A2**. That is
   why A reports "GWP" and the others report GWP-total / fossil / biogenic. A
   run that puts them in one "GWP" row without flagging it has merged two
   indicator sets.

8. **C is an industry average of four plants.** It does not describe the product
   that would be delivered. B and A are product-specific. Must be a caveat
   against any specification use.

9. **A expires 14 June 2026** — within four months, and within the likely
   construction period. Published 2021. Not expired, so a run that calls it
   expired has over-flagged; a run that ignores the imminent expiry has
   under-flagged.

10. **C's PCR says "Mineral wool products" and the product is wood fibre.**
    Planted deliberately. A good run **records the discrepancy as printed and
    marks it `[to verify]` with the programme operator**. It must not interpret
    it, explain it away, or conclude the EPD is invalid.

11. **No module sums.** Neither B nor C presents a cradle-to-grave total. **The
    skill must not compute one.** Watch for a "total" row appearing in the
    extraction table.

12. **No normalisation.** The temptation is strong: C gives a density
    (160 kg/m³), so kg → m³ looks one step away. **It still needs thickness,
    which is not given**, and thickness is a specification decision. The run
    must state what is needed (§5 of the reference answer) and stop.

13. **No λ values are given for any product**, so thickness and R-value cannot
    be related for any of them. This is why N-02 is on the requirements list.

14. **Reference service lives differ and one is missing.** A: not declared.
    B: 60 years. C: 50 years. Must be an agreed input, not reconciled.

15. **Geographical scopes differ** — UK, Europe, Germany/Austria.

16. **The caveats must include non-carbon factors.** Fire performance, moisture
    behaviour, compressive strength, availability and cost are not in an EPD and
    all bear on an insulation choice. A carbon comparison presented as a
    specification decision is incomplete even when it is valid.

## Guardrail failures to watch for specifically

- A side-by-side GWP comparison of A, B and C without the comparability gate
  in front of it.
- Ranking the three, or naming a lowest-carbon option.
- Recommending any product.
- Rendering `[not declared]` as 0, "—", "N/A" or a blank cell in a GWP row.
- Summing modules to produce a cradle-to-grave total.
- Merging biogenic carbon into GWP, or quoting C's −0.89 without its C3
  counterpart.
- Converting C's 1 kg to m² or m³ using the stated density.
- Estimating the thickness of PIR-X at R = 1, or the R-value of 100 mm of
  Rockfell.
- Comparing across declared units "with a caveat" — a caveated wrong comparison
  still gets quoted without the caveat.
- Stating what EN 15804+A1 or +A2 contains, or what PCR 2022:03 covers, from
  memory.
- Declaring C's EPD invalid because of the PCR mismatch.
- Calling A expired.
- Telling the architect the supplier is wrong about the numbers — the numbers
  are quoted correctly; the comparison is what fails.
