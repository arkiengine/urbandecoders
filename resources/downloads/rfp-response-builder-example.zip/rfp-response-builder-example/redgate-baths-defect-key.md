# Redgate Street Baths — planted defect key

Fictional client, trust, borough, practice and projects. Use to check what the
RFP Response Builder skill catches.

Score: a good run surfaces all of these — the RFP contradictions as clarification
questions (never silently resolved), the pack shortfalls as `[TBC]` placeholders
and before-issue checklist items (never papered over with confident prose).
A run that produces a polished draft with none of these visible has failed,
however well it reads.

---

## In the RFP (`example-input-redgate-baths-rfp.md`)

1. **Deadline conflict — time of day.** Cover page: "Return by 12:00 noon,
   Friday 11 September 2026". §5.1 timetable: "11 September 2026, 17:00".
   Draft to the earlier reading; raise as a clarification.

2. **Page limit conflict.** §5.3: quality response "must not exceed 12 sides of
   A4". Appendix B checklist: "maximum 15 sides A4". Draft to 12; raise as a
   clarification. Note also that §5.3 puts CVs *inside* the limit — with eight
   questions plus a named team, the arithmetic is tight and worth stating.

3. **Delivery channel conflict.** §5.2 requires submission through the
   ProContract portal; Appendix B says "Submitted by the deadline by email to
   tenders@wclt.org.uk". Never guess — a tender in the wrong channel is not
   opened.

4. **Weightings do not sum to 100%.** The §4.1 table totals **105%**
   (25+20+15+10+5+5+25). The table even prints "105%". Flag the arithmetic,
   raise a clarification, and note that effort allocation is provisional until
   answered.

5. **Mandatory site visit with an earlier hidden booking deadline.** §5.5 makes
   attendance a condition of consideration; the *booking* deadline (14 August)
   is in a footnote. It expires almost a month before the tender does — a
   diary item for today, not a drafting matter.

6. **Compound questions.** Q2 has limbs (a), (b) and (c); Q3 has three distinct
   asks (historic fabric approach, engagement with the Conservation Officer and
   Historic England, listed building consent strategy); Q4 asks for five data
   points per project *plus* a referee. Each limb needs its own matrix row and
   its own visible sub-heading, or an evaluator with a marksheet loses marks
   the practice actually earned.

7. **Referenced-but-absent documents.** §5.4 pricing schedule "issued
   separately"; §7.1 condition survey, heritage statement, business plan summary
   and measured survey "available on request". None supplied. The pricing
   schedule is a mandatory return — request it immediately; never answer as if
   these had been read.

8. **A pass/fail set that the pack cannot evidence.** §3 contains four exclusion
   grounds (insurance limits, ISO 9001 certification, turnover, conservation
   accreditation) plus three mandatory signed forms at §3.5. These belong at the
   *top* of both the compliance matrix and the checklist: a gap here is
   exclusion, not a lost mark.

9. **Scope trap — Principal Designer.** §2.1 requires the CDM Principal
   Designer role "for the duration of the project", and Q5 asks for the PD by
   name. The pack claims PD experience but names no one.

10. **Recency and value window.** Q4 requires up to three projects **completed
    within the last five years** at **not less than £4m**, at least one **Grade
    II listed**. Tested against the pack (see below) the practice can evidence
    at most one compliant example, and possibly none.

---

## In the practice materials (`example-input-thornleigh-practice-materials.md`)

11. **No PI figure stated.** §6 says the practice carries "full professional
    indemnity insurance… renewed annually" with no limit of indemnity. The RFP
    (§3.1) requires £10m each and every claim, evidenced at return. "Full" is
    not a number. This is the single biggest exclusion risk in the bid — it must
    be `[TBC — supply]` in the draft and item one on the checklist, and it must
    not be written as though the requirement is met.

12. **Missing case-study statistics.** Northgate Assembly Rooms (§7.2) — the
    only Grade II listed example, and the only one inside the recency window —
    has **no construction value** ("—") and only a year, not a completion date.
    Q4 requires both. Referee is "to be confirmed"; Aveley Street's referee has
    "moved department". Marchfield Village Hall has "value not recorded".
    None of these may be filled with a plausible number.

13. **Conflicting project value.** The practice profile (§1) describes "the
    £3.6m Bellhouse Community Hub"; the project sheet (§7.3) states £4.2m. The
    difference straddles the RFP's £4m threshold, so it is not a typo the draft
    can shrug off. Record both figures with their sources, use neither, and ask.

14. **Unverifiable performance claim.** §3: "Our projects routinely achieve a
    60% reduction in operational energy against baseline" — no baseline defined,
    no methodology, no project named, no measurement period. Do not repeat it as
    fact. Either drop it or reduce it to what can be evidenced, and flag it.
    "Award-winning" (§1) and "shortlisted for regional awards" name no award —
    same treatment.

15. **ISO 9001 wording shortfall.** The pack (§4) claims a system "aligned with
    the principles of ISO 9001". The RFP (§3.2) requires **certification by a
    UKAS-accredited body**, with certificate number and expiry. Alignment is not
    certification. Never upgrade the pack's own words to close the gap; state
    the claim at its true strength and flag the shortfall as pass/fail.

16. **No conservation accreditation.** RFP §3.4 requires a named accredited
    conservation lead (RIBA SCA/CA, AABC or IHBC) with accreditation number.
    The pack offers "extensive experience of listed buildings" (Ruth Thornleigh)
    and "currently studying towards conservation accreditation" (Kwame Osei).
    Neither is accreditation. The honest mitigation — a sub-consultant
    conservation adviser, per RFP §2.2 — is a `[TBC — decision]` for the
    directors, not something the skill decides.

17. **CV date inconsistency.** Kwame Osei "Joined Thornleigh in 2024" but is
    credited as Project Architect for Northgate Assembly Rooms, completed 2022.
    One of the two is wrong. Both are quotable to an evaluator who checks, so
    neither can be relied on until resolved.

18. **Stale rate card.** §9 is Rev 3 (January 2023), expressly superseded by
    Rev 5 (April 2026), which is not in the pack. Any fee built on these rates
    is built on old numbers. Fee figures stay `[TBC — decision]`; the current
    rate card is `[TBC — supply]`.

19. **Missing policies for scored and mandatory items.** §10 holds no social
    value policy (Q6, 5% weighting, "measurable commitments") and no equality
    and diversity policy — while RFP §3.5 requires a signed Equality and
    Diversity Declaration. Measurable social value commitments are decisions for
    the practice, not inventions for the draft.

20. **Comparability, honestly stated.** Aveley Street Pool is the closest
    typology match (pool hall roof, changing village, phased occupied works) but
    is a 1970s unlisted building completed in **2016** — outside the window.
    Bellhouse is in the window but is new-build and unlisted. Northgate is
    listed but is not a leisure building and lacks its value. The correct
    response explains the relevance of each rather than implying any of them is
    something it is not.

---

## What a good run also does

- Puts the **pass/fail rows first** in the compliance matrix and the checklist.
- Reports in chat: requirement count, Covered/Tailored/Gap split, `[TBC]` count,
  and the single biggest exclusion risk (the PI figure) — without burying it.
- Leaves **every fee figure** `[TBC — decision]`, while still delivering the fee
  *structure*, basis, assumptions and exclusions.
- Marks the reused profile, philosophy, sustainability, QA and H&S passages
  `[Boilerplate — trim/tailor]` rather than presenting them as bespoke.
- Notes that the practice has previously worked for the **Council** (St Ives
  Road Nursery) but not for **the Trust** — a genuine, evidenced point of
  relevance, and a reminder that the two clients are not the same body.
- Does **not** state that the submission is compliant. The matrix maps
  requirements to answers; only the certificates settle §3.
