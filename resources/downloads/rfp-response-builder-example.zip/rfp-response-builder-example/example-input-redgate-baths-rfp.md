# INVITATION TO TENDER — ARCHITECT-LED DESIGN TEAM

**Redgate Street Baths — Restoration and Community Leisure Hub**

Whitcombe Community Leisure Trust (WCLT)
on behalf of the London Borough of Whitcombe

Tender reference: **WCLT/2026/AR-04**
Issued: 3 August 2026
**Return by 12:00 noon, Friday 11 September 2026**

*All fictional. Sample material for the "AI for Architects" course.*

---

## 1. Introduction

1.1 Whitcombe Community Leisure Trust ("the Trust") is a registered charity
established in 2021 to operate leisure and community facilities on behalf of the
London Borough of Whitcombe ("the Council"). The Trust holds a 125-year lease on
Redgate Street Baths from the Council.

1.2 Redgate Street Baths is a Grade II listed municipal baths of 1931, closed to
the public since 2019 following a roof failure over the main pool hall. The
building comprises a 25m pool hall with a barrel-vaulted roof, a former slipper
baths wing, a boiler house, and a single-storey 1970s entrance addition of no
heritage merit.

1.3 The Trust has secured £4.1m from the National Heritage Fund and £2.7m from
the Council's capital programme. **The construction budget is £6.8m excluding
fees, VAT and contingency.** A further £0.4m of match funding is being sought.
The Trust's business plan requires the building to reopen for the 2028/29
swimming season.

1.4 Tenderers should note the Trust is a small organisation with no in-house
technical staff. The successful practice will be expected to lead the design
team and act as the Trust's principal technical adviser.

## 2. Scope of services

2.1 The Trust seeks an architect-led multidisciplinary design team for:

- RIBA Stages 1 to 4 in full;
- RIBA Stage 5 services as described at 2.4 below;
- the role of Principal Designer under CDM 2015 for the duration of the project;
- Lead Designer under the appointment.

2.2 The design team is to include, as sub-consultants to the architect:
structural engineer, building services engineer, quantity surveyor, and
conservation/heritage adviser. Specialist pool water-treatment engineering will
be procured separately by the Trust.

2.3 The scheme comprises: repair and reinstatement of the pool hall roof and
rooflights; restoration of the pool tank and surround; conversion of the slipper
baths wing to a community hall, café and treatment rooms; a new accessible
entrance and changing village replacing the 1970s addition; and full
re-servicing.

2.4 Stage 5 services are limited to: monthly site inspections, review of
contractor design portions, response to site queries, and inspections at
practical completion. The Trust will appoint a separate Contract Administrator.

2.5 Procurement is anticipated to be traditional, single-stage, with a JCT
Standard Building Contract with Quantities. The Trust reserves the right to
change procurement route following Stage 2.

2.6 The building is vacant. However, the adjoining Redgate Street Children's
Centre (Council-operated) will remain in occupation throughout and shares the
site access and the boiler house party wall.

## 3. Eligibility and pass/fail requirements

Tenderers failing any of the following will be excluded without evaluation.

3.1 **Insurance.** Tenderers must hold, and evidence at tender return:
professional indemnity insurance of not less than **£10m each and every claim**;
public liability of not less than £10m; employer's liability of not less than
£10m. A certificate or broker's letter stating the limit of indemnity must be
included as Appendix A to the response.

3.2 **Quality management.** Tenderers must hold current **certification to ISO
9001** by a UKAS-accredited body. Certificate number and expiry date to be
stated.

3.3 **Financial standing.** Annual turnover in each of the last two financial
years must be not less than twice the tendered fee.

3.4 **Conservation capability.** The named Project Lead or a named member of the
core team must hold current conservation accreditation (RIBA Conservation
Architect / Specialist Conservation Architect, or AABC, or IHBC). Accreditation
number to be stated.

3.5 **Mandatory forms.** The Form of Tender (Appendix A of this ITT), the
Non-Collusion Certificate and the Equality and Diversity Declaration must each be
completed and signed by a director or authorised signatory. Unsigned forms
render the tender invalid.

## 4. Evaluation

4.1 Tenders will be evaluated on the following criteria.

| Ref | Criterion | Weighting |
|---|---|---|
| 4.2(a) | Methodology and approach to the project | 25% |
| 4.2(b) | Conservation and heritage approach | 20% |
| 4.2(c) | Relevant experience | 15% |
| 4.2(d) | Team, resource and continuity | 10% |
| 4.2(e) | Social value | 5% |
| 4.2(f) | Programme | 5% |
| 4.3 | Fee | 25% |
| | **Total** | **105%** |

4.2 Quality responses will be scored 0–5 against each criterion. A score of 0 or
1 against any quality criterion may result in the tender being set aside.

4.3 Fee will be scored on the lowest compliant total fixed fee for Stages 1 to 5
as described.

4.4 The Trust may hold interviews with up to three tenderers in the week
commencing 28 September 2026. Interviews will inform but not re-score the
quality evaluation.

## 5. Submission requirements

5.1 **Timetable**

| Event | Date |
|---|---|
| ITT issued | 3 August 2026 |
| Site visit | 19 August 2026, 10:00 |
| Deadline for clarification questions | 21 August 2026, 17:00 |
| Trust responses issued to all tenderers | 28 August 2026 |
| **Tender return** | **11 September 2026, 17:00** |
| Evaluation | w/c 14 September 2026 |
| Interviews (if held) | w/c 28 September 2026 |
| Anticipated appointment | 12 October 2026 |

5.2 Tenders must be submitted through the Council's e-tendering portal
(ProContract), reference WCLT/2026/AR-04. Late submissions will not be opened.
Tenderers are responsible for allowing sufficient time for upload; the portal
closes automatically.

5.3 The quality response must not exceed **12 sides of A4**, minimum 11pt,
excluding the Form of Tender, insurance certificates and the completed pricing
schedule. CVs are limited to one side each and are **included** within the page
limit.

5.4 The pricing schedule is issued separately as a spreadsheet and must be
returned unaltered as a separate upload.

5.5 A site visit will be held on 19 August 2026 at 10:00. **Attendance is
mandatory**; tenders from practices not represented at the visit will not be
considered.[^1]

[^1]: Places must be booked with the Trust by email no later than 14 August 2026.
Two attendees per practice.

## 6. Questions to be answered

Responses must address the following, in this order and under these headings.

**Q1.** Describe your understanding of the project, the site and the Trust's
objectives. (Criterion 4.2(a))

**Q2.** Set out your proposed methodology for Stages 1 to 4, including
(a) how you will develop and test the brief against the £6.8m construction
budget; (b) how you will manage the design team and information flow; and
(c) how you will manage design change and cost risk. (Criterion 4.2(a))

**Q3.** Set out your approach to the historic fabric, including your proposed
strategy for engagement with the Council's Conservation Officer and Historic
England, and your approach to the listed building consent application.
(Criterion 4.2(b))

**Q4.** Provide up to three project examples completed within the last five
years, each of a construction value not less than £4m, of which at least one
must be a Grade II listed building. For each, state the client, the construction
value, the completion date, your role, and a client referee with current contact
details. (Criterion 4.2(c))

**Q5.** Identify your proposed team by name and role, including the CDM
Principal Designer and the accredited conservation lead. State the time
commitment of each and your commitment to continuity of personnel.
(Criterion 4.2(d))

**Q6.** Describe the social value your appointment would deliver to the Borough
of Whitcombe, with measurable commitments. (Criterion 4.2(e))

**Q7.** Provide a programme from appointment to practical completion, showing
statutory approvals and the Trust's decision points, and confirm your ability to
achieve reopening for the 2028/29 swimming season. (Criterion 4.2(f))

**Q8.** Complete the pricing schedule. State all assumptions and exclusions, and
provide hourly rates by grade for additional services. (Criterion 4.3)

## 7. Further information

7.1 The following are available on request from the Trust: the 2021 Condition
Survey (Ridgeway & Partners); the 2023 Heritage Statement; the Trust's business
plan summary; measured survey drawings (2019, partial).

7.2 Clarification questions must be submitted through the portal. Questions and
answers will be circulated to all tenderers in anonymised form.

7.3 The Trust does not bind itself to accept the lowest or any tender. Tender
validity period: 90 days.

---

## Appendix B — Submission checklist

Tenderers should check the following before submission:

- [ ] Form of Tender completed and signed by a director
- [ ] Non-Collusion Certificate signed
- [ ] Equality and Diversity Declaration signed
- [ ] Quality response, **maximum 15 sides A4**
- [ ] CVs (one side each)
- [ ] Insurance certificates
- [ ] ISO 9001 certificate
- [ ] Conservation accreditation evidence
- [ ] Pricing schedule, returned unaltered
- [ ] Submitted by the deadline **by email to tenders@wclt.org.uk**
