# THORNLEIGH ARCHITECTS LLP — STANDARD BID MATERIALS

Internal pack, Rev 7. Last reviewed: not stated.
*All fictional. Sample material for the "AI for Architects" course.*

---

## 1. Practice profile (standard text — reuse)

Thornleigh Architects LLP is an award-winning practice of 24 people based in
south London, founded in 2004 by Ruth Thornleigh. We work across community,
civic, education and residential sectors, with a particular strength in the
adaptation and reuse of existing buildings.

We are a Chartered Practice of the Royal Institute of British Architects. Our
work has been published in the architectural press and shortlisted for regional
awards.

Recent work includes the restoration of the Northgate Assembly Rooms in
Ferrisby, the £3.6m Bellhouse Community Hub in Draycott Green, and the
refurbishment of Aveley Street Pool for the Borough of Kilnbrook.

We are structured as four project teams, each led by a Director or Associate,
supported by a shared technical and specification resource. Average project
value is £2m–£8m.

## 2. Design philosophy (standard text — reuse)

We begin every project by understanding what is already there. Existing
buildings carry decisions made by people who understood their material and their
climate, and our first move is to read those decisions before adding to them.

We believe good buildings come from long conversations. Our process is
consultative, iterative and evidence-led. We test options rather than defend
them, and we bring clients into the decision-making early enough that the
decisions are genuinely theirs.

We build simply and durably. We prefer few materials, well detailed, to many
materials arranged for effect.

## 3. Sustainability (standard text — reuse)

Sustainability is not a bolt-on service at Thornleigh. Retrofit-first is our
default position: the greenest building is usually the one already standing.

Our projects routinely achieve a 60% reduction in operational energy against
baseline. We design to a fabric-first hierarchy, target low embodied carbon
through material selection and structural reuse, and undertake whole-life carbon
assessment on all projects over £3m.

We are signatories to Architects Declare.

## 4. Quality management (standard text — reuse)

Thornleigh operates a documented quality management system aligned with the
principles of ISO 9001. All projects follow our standard stage gateway process,
with a formal design review at the end of each RIBA stage chaired by a Director
not otherwise involved in the project.

Drawings and specifications are subject to two-stage internal check before
issue. We maintain a practice-wide issue register and lessons-learned log.

## 5. Health and safety (standard text — reuse)

Thornleigh has a written Health and Safety Policy, reviewed annually, and a
nominated Health and Safety Officer (Ruth Thornleigh). We have undertaken
Principal Designer duties under CDM 2015 on projects since 2016. All technical
staff have completed CDM awareness training.

We have had no reportable incidents and no HSE enforcement action.

## 6. Insurance (standard text — reuse)

Thornleigh Architects LLP carries full professional indemnity insurance, public
liability insurance and employer's liability insurance, all renewed annually
through our brokers. Certificates are available on request.

## 7. Project sheets

### 7.1 Aveley Street Pool, Borough of Kilnbrook

| | |
|---|---|
| Client | Borough of Kilnbrook |
| Construction value | £5.1m |
| Completed | March 2016 |
| Our role | Architect and Lead Designer, Stages 1–5 |
| Contract | JCT Design & Build, two-stage |

Refurbishment of an operational 1970s leisure centre: replacement of pool hall
roof and rooflights, new changing village, plant replacement and improved
accessibility. The centre remained open to the public throughout, with works
phased over three summer periods and a temporary entrance maintained.

Referee: Sam Underhill, Borough of Kilnbrook (contact details to be confirmed —
Sam has moved department).

### 7.2 Northgate Assembly Rooms, Ferrisby

| | |
|---|---|
| Client | Ferrisby Town Council |
| Construction value | — |
| Completed | 2022 |
| Our role | Architect, Stages 1–4 |
| Contract | JCT Intermediate |

Grade II listed 1868 assembly rooms converted to a community and performance
venue. Works included structural repair to the roof trusses, reinstatement of
the lost gallery, new accessible entrance and WCs, and a new heating strategy
retaining the historic joinery. Listed building consent obtained at first
submission following pre-application discussion with the Conservation Officer.

Project Architect: Kwame Osei.

Referee: to be confirmed.

### 7.3 Bellhouse Community Hub, Draycott Green

| | |
|---|---|
| Client | Draycott Green Regeneration Partnership |
| Construction value | £4.2m |
| Completed | September 2023 |
| Our role | Architect and Lead Designer, Stages 1–5 |
| Contract | JCT Standard Building Contract with Quantities |

New-build community hub with a sports hall, nursery, café and flexible
community rooms, replacing a demolished 1960s youth centre. Delivered on
programme and within the cost plan. Shortlisted for a regional award.

Referee: Priya Nandra, Draycott Green Regeneration Partnership,
p.nandra@dgrp.example.org

### 7.4 Other relevant work

- Marchfield Village Hall, Marchfield — small community refurbishment, 2024,
  value not recorded.
- St Ives Road Nursery, Whitcombe — new-build nursery for the London Borough of
  Whitcombe, 2021, £1.4m. (Note: this is a previous commission for the Council,
  though not for the Trust.)

## 8. Team CVs

### Ruth Thornleigh — Founding Director, RIBA
Founded Thornleigh in 2004. 28 years' experience. Extensive experience of listed
buildings and buildings in conservation areas, including the Northgate Assembly
Rooms. Leads the practice's civic and community work. Practice Health and Safety
Officer. Sits on the Whitcombe Design Review Panel.

### Anna Beltrán — Associate, RIBA
Joined 2013. 16 years' experience. Project lead for Bellhouse Community Hub and
Aveley Street Pool. Specialism in leisure and sports buildings, including pool
hall environments and plant coordination. CDM awareness trained.

### Kwame Osei — Project Architect, RIBA
Joined Thornleigh in 2024. 9 years' experience. Project Architect for Northgate
Assembly Rooms. Interest in traditional construction and lime-based repair.
Currently studying towards conservation accreditation.

### Technical resource
Two Part 2 architectural assistants and a technical coordinator support the
project teams. CVs available on request.

## 9. Fee rates

Rate card **Rev 3, January 2023**. *(Note: superseded by Rev 5, April 2026 —
Rev 5 is held by the practice manager and is not included in this pack.)*

| Grade | Hourly rate |
|---|---|
| Director | £145 |
| Associate | £110 |
| Project Architect | £88 |
| Architectural Assistant | £58 |
| Technical Coordinator | £72 |

Fee basis is normally resource-based for refurbishment and adaptation work, and
percentage-based for new build. Typical percentage range for new build:
5.5%–7.5% of construction cost depending on stages and complexity.

## 10. Policies held

- Health and Safety Policy (2025)
- Quality Management Manual (2024)
- Sustainability Policy (2024)
- Data Protection Policy (2023)

*No social value policy or equality and diversity policy is currently held in
the standard pack.*
