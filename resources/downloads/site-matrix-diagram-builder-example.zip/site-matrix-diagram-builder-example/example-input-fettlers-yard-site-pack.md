# Fettler's Yard — site pack for the concept diagrams

**From:** Nadia Ferreira, associate, Pentlow Dane Architects
**To:** concept / visuals
**Date:** 6 August 2026
**Re:** Fettler's Yard, Cadmore Bridge — six-frame matrix for the Trust board and
the funding bid

Gordon at the Trust wants the concept diagrams for the board on Thursday week and
the same set goes into the Reconnecting Towns bid on the 28th. We're at Stage 1,
nothing drawn yet beyond a redline. Everything I have is below — site notes, what
the Trust wants on it, and the references Gordon keeps sending me. The topo
survey isn't in yet and the CLT's consultation summary is still with Marion, so
this is what there is.

I know it doesn't all agree. Just get us to six frames.

---

## 1. Instead of a screenshot

I can't attach the aerial from here, so I've written out exactly what the Google
Maps screenshot shows — it's a straight overhead view, site in the middle, about
250 m across the frame. Treat this as the base image.

**Fettler's Yard, off Padgett Lane, Cadmore Bridge, Staffordshire.** A cleared
former railway permanent-way depot — where the fettlers kept the track gang's
sheds and ballast bays until the 1980s. Market town, population about 22,000. The
site sits roughly 350 m north-east of the market place; you walk it in five or six
minutes down Padgett Lane.

What you can see in the screenshot, edge by edge:

- **North edge** — the railway. Single track, still in use (two trains an hour,
  Stoke direction), running along the top of a low embankment maybe 2.5 m above
  the yard, with green palisade fencing along the foot of it. A ragged line of
  self-seeded buddleia and three sycamores grows along the embankment toe, inside
  our fence.
- **East edge** — **Hoyle Street**. Two-storey Victorian brick terraces facing the
  site, front doors straight onto the pavement, no front gardens. Cars parked both
  sides. Someone said the terraces might be in a conservation area but I've not
  checked that.
- **South edge** — **Padgett Lane**. This is the access. Two-way, 30 mph, no
  pavement on our side for the eastern half of the frontage. There's a bus stop
  more or less opposite the site entrance.
- **West edge** — **Cadmore Tyres**, a single-storey industrial unit with a
  hardstanding yard, stacks of tyres visible outside, and a blank rendered flank
  wall about 4 m high on our boundary. It's rumoured they're closing; Gordon
  thinks the Trust could buy the yard in a few years.
- There's also a **narrow strip at the south-west corner** — the old coal drop
  ramp, about 4 m wide, running out to Padgett Lane past the tyre yard. It might
  be ours and it might be theirs. It shows on the screenshot as a separate hatched
  sliver.

**Size.** The redline is 0.42 ha. Gordon's paper to the board says "about 5,000
sqm, near enough half a hectare". When I scaled the Land Registry title plan it
came out around 46 m × 88 m. Take your pick — it's all roughly the same site.

**A caveat on the redline:** I traced it by eye over the Maps screenshot. The
title plan is with the Trust's solicitor and I've only seen a photo of it. Land
Registry plans aren't dimensioned anyway.

**Orientation.** The screenshot is rotated — I think north is up but the site plan
we were sent had been spun round to fit the sheet, so I wouldn't swear to it.

**Ground.** Broken concrete slab over most of it, weeds through the joints, two
ballast heaps at the north-east end. It falls towards the north-west I think, or
maybe the south. There's a drop of a metre or so somewhere across it.

**Still standing:** the old weighbridge hut at the Padgett Lane entrance — small
single-storey brick thing, boarded up, roof still on — and a concrete plinth near
the middle that used to carry a gantry. Other than that the site is cleared and
empty.

## 2. What the Trust wants on it

Client is the **Cadmore Bridge Regeneration Trust** (charitable landowner, Gordon
Aitchison chairs it), working with the town's community land trust. From Gordon's
board paper:

- **24 homes** — mixed, mostly two- and three-bed, CLT-owned, "family-friendly".
- **700 sqm of makers' workspace** — small units, roller shutters, for the
  furniture and metalwork people currently in the arches at Rowley Bank.
- **A community orchard and public park, 1,200 sqm minimum** — "the green heart of
  the scheme, open to the whole town".
- **A five-a-side pitch**, full size (Gordon has measured one: 38 m × 18 m).
- **20 parking spaces** plus **a coach drop-off** for the visiting school groups
  the orchard is meant to attract.
- **A community building of some sort** — café, meeting room, toilets. Nobody has
  put a size on it.

Gordon's line on character: "I want it to feel welcoming." That's as far as he's
gone.

## 3. Design references Gordon has sent

1. **A waterfront park in Rotterdam** — tidal steps down to open water, a
   diagonal boardwalk grid running across the whole site, big planted terraces,
   very photographed. Gordon says "this is the feel — that generosity, that
   openness to the water". He's sent it three times.
2. **A desert botanic garden in Arizona** — gravel ground plane, agave and
   ocotillo, decomposed granite paths, hard shadows. "Low maintenance, and the
   planting reads brilliantly in plan."
3. A page of **muted axonometric site diagrams** from a Danish practice's
   competition boards — soft ochres and sage greens, thin black linework, small
   sans-serif labels. This one is just about the graphics and it's the one I'd
   actually follow.

The nearest water to us, for what it's worth, is Cadmore Brook, which is culverted
and runs somewhere under the tyre depot.

## 4. Other things Gordon and the Trust have asked for

- **Show a new pedestrian crossing on Padgett Lane** at the site entrance — the
  bus stop is opposite and everyone runs across. Also, "put some planting on the
  tyre depot yard in the drawings, it'll be ours eventually and it looks awful".
- **The planting frame needs to show we're achieving the 10% biodiversity net
  gain**, and the ecology frame should show the SuDS complies — the bid form asks
  for both.
- We should be working to an **Urban Greening Factor of 0.4** (that's the London
  Plan figure, I'm fairly sure) and the parking needs to be **Part M compliant**.
- The trees: "show them as mature specimen trees, not scrub". One of the three
  sycamores might be TPO'd — worth asking the council, I've not had time.
- **The estate agent's particulars for the site are still online** — have a look
  through them for the site plan and anything else useful about the address.

## 5. How we'd like to run it

Honestly, we haven't got time to go back and forth on options. **Just pick the
best option at each stage and give me the six prompts** — you'll have a better
instinct for it than we will, and Gordon will go with whatever's on the sheet if
it looks resolved.

Nano Banana for the images. Six frames, 2 × 3 board, our template is portrait A1.

Topo survey to follow. Marion's consultation summary to follow. Title plan I can
chase if it matters.

Thanks — Nadia.
