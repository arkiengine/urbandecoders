# Fettler's Yard — six-frame site matrix: worked run

A complete record of the skill run against `example-input-fettlers-yard-site-pack.md`.
Everything below happened in one conversation; the user's turns are marked
**[Nadia]** so the choices are auditable. This is the reference answer — compare
your own runs against it, and against `fettlers-yard-defect-key.md`.

**Stage:** RIBA Stage 1, concept diagrams for a trust board and a funding bid.
**Deliverable:** six coordinated image prompts, one shared legend, a 2 × 3 board
layout, and a checks list.

---

## 1. Site reading — before any design

Read from the written base description supplied in place of a screenshot.
Tags: **[seen]** stated or visible in the source · **[inferred]** my reading ·
**[unclear in source]** contradictory or missing.

**A note on how I will describe directions.** North is **[unclear in source]** —
the pack says the screenshot may be rotated. So every frame, every prompt and
every label below names edges by their feature (*railway edge*, *Hoyle Street
edge*, *Padgett Lane edge*, *tyre-depot edge*) and never by compass point. No
sun-path, south-facing or overshadowing argument appears anywhere in this run.
When the north point is confirmed, those arguments become available; until then
they would be inventions.

### The parcel

| Item | Reading | Tag |
|---|---|---|
| Use | Cleared former railway permanent-way depot, Padgett Lane, Cadmore Bridge | [seen] |
| Shape | Broadly rectangular, long axis running parallel to the railway | [inferred] from the edge description and the scaled dimensions |
| Size | **Three figures given:** 0.42 ha redline · "about 5,000 m²" (board paper) · 46 × 88 m = 4,048 m² (scaled title plan) | [unclear in source] |
| Working assumption | **None taken.** Arithmetic below is run against 4,048 m² and 5,000 m² as a range | — |
| Boundary source | Traced by eye over a commercial map screenshot; title plan seen only as a photograph | [seen] — and the reason the boundary is [inferred] throughout |
| Orientation | North possibly up, possibly not | [unclear in source] |
| Levels | Falls "north-west I think, or maybe the south", drop of "a metre or so somewhere"; topo survey to follow | [unclear in source] |

### The edges

| Edge | Condition | Tag |
|---|---|---|
| **Railway edge** (~88 m) | Live single track, two trains an hour, on an embankment ~2.5 m above the yard; green palisade fence at the toe. Noise, vibration and an absolute constraint on access | [seen] |
| **Hoyle Street edge** (~46 m) | Two-storey Victorian terraces facing the site, doors to pavement, no front gardens, on-street parking both sides. Overlooking works both ways | [seen] |
| **Padgett Lane edge** (~88 m) | The only confirmed access. Two-way, 30 mph, no pavement on the site side for the eastern half. Bus stop roughly opposite the entrance | [seen] |
| **Tyre-depot edge** (~46 m) | Cadmore Tyres: single-storey unit, hardstanding, ~4 m blank rendered flank wall on the boundary, tyres stacked outside | [seen] |
| **The fifth edge** | ~4 m coal-drop ramp strip at the Padgett Lane / tyre-depot corner, running out to the lane. Ownership unknown — "might be ours and it might be theirs" | [unclear in source] — **boundary-affecting, see question 1 below** |

### On the site

- Broken concrete slab with weeds through the joints; two ballast heaps at the
  Hoyle Street end of the railway edge. **[seen]**
- Self-seeded buddleia and **three sycamores** along the embankment toe, inside
  the fence. One "might be TPO'd". **[seen]** / protection **[to verify]** with
  the local authority tree officer.
- **A boarded weighbridge hut, roof on**, at the Padgett Lane entrance, and a
  concrete gantry plinth mid-site. **[seen]** — the pack nonetheless calls the
  site "cleared and empty" (see question 2).
- Cadmore Brook is culverted somewhere beneath the tyre depot. **[seen]** —
  off-site, third-party land, and **not a site feature**.

### Two things about the references

1. The **Rotterdam waterfront park** is organised entirely around open tidal
   water and a diagonal boardwalk grid over it. Fettler's Yard has no water. I
   will take the reference for **graphic tone and the ambition of generosity
   only** — no water body, no tidal edge, no boardwalk, no imported diagonal
   grid will appear in any frame. References lend character; they never lend
   terrain.
2. The **Arizona desert garden** (gravel, agave, hard shadow) and the stated
   community orchard / biodiversity ambition are pulling in opposite
   directions in a damp Staffordshire yard. That is a genuine choice, not an
   error — see the style question below.

The **Danish diagram sheet** is the reference that can be followed directly: it
is about graphic language, and graphic language is what this deliverable is.

---

## 2. What I need before Frame 01 — and four things I can't do as asked

### Blocking questions

1. **The coal-drop ramp.** In or out? It is the only possible second connection
   to Padgett Lane, so it changes what circulation options exist. If title is
   unresolved by Thursday, I will draw the four confirmed edges as the working
   boundary and show the ramp as a dashed *ownership unconfirmed* strip.
2. **The weighbridge hut.** The site is described as empty and it is still
   standing with its roof on. Retention or removal is a design and consent
   decision — and a small brick railway building beside a possible conservation
   area is exactly what a conservation officer asks about. Which is it?
3. **The design priority.** The programme is specified in detail; the priority
   is "I want it to feel welcoming", which does not distinguish between three
   options. What should lead the concept — community, biodiversity, movement,
   quiet, workspace viability, deliverability in phases?
4. **The site area.** 0.42 ha, 5,000 m² and 4,048 m² are not the same site.
   Which governs? I have run the numbers against the range below rather than
   choosing for you.

### Four things I will not do

- **I will not pick the options for you.** I understand the deadline, and I will
  make choosing as fast as I can — a reasoned comparison, a clear
  recommendation, and a one-letter reply per frame. But these six choices are
  the argument you will be asked to defend at the board and in the bid, and
  "the diagram tool chose it" is not an answer. If you would rather not go frame
  by frame, say so and I will lay out a complete recommended route for you to
  approve in one go — that is one confirmation instead of six, and it is still
  yours.
- **I will not show a 10% biodiversity net gain or a compliant SuDS scheme.** A
  concept diagram cannot demonstrate either. BNG is a metric calculation against
  a baseline habitat survey; drainage compliance is a strategy agreed with the
  lead local flood authority. What Frame 05 *can* honestly show is intent —
  labelled as intent. If the bid form asks for the substance, the honest answer
  is that both are commissioned, not drawn. Documents to consult before anything
  is claimed: the statutory biodiversity metric and its user guide, and the
  current SuDS design guidance adopted locally — **[to verify]**, and I am not
  quoting figures or thresholds from either from memory.
- **I will not put an Urban Greening Factor of 0.4 in the drawings.** That figure
  comes from London Plan policy and Cadmore Bridge is not in London; the
  applicable requirement, if any, is in the borough's own development plan.
  Likewise "Part M compliant" parking — the requirement lives in the current
  Approved Document, and I will not restate its dimensions from memory. Both are
  on the checks list as **[to verify]**.
- **I will not go looking at the estate agent's particulars.** Site and client
  material stays confidential unless you explicitly ask me to search. If the
  particulars contain the site plan, please send them over — that is worth more
  than anything I could infer from them anyway.

### Two off-site asks, logged

The **new crossing on Padgett Lane** is on adopted highway — not the Trust's to
propose in a concept diagram, and a matter for the highway authority. The
**planting of the tyre-depot yard** is third-party land with a rumoured sale and
no agreement. Neither will be drawn as part of the proposal. Both can appear as
clearly labelled *aspiration — off-site, third-party land* annotations if you
want them visible, and my advice is that in a funding bid they should be labelled
loudly or left out.

> **[Nadia]** Ramp: assume out, Gordon's solicitor won't have it by Thursday.
> Hut: we'd rather keep it, it's the only thing left of the yard — but show us
> the alternative. Priority: community — the Trust's whole case is that this is
> the town's site. Area: use the scaled title plan, I trust it more than
> Gordon's paper. And yes, keep the crossing and the tyre yard out; I'll take
> that back to him. Fine on the compliance stuff, I'll tell Gordon the bid needs
> a real metric.

---

## 3. Diagram rules — locked before Frame 01

| Rule | Setting |
|---|---|
| Working boundary | Four confirmed edges. Coal-drop ramp shown as a dashed *ownership unconfirmed* strip, outside the working site |
| Boundary status | **[inferred]** — traced by eye over a map screenshot; provisional until checked against the title plan |
| Site area used | **4,048 m²** (46 × 88 m, scaled) as the working figure; 5,000 m² carried as the optimistic bound |
| Orientation | North **[unclear in source]** — edges named by feature, north arrow omitted from all frames with a note saying why |
| Crop and scale | Identical in all six frames: site centred, ~30 m of surrounding context on every side, same scale throughout |
| Graphic style | The Danish competition sheet: soft ochres and sage greens, thin black linework, small sans-serif labels, off-white ground |
| Planting character | **Your call, and it is a real one.** The Arizona gravel palette and the community orchard cannot both lead. Recommended: orchard character leads, and the desert reference is set aside — a gravel-and-agave ground plane will read as the opposite of "the town's site" |
| Off-site context | Flat 10% warm grey, exactly as described, nothing added |
| Retained | Weighbridge hut retained (your instruction), shown hatched; removal offered as a variant at Frame 04 |
| Everything stops | At the property line, in every frame |

> **[Nadia]** Agreed, orchard leads. Gordon can keep the Rotterdam picture on
> his wall.

---

## 4. The six frames

### Frame 01 — Site boundary

**Purpose:** lock the line, and make the frame declare what is and is not ours.

**Option A — The provable line.** The four confirmed edges only, as a firm black
boundary; the ramp strip dashed and greyed outside it; edge conditions annotated
in one word each (*rail*, *homes*, *street*, *industry*).
- The drawn line is one you can defend in a bid document.
- The ramp stays visible, so nobody forgets the question.
- Says nothing about influence beyond the line — Frame 02 does that.

**Option B — The conditional site.** Same firm line, plus the ramp inside a
second dashed boundary labelled *subject to title*, so later frames can carry a
second access as a dashed alternative.
- Keeps a two-entry circulation option alive without asserting ownership.
- Costs clarity: two boundaries in a bid document invite the question you can't
  yet answer.

**Option C — Boundary and influence.** The confirmed line plus a soft halo
showing the railway embankment, the tyre-depot flank and the Hoyle Street
frontage as off-site conditions bearing on the site.
- Front-loads the context argument into Frame 01.
- Risks doubling up with Frame 02, which is where forces belong.

**Recommendation:** **A**. In a document that goes to funders, the drawn line
should be the line you can prove, and the dashed ramp keeps the loose end
honest without making the boundary itself look uncertain.

**Question:** choose A, B or C (or ask for a variation) to continue.

> **[Nadia]** A.

---

### Frame 02 — Context forces

**Purpose:** read what acts on the site, before proposing anything on it.

**Carried forward:** Frame 01 = A (provable four-edge line, ramp dashed out).

**Option A — Pressure from three sides.** Foreground railway noise and vibration
along the embankment, traffic and the missing pavement on Padgett Lane, and the
dead 4 m flank of the tyre depot. The Hoyle Street edge reads as the only
neighbourly frontage.
- Sets up a buffer-led concept: protect the middle.
- Strong argument for putting workspace against the railway.
- Reads slightly defensive for a project whose case is public generosity.

**Option B — Approach and desire lines.** Foreground movement: the walk from the
market place along Padgett Lane, the bus stop opposite the entrance, the Hoyle
Street residents' likely short cut across the site, the depot's HGV turning.
- Sets up a route-led concept and a public through-site case.
- The Hoyle Street short cut is **[inferred]** — no evidence in the pack. It
  would be drawn as a dashed *possible desire line*, not a fact.

**Option C — Four edges, four different neighbours.** Foreground the fact that
each edge asks for a different response: infrastructure, industry, homes,
street. The site reads as an edge-condition problem before it is a plan.
- Matches what the source actually establishes most firmly.
- Makes the "community" priority concrete: the Hoyle Street edge is where the
  scheme meets the town's existing residents.
- Less immediately dramatic than A on a board.

**Recommendation:** **B** — a movement reading gives the strongest public case
in a funding bid. But it rests partly on an inferred desire line, and C rests
entirely on things the source states.

**Question:** choose A, B or C to continue.

> **[Nadia]** C. I'd rather not put an invented short cut in front of Gordon.

---

### Frame 03 — Primary circulation

**Purpose:** set movement — the first real design decision, which everything
after inherits.

**Carried forward:** 01 = A (provable line) · 02 = C (four edges, four
neighbours).

Two constraints before the options: the **railway edge cannot be an access** at
any point, and the **coach drop-off cannot be accommodated on site** — a coach
needs a layby on Padgett Lane, which is adopted highway and off-site. It is
logged, not drawn.

**Option A — Single spine along the railway edge.** One route running the full
88 m parallel to the track, entered from Padgett Lane at the ramp corner, turning
head at the Hoyle Street end; everything hangs off it.
- Simple, deliverable, phaseable from one end.
- Puts a road along the quietest, most planting-hungry edge.
- 46 m of depth means a single spine leaves one deep band and one shallow one.

**Option B — Two entries and a public cut.** Vehicle entry from Padgett Lane at
the ramp corner, a second point at the Hoyle Street corner, plus a pedestrian
route cutting the site between Hoyle Street and Padgett Lane.
- Best public permeability; the cut makes the site read as the town's.
- Requires the second entry, which needs the ramp question answered — currently
  unresolved.

**Option C — Vehicles held at the frontage, car-free within.** All vehicles stop
in a single court at the Padgett Lane edge beside the weighbridge hut; beyond it
the site is pedestrian. Longest walk-in is under 45 m.
- The 46 m depth makes car-free genuinely workable, not a gesture.
- The parked cars sit against the street rather than through the green.
- The workshop units lose vehicle access to their shutters — which for
  furniture and metalwork tenants may be fatal.

**Recommendation:** **C**, because on a site this shallow a car-free interior
costs almost nothing in walking distance and buys the entire middle of the site
back. The workshop servicing issue is real and would need solving, not ignoring.

**Question:** choose A, B or C to continue.

> **[Nadia]** C, but the makers absolutely have to get a van to the shutters —
> they're moving metalwork. Can we do C with a service spur?

**Restating that as C′ before I carry it forward:**

**Option C′ — Car-free interior with a shared-surface service spur.** Parking
court at the Padgett Lane edge as in C, plus a single 4.5 m shared-surface spur
running from the court along the railway edge to the workshop shutters, with a
turning head. No through route; the spur is a dead end and reads as yard, not
road. Everything else pedestrian.
- Keeps the car-free centre and the workshop viability.
- Costs a strip of the railway edge that Frame 05 would otherwise plant.
- Confirm this is what you mean before Frame 04 inherits it.

> **[Nadia]** Yes, C′.

---

### Frame 04 — Programme zoning

**Purpose:** place the programme, around the circulation you have chosen.

**Carried forward:** 01 = A · 02 = C · 03 = C′ (car-free interior, frontage
parking court, railway-edge service spur).

#### The arithmetic first, because it does not close

Everything at ground level, against a site of **4,048 m²** (your working figure;
the 5,000 m² board figure in brackets):

| Item | Ground area needed | Note |
|---|---|---|
| 24 homes as two-storey houses | ~1,320 m² footprint | before any private amenity space |
| 24 homes as three-storey maisonettes | ~550–650 m² footprint | the only version that leaves room |
| Makers' workspace, 700 m² | 700 m² single storey / ~350 m² if stacked | roller shutters imply mostly single storey |
| Orchard and park | 1,200 m² minimum | stated as a minimum |
| Five-a-side pitch, 38 × 18 m | 684 m², **924 m² with a 2 m margin** | margin is a **[to verify]** dimension, not quoted from memory |
| 20 parking spaces + aisle | ~300 m² | indicative, not a standard |
| Coach drop-off | — | cannot be on site (Frame 03) |
| Community building | **[not stated]** | no size given; nothing allowed for |
| Access, footpaths, thresholds | **not counted** | I have not assumed a percentage |

Lowest-footprint version: 650 + 700 + 1,200 + 924 + 300 = **3,774 m²**, leaving
274 m² (or ~1,226 m² on the optimistic area) for every path, every threshold,
every square metre of private amenity, and the entire unsized community building.

**Two-storey houses instead of three: 4,444 m² — over the site before a single
path.**

So: **the stated programme does not fit as stated.** That is the most useful
thing this sequence can tell you at Stage 1, and it is not mine to solve. The
pitch is the pressure point — a full-size five-a-side with margins consumes
three-quarters of the "1,200 m² minimum" park, so at the stated sizes the
community orchard is roughly 280 m² of what is otherwise a sports pitch. The
options below each take a different position on that, and none of them makes the
problem disappear.

**Option A — Buffer band and one green.** Workshops in a continuous ~14 m band
along the railway edge, doing acoustic work as well as programme; homes as
three-storey terraces along the Padgett Lane edge returning at the Hoyle Street
corner; the whole public green as one piece at the Hoyle Street end, fronting
the terraces.
- One green, publicly fronted, visible from the existing houses — the strongest
  reading of "the town's site".
- Requires three-storey homes. That is a decision, not a drawing convention.
- The pitch fits only by taking most of that green.

**Option B — Two courts.** A residential court at the ramp-corner half and a
public court at the Hoyle Street half: workspace, pitch and orchard grouped as a
working yard opening to Hoyle Street.
- Cleanest separation of quiet and active; easy to phase in two bids.
- The public half becomes busy against the existing terraces — overlooking and
  noise both ways.

**Option C — Green spine.** A continuous ~18 m green band running the length of
the site between homes on the Padgett Lane side and workshops on the railway
side; pitch at the ramp-corner end, orchard at the Hoyle Street end.
- Every home and every workshop fronts the green.
- The band is long and thin: a route more than a park, and the pitch eats one
  end of it entirely.

**Recommendation:** **A**, on your stated priority. A single, generously
proportioned, publicly fronted green is a better answer to "the town's site"
than two courts or a strip — but it stands or falls on the pitch question below.

**Question:** choose A, B or C — and separately, tell me what gives on the
pitch. Three honest positions: (i) full-size pitch, orchard reduced to ~280 m²;
(ii) marked training area rather than a full pitch, orchard keeps the space;
(iii) pitch dropped, taken to the recreation ground instead. I am not choosing
this one for you either — it is the difference between a park with a pitch in it
and a pitch with some trees round it.

> **[Nadia]** A. And (ii) — Gordon will hate it but a full pitch was never
> realistic on this site and he needs to hear it with the numbers on. Keep the
> hut as the entrance marker like we said.

**Recorded:** Frame 04 = **A**, with the public green as orchard-led and a
marked multi-use training area within it (not a full-size pitch). The
three-storey home typology is now a live assumption carried into the checks
list — it came out of the arithmetic, not out of the brief.

---

### Frame 05 — Planting and ecological performance

**Purpose:** layer the landscape and show how the site performs — as intent,
not as compliance.

**Carried forward:** 01 = A · 02 = C · 03 = C′ · 04 = A + training area,
orchard-led green.

Before the options, the two things this frame will not do: it does not
demonstrate 10% biodiversity net gain, and it does not show a compliant drainage
strategy. Both are labelled *intent* on the frame itself so nobody in the bid
process mistakes a diagram for a calculation.

**Option A — Orchard-led.** Productive canopy across the green (fruit trees at
regular spacing), mown paths and edges, meadow verge to the railway toe, low
hedge to the tyre-depot flank.
- Most legible in plan; reads immediately as "community orchard".
- Thin on the acoustic and visual work the railway and tyre edges need.

**Option B — Buffer-led.** Dense multi-layer planting on the railway and
tyre-depot edges — canopy, mid-layer, groundcover — doing the screening and
acoustic softening; a simpler, more open green in the middle.
- Answers the two hostile edges directly, which is what Frame 02 said mattered.
- The existing sycamores and buddleia become the start of that buffer rather
  than something to clear.
- The orchard becomes a lighter gesture inside an open green.

**Option C — Rain-led.** Planting organised around the water route: a swale
following the fall of the ground to a basin at the low point, tree pits along it,
orchard on the higher ground, buffer planting on the two hostile edges.
- The only option that makes the ecology frame do structural work rather than
  decorate.
- **Blocked, partly.** The fall of the ground is **[unclear in source]** — "north
  west I think, or maybe the south". Until the topo survey lands, C can only be
  drawn with the swale direction marked *indicative — fall to be confirmed by
  survey*. If the survey contradicts it, this frame is regenerated.

**Recommendation:** none of them is wrong; it depends on whether you want the
frame to sell the orchard (A), answer the edges (B), or carry the environmental
argument (C).

**Question:** choose A, B or C.

> **[Nadia]** You decide, honestly. Whichever one reads best in the bid.

**I won't — but here is the comparison, and a recommendation you can confirm in
one word.**

| | What it buys | What it costs | Against "community" priority |
|---|---|---|---|
| A Orchard-led | Instant legibility; the picture Gordon has in his head | Leaves the railway and tyre edges unresolved | Good story, weak argument |
| B Buffer-led | Solves the two problems Frame 02 identified; retains the existing trees as an asset | The orchard reads as incidental | Solid, undramatic |
| C Rain-led | Ties planting to performance; the only version that gives the bid an environmental argument beyond "trees" | Rests on a level fall nobody has surveyed; one arrow is provisional | Strongest bid material, honest caveat attached |

**My recommendation is C**, with the buffer planting from B kept on the railway
and tyre-depot edges — it is not really a compromise, it is what a rain-led
scheme on a site with two hostile edges would do anyway. The swale direction is
provisional and clearly labelled. If the topo contradicts it, we regenerate one
frame, not six.

Confirm with **C** and I'll carry it forward; say **A** or **B** and I'll carry
that instead.

> **[Nadia]** C. And yes, label the arrow — Gordon needs to understand the topo
> matters.

---

### Frame 06 — Final concept plan

**Purpose:** consolidate. Nothing new appears here — if it was not chosen in
Frames 01–05, it does not exist.

**Carried forward:** 01 = A · 02 = C · 03 = C′ · 04 = A + training area ·
05 = C + B's edge buffers.

**Option A — Clean plan.** The resolved plan with the legend and nothing else.
- Most confident on a board; lets the drawing speak.
- The six-frame argument is lost the moment the final frame is used alone.

**Option B — Annotated plan.** The resolved plan with light callouts naming each
of the five moves and the frame it came from.
- The single image carries the whole argument — which matters, because the final
  frame is the one that gets lifted out and used alone in the bid.
- Slightly busier; needs restraint in the label sizing.

**Option C — Plan with a key-moves strip.** The resolved plan with a strip of
five small thumbnails along the bottom.
- Elegant, and readable at a distance.
- Two graphic systems in one image; harder to generate consistently.

**Recommendation:** **B**. The frame that leaves the building alone is the one
that needs to explain itself.

**Question:** choose A, B or C.

> **[Nadia]** B.

---

## 5. Final package

### 5.1 Selected concept route

| Frame | Choice | Option name | Note |
|---|---|---|---|
| 01 Site boundary | **A** | The provable line | Four confirmed edges; ramp dashed, outside |
| 02 Context forces | **C** | Four edges, four neighbours | B declined by the user as resting on an inferred desire line |
| 03 Circulation | **C′** | Car-free interior + service spur | User modification to C, restated and confirmed |
| 04 Programme zoning | **A** | Buffer band and one green | With user decision (ii): training area, not a full pitch |
| 05 Planting & ecology | **C** | Rain-led, with B's edge buffers | Confirmed after a comparison; swale direction provisional |
| 06 Final plan | **B** | Annotated plan | — |

Every one of these was chosen by the user. Nothing on the board was picked by
the skill.

### 5.2 Six-frame storyboard

**01 — Site boundary.** The 46 × 88 m parcel drawn as a firm black line against
flat grey context. Each edge annotated in one word: rail, homes, street,
industry. The coal-drop ramp strip sits dashed and greyed outside the line,
labelled *ownership unconfirmed*. The weighbridge hut is hatched at the Padgett
Lane entrance. A footnote states that the boundary is traced from a map
screenshot and that no north point is shown.

**02 — Context forces.** The same base with four annotation groups, one per
edge: railway noise and vibration and the 2.5 m embankment; the terraces'
frontage and mutual overlooking on Hoyle Street; the traffic, absent pavement
and bus stop on Padgett Lane; the blank 4 m flank and HGV movements at the tyre
depot. Nothing proposed. The point of the frame is that four edges want four
different things.

**03 — Primary circulation.** A parking court at the Padgett Lane edge beside
the retained hut, everything beyond it pedestrian. A single 4.5 m
shared-surface service spur runs from the court along the railway edge to the
workshop shutters and ends in a turning head. Pedestrian routes fan from the
court into the site. An annotation records that the coach drop-off cannot be
accommodated on site.

**04 — Programme zoning.** Three bands. Workshops in a ~14 m band along the
railway edge, doubling as an acoustic buffer, served by the spur. Homes as
three-storey terraces along the Padgett Lane edge, returning at the ramp corner.
The public green as one piece at the Hoyle Street end, fronting the existing
terraces, with a marked multi-use training area within it. A note gives the area
arithmetic and states that the three-storey typology is what makes it close.

**05 — Planting and ecological performance.** Orchard canopy across the green;
multi-layer buffer planting along the railway edge (starting from the three
retained sycamores) and against the tyre-depot flank; a swale running from the
high ground to a basin, with the direction arrow labelled *indicative — fall to
be confirmed by survey*. Two labels state that the frame shows intent, not a BNG
calculation and not a drainage strategy.

**06 — Final concept plan.** All chosen moves resolved together at full
strength, edges reconciled, with five light callouts naming the moves and the
frames they came from. The provisional swale arrow keeps its label. Nothing
appears that was not chosen in Frames 01–05.

### 5.3 The six image prompts

Built from `references/frame-prompt-template.md`. The **LOCKED BASE** and
**STYLE** blocks below are identical, word for word, in all six prompts —
copy them, do not retype them. Generate in order.

---

#### Frame 01

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 01
of 06 of a six-frame urban site matrix diagram, titled "Site boundary".

LOCKED BASE (identical in all six frames — do not vary):
- Same site boundary, orientation, crop and scale as the uploaded site image.
  The site is a broadly rectangular former railway yard, roughly 46 m by 88 m,
  its long axis parallel to a railway embankment.
- No north arrow and no compass labels: orientation is unconfirmed. Name edges
  by their features only — railway edge, Hoyle Street edge, Padgett Lane edge,
  tyre-depot edge.
- All design action stops at the property line. Surrounding context rendered as
  flat light-grey masses and lines exactly as in the base image — do not add,
  move or remove any road, building, water body or tree outside the boundary.
- No water anywhere in the image. There is no canal, river, dock or basin on or
  near this site.
- Plan view only. No perspective, no 3D, no photorealism.

THIS FRAME'S CONTENT (full strength):
- The four confirmed edges drawn as one firm black boundary line.
- A narrow strip at the corner where the Padgett Lane edge meets the tyre-depot
  edge, drawn dashed and greyed OUTSIDE the boundary, labelled "ownership
  unconfirmed".
- One-word edge annotations set outside the line: "rail" along the railway edge,
  "homes" along the Hoyle Street edge, "street" along the Padgett Lane edge,
  "industry" along the tyre-depot edge.
- A small hatched rectangle at the Padgett Lane entrance labelled "weighbridge
  hut — retained".
- Three small dark-green tree rings along the inside of the railway edge.
- A small footnote in grey italic: "Boundary traced from map screenshot —
  provisional. North not confirmed."

STYLE (identical wording in all six frames):
Professional architectural presentation-board diagram, clean plan-view graphic,
soft muted colour fills in ochre, sand and sage, precise thin black linework,
clear labelled arrows, small sans-serif labels, small legend bottom-left,
off-white background. Square 1:1 format.

LEGEND (use only these, consistently):
- 1.5 pt solid black line: site boundary
- 0.5 pt black dashed line: extent with unconfirmed ownership
- Flat 10% warm grey: off-site context
- Black hatch: retained structure
- Dark green ring, no fill: existing tree
```

---

#### Frame 02

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 02
of 06 of a six-frame urban site matrix diagram, titled "Context forces".

[LOCKED BASE — identical block, as Frame 01]

CARRIED FORWARD (shown as in Frame 01, at full strength — this is the base):
- The confirmed boundary, the dashed unconfirmed strip, the retained hut, the
  three existing trees.

THIS FRAME'S CONTENT (full strength):
- Four groups of thin dark-grey open annotation arrows, one per edge, pointing
  inward from outside the boundary, with short labels:
  - Railway edge: "live single track, 2 trains/hour", "embankment +2.5 m",
    "noise and vibration", "no access possible".
  - Hoyle Street edge: "two-storey terraces, doors to pavement", "overlooking
    both ways", "on-street parking".
  - Padgett Lane edge: "only confirmed access", "30 mph", "no pavement this
    side (east half)", "bus stop opposite".
  - Tyre-depot edge: "blank 4 m flank wall", "HGV movements", "yard storage".
- No proposal of any kind: no routes, no zones, no planting.
- A grey italic note: "Four edges, four different demands."

[STYLE — identical block, as Frame 01]

LEGEND (use only these, consistently):
- 1.5 pt solid black line: site boundary
- 0.5 pt black dashed line: extent with unconfirmed ownership
- Flat 10% warm grey: off-site context
- Thin dark-grey open arrow: context force acting on the site
```

---

#### Frame 03

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 03
of 06 of a six-frame urban site matrix diagram, titled "Primary circulation".

[LOCKED BASE — identical block, as Frame 01]

CARRIED FORWARD (muted to ~30% strength):
- The four edge annotation groups from Frame 02, reduced to short grey labels.

THIS FRAME'S CONTENT (full strength):
- A vehicle parking court in sand fill along the Padgett Lane edge, beside the
  retained weighbridge hut, entered from Padgett Lane at the corner nearest the
  tyre-depot edge. Approximately 20 marked spaces.
- A single 4.5 m wide shared-surface service spur in the same sand fill, running
  from the court along the inside of the railway edge to a turning head at the
  Hoyle Street end. Drawn as a yard surface, not a road: no kerbs, no centre
  line.
- Dashed ochre pedestrian routes running from the parking court into the body of
  the site and to the Hoyle Street edge.
- The whole area beyond the parking court and the spur shown clear of vehicles.
- A grey italic note beside the Padgett Lane edge: "Coach drop-off cannot be
  accommodated on site — would require a layby on adopted highway."

[STYLE — identical block, as Frame 01]

LEGEND (use only these, consistently):
- 1.5 pt solid black line: site boundary
- Flat 10% warm grey: off-site context
- Sand fill: vehicle surface — parking court and shared-surface service spur
- Dashed ochre line: pedestrian route
- Black hatch: retained structure
```

---

#### Frame 04

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 04
of 06 of a six-frame urban site matrix diagram, titled "Programme zoning".

[LOCKED BASE — identical block, as Frame 01]

CARRIED FORWARD (muted to ~30% strength):
- The parking court, service spur and pedestrian routes from Frame 03, in pale
  sand and pale ochre.

THIS FRAME'S CONTENT (full strength):
- A continuous band of makers' workspace in deep ochre fill, approximately 14 m
  deep, along the inside of the railway edge, served by the muted spur, with
  roller-shutter positions marked as short thick ticks facing the spur. Labelled
  "makers' workspace 700 m2".
- Homes in muted terracotta fill as three-storey terraces along the inside of
  the Padgett Lane edge, returning around the corner nearest the tyre-depot
  edge. Labelled "24 homes, three storeys".
- One public green in sage fill occupying the Hoyle Street end of the site,
  fronting the existing terraces. Labelled "community orchard and park".
- Within the green, a pale olive rectangle with a dotted outline, clearly
  smaller than a full pitch, labelled "multi-use training area".
- A small grey italic block at the edge of the frame: "Stated programme exceeds
  the site at two storeys. Three-storey homes assumed to close the arithmetic —
  not a brief instruction. Full-size five-a-side omitted by client decision.
  Community building size not stated — no allowance shown."

[STYLE — identical block, as Frame 01]

LEGEND (use only these, consistently):
- 1.5 pt solid black line: site boundary
- Flat 10% warm grey: off-site context
- Muted terracotta fill: homes
- Deep ochre fill: makers' workspace
- Sage fill: public green — orchard and park
- Pale olive, dotted outline: multi-use training area (provisional)
- Pale sand / pale ochre: circulation carried forward
```

---

#### Frame 05

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 05
of 06 of a six-frame urban site matrix diagram, titled "Planting and ecological
performance".

[LOCKED BASE — identical block, as Frame 01]

CARRIED FORWARD (muted to ~30% strength):
- The three programme zones from Frame 04 and the circulation from Frame 03, all
  reduced to pale outlines and pale fills.

THIS FRAME'S CONTENT (full strength):
- Orchard canopy across the public green: sage-green circles at 40% opacity in a
  loose regular grid, drawn at intended maturity.
- A dark sage stipple band of multi-layer buffer planting along the inside of the
  railway edge behind the workspace band, incorporating the three existing tree
  rings, and a narrower band of the same against the tyre-depot flank.
- A pale blue-grey dashed swale line running through the site to a small basin
  outline at one end, with a single open arrow along it labelled in grey italic:
  "indicative fall — direction to be confirmed by survey".
- Small blue-grey dashed connections from the parking court and the workspace
  band to the swale.
- Two grey italic notes at the frame edge: "Diagram shows intent, not a
  biodiversity net gain calculation." and "Diagram shows intent, not a drainage
  strategy."

[STYLE — identical block, as Frame 01]

LEGEND (use only these, consistently):
- 1.5 pt solid black line: site boundary
- Flat 10% warm grey: off-site context
- Sage-green circle, 40% opacity: orchard canopy
- Dark sage stipple band: multi-layer buffer planting
- Dark green ring, no fill: existing tree, retained
- Pale blue-grey dashed line: surface water route (indicative)
- Pale blue-grey outline: attenuation basin (indicative)
```

---

#### Frame 06

```text
Using the uploaded empty-site image as the exact map-view base, create Frame 06
of 06 of a six-frame urban site matrix diagram, titled "Concept plan".

[LOCKED BASE — identical block, as Frame 01]

THIS FRAME'S CONTENT (all previous chosen moves at full strength, harmonised —
nothing new):
- The confirmed boundary and the dashed unconfirmed strip outside it.
- Parking court and shared-surface service spur at the Padgett Lane edge;
  car-free interior; pedestrian routes.
- Makers' workspace band along the railway edge; three-storey homes along the
  Padgett Lane edge; the public green at the Hoyle Street end with the
  multi-use training area within it.
- Orchard canopy, buffer planting bands, retained sycamores, swale and basin
  with the "indicative fall — direction to be confirmed by survey" label
  retained.
- The retained weighbridge hut, hatched, marking the entrance.
- Five light grey callout labels, each with a short line to what it names:
  "01 boundary — four confirmed edges", "02 context — four edges, four demands",
  "03 movement — car-free interior, service spur", "04 programme — buffer band
  and one green", "05 landscape — rain-led, orchard on the high ground".
- Edges and overlaps resolved: zone boundaries aligned, no clashing fills.
- No element that does not appear in Frames 01 to 05.

[STYLE — identical block, as Frame 01]

LEGEND: the full shared legend table, all layers.
```

---

### 5.4 Shared legend

One table for the whole set. Each frame quotes only its own subset; no frame
introduces a colour that is not here.

| Symbol | Layer | Appears in |
|---|---|---|
| 1.5 pt solid black line | Site boundary | 01–06 |
| 0.5 pt black dashed line | Extent with unconfirmed ownership | 01, 02, 06 |
| Flat 10% warm grey | Off-site context | 01–06 |
| Thin dark-grey open arrow | Context force | 02 |
| Sand fill | Vehicle surface — court and service spur | 03–06 |
| Dashed ochre line | Pedestrian route | 03–06 |
| Muted terracotta fill | Homes | 04–06 |
| Deep ochre fill | Makers' workspace | 04–06 |
| Sage fill | Public green — orchard and park | 04–06 |
| Pale olive, dotted outline | Multi-use training area (provisional) | 04–06 |
| Sage-green circle, 40% opacity | Orchard canopy | 05, 06 |
| Dark sage stipple band | Multi-layer buffer planting | 05, 06 |
| Dark green ring, no fill | Existing tree, retained | 01, 05, 06 |
| Pale blue-grey dashed line | Surface water route (indicative) | 05, 06 |
| Pale blue-grey outline | Attenuation basin (indicative) | 05, 06 |
| Black hatch | Retained structure (weighbridge hut) | 01, 03–06 |
| Grey italic text | Provisional or unverified information | 01–06 |

### 5.5 Presentation-board layout

Portrait A1, 2 columns × 3 rows, frames in reading order 01–06. Title block top
left ("Fettler's Yard — concept evolution, Stage 1"), the shared legend bottom
right below Frame 06, a single scale bar beside the legend (added at layout
stage, from the boundary dimension, **not** generated in the images), and a
one-line provenance note along the foot: *"Boundary provisional; north not
confirmed; see checks list."*

Assemble in InDesign or Illustrator — the prompts are per frame, not per board,
and no image generator should be asked to produce the composed sheet.

### 5.6 The package as a file

Offered and taken: written to
`/mnt/user-data/outputs/site-matrix-stage1-concept-package.md`. No client name
or address in the filename.

### 5.7 Checks before use

Nothing below was resolved during the run. Every item is live.

**Blocking — resolve before this goes in the bid**

1. **Site area.** 0.42 ha / 5,000 m² / 4,048 m² all in circulation. Frames drawn
   to 4,048 m². Confirm against the title plan; the Frame 04 arithmetic changes
   with it.
2. **Boundary.** Traced by eye over a map screenshot; **[inferred]**. Redraw over
   the title plan or a survey before any dimension leaves the studio.
3. **North point.** **[unclear in source]**. No frame carries a north arrow and
   no argument in this package depends on orientation. Once confirmed, the
   sun-path and overshadowing arguments become available — and the railway
   embankment's effect on the green will need checking.
4. **Coal-drop ramp title.** Shown dashed and excluded. If it turns out to be the
   Trust's, Frame 03's two-entry option (B) becomes available and Frames 03–06
   would be re-run.
5. **Levels.** Fall unknown; the Frame 05 swale arrow is labelled provisional. If
   the topo contradicts it, regenerate Frame 05 and Frame 06.

**Verify — do not take from this package**

6. **Biodiversity net gain.** Not shown and not claimed. A metric calculation
   against a baseline habitat survey is required. Consult the statutory
   biodiversity metric and its current user guide — **[to verify]**.
7. **Drainage.** Not shown as a strategy. Consult the SuDS design guidance
   adopted by the lead local flood authority — **[to verify]**.
8. **Urban Greening Factor.** The 0.4 figure in the pack is London Plan policy
   and does not apply here. Check the borough's development plan for any local
   requirement — **[to verify]**. No UGF figure appears in any frame.
9. **Accessible parking and approach.** "Part M compliant" was requested; no
   dimensions are drawn from memory. Check the current Approved Document at the
   point spaces are laid out — **[to verify]**.
10. **Pitch and training-area dimensions.** The 38 × 18 m pitch and the 2 m
    margin used in the arithmetic came from the pack and a working assumption
    respectively; check against the relevant sport governing body's guidance
    before the training area is sized — **[to verify]**.
11. **TPO on the sycamores.** Unconfirmed. Frames retain all three regardless;
    confirm with the tree officer — **[to verify]**.
12. **Conservation area on Hoyle Street.** Hearsay in the source, unchecked.
    Material to the weighbridge hut's retention and to the treatment of the
    Hoyle Street frontage — **[to verify]**.

**Assumptions and decisions to record**

13. **Three-storey homes.** Not in the brief. It emerged from the Frame 04
    arithmetic as the only way 24 homes close on this site alongside the rest of
    the programme. If the Trust wants two storeys, something else goes.
14. **Community building unsized.** **[not stated]**; no area allowed for
    anywhere in the frames. Every square metre it needs comes out of something
    drawn.
15. **Coach drop-off.** Cannot be accommodated on site. Annotated on Frame 03,
    unresolved.
16. **Weighbridge hut retained** by client instruction. Structural condition
    unknown; retention is not costed or surveyed.
17. **Tyre depot closure** is rumour, not fact. Nothing in the frames depends on
    it, and no planting is drawn on that land.
18. **Off-site asks excluded.** The Padgett Lane crossing (adopted highway) and
    the tyre-yard planting (third-party land) are not drawn. Both were requested;
    both are the user's to pursue separately.
19. **Base map licensing.** The base is a commercial map screenshot. The Trust
    should satisfy itself about terms before the frames appear in a public bid
    document.
20. **Absent documents.** Topo survey, consultation summary and title plan were
    all "to follow" and none informed this run.

**Reported in chat as well as here:** four of the six frames rest on a boundary
nobody has checked, the programme does not fit the site as stated, and two of
the things the bid form asks for cannot be produced by diagrams at all. Those
three sentences matter more than the pictures.
