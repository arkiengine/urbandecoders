# Wellgate Yard — change and instruction log

**Period covered:** 3 October 2025 to 24 February 2026.
**Prepared:** 26 February 2026, ahead of the final account meeting.

> **Read this first — the blind spot.** This log is built from **the
> architect's own email folder**, the design team minutes and the site visit
> records. The client's correspondence, the contractor's correspondence other
> than what was copied in, the QS's files, and **any direct client-to-contractor
> correspondence** were not supplied.
>
> At least three items below (W-02, W-04, W-08) turn on things said directly
> between the client and the contractor on site. **Those conversations are
> invisible to this log**, and the items are recorded from the second-hand
> account that reached the architect.

---

## §1 — The log

| Ref | Date | Element | What changed | How it arose | Source + location | **Verbatim trigger** | Instruction status | By |
|---|---|---|---|---|---|---|---|---|
| **W-01** | 21.10.25 | Community building roof | Single ply → zinc standing seam | `client request` (origin DTM-08) | Email, architect → contractor, 21.10.25 | **"Yes, that works — can you get it ordered so we don't lose the slot."** | **`implied`** | Architect |
| **W-02** | ~30.10.25 | Plot 7 kitchen window | Position moved 300 mm from A-1101 rev D | `client request` **(reported)** | SV-06 item 4, 06.11.25 | **"Contractor states this was agreed with the client on site last week to improve the view. No instruction seen."** | **`verbal unrecorded`** | Client (disputed — see C-01) |
| W-03 | 14.11.25 | Plots 4 and 5 | Rooflights omitted | `unknown` | AI-001, 14.11.25 | "Omit rooflights to plots 4 and 5." | `formal` | Architect |
| **W-04** | 28.11.25 | Community building | Use changed to nursery provision | `client request` | DTM-10 item 3.4, 28.11.25 | **"The client confirmed the community building will now be used for nursery provision rather than general community use. The architect noted this may affect the specification and layout. No further discussion."** | **`written non-formal`** | Client |
| **W-05** | 02.12.25 | Community building entrance doors | Widened; observed 1,800 clear against 1,500 on A-1105 rev C | `client request` | Email, client → architect, 02.12.25 | **"Can we go ahead and widen the community building entrance doors?… Happy for you to just sort it."** | **`written non-formal`** — see C-02 | Client |
| W-06 | 09.12.25 | Community building | Ironmongery substituted | `unknown` | AI-002, 09.12.25 | "Substitute ironmongery to community building." | `formal` | Architect |
| **W-07** | ~19.12.25 | North boundary drainage | Re-routed; made ground not on the SI | `site condition` | Email, contractor → architect, 08.01.26 | **"We flagged this to [client] on site on 19 December and he told us to get on with it."** | **`verbal unrecorded`** | Client (reported by the contractor) |
| W-08 | 22.01.26 | North boundary drainage | Additional connection | `site condition` | AI-003, 22.01.26 | "Additional drainage connection, north boundary." | `formal` | Architect — see C-03 |
| **W-09** | 29.01.26 | Community building flooring | Engineered board → safety vinyl | `design development` (consequent on W-04) | Email, architect → contractor, 29.01.26 | **"please change the flooring to the safety vinyl rather than the engineered board. Go ahead and we'll sort the paperwork."** | **`implied`** | Architect |
| **W-10** | before 03.02.26 | Balcony balustrades, plots 12–18 | Galvanising omitted; powder coat only | `contractor proposal` | SV-10 item 5, 03.02.26 | **"Contractor states galvanising was omitted to meet the programme and that this was 'discussed with the CA'. No record found."** | **`verbal unrecorded`** | Unknown — see C-04 |
| **W-11** | 11.02.26 | External paving | 450×450 → 600×600 slab | `contractor proposal` | Email, contractor → architect, 11.02.26 | **"Assume that's fine as discussed."** | **`none found`** — see W-12 | — |
| W-12 | 24.02.26 | External paving | Reverted to 450×450 | `error correction` | Email, architect → contractor, 24.02.26 | **"Please revert the paving to the specified 450×450. The 600×600 was never agreed."** | `written non-formal` | Architect |

---

## §2 — Verbal and implied instructions

**The items most likely to cause a dispute. Listed first because they are the
reason this log exists.**

| Ref | Status | The sentence |
|---|---|---|
| **W-01** | `implied` | "**Yes, that works** — can you get it ordered so we don't lose the slot." |
| **W-09** | `implied` | "**Go ahead and we'll sort the paperwork.**" |
| **W-02** | `verbal unrecorded` | "agreed with the client on site last week" — **no instruction seen** |
| **W-07** | `verbal unrecorded` | "he told us to get on with it" — client, on site, 19.12.25 |
| **W-10** | `verbal unrecorded` | "discussed with the CA" — **no record found** |
| **W-11** | `none found` | "Assume that's fine as discussed" — **and subsequently contradicted** |

**Six of twelve items have no formal instruction. Two of them are sentences the
architect wrote.**

W-01 and W-09 are the two where this practice's own words may have created a
change. W-01 authorised an order ("can you get it ordered so we don't lose the
slot") four months before the client said at DTM-14 that he had not seen the
correspondence and the budget had not been adjusted. W-09 says in terms that
the paperwork does not exist yet.

---

## §3 — Conflicts and contradictions

**C-01 — Plot 7 window: agreed or not.**
- SV-06 (06.11.25): "Contractor states this was agreed with the client on site
  last week… **No instruction seen.**"
- DTM-12 (12.01.26): "The contractor confirmed it was built as agreed on site.
  **The client said he did not recall agreeing it** but was content for it to
  remain."

Both are recorded. The client's later acceptance ("content for it to remain")
and the question of whether it was agreed at the time are **separate matters**,
and this log does not merge them or rule on either.

**C-02 — The entrance door width instruction is not the instruction that was
issued.**
- The client asked to widen the entrance doors (02.12.25).
- **AI-002, issued 09.12.25, instructs "Substitute ironmongery to community
  building."**
- SV-08 (15.12.25) observes the openings formed at 1,800 against 1,500 on
  A-1105 rev C.

The only formal instruction in that week is about ironmongery. **The door
widening — a structural opening change — was built and has no instruction
covering it.** Whether AI-002 was intended to cover it is not stated anywhere
supplied. Recorded as a contradiction, not resolved.

**C-03 — AI-003 and the verbal on 19 December.**
- The contractor states the client told them to proceed on site on 19.12.25
  (email, 08.01.26).
- **AI-003 was issued 22.01.26**, five weeks after the work was instructed
  verbally and a fortnight after the contractor's email.

Whether AI-003 regularises W-07 or is a separate matter is not stated. The log
records both and keeps them as separate rows.

**C-04 — Balustrade galvanising: "discussed with the CA".**
SV-10 records the contractor's account and that **no record was found**. The
architect's own email folder for the period was supplied and contains nothing.
That is an absence in the supplied material, not proof that no conversation
occurred.

**C-05 — The zinc roof was agreed, then disputed.**
- 21.10.25: architect emails "Yes, that works".
- 18.02.26, DTM-14: "The client asked when that had been agreed… The client
  said he had not seen it and that the budget had not been adjusted."

The 17.10.25 contractor email was **copied to the client**. Both facts are
recorded. This log does not determine what follows from either.

**C-06 — The paving was proposed and then refused.**
W-11 (11.02.26, "Assume that's fine as discussed") and W-12 (24.02.26, "The
600×600 was never agreed"). Whether work had been executed between those dates
is not established by anything supplied.

---

## §4 — Chronology

| Date | Ref | Event |
|---|---|---|
| 03.10.25 | — | DTM-08: client raises zinc roof |
| 17.10.25 | — | Contractor prices zinc, copied to client |
| **21.10.25** | **W-01** | **"Yes, that works"** |
| ~30.10.25 | W-02 | Plot 7 window moved on site |
| 06.11.25 | — | SV-06 records it; no instruction seen |
| 14.11.25 | W-03 | AI-001 |
| 28.11.25 | W-04 | DTM-10: use changed to nursery |
| **02.12.25** | **W-05** | **"Happy for you to just sort it"** |
| 09.12.25 | W-06 | AI-002 (ironmongery) |
| 15.12.25 | — | SV-08 observes 1,800 doors |
| **~19.12.25** | **W-07** | **Client verbal on site: "get on with it"** |
| 08.01.26 | — | Contractor reports it, three weeks later |
| 12.01.26 | — | DTM-12: client does not recall agreeing W-02 |
| 22.01.26 | W-08 | AI-003 (drainage) |
| **29.01.26** | **W-09** | **"Go ahead and we'll sort the paperwork"** |
| 03.02.26 | W-10 | SV-10 observes ungalvanised balustrades |
| 11.02.26 | W-11 | Contractor asserts paving change |
| 18.02.26 | — | DTM-14: client disputes zinc roof |
| 24.02.26 | W-12 | Architect reverts paving |

**Visible gaps in the sequence:**
- **W-02**: moved "last week" per SV-06, so approximately 30 October. No
  correspondence in the bundle for that week. The agreement, if any, happened
  somewhere this log cannot see.
- **W-07**: client verbal on 19 December, reported by the contractor on
  8 January. **A three-week gap with nothing in between.**
- **W-10**: no date at all for when the galvanising was omitted. Only the
  observation on 3 February.

---

## §5 — Regularisation list

**The action list. This is the reason to run the log before a final account
meeting rather than during one.**

| Ref | What needs confirming | By whom | Referring to |
|---|---|---|---|
| **W-01** | The zinc roof change — scope, and the cost position. Disputed at DTM-14 | **Architect / CA**, with the client | The email of 21.10.25 and the contractor's price of 17.10.25 |
| **W-05 / C-02** | **The entrance door widening.** Built at 1,800 against 1,500 drawn, with no instruction covering it. AI-002 covers ironmongery only | **Architect / CA** | Client email 02.12.25; A-1105 rev C; SV-08 |
| **W-09** | The flooring change. The email itself says the paperwork does not exist | **Architect / CA** | Email 29.01.26 |
| **W-04** | The change of use to nursery provision, and what it carries with it. The architect noted at the time it "may affect the specification and layout" | **Client**, confirming in writing | DTM-10 item 3.4 |
| **W-02** | Whether the window position change was instructed, by whom, and the cost position | **Client and contractor** | SV-06; DTM-12 |
| **W-07** | Whether AI-003 regularises the 19 December verbal, or whether a separate confirmation is needed | **CA** | Contractor email 08.01.26; AI-003 |
| **W-10** | Whether the galvanising omission was discussed and with whom; whether it is accepted or to be remedied | **CA and contractor** | SV-10 |
| **W-11 / W-12** | Whether any 600×600 paving was laid between 11 and 24 February | **Contractor** | Both emails |

**Oldest unregularised item: W-01, 21 October 2025 — 128 days.**

---

## §6 — Queries

| # | Query |
|---|---|
| Q-01 | The client's own correspondence and any direct client-to-contractor correspondence were not supplied. W-02, W-07 and W-10 all turn on conversations that would appear there. |
| Q-02 | Was AI-002 intended to cover the door widening as well as the ironmongery? Nothing supplied says. |
| Q-03 | What date was the balustrade galvanising omitted? No source states one. |
| Q-04 | Was any 600×600 paving laid? |
| Q-05 | The origin of AI-001 (rooflight omission) is not established by anything in the bundle — it appears only in the instruction register. |
| Q-06 | Does the nursery change of use (W-04) carry further changes not yet visible in this bundle? |

---

## §7 — Response to "tell us where we're exposed"

**This log does not assess exposure, value anything, or determine whether any
item is a variation under the contract.** Those are the contract
administrator's and the quantity surveyor's, and a change log that strays into
them produces a document that is wrong in a way nobody checks.

What it reports factually:

- **12 items. 3 `formal`. 3 `written non-formal`. 3 `verbal unrecorded`. 2
  `implied`. 1 `none found`.**
- **Nine of twelve have no formal instruction.**
- **Two of the nine are sentences written by this practice** (W-01, W-09).
- **One change was built with no instruction covering it and a drawn dimension
  it contradicts** (W-05 / C-02 — doors at 1,800 against 1,500 on A-1105 rev C).
- **Six conflicts** are unresolved, two of them disputed in minuted meetings.
- The oldest unregularised item is 128 days old.
- **Three items rest on conversations in correspondence this log was not
  given.**

---

## §8 — Shape of this log

**12 items, 5 months, 3 formal instructions.**

**Most likely to be contested:** W-01 (zinc roof — already disputed at DTM-14,
and the architect's own email authorised the order) and W-05 (door widening —
built, no instruction, contradicts a drawn dimension).

**Biggest limitation:** the blind spot in §0. Three items turn on what was said
between the client and the contractor on site, and none of that correspondence
was supplied.
