# Wellgate Yard — correspondence bundle, October 2025 to February 2026

**Project:** Wellgate Yard, Marlden — 18 dwellings and a community building
**Instruction:** "We think things have been instructed verbally. Reconstruct
the change history before the final account meeting."

*Fictional project, client and contractor. Deliberately imperfect.*

---

## §1 — What was supplied, and what was not

**Supplied:** the architect's own sent and received email folder for the
period; minutes of DTM-08 to DTM-14; site visit records SV-05 to SV-11; the
formal instruction register.

**Not supplied:** the client's own correspondence, the contractor's
correspondence other than what was copied to the architect, the quantity
surveyor's files, any correspondence between the client and the contractor
direct.

---

## §2 — Formal instruction register, as issued

| Ref | Date | Subject |
|---|---|---|
| AI-001 | 14.11.25 | Omit rooflights to plots 4 and 5 |
| AI-002 | 09.12.25 | Substitute ironmongery to community building |
| AI-003 | 22.01.26 | Additional drainage connection, north boundary |

---

## §3 — Correspondence and records, chronologically

---

**03.10.25 — DTM-08 minutes, item 6.2**
> "The client asked whether the community building roof could be zinc rather
> than the specified single ply. The architect said this would be looked at."

---

**17.10.25 — Email, contractor to architect, copied to client**
> "Further to the meeting, we price zinc standing seam to the community
> building roof at an addition. Please confirm if you would like us to
> proceed."

---

**21.10.25 — Email, architect to contractor**
> "Thanks. **Yes, that works** — can you get it ordered so we don't lose the
> slot."

---

**06.11.25 — SV-06 site visit record, item 4**
> "Plot 7 kitchen window observed set out 300 mm from the position on A-1101
> rev D. Contractor states this was agreed with the client on site last week
> to improve the view. No instruction seen."

---

**14.11.25 — AI-001 issued**
> "Omit rooflights to plots 4 and 5."

---

**28.11.25 — DTM-10 minutes, item 3.4**
> "The client confirmed the community building will now be used for nursery
> provision rather than general community use. The architect noted this may
> affect the specification and layout. No further discussion."

---

**02.12.25 — Email, client to architect**
> "Can we go ahead and widen the community building entrance doors? Someone
> mentioned the nursery use might need it. **Happy for you to just sort it.**"

---

**09.12.25 — AI-002 issued**
> "Substitute ironmongery to community building."

---

**15.12.25 — SV-08 site visit record, item 2**
> "Community building entrance door openings observed formed at 1,800 clear
> against 1,500 on A-1105 rev C."

---

**08.01.26 — Email, contractor to architect**
> "We have hit made ground at the north boundary that isn't on the SI. We've
> had to re-route the drainage. We flagged this to [client] on site on
> 19 December and he told us to get on with it. Costs to follow."

---

**12.01.26 — DTM-12 minutes, item 5.1**
> "The architect raised the Plot 7 window position. The contractor confirmed
> it was built as agreed on site. The client said he did not recall agreeing
> it but was content for it to remain."

---

**22.01.26 — AI-003 issued**
> "Additional drainage connection, north boundary."

---

**29.01.26 — Email, architect to contractor**
> "On the community building — given the nursery use, please change the
> flooring to the safety vinyl rather than the engineered board. **Go ahead
> and we'll sort the paperwork.**"

---

**03.02.26 — SV-10 site visit record, item 5**
> "Balcony balustrade to plots 12–18 observed as powder coated steel. The
> specification requires galvanised and powder coated. Contractor states
> galvanising was omitted to meet the programme and that this was 'discussed
> with the CA'. No record found."

---

**11.02.26 — Email, contractor to architect**
> "Confirming our conversation — the external paving will be the 600×600 slab
> rather than the 450×450 as it's what's available. Assume that's fine as
> discussed."

---

**18.02.26 — DTM-14 minutes, item 2.3**
> "The contractor raised that the community building roof has been installed
> in zinc. The client asked when that had been agreed. The architect referred
> to the October correspondence. The client said he had not seen it and that
> the budget had not been adjusted."

---

**24.02.26 — Email, architect to contractor**
> "Please revert the paving to the specified 450×450. The 600×600 was never
> agreed."

---

## §4 — What the practice has asked for

1. "Build a change log from this."
2. "What's been changed with no instruction behind it?"
3. "Which items need regularising, and who by?"
4. "Tell us where we're exposed before the final account meeting."
