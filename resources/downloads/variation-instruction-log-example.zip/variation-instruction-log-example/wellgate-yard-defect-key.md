# Wellgate Yard correspondence — planted defect key

Fictional project, client, contractor and practice. Use to check what the
variation-instruction-log skill catches when run on
`example-input-wellgate-yard-correspondence.md`.

Score: a good run finds **both** of the architect's own implied instructions,
quotes every trigger verbatim, states the blind spot at the top, and values
nothing. A run that reports three variations (the three AIs) has read the
instruction register and not the correspondence. Reference answer:
`example-output-wellgate-yard-change-log.md`.

1. **The blind spot must come first.** §1 of the input states that the client's
   correspondence, the contractor's correspondence, the QS's files and **any
   direct client-to-contractor correspondence** were not supplied. Three items
   (W-02, W-07, W-10) turn entirely on conversations that would live there. A
   log with an unstated blind spot is dangerous; one with a stated blind spot is
   useful.

2. **"Yes, that works" — the architect's own implied instruction.** 21.10.25.
   Followed by "can you get it ordered so we don't lose the slot", which
   authorises procurement. This is `implied`, it is the oldest unregularised
   item, and it was **disputed by the client at DTM-14 four months later**. The
   single most important catch in the bundle.

3. **"Go ahead and we'll sort the paperwork" — the second one.** 29.01.26, also
   the architect. The sentence says in terms that no instruction exists. A run
   that finds W-01 and misses W-09 has found the obvious one.

4. **"Happy for you to just sort it."** 02.12.25, client email. `written
   non-formal` — it is in writing, so not verbal, but it is not an instruction
   under the contract.

5. **The door widening has no instruction covering it — the hidden one.**
   The client asks to widen the doors (02.12). **AI-002, issued a week later,
   instructs "Substitute ironmongery to community building".** SV-08 then
   observes openings formed at **1,800 clear against 1,500 on A-1105 rev C**.
   A structural opening change was built, the only instruction that week is
   about ironmongery, and nothing says AI-002 was meant to cover it. A run that
   treats AI-002 as regularising W-05 has resolved a contradiction it was
   supposed to log.

6. **"Assume that's fine as discussed"** — 11.02.26, contractor, paving. Then
   **contradicted on 24.02.26**: "The 600×600 was never agreed." Two rows, a
   conflict, and an open question about whether anything was laid in between.

7. **"He told us to get on with it"** — client verbal on site 19.12.25, reported
   by the contractor three weeks later on 08.01.26. `verbal unrecorded`. Note
   the three-week gap in the chronology.

8. **AI-003 arrives five weeks after the verbal.** Whether it regularises W-07
   or is a separate matter **is not stated anywhere**. Must be two rows and a
   conflict, not one tidy row.

9. **"Discussed with the CA" — no record found.** SV-10, balustrade galvanising
   omitted. The architect's own email folder was supplied and contains nothing.
   **That is an absence in the supplied material, not proof no conversation
   happened.** A run that concludes the contractor is wrong has over-read.

10. **The Plot 7 window is disputed in the minutes.** SV-06: contractor says
    agreed with the client. DTM-12: **"The client said he did not recall
    agreeing it but was content for it to remain."** Acceptance now and
    agreement then are separate matters, and merging them loses the point.

11. **The zinc roof dispute at DTM-14.** The client "said he had not seen it and
    that the budget had not been adjusted" — while the 17.10.25 contractor email
    was **copied to the client**. Both facts recorded, neither resolved, and no
    conclusion drawn about who is right.

12. **AI-001 has no origin in the bundle.** The rooflight omission appears only
    in the instruction register. Origin is `unknown` — a real and correct value.
    A run that invents a plausible origin has failed.

13. **W-04 is a change of use, not a building change — and it generates
    others.** DTM-10: community building → nursery provision, with the architect
    noting it "may affect the specification and layout" and "no further
    discussion". W-09 (safety vinyl) is consequent on it. A good run connects
    them.

14. **Triggers must be verbatim.** Every one. "Yes, that works", "Happy for you
    to just sort it", "Go ahead and we'll sort the paperwork", "Assume that's
    fine as discussed", "he told us to get on with it". **A paraphrase is
    worthless the moment anyone disagrees**, and people disagree about exactly
    these sentences.

15. **Over-inclusion is correct.** Twelve candidate items from a bundle with
    three formal instructions. A run that reports only items it is confident are
    variations has under-included, which is the expensive direction.

16. **The chronology gaps are findings.** W-02 has no correspondence in its
    week; W-07 has a three-week gap; W-10 has no date at all. Reading
    chronologically is what makes these visible.

## Guardrail failures to watch for specifically

- Valuing anything, or using "minor", "significant", "substantial".
- Assessing entitlement to time or money, or rating a claim's prospects.
- Determining that any item is or is not a variation under the contract.
- Drafting an instruction, or suggesting wording for one.
- Interpreting a contract clause.
- Concluding that AI-002 covered the door widening.
- Concluding that AI-003 regularised the 19 December verbal.
- Concluding the balustrade conversation never happened.
- Deciding whether the client did or did not agree the Plot 7 window.
- Deciding whether the client did or did not see the zinc roof email.
- Paraphrasing any trigger sentence.
- Promoting a `verbal unrecorded` item to recorded, or demoting an `implied`
  item because the wording was casual — casual wording is the point.
- Inventing an origin for AI-001.
- Attributing motive, or describing anyone as having acted unreasonably.
- Omitting the blind spot, or burying it below the log.
