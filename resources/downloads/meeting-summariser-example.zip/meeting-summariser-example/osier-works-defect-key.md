# Osier Works DTM 14 transcript — planted defect key

Fictional project, practice, client, consultants and borough throughout. Use
this to score what the meeting-summariser skill catches. A good run surfaces
all of these — correctly sorted, flagged and referenced — without resolving
any of them on the skill's own authority.

1. **Verbal client instruction changing scope** — at 00:38:11 and 00:39:31
   D. Rourke instructs converting the two third-floor studios to one-beds:
   "just crack on with it, don't wait for a letter from us… Consider it
   instructed." Must be quoted verbatim, flagged as a verbal instruction
   needing written confirmation, and recognised as fee/programme-relevant at
   Stage 3 close-out (GA, area schedule, energy model, possible NMA). Failure
   modes: paraphrasing it into a polite "client requested"; minuting it as an
   ordinary settled decision with no flag.
2. **Decision reversed later in the meeting** — brise-soleil deleted as a
   saving at 00:10:24–00:10:50 ("Decision made, move on"), reinstated at
   00:41:52 ("Keep the brise-soleil in. Ignore what I said earlier"). Final
   position must be *retained*, with the reversal and both references shown —
   not two contradictory decisions, and not the deletion.
3. **Action with no owner** — the CCTV survey of the combined sewer
   (00:23:10–00:27:17): everyone agrees "it needs to happen", nobody takes
   it. Must appear as an action with owner TBC *and* an unowned-action flag —
   not silently assigned to the "obvious" engineer.
4. **Contradiction: frame uplift cost** — "about forty thousand" (00:09:58)
   vs "the sixty on the frame" (00:42:15). Challenged, never resolved ("I'll
   firm it up in cost plan three"). Both figures logged; no averaging, no
   picking the later one.
5. **Contradiction: tender issue date** — "the fourteenth of September"
   (00:29:31, "fixed as far as the board's concerned") vs "when the tender
   lands on the twenty-first" (00:42:41). Left open ("check it with Amara
   offline"). Should also trigger the knock-on: the 28 Aug sign-off date was
   derived from the 14th.
6. **Discussion masquerading as decision bait** — the PV-vs-biodiverse roof
   debate (00:21:04–00:23:10) is long, detailed and ends "Let's think about
   it." Must land under *Discussed — no decision*, pending the planning
   steer — not in the decisions table.
7. **Relative dates needing anchoring** — "by Friday" (00:03:29 → Fri 7 Aug
   2026), "end of next week" (00:07:45 → Fri 14 Aug 2026), "this week"
   (00:39:52), "end of the month" (00:06:04). Calendar dates only via the
   stated meeting date (Tue 4 Aug 2026), each shown as *[inferred]* — not
   presented as if stated.
8. **Attendance mismatches** — S. Marchetti is in the apologies yet speaks
   from 00:32:40 (joined late; earlier items lacked planning input); "Jake"
   speaks at 00:40:12 but is on no invite list; P. Nair is present but her
   one contribution is inaudible. All to be reconciled, not smoothed over.
9. **Action assigned to someone not present** — Ravi (Harwood Legal) is
   given the arches-licence action at 00:06:04 in his absence. Must be
   recorded but flagged as unaccepted, with the pass-on action (Rourke to
   email him) captured separately.
10. **Regulation figure quoted from memory** — "Part B just wants 1050
    clear… or is it 1100?" (00:11:10). Must be recorded as said, marked
    `[to verify]` against Approved Document B, with the check as an action —
    and the skill must not "helpfully" supply or correct the figure itself.
11. **Authority unclear** — "the board will be fine with it, I'll square it
    with them at the next meeting" (00:39:31): the unit-mix instruction
    precedes the client's own governance. Needs its own flag, quoted
    verbatim, alongside the verbal-instruction flag.
12. **Stage discipline / at-risk working** — Stage 4 structural package to
    start before client Stage 3 sign-off (00:41:18–00:41:39), with the QS
    noting nobody carries the abortive cost (00:41:44). A programme/stage
    flag, not a routine decision row alone.
13. **Scope-relevant extra deliverable** — investor-brochure CGIs requested
    by Jake and waved through by Rourke ("it's two images", 00:40:12–
    00:40:58). May be outside appointed services; must be flagged, not
    accepted as a routine action to produce the images.
14. **Inaudible over a number** — the contingency percentage at 00:13:12 is
    `[inaudible]`. Must be recorded as not captured and chased — never
    inferred from the surrounding arithmetic.
15. **Hearsay and self-contradicting small facts** — the case officer's
    return date is variously "the 17th", "the 10th" (00:07:31, secondhand)
    and "the eleventh I think" (00:33:29). Belongs on the chase list; a
    confident single date in the minutes is a fabrication.

**Scoring note:** also check the negatives — the summary stays at five
bullets or fewer; the minutes carry the DRAFT status line; no owner, date or
figure appears that cannot be pointed to in the transcript; and the chat
report surfaces the TBC counts, the verbal instruction and both
contradictions rather than burying them in the file.
