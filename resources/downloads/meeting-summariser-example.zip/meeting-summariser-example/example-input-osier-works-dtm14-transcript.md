# Osier Works — DTM 14 — meeting transcript

**Transcript exported from Microsoft Teams**
Meeting: Osier Works — Design Team Meeting 14
Date: Tuesday 4 August 2026, 10:02–10:46
Recording started 10:02:31. Transcription is automatic and may contain errors.

**Invited:** Hannah Voss (Foley Barr Architects); Priya Nair (Foley Barr Architects); Daniel Rourke (Ridgeline Properties); Tom Akande (Berrow & Chase); Lena Petrova (Calder Building Services); Martin Gill (Draycott & Hale); Sofia Marchetti (Marchetti Planning)

**Apologies noted in invite:** Sofia Marchetti (school event, will try to join for part)

---

[00:00:12] Voss, Hannah: Morning everyone, we're recording as usual, transcript will do the rounds. This is DTM 14 for Osier Works. Sofia's sent apologies, she may try and dial in later. Priya's on with me taking notes. Agenda's the one I circulated Friday — Stage 3 close-out, structure, services, cost, programme, AOB. Daniel, anything to add up front?

[00:01:08] Rourke, Daniel: No, that covers it. Well — one sales thing but I'll save it for AOB.

[00:01:15] Voss, Hannah: Fine. Okay, Stage 3 status from our side. The plans are essentially there, the landscape package landed Thursday, and we're compiling the Stage 3 report for issue. We're still carrying the query on the substation position but Cadent haven't come back, so that stays open.

[00:03:02] Akande, Tom: Sorry, just on that — is the substation query with the DNO or with us? Because I had it down as a client action from DTM 12.

[00:03:14] Rourke, Daniel: It's with us, our land team chased it Monday. Nothing yet. Leave it with me.

[00:03:20] Voss, Hannah: Thanks Daniel, we'll keep it on the tracker. Right, structure. Tom.

[00:03:29] Akande, Tom: Yep. So the transfer structure over the workspace at ground, we've landed on the 450 deep option, that coordinates with Lena's ceiling zone, no change there. The retained façade to Verey Street — the condition survey came back worse than hoped on the parapet, we're going to need to rebuild the top three courses. I'll get the markups on the GAs to Hannah by Friday.

[00:05:41] Voss, Hannah: Friday works, we'll fold it into the Stage 3 set.

[00:05:47] Akande, Tom: And the arches — we still can't confirm loading on the two railway arches until Network Rail's asset engineer responds. That's been sat six weeks now.

[00:06:04] Rourke, Daniel: Yeah, and honestly the arches licence is the same story. Ravi at Harwood Legal is handling the licence side — can we say Ravi confirms the licence position with Network Rail's property team by the end of the month? I'll pass that on.

[00:06:29] Voss, Hannah: Okay, noted — Ravi to confirm the arches licence position, end of August. He's not on this call so worth an email, Daniel.

[00:06:36] Rourke, Daniel: Yep yep.

[00:06:41] Voss, Hannah: While we're on constraints — Priya, remind me, condition 14, the materials condition?

[00:06:52] Nair, Priya: [inaudible]

[00:06:57] Voss, Hannah: Right, yes — we'll need Sofia to confirm the condition 14 wording with the case officer, whether the sample panel has to be up before commencement or before superstructure. Sofia's not here, so let's log it for her and I'll flag it when the notes go round.

[00:07:31] Rourke, Daniel: The officer's on leave till the 17th anyway, someone told me. Or the 10th. One of the two.

[00:07:39] Voss, Hannah: Okay. Services — Lena.

[00:07:45] Petrova, Lena: Thanks. Main headline is overheating. The design-stage TM59 is running now with the current glazing spec. South elevation flats are the ones I'm watching, particularly the three-beds on levels three and four. I should have results by end of next week.

[00:09:02] Voss, Hannah: End of next week — okay. That's tight for the Stage 3 report but we can issue with it as a trailing appendix if we have to.

[00:09:13] Petrova, Lena: And obviously the result depends on what we do with shading, which brings us to the brise-soleil conversation.

[00:09:21] Gill, Martin: Which brings us to money, yes. So — the brise-soleil to the south elevation, as priced at Stage 3 cost plan two, is carrying about eighty-five thousand. Given where the frame package has gone, we'd suggested it as a saving candidate.

[00:09:55] Rourke, Daniel: Where's the frame gone?

[00:09:58] Gill, Martin: Steel's moved against us since cost plan two — the uplift on the frame package is about forty thousand on current rates. Plus the parapet rebuild Tom's just mentioned, which isn't priced yet.

[00:10:24] Rourke, Daniel: Right. Okay, look — take the brise-soleil out. If TM59 comes back awkward we'll deal with it, but eighty-five grand for aluminium fins, take it out.

[00:10:41] Voss, Hannah: Just to be clear for the notes — we're deleting the brise-soleil from the south elevation, and the Stage 3 set gets updated accordingly?

[00:10:50] Rourke, Daniel: Yes. Decision made, move on.

[00:10:54] Petrova, Lena: I'd just note the TM59 was run *with* the shading in the last cycle, so —

[00:11:01] Rourke, Daniel: Noted, understood. Next.

[00:11:05] Voss, Hannah: Okay. Tom, anything else structural?

[00:11:10] Akande, Tom: One more — the escape corridor at level one, by the core. With the riser Lena needs, we're down to about 1080 clear. Corridor's fine I think — Part B just wants 1050 clear for that occupancy, or is it 1100? Whatever, I think we're okay, but someone should check.

[00:12:15] Voss, Hannah: We'll check it against the approved document rather than folklore. Priya, stick it on the list.

[00:12:22] Nair, Priya: On the list.

[00:12:26] Voss, Hannah: Cost then. Martin, the wider picture.

[00:12:33] Gill, Martin: So overall we're showing a forecast outturn of eight point four against the eight point two budget, driven by frame, the parapet unknown, and prelims creep. If the brise-soleil saving lands that's eighty-five back, which gets us most of the way. Contingency currently sits at — hang on — so contingency drops to [inaudible 00:13:12] percent, which is thinner than I'd like at this stage, frankly.

[00:13:26] Rourke, Daniel: What are you assuming on the arches fit-out?

[00:13:30] Gill, Martin: Shell only, as per the brief. Cat A to the workspace slab, arches left as lined shells.

[00:13:38] Rourke, Daniel: Good, keep it that way.

[00:21:04] Voss, Hannah: Right — roof. We owe the team a position on the roof, because at DTM 13 we parked the PV-versus-green-roof question and it's still parked. Lena?

[00:21:16] Petrova, Lena: So the sums haven't fundamentally changed. Full PV array gets you roughly the regs uplift you want for the energy statement, biodiverse roof helps the urban greening number, and the roof isn't big enough to do both properly once you've got plant and the maintenance zone. Hybrid is possible but both halves end up compromised.

[00:22:31] Rourke, Daniel: And planning want the greening, presumably.

[00:22:35] Voss, Hannah: The UGF target in the condition is the driver, yes, though Sofia would know whether there's flex — that's a her question.

[00:22:47] Akande, Tom: Structurally either works, the biodiverse build-up is heavier but it's not a driver.

[00:22:55] Gill, Martin: Cost-wise there's maybe twenty between them depending on spec, it's not decisive.

[00:23:02] Rourke, Daniel: Hmm. I don't want to decide that today without the planning angle. Let's think about it.

[00:23:10] Voss, Hannah: Okay, so it stays open pending the planning view. Moving on — drainage. The below-ground drainage design is waiting on the CCTV survey of the existing combined sewer, and tender information needs it. We really need to get the CCTV survey booked before the contractor pricing set goes out.

[00:27:09] Rourke, Daniel: Agreed, that needs to happen.

[00:27:12] Akande, Tom: Yeah, it's on the critical path for the drainage design, definitely.

[00:27:17] Voss, Hannah: Good — everyone agrees it needs to happen. Right, programme. Daniel, where are we on tender?

[00:29:31] Rourke, Daniel: Tender goes out on the fourteenth of September. That's fixed as far as the board's concerned — funding drawdown is keyed to it. Which means Stage 3 sign-off from us needs to be back to you by, what, end of August?

[00:29:52] Voss, Hannah: We'd want your Stage 3 sign-off by the twenty-eighth of August to hold a fourteenth of September tender, yes. That assumes the TM59 doesn't blow anything up.

[00:30:04] Rourke, Daniel: It won't. Fine, twenty-eighth.

[00:30:09] Voss, Hannah: I'll take that as the client sign-off date then — 28 August, Daniel's action. Okay —

[00:32:40] Marchetti, Sofia: — hi all, sorry, sorry, I'm here, school thing overran. What have I missed on planning?

[00:32:47] Voss, Hannah: Sofia, welcome. Quick catch-up: condition 14 wording — we need you to confirm with the case officer whether the sample panel is pre-commencement or pre-superstructure. And a new one from just now: is there flexibility on the UGF target in condition 9, because it's driving the roof decision, PV versus biodiverse.

[00:33:29] Marchetti, Sofia: Okay. The officer's back off leave on the eleventh I think, I'll get onto both. Say by the fifteenth for a steer on the UGF, the condition 14 one might be quicker.

[00:33:44] Voss, Hannah: Fifteenth of August, lovely. Right — AOB. Daniel, your sales thing.

[00:38:11] Rourke, Daniel: Yes. So, two things actually. Sales feedback first. The studios aren't shifting — the two studios on the third floor, sales say they'd move tomorrow as one-beds. So can we lose the two studios on third and make them one-beds? Just crack on with it, don't wait for a letter from us — I know what the paperwork's like our end, it'll take three weeks and we haven't got three weeks.

[00:38:55] Voss, Hannah: Okay — I have to say that's a plan change at the point of Stage 3 close-out. It touches the third floor GA, the area schedule, the energy model, probably the planning drawings — honestly it may need a non-material amendment, Sofia?

[00:39:19] Marchetti, Sofia: If the unit count changes, or the mix as approved — yes, potentially an NMA at least. I'd need to check the wording of the permission.

[00:39:31] Rourke, Daniel: The count doesn't change, thirty-four stays thirty-four. Look, the board will be fine with it, I'll square it with them at the next meeting, but I don't want to lose two weeks waiting for that. Consider it instructed.

[00:39:52] Voss, Hannah: Understood. We'll look at what it involves and I'll come back to you on programme and fee impact this week — I'm not redrawing the third floor tonight, but message received.

[00:40:04] Rourke, Daniel: That's all I ask. Second thing — Jake, you're on, aren't you? Jump in.

[00:40:12] Jake: Hi all, yeah — Jake, I do the investor comms at Ridgeline. Short version: we've got the investor brochure going to print end of the month and it's crying out for a couple of proper CGIs — the courtyard and the Verey Street elevation ideally. Could your team knock those up? They looked great in the planning set.

[00:40:39] Voss, Hannah: The planning views were done by our visualiser under the planning deliverables. Marketing CGIs for an investor brochure — I'd need to look at whether that's in our scope, and our visualiser's lead time. It's genuinely not a knock-up.

[00:40:58] Rourke, Daniel: Let's not make a thing of it, it's two images. End of the month, yes? Lovely.

[00:41:07] Voss, Hannah: I'll come back on that too. Okay — last item, Stage 4 mobilisation. Tom, you'd asked about an early start.

[00:41:18] Akande, Tom: Yes — to protect the tender date, we'd want to start the Stage 4 structural package now-ish rather than waiting for the client Stage 3 sign-off on the twenty-eighth. That's us working at risk for a couple of weeks, effectively.

[00:41:39] Rourke, Daniel: Fine by me. Crack on at risk, we're not going to pull the scheme.

[00:41:44] Gill, Martin: For the record, if the scheme did move, that's abortive time nobody's carrying in the cost plan.

[00:41:52] Rourke, Daniel: Noted. Crack on. Oh — and while I remember, going back to the shading thing. I've been stewing on it since the cost item. If Lena's overheating thing comes back bad and we've stripped the fins off, we look like idiots and we're redesigning in Stage 4 at the contractor's prices. Keep the brise-soleil in. Ignore what I said earlier — it stays, Martin finds me the eighty-five somewhere else.

[00:42:15] Gill, Martin: [laughs] I'll add it to the list. To be fair that does make my forecast worse — we're carrying the sixty on the frame plus the parapet plus keeping the fins, so —

[00:42:29] Rourke, Daniel: The sixty? You said forty earlier.

[00:42:34] Gill, Martin: Did I? Frame uplift. Anyway, it's moved against us, I'll firm it up in cost plan three.

[00:42:41] Rourke, Daniel: Fine. And when the tender lands on the twenty-first, we'll see where the market really is.

[00:42:47] Voss, Hannah: The twenty-first? Daniel, you said the fourteenth earlier — for the notes, which is it?

[00:42:53] Rourke, Daniel: Did I? September anyway. The funding date's the funding date, check it with Amara offline.

[00:43:00] Voss, Hannah: We'll confirm it outside the meeting then. Right — anything else? No? Lena, results end of next week, Tom, markups Friday, and I'll circulate the notes. Cost plan three, Martin — date?

[00:43:19] Gill, Martin: First week of September, once Tom's parapet detail and the fins decision have landed. Call it the fourth.

[00:43:27] Voss, Hannah: Fourth of September, cost plan three. Thanks all. Priya, stop the recording.

*Recording stopped 10:46:38.*
