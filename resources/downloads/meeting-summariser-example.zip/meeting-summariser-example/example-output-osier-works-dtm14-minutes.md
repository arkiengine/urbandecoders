# Osier Works — Design Team Meeting 14 — draft minutes

| | |
|---|---|
| **Project** | Osier Works |
| **Meeting** | Design Team Meeting (DTM) 14 |
| **Date / time** | Tuesday 4 August 2026, 10:02–10:46 |
| **Platform** | Microsoft Teams (recorded; automatic transcription) |
| **RIBA stage** | Stage 3, approaching close-out (as stated in meeting) |
| **Chair** | Hannah Voss, Foley Barr Architects |
| **Source** | `example-input-osier-works-dtm14-transcript.md` — Teams transcript export |

> **Status: DRAFT — for review by the project lead (H. Voss) before issue.
> Prepared from the transcript; not a verified record.** Timestamps refer to
> the transcript. All relative dates are resolved against the meeting date
> (Tue 4 Aug 2026) and marked *[inferred]* where the transcript gave only a
> relative expression.

## 1. Attendance

| Name | Organisation | Status |
|---|---|---|
| Hannah Voss | Foley Barr Architects | Present (chair) |
| Priya Nair | Foley Barr Architects | Present (notes; one contribution inaudible at 00:06:52) |
| Daniel Rourke | Ridgeline Properties (client) | Present |
| Tom Akande | Berrow & Chase (structure) | Present |
| Lena Petrova | Calder Building Services (M&E) | Present |
| Martin Gill | Draycott & Hale (cost) | Present |
| Sofia Marchetti | Marchetti Planning | **Apologies noted, but joined late at 00:32:40** — present for planning, AOB and close only |
| "Jake" (surname not stated) | Ridgeline Properties, investor comms | **Spoke at 00:40:12 but not on the invite list** — attendance to be confirmed |

Referenced but not present: Ravi (Harwood Legal) — assigned an action in his
absence, see A-03; "Amara" (Ridgeline, role not stated) — see CO-02.

## 2. Summary

- Stage 3 report is compiling for issue; client Stage 3 sign-off targeted for
  28 Aug to hold a September tender (tender date itself now in doubt — CO-02).
- The south-elevation brise-soleil was deleted as a cost saving and then
  **reinstated later in the same meeting** — final position: retained (D-03).
- Cost forecast outturn reported at £8.4m against an £8.2m budget; contingency
  described as thin (figure inaudible in transcript).
- The client verbally instructed converting the two third-floor studios to
  one-beds, ahead of board approval and without written instruction (VI-01);
  architect to advise on programme and fee impact.
- The roof strategy (PV vs biodiverse) remains **open**, pending the planning
  consultant's steer on urban greening flexibility.

## 3. Decisions

| Ref | Decision | Made / confirmed by | Source | Notes |
|---|---|---|---|---|
| D-01 | Transfer structure over ground-floor workspace confirmed as the 450 deep option, coordinated with the services ceiling zone | T. Akande | 00:03:29 | Reported as settled; no dissent |
| D-02 | Retained Verey Street façade: top three parapet courses to be rebuilt, following condition survey | T. Akande | 00:03:29 | Cost not yet in plan — picked up in A-13 |
| D-03 | **Brise-soleil to south elevation RETAINED** | D. Rourke | 00:41:52 | **Reversal.** Deletion was instructed and confirmed "decision made" at 00:10:24–00:10:50, then reversed at 00:41:52 ("Keep the brise-soleil in. Ignore what I said earlier"). Final position: retained; QS to find the c.£85k elsewhere (A-13). L. Petrova's note that TM59 was previously run *with* shading (00:10:54) stands |
| D-04 | Arches fit-out remains shell only (Cat A to workspace slab; arches as lined shells) | D. Rourke | 00:13:38 | Confirms existing cost-plan assumption |
| D-05 | Client Stage 3 sign-off due 28 Aug 2026 | D. Rourke | 00:30:04 | Stated as required to hold a 14 Sept tender — but see CO-02 on the tender date |
| D-06 | Stage 4 structural package to start ahead of Stage 3 sign-off, at Berrow & Chase's risk | D. Rourke / T. Akande | 00:41:18–00:41:39 | See PR-01. M. Gill noted abortive time is not carried in the cost plan (00:41:44) |
| D-07 | Client instruction (verbal): two third-floor studios to be converted to one-beds; unit count unchanged at 34 | D. Rourke | 00:38:11, 00:39:31 | **Verbal instruction only — see VI-01, SC-01, AU-01.** Architect has not agreed to proceed with redesign; response on programme and fee impact due first (A-11). Possible non-material amendment per S. Marchetti (00:39:19) |

## 4. Actions

| Ref | Action | Owner | Due | Source | Notes |
|---|---|---|---|---|---|
| A-01 | Chase Cadent response on substation position query | D. Rourke | TBC | 00:03:14 | Carried from DTM 12; "leave it with me" |
| A-02 | Issue parapet rebuild markups on GAs to architect | T. Akande | Fri 7 Aug 2026 *[inferred from "by Friday"]* | 00:03:29 | For the Stage 3 set |
| A-03 | Confirm railway arches licence position with Network Rail property team | Ravi, Harwood Legal — **not present; to be confirmed with him** | Mon 31 Aug 2026 *[inferred from "end of the month"]* | 00:06:04 | Proposed by D. Rourke on Ravi's behalf |
| A-04 | Email Ravi to pass on A-03 | D. Rourke | TBC | 00:06:29–00:06:36 | "Yep yep" taken as acceptance |
| A-05 | Confirm condition 14 (materials/sample panel) trigger wording with case officer — pre-commencement vs pre-superstructure | S. Marchetti | TBC ("might be quicker" than 15 Aug) | 00:06:57, 00:32:47–00:33:29 | Assigned in her absence, re-raised and accepted after she joined |
| A-06 | Obtain steer on flexibility of UGF target (condition 9) — informs roof decision | S. Marchetti | 15 Aug 2026 | 00:33:29 | Case officer's return date uncertain — see *To confirm* |
| A-07 | Issue design-stage TM59 overheating results | L. Petrova | Fri 14 Aug 2026 *[inferred from "end of next week"]* | 00:07:45 | May trail the Stage 3 report as an appendix (00:09:02) |
| A-08 | Check level 1 escape corridor clear width (c.1080mm reported) against Approved Document B | P. Nair | TBC | 00:11:10–00:12:22 | Linked to TV-01 — figure quoted in meeting is `[to verify]` |
| A-09 | Book CCTV survey of existing combined sewer, ahead of tender pricing set | **TBC — no owner taken** | Before tender issue | 00:23:10–00:27:17 | See UA-01; on critical path for drainage design per T. Akande |
| A-10 | Provide client Stage 3 sign-off | D. Rourke | 28 Aug 2026 | 00:30:04 | = D-05 |
| A-11 | Advise client on programme and fee impact of studio→one-bed conversion | H. Voss | Fri 7 Aug 2026 *[inferred from "this week"]* | 00:39:52 | Precedes any redesign; see VI-01/SC-01 |
| A-12 | Respond on investor-brochure CGI request — scope position and visualiser lead time | H. Voss | TBC (brochure prints "end of the month") | 00:40:39, 00:41:07 | See SC-02 |
| A-13 | Issue cost plan 3 incorporating firmed-up frame uplift, parapet rebuild and retained brise-soleil | M. Gill | 4 Sept 2026 | 00:42:34, 00:43:19 | Frame uplift figure unresolved — see CO-01 |
| A-14 | Confirm tender issue date (14 vs 21 Sept) with Amara (Ridgeline) and circulate | H. Voss ("we'll confirm it outside the meeting") | TBC | 00:42:47–00:43:00 | See CO-02 |

## 5. Discussed — no decision reached

- **Roof strategy: PV array vs biodiverse roof** (00:21:04–00:23:10). Options
  and trade-offs rehearsed (energy statement uplift vs urban greening; roof
  too small for both; hybrid compromised; c.£20k between them; either works
  structurally). Client explicitly deferred: "I don't want to decide that
  today without the planning angle" — open pending A-06.
- **Contingency level** (00:12:33). Reported as reduced and "thinner than I'd
  like"; the percentage is `[inaudible — figure not captured]`.
- **Substation position** (00:01:15–00:03:20). Remains open awaiting Cadent
  (A-01).
- **Network Rail asset engineer response on arch loading** (00:05:47).
  Outstanding six weeks; no new action agreed beyond the licence-side A-03.

## 6. Flags for the project lead

**VI-01 — Verbal instruction: studio-to-one-bed conversion** (00:38:11,
00:39:31). D. Rourke: *"can we lose the two studios on third and make them
one-beds? Just crack on with it, don't wait for a letter from us"* and
*"Consider it instructed."* A change to the approved mix at Stage 3
close-out, instructed orally with written instruction expressly deferred.
Written confirmation appears necessary under the relevant appointment
`[mechanism to verify against the appointment]` before redesign proceeds.
Cross-refs: SC-01, AU-01, D-07, A-11.

**SC-01 — Scope / fee: mid-stage plan change** (00:38:55). The conversion
touches the third-floor GA, area schedule, energy model and possibly the
planning drawings (potential non-material amendment per S. Marchetti,
00:39:19) at the point of Stage 3 close-out. May sit outside the current
stage scope and fee; H. Voss has reserved the position (A-11). The minutes
make no finding on what the appointment covers.

**SC-02 — Scope / fee: investor-brochure CGIs** (00:40:12–00:40:58). Two
marketing CGIs requested by "Jake" (Ridgeline investor comms), backed by
D. Rourke (*"Let's not make a thing of it, it's two images"*). Previous
visuals were produced under planning deliverables; marketing imagery may be
outside the appointed services `[appointment to verify]`. Response reserved
(A-12).

**CO-01 — Contradiction: steel frame uplift figure** (00:09:58 vs 00:42:15).
M. Gill stated the frame package uplift as *"about forty thousand"* and
later *"the sixty on the frame."* Challenged by D. Rourke (00:42:29); not
resolved in the meeting (*"I'll firm it up in cost plan three"*). Both
figures stand in the record; neither is adopted here.

**CO-02 — Contradiction: tender issue date** (00:29:31 vs 00:42:41).
D. Rourke stated tender *"goes out on the fourteenth of September"* (and
"fixed as far as the board's concerned"), later *"when the tender lands on
the twenty-first."* Challenged and left unresolved (*"September anyway…
check it with Amara offline"*). The 28 Aug sign-off date (D-05) was set
against the 14th — it may need revisiting once A-14 resolves the date.

**UA-01 — Unowned action: CCTV drainage survey** (00:23:10–00:27:17).
Agreed by all to be necessary and on the critical path; **no one took the
booking**. Recorded as A-09 with owner TBC — recommend resolving before the
tender programme absorbs the float.

**TV-01 — Figure quoted from memory: escape corridor width** (00:11:10).
T. Akande: *"Part B just wants 1050 clear for that occupancy, or is it
1100?"* The governing figure is not confirmed in these minutes: consult
Approved Document B (relevant volume and table for the building type) —
`[to verify]`. Check assigned as A-08. The reported design dimension is
c.1080mm clear.

**PR-01 — Programme / stage discipline: Stage 4 start at risk** (00:41:18–
00:41:52). Stage 4 structural package to begin before client Stage 3
sign-off (due 28 Aug), agreed verbally. M. Gill noted abortive time is
carried by no one in the cost plan (00:41:44). The exposure was accepted in
the meeting; recording it here makes the at-risk period visible rather than
casual.

**AU-01 — Authority unclear: unit-mix instruction ahead of board approval**
(00:39:31). D. Rourke: *"the board will be fine with it, I'll square it with
them at the next meeting."* The instruction in VI-01 therefore precedes the
stated client governance step. Acting on it before board confirmation is a
risk to be taken knowingly, if at all.

**Attendance flags.** S. Marchetti was in the apologies but joined at
00:32:40 — items minuted before then were discussed without planning input.
"Jake" spoke but appears on no invite list; surname and standing to request
deliverables to be confirmed. An action is assigned to Ravi (Harwood
Legal), who was not present (A-03).

## 7. To confirm

1. Owner for the CCTV drainage survey booking (A-09 / UA-01).
2. Tender issue date — 14 or 21 September (A-14 / CO-02); knock-on to the
   28 Aug sign-off if the 21st.
3. Steel frame uplift — £40k or £60k (CO-01); to be firmed in cost plan 3.
4. Contingency percentage — `[inaudible at 00:13:12]`; request from M. Gill.
5. Ravi's acceptance of A-03 and its end-August date — he was not present.
6. Due date for condition 14 confirmation (A-05) — "might be quicker" than
   15 Aug, not fixed.
7. Case officer's return from leave — three versions heard: "the 17th",
   "the 10th" (both hearsay, 00:07:31) and "the eleventh I think"
   (S. Marchetti, 00:33:29).
8. P. Nair's contribution at 00:06:52 — `[inaudible]`; confirm nothing
   substantive was lost.
9. "Jake"'s full name and role, for the record.

---

*Prepared from the meeting transcript only. Anything agreed off-call, before
the recording started, or in side channels is not captured here. Draft until
reviewed and issued by the project lead.*

---

> **Accompanying chat report (delivered alongside the file, not part of the
> minutes):** 14 actions captured — 5 with owner or date TBC, including one
> with no owner at all (the CCTV drainage survey). The flag that needs
> attention today is VI-01/AU-01: a verbal client instruction changing the
> approved unit mix, given ahead of board approval, with written instruction
> expressly waved away — decide now whether to seek written confirmation
> before any redesign starts. Two contradictions need resolving before
> issue: the frame uplift (£40k vs £60k) and the tender date (14 vs 21
> Sept), the latter of which underpins the 28 Aug sign-off date. One
> decision was reversed mid-meeting (brise-soleil deleted, then retained) —
> the minutes record the final position with both references. Note also the
> corridor-width figure quoted from memory: it is marked `[to verify]`
> against Approved Document B and has an assigned checker.
