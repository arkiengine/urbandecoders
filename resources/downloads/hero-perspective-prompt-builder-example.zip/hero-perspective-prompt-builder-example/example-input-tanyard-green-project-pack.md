# Tanyard Green — project pack for the hero image

**From:** Erin Slattery, associate, Ardley Nash Architects
**To:** visualisation
**Date:** 3 August 2026
**Re:** Tanyard Green — hero image for the DAS cover (and a couple of others)

Pulling this together from what we've got. Submission is the 4th of September so
we need the cover image in the next fortnight. I've copied in the bits that
matter from the design vision, the massing schedule, the materials schedule and
Ravi's site notes, plus what Dominic at Fenwick Cheyne wants for the sales side.
Some of it doesn't agree with itself — shout if that's a problem.

---

## 1. The scheme

Tanyard Green is a 46-home scheme with 620 sqm of workspace and a small café
unit on the site of the former Tanyard Green council depot, Melbrook
(Nottinghamshire market town, pop. ~14,000). Client is Fenwick Cheyne Living.
We're at RIBA Stage 3; the planning application goes in on 4 September 2026.

Three blocks around a new courtyard, with a new pedestrian route cut through
from Sheepgate to the market square.

- **Block A** — north side, fronting the market square approach. Apartments over
  workspace at ground floor.
- **Block B** — east side, terraced houses.
- **Block C** — west side, apartments over the café unit.

## 2. From the design vision statement (issue P02, 12 June 2026)

> Tanyard Green will be the new heart of Melbrook — a five-storey landmark to
> the north announcing the scheme from the market square approach, stepping down
> to a domestic scale along Sheepgate. A buff brick picks up the limestone of the
> market square and the church tower beyond. At the top of Block A, a shared roof
> terrace gives residents views across the rooftops to St Cuthbert's tower. The
> courtyard is a sunny, south-facing social space with generous planting — an
> award-winning quality of place from day one.

## 3. From the massing schedule (rev C, 21 July 2026)

| Block | Storeys | Parapet | Notes |
|---|---|---|---|
| A | 4 + recessed roof plant | 13.8 m | Plant enclosure and PV array at roof level, set back 2.5 m from all faces |
| B | 2–3 | 9.2 m | Terraces, pitched roof |
| C | 3 | 10.4 m | Flat roof |

Floor-to-floor is 3.0 m throughout, ground floor 3.6 m in Block A.

Datum for the parapet figures not stated on the schedule — assume above ground
level at the courtyard, but Ravi may know.

## 4. From the materials schedule (rev B, 9 July 2026)

| Element | Specification |
|---|---|
| Blocks A and B, principal walls | Facing brick — Wienerberger *Ashdown Crowborough* multi red stock, wire-cut |
| Block C, principal walls | Facing brick — as above |
| Ground floor commercial frontage, Block A | Precast concrete reveal frame, exposed aggregate, warm grey |
| Window frames | Powder-coated aluminium, RAL 7022 (umbra grey) |
| Roof, Block B | Natural slate |
| Balconies | Galvanised steel, open balustrade — Blocks A and C only |
| Courtyard paving | Buff-toned concrete flag, brushed finish |

Brick is still live, to be fair — Dominic asked to see a buff option as well and
the elevation note (below) has it as TBC.

## 5. From the key elevation note (sheet 2101 rev P03, 24 July 2026)

Courtyard elevation, Block A — the main elevation, and the one we want as the
hero. Brick pier and recessed-panel rhythm at 3.6 m centres, deep window reveals,
projecting steel balconies to the upper two residential floors, workspace glazing
at ground floor in the precast frame. The pedestrian route through to the market
square is expressed as a 4.2 m-wide, double-height cut through the block on the
courtyard's north-west corner.

> **Note on sheet:** Brick to be confirmed — two options with client. Window
> pattern to the **east elevation (Block B, Sheepgate side)** is indicative only
> and will be developed at Stage 4.

Landscape GA is with Thorne Vale and hasn't landed yet — planting positions on
2101 are indicative.

## 6. From Ravi's site notes (site visit, 2 July 2026)

- Site is bounded by Sheepgate to the east, the market square approach road to
  the north, and the rear of the Corn Exchange car park to the south.
- **The market square is to the north of the site.** The courtyard sits between
  the three blocks and opens toward Sheepgate.
- **Rathmore House** — 1970s four-storey council office block, brown brick with a
  blank flank wall — sits directly opposite the site across the market square
  approach road, facing what will be the main entrance to Block A. It is not
  coming down; the Council occupy the ground two floors.
- The **Melbrook Cut** (canal arm) is about 240 m south-west of the site, beyond
  the ring road. It has been drained since 2019. There is a restoration bid in
  with the Canal & River Trust but nothing funded.
- Two mature limes on the Sheepgate boundary are retained (TPO — reference not
  to hand).
- Site plan with the north point is Appendix B, to follow from Priya.

## 7. Landscape (from Thorne Vale's planting note, 15 July 2026)

Courtyard planting is multi-stem birch and amelanchier, 8–10 cm girth
semi-mature standards at planting, with a rain garden on the courtyard's low
side. Two retained limes as above. Trees at planting will read as slender.

## 8. What we need the image to do

Dominic at Fenwick Cheyne and Marcus (planning consultant, Belvoir Fenn) have
both weighed in, and they don't entirely agree:

**Marcus (planning):**
- The DAS cover image, plus two boards for the public consultation on 20 August.
- He'd like "a verified view of the scheme from the market square for the
  committee" — says it carries more weight.
- Officers apparently don't like people in the images — "keep them clean".

**Dominic (client / sales):**
- Wants the same image doing double duty for the sales brochure and the
  launch site.
- "Get the canal in shot if you can — water and narrowboats, it's what sells a
  place like this."
- "Show the square finished with the Phase 2 workspace block closing the north
  side — that's the vision." (Phase 2 is on the Corn Exchange car park; no
  consent, land not in Fenwick Cheyne's ownership, heads of terms only.)
- "Please show the trees mature, it looks bare otherwise — it'll all fill in."
- "Make it busy — café tables out, buzzing, that café-culture feel." (The café
  unit is 45 sqm; a tenant is in discussion, nothing signed.)
- Wants it "cinematic, golden hour raking across the main elevation".

## 9. Practicalities

- Moodboard is on the shared drive — warm brick, soft planting, that sort of
  thing. I can send it over if you need it.
- We'd use Nano Banana. Dominic reckons it does 4K single-shot now, which would
  save us upscaling.
- 16:9 for the boards; the DAS cover is portrait, so we may need both.

Thanks — Erin.
