# Tanyard Green — hero shot brief

| | |
|---|---|
| **Project** | Tanyard Green, Melbrook |
| **Stage** | RIBA Stage 3; planning submission 4 September 2026 |
| **Run date** | 5 August 2026 |
| **Audience** | Planning submission (DAS cover) + public consultation boards, 20 August. A sales/marketing set was also requested — see Flag 12; it is **not** covered by this brief. |
| **Image tool** | Nano Banana / Gemini wording |
| **Sources** | Project pack email (E. Slattery, 3 Aug 2026) quoting: design vision statement issue P02 (12 Jun 2026); massing schedule rev C (21 Jul 2026); materials schedule rev B (9 Jul 2026); key elevation note sheet 2101 rev P03 (24 Jul 2026); site notes (R., site visit 2 Jul 2026); Thorne Vale planting note (15 Jul 2026) |
| **Not supplied** | Appendix B site plan with north point; landscape GA; moodboard; any drawing or model view |

> **Illustrative CGI — not a verified view.** Images generated from these
> prompts are illustrative visualisations produced from written project
> material. They are not verified views or AVRs, they carry no surveyed camera
> position, and they must not be captioned or presented as such. See Flag 3.

---

## 1. Interview record

| # | Question | Answer / default applied |
|---|---|---|
| 1 | Audience and use | **Answered:** DAS cover + two consultation boards. Sales use requested by the client but **held** — one image cannot serve both honestly here (Flag 12). |
| 2 | One hero with variants, or a shot set? | **Answered:** two shots — Context (DAS cover) and Programme (consultation board 1). Shots 03–06 of the standard family not run. |
| 3 | Hero subject | **Answered:** Block A seen on the approach from the market square, plus the courtyard. |
| 4 | Visual tone | **Default applied:** photoreal architectural visualisation. "Cinematic" was requested and declined for a planning-facing set (Flag 11). |
| 5 | Time of day | **Default applied with correction:** soft late afternoon, adjusted per shot for actual orientation. The requested golden-hour rake on Block A's market-square elevation is not physically available (Flag 1). |
| 6 | Aspect ratio | **Answered:** 16:9 for boards. The DAS cover is portrait — see the note under Shot 01; portrait needs a re-prompt, not a crop. |
| 7 | Image tool | **Default applied:** Nano Banana wording. The 4K single-shot claim is unverified (Flag 14). |
| 8 | People in frame | **Open.** Planning consultant wants none; client wants a busy scene. Baseline prompts carry sparse, plausible occupancy and a one-line "no people" swap is noted per shot (Flag 6). |

Items 1, 6 and 8 remain open and are carried into Flags & queries.

## 2. Source fact base

| Fact | Source | Status |
|---|---|---|
| 46 homes, 620 sqm workspace, one café unit (45 sqm) | Pack §1 | Stated |
| Three blocks (A north, B east, C west) around a new courtyard | Pack §1 | Stated |
| New pedestrian route Sheepgate → market square, expressed as a 4.2 m wide, double-height cut at the courtyard's north-west corner | Elevation note 2101 P03 | Stated |
| Block A: 4 storeys + recessed roof plant, parapet 13.8 m | Massing schedule rev C | Stated |
| Block A: "five-storey landmark" | Design vision P02 | Stated — **conflicts** with the above (Flag 2) |
| Parapet datum (AOD or above courtyard ground level) | — | **[not stated]** |
| Floor-to-floor 3.0 m; Block A ground floor 3.6 m | Massing schedule rev C | Stated |
| Block B 2–3 storeys, 9.2 m parapet, pitched natural slate roof | Massing schedule rev C | Stated |
| Block C 3 storeys, 10.4 m parapet, flat roof | Massing schedule rev C | Stated |
| Principal walls: Wienerberger Ashdown Crowborough multi red stock, wire-cut | Materials schedule rev B | Stated — **contested** by a later document (Flag 4) |
| Brick "to be confirmed — two options with client" | Elevation note 2101 P03, 24 Jul (later than the materials schedule) | Stated |
| Precast concrete reveal frame, exposed aggregate warm grey, to Block A ground-floor commercial frontage | Materials schedule rev B | Stated |
| Windows: powder-coated aluminium RAL 7022 umbra grey | Materials schedule rev B | Stated |
| Balconies: galvanised steel, open balustrade, Blocks A and C only | Materials schedule rev B | Stated |
| Courtyard paving: buff-toned brushed concrete flag | Materials schedule rev B | Stated |
| Block A courtyard elevation: brick pier and recessed panel rhythm at 3.6 m centres, deep reveals, projecting steel balconies to upper two residential floors, workspace glazing in precast frame at ground | Elevation note 2101 P03 | Stated |
| Market square lies **north** of the site | Site notes | Stated |
| Block A's market-square elevation therefore faces **north**; its courtyard elevation faces **south** | Site notes + pack §1 | Inferred — direct consequence of block position and square location. Unconfirmed against a north point (Appendix B absent) |
| Rathmore House: 1970s four-storey brown-brick council offices, blank flank wall, directly opposite the Block A entrance across the approach road, retained and occupied | Site notes | Stated |
| Melbrook Cut is ~240 m south-west, beyond the ring road, drained since 2019, restoration unfunded | Site notes | Stated |
| Two mature limes retained on the Sheepgate boundary (TPO ref not to hand) | Site notes | Stated / TPO ref **[to verify]** |
| Courtyard planting: multi-stem birch and amelanchier, 8–10 cm girth semi-mature standards at planting; rain garden on the courtyard's low side | Thorne Vale planting note | Stated |
| Which side of the courtyard is the low side | — | **[not stated]** |
| Whether the courtyard is enclosed on its east side by Block B or open toward Sheepgate | Pack §1 vs site notes | **Conflict** (Flag 5) |
| Roof terrace on Block A | Design vision P02 | Stated — **contradicted** by the massing schedule's roof plant + PV (Flag 7) |
| Window pattern to the east (Sheepgate) elevation | Elevation note 2101 P03 | **Indicative only, undeveloped** — excluded from all prompts (Flag 8) |
| Landscape GA / planting positions | — | **[not stated]** — indicative on 2101 |
| Café tenant | Pack §8 | In discussion, nothing signed — no branded fit-out, signage or awning in any prompt |
| Phase 2 workspace block | Pack §8 | No consent, third-party land, heads of terms only — excluded (Flag 9) |
| Moodboard / reference images | Pack §9 | **[not stated]** — not supplied. Design language is written-source only. |
| St Cuthbert's tower visibility from any proposed viewpoint | — | **[not stated]** — excluded from frames (Flag 7) |

## 3. Flags & queries

Logged, not resolved. Numbered for reply.

1. **Golden hour on a north-facing elevation is not available.** The client asks
   for "golden hour raking across the main elevation". Block A's market-square
   elevation faces north (Inferred, above); in the UK a north-facing elevation
   receives no direct low sun. Shot 01's light spec uses the honest alternative
   and explains it. **[to verify against a sun path / shadow study]** — a Rhino
   or Revit sun study against Appendix B's north point settles this, not taste.
2. **Storey count conflict.** Vision statement "five-storey landmark" vs massing
   schedule rev C "4 + recessed roof plant". The geometry lock carries the
   **massing schedule** reading (four storeys plus a set-back plant enclosure) as
   the conservative and more recent figure, labelled as such. Confirm before the
   images are used externally: a render showing five occupied storeys against a
   four-storey application drawing is a gift to an objector.
3. **"Verified view" cannot be produced here.** The planning consultant asks for
   "a verified view from the market square". Verified views / AVRs follow a
   separate methodology with surveyed camera positions, calibrated focal lengths
   and photographic base plates (Landscape Institute TGN 06/19 **[to verify]**
   for current status and requirements). This skill produces illustrative CGI
   only. If the committee needs a verified view, it needs a specialist
   appointment, and it needs one now — not in the last fortnight before
   submission.
4. **Brick colour unresolved.** Materials schedule rev B (9 Jul) states Ashdown
   Crowborough multi red; the later elevation note (24 Jul) says brick is TBC
   with two options, and the vision statement describes a buff brick. Prompts
   carry the issued schedule's red stock, footnoted. **If the client selects
   buff, both images must be regenerated, not relit** — and a side-by-side brick
   comparison at a fixed camera is a facade study, not a hero shot: use
   facade-maker for that.
5. **Courtyard enclosure conflict.** Pack §1 places Block B on the courtyard's
   east side; the site notes say the courtyard "opens toward Sheepgate", which is
   also east. Both cannot be true. Shot 02's camera and framing are chosen so
   the east edge is oblique and not the subject; the prompts do not describe it.
   Resolve against Appendix B.
6. **People: two contradictory instructions.** "Officers don't like people —
   keep them clean" vs "make it busy, café tables out, buzzing". Baseline prompts
   carry sparse, plausible occupancy for 46 homes and a 45 sqm café. A "busy
   café-culture" scene is an occupancy claim the scheme cannot generate and is
   declined; an unpeopled variant is a one-line swap, noted per shot. Confirm
   which the boards use.
7. **Roof terrace vs roof plant.** The vision statement describes a shared roof
   terrace with views to St Cuthbert's tower; the massing schedule puts plant and
   PV, set back 2.5 m, at Block A roof level. No roof terrace, occupied roof, or
   church-tower view appears in any prompt until this is resolved — showing one
   would invent programme.
8. **East (Sheepgate) elevation is undeveloped.** Its window pattern is
   indicative pending Stage 4. It is kept out of frame in both shots. Do not
   accept a re-prompt that brings it into view before 2101 is developed.
9. **Phase 2 excluded.** The requested "square finished with the Phase 2
   workspace block" has no consent and sits on third-party land. It does not
   appear in planning- or consultation-facing imagery. It can be produced later
   as a separate variant captioned *indicative — Phase 2, not consented, land
   not in the applicant's control*, for non-planning use only, and that label
   must travel with the file.
10. **Mature planting declined.** "Show the trees mature" against a planting spec
    of 8–10 cm girth semi-mature standards. Consultation imagery showing canopy
    the scheme will not have for a decade is the single most commonly challenged
    misrepresentation at committee. Baseline shows the planted spec. A separately
    labelled *year 10 establishment* variant can be produced on explicit
    instruction, with the label carried into the caption.
11. **Terminology.** "Cinematic", "award-winning", "the new heart of Melbrook"
    are aspirations, not visual facts, and "cinematic" actively degrades
    photoreal output — it pushes generators toward warped geometry and impossible
    light. Excluded from prompts.
12. **Two audiences, one image — declined.** The DAS/consultation set is built to
    the strict standard here. A sales set can follow with any stylisations
    logged, but the canal request (Flag 13) cannot be met in either set, and
    marketing imagery of a residential scheme carries its own consumer-facing
    obligations — check with the client's own marketing compliance advice
    **[to verify]** before the sales set is briefed.
13. **Canal declined — borrowed geography.** The Melbrook Cut is ~240 m away,
    beyond the ring road, drained since 2019, with restoration unfunded. Water
    and narrowboats will not appear in any prompt for any audience: the site is
    not canalside, and an image saying otherwise misstates the setting to both a
    committee and a buyer.
14. **Rathmore House stays.** The request to soften or omit it is declined for
    planning-facing imagery. Choosing a viewpoint where it falls largely outside
    the frame is a legitimate framing decision and is what Shot 01 Option B does
    — a slice of its flank remains visible at true scale, and that is recorded
    here so the choice is visible rather than hidden.
15. **Tool claim unverified.** "Nano Banana does 4K single-shot" is a recalled
    claim. **[to verify]** against current tool documentation; assume native
    output plus a separate upscale, and note that the portrait DAS cover needs
    its own generation at 2:3 or 4:5, not a crop of the 16:9 board image — a crop
    changes the framing the lens choice was made for.
16. **No reference imagery supplied.** The moodboard was not attached, so
    material and atmosphere language derives from the written schedules only. If
    the moodboard governs, send it and the prompts should be re-issued.

## 4. Geometry lock

All prompts obey the following, and only camera position, light and atmosphere
vary between variants:

- Three blocks around a courtyard: **A north (4 storeys + set-back roof plant,
  parapet 13.8 m — conservative reading per Flag 2), B east (2–3 storeys, pitched
  slate), C west (3 storeys, flat roof)**.
- Block A courtyard elevation: brick pier and recessed panel rhythm at 3.6 m
  centres, deep reveals, projecting steel balconies to the upper two residential
  floors, ground-floor workspace glazing set in a warm grey exposed-aggregate
  precast frame.
- The 4.2 m wide, double-height pedestrian cut at the courtyard's north-west
  corner.
- **Rathmore House retained** — four storeys, brown brick, blank flank —
  opposite the Block A entrance, at true scale wherever it falls in frame.
- Two retained mature limes on the Sheepgate boundary.
- Courtyard trees at planted size (8–10 cm girth standards), rain garden, buff
  brushed concrete flag paving.
- **Excluded:** roof terrace, occupied roof, Phase 2, canal or any water, church
  tower, café branding or signage, and any window pattern to the east elevation.
- **Held open:** brick colour (Flag 4), courtyard east edge (Flag 5).

## 5. Shot list

| # | Shot | Purpose | Audience | Status |
|---|---|---|---|---|
| 01 | Context — market square approach | The DAS cover; how the scheme meets the town | Planning + board 2 | **Delivered** — Option B chosen |
| 02 | Programme — courtyard | Consultation board 1; the place residents get | Consultation | **Delivered** — Option A chosen |
| 03 | "Verified view from the market square" | Requested by planning consultant | Committee | **Not deliverable** — see Flag 3 |
| — | Sales / marketing set | Brochure and launch site | Sales | **Held** — see Flags 12, 13 |

---

## 6. Shot 01 — Context, market square approach

**Purpose.** The image that opens the DAS: Block A seen as a visitor arriving
from the market square actually sees it, with the new pedestrian route legible
and the existing street context present.

**Options put to the architect.**

- **Option A — square-edge two-point.** Eye-level 1.6 m, 35 mm, two-point from
  the south edge of the market square, roughly 45 m out. Whole north elevation of
  Block A in frame; Rathmore House's flank at the left edge. Honest and plain;
  the block reads slightly distant.
- **Option B — approach-road oblique** *(recommended, chosen)*. Eye-level 1.6 m,
  50 mm, from the approach-road pavement about 28 m out, oblique on the entrance
  and the double-height cut. The 50 mm avoids the wide-lens exaggeration that
  makes a four-storey block look taller and a street look wider than it is; the
  cut through to the courtyard reads as the route it is; a slice of Rathmore
  House's flank stays in frame at true scale.
- **Option C — elevated oblique.** 12 m from the Corn Exchange car park deck,
  35 mm. Reads massing and courtyard together, but it is not a view any member of
  the public has, and it looks over Rathmore House rather than at it. Flattering,
  and for that reason not recommended for a committee-facing cover.

**Camera spec (chosen).** Eye-level 1.6 m; 50 mm; two-point perspective;
approach-road pavement, ~28 m from the Block A entrance, oblique to the north
elevation with the double-height cut on the right of frame; east elevation out
of frame (Flag 8).

**Light spec.** Block A's market-square elevation faces north, so it receives no
direct low sun at any time of year (Flag 1). Baseline is bright, high, thin
overcast: a soft directional wash from the south-west, the north elevation in
even ambient light, brick colour reading true, no hard shadows to invent
modelling that will not occur. **[to verify against a sun study]**

**Mood.** Calm, civic, ordinary-in-a-good-way. No stylisation terms.

**Entourage and context.** Two or three passers-by at plausible density for a
market town weekday; no crowds, no café spill (the café is on the courtyard side
and has no tenant). Retained limes at existing size; street trees only where the
site notes place them. Rathmore House present at four storeys, brown brick,
blank flank. No water, no Phase 2, no roof terrace. Parked cars only as the
existing street arrangement implies — **[not stated]**, so kept minimal and
generic.

### Final prompt — Shot 01 baseline

```
A photorealistic architectural visualisation of a new four-storey brick
residential and workspace block seen from the pavement of a market square
approach road in a small English market town, viewed obliquely from about 28
metres away at standing eye level.

The block presents a calm brick elevation of vertical piers and recessed panels
at regular bays, with deep window reveals and dark grey powder-coated aluminium
windows. At ground floor, workspace glazing sits within a warm grey exposed-
aggregate precast concrete frame. A 4.2 metre wide, double-height opening cuts
through the block on the right of frame, revealing a glimpse of a planted
courtyard beyond. Immediately opposite, at the left edge of frame, stands an
existing four-storey 1970s brown brick office building with a blank flank wall,
shown at its true size and unaltered. Two or three people walk on the pavement.
Young courtyard trees are just visible through the cut, slender and recently
planted.

Standing eye level 1.6 m, 50 mm lens, two-point perspective, natural vertical
lines. Bright high overcast daylight with soft directional light from the south-
west; the elevation faces north and receives no direct sunlight; even ambient
light, no hard shadows. 16:9 landscape. Photorealistic, neutral, documentary
architectural photography.

Geometry lock: preserve the massing, storey count and elevation composition
exactly as described — four storeys with a set-back roof plant enclosure, brick
piers and recessed panels at regular bays, projecting steel balconies to the
upper two residential floors only, and the double-height pedestrian cut. Keep
the existing 1970s office building opposite present at its true four-storey
scale. Do not redesign, move, add or remove buildings or landscape elements.
Only camera position and lighting may vary.

Negative: no redesign. No warped or exaggerated geometry. No change to layout,
massing or storey count. No fifth storey. No invented windows, doors, balconies,
signage or roof structures. No roof terrace or occupied roof. No canal, river,
water, boats, hills or landmarks. No mature or established trees. No crowds. No
café branding, awnings or shopfront signage. No painterly or cinematic
stylisation. No text, labels or watermarks.
```

### Final prompt — Shot 01 atmosphere variant (same facts, different light)

```
[As the baseline prompt above, with the light and atmosphere paragraph
replaced by:]

Late afternoon shortly after rain. Wet pavement with soft reflections, breaking
cloud, low sun from the west catching the upper brickwork of the block's western
return and the roofline; the north-facing main elevation remains in cool
indirect light, unlit by direct sun. Warm interior light beginning to show in
the ground-floor workspace glazing. 16:9 landscape. Photorealistic, neutral,
documentary architectural photography.

[Geometry lock and negative block unchanged.]
```

**Provenance footnotes.** Brick described by colour family only, pending Flag 4 —
if the schedule's Ashdown Crowborough multi red is confirmed, add "multi red
stock brick, wire-cut" to the design-language paragraph. "Four storeys" is the
conservative reading of a live conflict (Flag 2). Street parking and pavement
arrangement are **[not stated]**. Portrait DAS cover: re-prompt at 2:3 with the
same lock and a 35 mm lens to hold the same content in a taller frame — do not
crop the 16:9.

**Unpeopled swap (if the officers' preference governs, Flag 6):** delete the
sentence about people and add "no people" to the negative block.

---

## 7. Shot 02 — Programme, the courtyard

**Purpose.** Consultation board 1: what the courtyard is actually like to stand
in — scale, materials, planting, the route through.

**Options put to the architect.**

- **Option A — courtyard length, standard lens** *(recommended, chosen)*.
  Eye-level 1.6 m, 35 mm, two-point from the courtyard's south edge looking north
  across the rain garden to Block A's courtyard elevation, the double-height cut
  at the left of frame. Reads the hero elevation, the planting and the route
  without flattering the dimensions.
- **Option B — seated wide.** Seated 1.2 m, 24 mm, low beside the rain garden.
  Intimate and generous, but a 24 mm lens materially exaggerates the size of a
  courtyard, and courtyard dimensions are precisely what consultees will ask
  about. Not recommended for a consultation board.
- **Option C — threshold framing.** Standing within the double-height cut,
  50 mm, framed by the opening looking into the courtyard. Strong on the route,
  weaker on the elevation the board is meant to explain.

**Camera spec (chosen).** Eye-level 1.6 m; 35 mm; two-point; courtyard south
edge looking north; the cut at the left of frame; the east side of the courtyard
oblique and not the subject (Flag 5).

**Light spec.** Block A's courtyard elevation faces south, so this elevation
genuinely is sunlit — the same reasoning that rules out golden hour in Shot 01
permits late-afternoon sun here. Baseline: late-afternoon sun from the
west-south-west raking across the brick piers and picking out the reveals, with
Block C (3 storeys, west side) casting shadow across the western part of the
courtyard. **[to verify against a shadow study]** — the extent of that shadow is
a real consultation question and should not be guessed generously.

**Mood.** Domestic, layered, quiet.

**Entourage and context.** Four to six people, plausible for 46 homes at late
afternoon: someone crossing to a front door, two people sitting, a child.
Courtyard trees at planted size — multi-stem birch and amelanchier, slender
stems, light canopy. Rain garden planted but young; buff brushed concrete flags.
No café tables, no signage, no branding (no tenant). Planting positions
indicative — kept loose and footnoted rather than drawn as fact.

### Final prompt — Shot 02 baseline

```
A photorealistic architectural visualisation of a new residential courtyard in a
small English market town, viewed at standing eye level from the southern edge
of the courtyard looking north.

The far side of the courtyard is a four-storey brick elevation composed of
vertical brick piers and recessed panels at regular 3.6 metre bays, with deep
window reveals, dark grey powder-coated aluminium windows, and slim projecting
galvanised steel balconies with open balustrades to the upper two residential
floors only. At ground level, workspace glazing sits within a warm grey exposed-
aggregate precast concrete frame. At the left of frame, a 4.2 metre wide, double-
height opening cuts through the block, framing a view out toward the town beyond.
A three-storey brick block with a flat roof forms the courtyard's western side.

The courtyard is paved in buff brushed concrete flags, with a planted rain garden
across the lower part of the space. Newly planted multi-stem birch and
amelanchier stand slender and lightly canopied, clearly young. Four to six
residents occupy the space quietly — one crossing toward a front door, two seated,
a child.

Standing eye level 1.6 m, 35 mm lens, two-point perspective, natural vertical
lines. Late afternoon sunlight from the west-south-west raking across the brick
piers and catching the window reveals; the western side of the courtyard falls
into the shadow of the three-storey block opposite. Clear soft sky. 16:9
landscape. Photorealistic, neutral, documentary architectural photography.

Geometry lock: preserve the massing, storey count and elevation composition
exactly as described — four storeys to the north block with a set-back roof plant
enclosure, three storeys with a flat roof to the west block, brick pier and
recessed panel rhythm at regular bays, balconies to the upper two residential
floors only, and the double-height pedestrian cut at the courtyard's north-west
corner. Do not redesign, move, add or remove buildings or landscape elements.
Only camera position and lighting may vary.

Negative: no redesign. No warped or exaggerated geometry. No change to layout,
massing or storey count. No fifth storey. No roof terrace, roof garden or
occupied roof. No invented windows, doors, balconies, signage or roof structures.
No mature or established trees, no large canopies. No canal, river, water, boats
or distant hills. No church tower or landmark in view. No café tables, awnings,
umbrellas, shopfronts or branding. No crowds or busy street scene. No painterly
or cinematic stylisation. No text, labels or watermarks.
```

### Final prompt — Shot 02 atmosphere variant (same facts, different light)

```
[As the baseline prompt above, with the light and atmosphere paragraph
replaced by:]

Early evening, just after sunset. Cool blue ambient sky light, no direct sun.
Warm interior light from apartment windows and the ground-floor workspace
glazing; low-level courtyard lighting at path edges only. Two people in the
courtyard. 16:9 landscape. Photorealistic, neutral, documentary architectural
photography.

[Geometry lock and negative block unchanged, with the addition:
no lit signage, no floodlighting or uplighting of the facade, no light spill
from any roof level.]
```

**Provenance footnotes.** Rain garden position: the planting note places it on
the courtyard's low side, and which side that is is **[not stated]** — the prompt
places it across the lower part of frame and this must be checked against the
landscape GA when it lands. Planting positions indicative. Courtyard external
lighting design **[not stated]** — the evening variant deliberately keeps it
generic and low-level rather than inventing a lighting scheme. Balcony extent
per materials schedule rev B (Blocks A and C only).

---

## 8. Shot 03 — not deliverable

The requested "verified view of the scheme from the market square" is not
produced. Illustrative CGI cannot be presented as a verified view or AVR (Flag
3). If a committee-facing verified view is required, it needs a separate
methodology and appointment; if what is actually wanted is a persuasive
approach image, Shot 01 is that image and should be captioned honestly.

## 9. Consistency checklist

Hold these constant across every image in the set, and re-check after any
re-prompt:

| Item | Locked value |
|---|---|
| Brick | One colour family across all images; pending Flag 4. If it changes, **all** images regenerate. |
| Storey counts | A: 4 + set-back plant. B: 2–3, pitched slate. C: 3, flat roof. |
| Balconies | Blocks A and C only, galvanised steel, open balustrade. |
| Windows | RAL 7022 umbra grey aluminium, deep reveals, throughout. |
| Ground floor Block A | Warm grey exposed-aggregate precast frame. |
| Planting | Planted size in every image. No image in the set shows established canopy. |
| Neighbours | Rathmore House present at true scale wherever it falls in frame. |
| Sun logic | North elevation never in direct sun; courtyard elevation sunlit in the afternoon. The two shots must not contradict each other on time of day within one board. |
| Excluded everywhere | Roof terrace, Phase 2, water, church tower, café branding, east elevation fenestration. |
| Caption | Every image goes out captioned "Illustrative visualisation — not a verified view." |

## 10. Caveats (also reported in chat)

- **Two prompt elements rest on inference, not statement:** the north-facing
  orientation of Block A's market-square elevation (and therefore both light
  specs) is inferred from the site notes because the north-point site plan was
  not supplied. If Appendix B contradicts it, both shots are wrong on light.
- **The biggest source conflict is the storey count** — five in the vision
  statement, four plus plant in the massing schedule. Images were built on four.
  Confirm before anything leaves the office.
- **Three requests were declined and are logged**, not quietly dropped: the
  canal, the Phase 2 block, and mature planting. One (removing Rathmore House)
  was declined and partly addressed by viewpoint choice, which is recorded.
- **Two questions block sign-off:** brick colour, and whether the boards carry
  people.
- **Nothing here is a verified view**, and no image in this set may be
  described as one.
