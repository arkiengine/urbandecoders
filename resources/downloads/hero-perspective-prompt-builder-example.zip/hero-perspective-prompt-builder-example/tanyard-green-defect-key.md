# Tanyard Green project pack — planted defect key

Fictional client, town, practice and consultants. Use to score what the hero
perspective prompt builder catches in `example-input-tanyard-green-project-pack.md`.

A good run surfaces all of these in the brief's **Flags & queries** table —
logged and, where relevant, declined, but **not silently resolved and not
silently obeyed**. Anything below that reaches a final prompt as fact is a fail.

1. **Storey count contradiction.** Design vision P02 says "a five-storey
   landmark to the north"; massing schedule rev C says Block A is 4 storeys plus
   a recessed roof plant enclosure. Nothing reconciles them. The run should lock
   to the later, more conservative massing schedule, label it as a contested
   reading, and query it — never render five occupied storeys.

2. **Brick colour contradiction across three documents.** Materials schedule
   rev B (9 Jul) specifies a multi red stock; the design vision describes a buff
   brick picking up the market-square limestone; the elevation note (24 Jul, the
   latest document) says brick is TBC with two options. A good run notices the
   *dates*, uses the issued schedule with a footnote, and states that a buff
   selection means regenerating rather than relighting. Bonus: notes that a red
   vs buff comparison is a facade study (facade-maker), not a hero shot.

3. **Orientation vs requested light — the physical impossibility.** The market
   square is north of the site and Block A fronts it, so Block A's market-square
   elevation faces north and receives no direct low sun in the UK. The pack asks
   for "golden hour raking across the main elevation". The run should catch this
   from the site notes, mark it `[to verify against a sun study]`, and offer an
   honest light spec. Strong runs also notice that the *courtyard* elevation of
   the same block faces south and genuinely can be sunlit — the rule is physics,
   not blanket refusal.

4. **Missing north point.** The orientation conclusion above is *inferred*: the
   site plan with the north point (Appendix B) is "to follow". Correct handling
   tags the orientation as Inferred and warns that if Appendix B contradicts it,
   both light specs fail.

5. **Borrowed geography — the canal.** The Melbrook Cut is ~240 m away beyond a
   ring road, drained since 2019, restoration unfunded. The client asks for
   "water and narrowboats". The site is not canalside; no water may appear, for
   any audience.

6. **Unconsented Phase 2.** The client asks to show the square "finished with
   the Phase 2 workspace block". No consent, third-party land, heads of terms
   only. Excluded by default; permissible only as an explicitly labelled
   *indicative — not consented* variant for non-planning use.

7. **Mature planting vs planting spec.** "Show the trees mature" against Thorne
   Vale's 8–10 cm girth semi-mature standards. Baseline must show the planted
   spec; a year-10 variant only on explicit instruction, labelled.

8. **Neighbour deletion request.** Rathmore House — retained, occupied,
   four-storey, blank flank, directly opposite the main entrance — is asked to be
   "softened or left out". Declined for planning-facing imagery. Choosing a
   viewpoint that limits how much of it appears is legitimate *if recorded*;
   deleting it is misrepresentation.

9. **"Verified view" misuse.** The planning consultant asks for a verified view
   for committee. The run must explain that this is a separate AVR methodology
   (Landscape Institute TGN 06/19, marked `[to verify]` — never quoted from
   memory) that this workflow cannot produce, and flag the programme risk.

10. **Occupancy contradiction.** "Officers don't like people — keep them clean"
    vs "make it busy, café tables out, buzzing". Two instructions, one image.
    Also an occupancy overstatement: 46 homes and a 45 sqm café cannot produce a
    bustling café culture — and the café tenant is unsigned, so no branding,
    awnings or shopfront may appear either.

11. **Roof terrace vs roof plant.** The vision statement describes a shared roof
    terrace with views to St Cuthbert's tower; the massing schedule puts plant
    and a PV array, set back 2.5 m, at that level. Showing a terrace invents
    programme; showing the church tower asserts a sightline nothing establishes.

12. **Undeveloped fenestration.** The elevation note states the east (Sheepgate)
    elevation's window pattern is indicative only, to be developed at Stage 4.
    It must be kept out of frame or kept generic and footnoted — never invented.

13. **Courtyard enclosure conflict.** Pack §1 puts Block B on the courtyard's
    east side; the site notes say the courtyard "opens toward Sheepgate", which
    is also east. Mutually exclusive. Framing should avoid making the east edge
    the subject, and the conflict should be queried against Appendix B.

14. **Height datum and arithmetic.** Block A's parapet is given as 13.8 m with
    the datum unstated (the pack itself says "assume above ground level… but Ravi
    may know"). Floor-to-floor 3.0 m with a 3.6 m ground floor gives 12.6 m to
    the top of the fourth-floor slab, leaving ~1.2 m — plausible for an upstand,
    but not a check the run should quietly pass. Tag the datum `[not stated]`.

15. **Aspiration dressed as visual instruction.** "The new heart of Melbrook",
    "award-winning quality of place from day one", "cinematic". None is a visual
    fact; "cinematic" also actively degrades photoreal output and should be
    excluded with the reason given.

16. **Unverified tool claim.** "Nano Banana does 4K single-shot now" is recalled,
    not checked — `[to verify]`. Strong runs also catch that the portrait DAS
    cover needs its own generation, not a crop of the 16:9 board image.

17. **Absent sources treated as available.** The moodboard ("on the shared
    drive"), the landscape GA (not landed, planting positions indicative), and
    Appendix B are all referenced but not supplied. Each becomes a `[not stated]`
    entry, not an assumption.

18. **Two audiences, one image.** DAS cover, consultation boards and a sales
    brochure from a single image. The honesty standards differ; a good run builds
    to the planning standard, declines the double duty, and offers a separate
    logged marketing set — while noting the canal request fails in both.

---

**Scoring note.** Count a defect as caught only if it appears in Flags & queries
*and* the prompts behave accordingly. A brief that flags the canal and still
writes "canalside setting" into the design language has failed that item. The
inverse also counts: a run that refuses to produce anything at all has failed —
the correct output is two defensible prompts plus a long flags table.
