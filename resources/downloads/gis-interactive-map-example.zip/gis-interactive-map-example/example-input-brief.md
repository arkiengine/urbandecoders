# Mapping request — Brindle Works, Netherbourne

> **Note for skill testing:** this is a wholly fictional project. Netherbourne,
> its borough council, Brindle Works and every dataset attached are invented for
> training purposes. The coordinates fall in a real-ish West Yorkshire extent but
> correspond to no real site. Several defects are planted deliberately — see the
> defect key.

**From:** Priya (urban designer, Stage 1 site appraisal team)
**Attached:** `example-input-site-boundary.geojson`, `example-input-constraints.geojson`, `example-input-poi.geojson`

---

Hi — for Thursday's internal review I need one interactive map I can send round
the team as a single file (people will open it from email, no GIS installed, some
will be offline on the train).

Please build an interactive map of the three attached datasets, **centred on
Netherbourne town centre** (roughly -1.836, 53.719), with:

- the site boundary clearly visible,
- the constraints as a separate layer I can switch off,
- the points of interest as a third layer,
- a key, and popups so people can click things and see what they are.

The site is about 2.1 ha (it's in the boundary file). The flood outline in the
constraints file was **traced from the EA flood map**, so it should be reliable —
can you **confirm on the map that the site sits outside Flood Zone 2**? That
would save us a paragraph in the appraisal.

The old chimney on the site is Grade II listed as far as we know, and the area
north-east of the canal is a conservation area (I think it's still draft).

One of the bus stops came out of a different export so the numbers might look a
bit odd — hopefully you can sort that.

Thanks!
