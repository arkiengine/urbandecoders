# Harrowgate Mills — area schedule rev F

**Project:** Harrowgate Mills, Marlden — mill conversion plus new-build
**Issued by:** Vale & Hartnoll Architects
**Date:** 3 February 2026
**Issued to:** client, QS, agent
**Purpose stated on the sheet:** "For planning submission and valuation"

*Fictional project. Deliberately imperfect. Figures as printed.*

---

## §1 — Sheet header, as printed

> Harrowgate Mills — Schedule of Accommodation
> Rev F · 03.02.2026 · Prepared by LJ · Checked by —
> *(no measurement standard stated anywhere on the sheet)*

---

## §2 — Block A — Mill conversion (residential)

| Unit | Level | Type | Area (m²) |
|---|---|---|---|
| A-01 | 00 | 1B2P | 52.0 |
| A-02 | 00 | 1B2P | 51.5 |
| A-03 | 00 | 2B4P | 71.0 |
| A-04 | 01 | 2B4P | 72.5 |
| A-05 | 01 | 2B4P | 70.0 |
| A-06 | 01 | 3B5P | 94.0 |
| A-07 | 02 | 2B4P | 71.5 |
| A-08 | 02 | 2B4P | 70.5 |
| A-09 | 02 | 3B5P | 95.0 |
| A-10 | 03 | 2B4P | 73.0 |
| A-11 | 03 | 3B5P | 96.5 |
| **Block A subtotal** | | | **818.0** |

*Note printed below the table: "Areas are GIA."*

---

## §3 — Block B — New build (residential)

| Unit | Level | Type | Area (m²) |
|---|---|---|---|
| B-01 | 00 | 2B4P | 76.0 |
| B-02 | 00 | 2B4P | 75.5 |
| B-03 | 01 | 2B4P | 76.0 |
| B-04 | 01 | 1B2P | 54.0 |
| B-05 | 01 | 3B5P | 99.0 |
| B-06 | 02 | 2B4P | 76.5 |
| B-07 | 02 | 1B2P | 53.5 |
| B-08 | 02 | 3B5P | 98.0 |
| B-09 | 03 | 2B4P | 77.0 |
| B-10 | 03 | 3B5P | 1,065.0 |
| **Block B subtotal** | | | **685.5** |

*Note printed below the table: "Areas are NIA, excluding circulation."*

---

## §4 — Commercial

| Ref | Level | Use | Area |
|---|---|---|---|
| C-01 | 00 | Café | 1,420 ft² |
| C-02 | 00 | Workspace | 2,380 ft² |
| C-03 | 01 | Workspace | 2,410 ft² |
| **Commercial subtotal** | | | **6,210 ft²** |

*Note printed below the table: "Commercial areas are NIA."*

---

## §5 — Summary, as printed

| Line | Figure |
|---|---|
| Block A residential | 818.0 m² |
| Block B residential | 685.5 m² |
| Commercial | 576.9 m² |
| **Total floor area** | **2,080.4 m²** |
| Gross internal area (whole building) | 2,640 m² |
| **Net to gross efficiency** | **79%** |
| Total units | 21 |
| Average unit size | 71.6 m² |

---

## §6 — Unit mix, as printed

| Type | No. | % |
|---|---|---|
| 1B2P | 5 | 24% |
| 2B4P | 11 | 52% |
| 3B5P | 5 | 24% |
| **Total** | **21** | **100%** |

---

## §7 — Brief requirements (from the client's brief, rev 3, Sept 2025)

| Requirement | Stated figure |
|---|---|
| Total residential units | "approximately 20–24" |
| Three-bedroom units | "no fewer than 30% of the total" |
| Minimum 1B2P area | "to meet the nationally described space standard" |
| Commercial floorspace | "at least 600 m² NIA" |
| Amenity space | "25 m² per house, 7 m² per flat" |

---

## §8 — Drawings supplied

- Proposed plans levels 00–03, rev E (**schedule is rev F**)
- Plans show **22 residential units**: 11 in Block A, 11 in Block B.
- Level 03 of Block B shows **two units, B-10 and B-11**.

---

## §9 — What the architect has asked for

1. "Audit this before it goes out."
2. "The QS says our GIA doesn't match the planning submission. Who's right?"
3. "Check the mix against the brief — I think we're fine on three-beds."
4. "Is 79% a good efficiency for a mill conversion?"
