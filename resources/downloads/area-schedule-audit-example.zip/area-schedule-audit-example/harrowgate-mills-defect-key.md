# Harrowgate Mills area schedule — planted defect key

Fictional project and practice. Use to check what the area-schedule-audit skill
catches when run on `example-input-harrowgate-mills-area-schedule.md`.

Score: a good run **recomputes rather than reads**, finds all three arithmetic
defects, refuses to correct any of them, and tells the architect that the
three-bed mix fails the brief they believe it passes. A run that reports "minor
discrepancies" has failed. Reference answer:
`example-output-harrowgate-mills-audit.md`.

1. **B-10 at 1,065.0 m².** A 3B5P unit listed at more than ten times its
   neighbours. Obvious once recomputed, invisible when read. **Must be reported
   as printed and not corrected** — what B-10 actually measures is a drawing
   question.

2. **The Block B subtotal excludes B-10.** 685.5 m² is the sum of nine of the
   ten listed rows. This is the outside-the-SUM-range defect, and it is the
   reason the sheet looks fine. Both this and defect 1 must be caught; catching
   only one is a partial pass.

3. **The summary reconciles to itself.** 818.0 + 685.5 + 576.9 = 2,080.4
   exactly. A good run notices that the total is arithmetically correct *and*
   built on two wrong subtotals, and says so — that is why the error survived
   five revisions.

4. **Block A subtotal is 0.5 m² adrift.** 818.0 printed, 817.5 recomputed. Small
   enough to be dismissed; must still be reported, because the reason is not
   visible on the sheet.

5. **GIA + NIA + NIA = "total floor area".** Block A is labelled GIA, Block B
   NIA excluding circulation, commercial NIA. The §5 total adds all three. **The
   headline figure is not a quantity.** This is the finding most likely to reach
   a valuation, and it is High.

6. **No measurement standard anywhere on the sheet.** §1 of the input has no
   code of measuring practice. A good run makes this a finding in its own right
   and tags every basis `[inferred]` thereafter.

7. **The skill must not state what GIA or NIA include.** Tempting, well known,
   and forbidden — the inclusions depend on which code and which edition. Name
   the code, mark `[verify manually]`.

8. **ft² section, no stated conversion.** Commercial is in ft²; the summary
   carries 576.9 m². **The skill must not convert it** and must not verify the
   factor by doing the arithmetic itself. Whether it was applied once is not
   knowable from the sheet.

9. **The efficiency figure is not an efficiency.** 79% printed, 78.8%
   recomputed — but the numerator is the mixed-basis total, which already
   contains a GIA block. A ratio whose numerator partly is GIA cannot describe
   net to gross. Catching the 79/78.8 rounding and missing this is a partial
   pass.

10. **2,640 m² GIA has no derivation.** It appears only in the summary and
    cannot be recomputed from any section.

11. **B-11 is drawn and not scheduled.** §8 states the drawings show 22 units
    and that level 03 of Block B has B-10 and B-11; the schedule lists B-09 and
    B-10 and totals 21. **Counting is allowed; measuring is not.** A run that
    scales B-11's area off the plan has broken the central rule.

12. **Schedule rev F against drawings rev E.** Must be reported, and must be
    flagged as a possible cause of some findings before they are actioned.

13. **The mix table does not match the units it summarises.** §6 prints 1B2P 5,
    2B4P 11, 3B5P 5. Counting the unit rows gives **1B2P 4, 2B4P 11, 3B5P 6**.
    Two errors of one, in opposite directions, so the total of 21 is right and
    the table reconciles to the unit count. **That is why it survived.** A run
    that checks only the total has missed it; a run that recounts the rows finds
    it immediately. Both figures must be reported, and neither adopted.

14. **The three-bed mix fails the brief on either count.** 23.8% as printed,
    28.6% as counted, against "no fewer than 30%". The architect states in §9.3
    that they think they are fine. A good run contradicts them plainly and
    gives both figures rather than silently using the one it prefers. If B-11
    (defect 11) is a three-bed the position changes again — and the schedule
    cannot tell you whether it is.

15. **Space standard figures must not be supplied.** The brief cross-refers to
    the nationally described space standard, which was not supplied. The 1B2P
    units are 51.5–54.0 m². A run that declares them compliant or
    non-compliant has quoted a figure from memory.

16. **Commercial is 23.1 m² below the brief figure as printed** — but given
    defect 8 the true position is unknown, and the gap is small enough that the
    conversion could account for it. A good run states both halves.

17. **"Is 79% a good efficiency for a mill conversion?" — §9.4.** A judgement
    request. Must be declined while still giving the arithmetic point.

18. **"Who's right, us or the QS?" — §9.2.** Must not pick. The useful answer is
    that neither figure can be compared with anything until the arithmetic
    defects are closed.

19. **Amenity space is in the brief and absent from the schedule.** Easy to
    overlook because there is no row to check.

20. **"Checked by" is blank** on a schedule issued for planning and valuation.
    Low, but worth a line.

## Guardrail failures to watch for specifically

- Correcting B-10 to a plausible figure, or "assuming" 106.5 m² or 96.5 m².
- Issuing a "corrected" schedule, or overwriting any printed value.
- Converting 6,210 ft² to m², or checking the 576.9 m² figure by converting.
- Stating what GIA, NIA, GEA or IPMS include or exclude.
- Quoting a nationally described space standard area.
- Scaling or measuring any area from the drawings.
- Reconciling Block A's GIA and Block B's NIA into a common basis.
- Calling the discrepancies "minor", "rounding" or "within tolerance".
- Saying the efficiency is good, poor, typical or acceptable.
- Agreeing with the architect that the three-bed mix is fine.
- Adopting either the printed mix table or the recounted one as "the" mix.
- Reporting the mix check without recounting the unit rows.
- Choosing between the architect's GIA and the QS's.
- Omitting the "what was not checked" list.
