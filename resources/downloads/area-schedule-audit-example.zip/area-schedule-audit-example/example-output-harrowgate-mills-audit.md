# Harrowgate Mills area schedule rev F — audit

**Audited:** 5 February 2026. **Stated purpose of the schedule:** "For planning
submission and valuation."

---

## §1 — Verdict

**This schedule must not be issued.** It cannot be used for planning submission
or valuation in its present state.

The single biggest problem: **the Block B subtotal is wrong by 1,065.0 m²**.
Unit B-10 is listed at 1,065.0 m² — plainly a transposition of a 3B5P unit —
and the printed subtotal of 685.5 m² excludes it entirely. Both the row and the
subtotal are wrong, in different ways, and either alone would invalidate every
figure downstream.

Beyond that, **the summary adds a GIA block to an NIA block to a ft² figure and
calls the result "total floor area"**. That line is not a quantity.

**Safe to use for as it stands:** nothing.
**Not safe for:** planning submission, valuation, viability, fee calculation,
tender, sales particulars, or the client's own mix check.

---

## §2 — Basis of measurement

**No measurement standard is stated anywhere on the sheet** (§1 of the
schedule). This is a High finding in its own right: an unlabelled area schedule
is uninterpretable, and every area in it is `[inferred]` as to basis.

| Section | Basis as printed | Tag |
|---|---|---|
| Block A (§2) | "Areas are GIA" | `[as printed]` |
| Block B (§3) | "Areas are NIA, excluding circulation" | `[as printed]` |
| Commercial (§4) | "Areas are NIA" | `[as printed]` |
| Summary (§5) "Total floor area" | **Not stated** | `[inferred]` — it is a sum of two different bases |
| Summary (§5) "Gross internal area 2,640 m²" | Labelled GIA | `[as printed]` — derivation unknown |

**H-01 — Two bases summed into one figure.** The §5 "Total floor area" of
2,080.4 m² adds Block A (GIA), Block B (NIA excluding circulation) and
commercial (NIA). GIA and NIA are different quantities with different
inclusions. **The resulting figure has no meaning and must not be quoted.** It
is the figure most likely to reach the planning submission and the valuation.

**H-02 — Which standard?** GIA and NIA are defined in a code of measuring
practice, and what each includes or excludes depends on which code and which
edition. **This audit does not state those definitions.** Name the code the
practice measures to, mark it on the sheet, and confirm the inclusions against
your own copy. `[verify manually]`

---

## §3 — Arithmetic check

**Block A (§2)**

| | Figure |
|---|---|
| Subtotal as printed | 818.0 m² |
| Sum of the 11 listed rows, recomputed | **817.5 m²** |
| Difference | **0.5 m²** |

`[recomputed]` from the eleven rows A-01 to A-11. A small discrepancy, but it
means the printed subtotal is not the sum of the rows shown, and the reason is
not visible on the sheet.

**Block B (§3)**

| | Figure |
|---|---|
| Subtotal as printed | 685.5 m² |
| Sum of the 10 listed rows, recomputed | **1,750.5 m²** |
| Sum **excluding** B-10 | **685.5 m²** |
| Difference | **1,065.0 m²** |

`[recomputed]`. The printed subtotal equals the sum of nine rows. **B-10 is in
the table and not in the subtotal.** Two separate defects:

- **H-03 — B-10 is listed at 1,065.0 m².** Every other 3B5P in the schedule is
  94.0–99.0 m². This is almost certainly a transposed or mistyped figure.
  **It is reported as printed and is not corrected here** — what B-10 actually
  measures is a question about the drawings, not about the spreadsheet.
- **H-04 — The subtotal excludes a listed row.** This is the classic
  outside-the-SUM-range defect and it is invisible on a printout.

**Commercial (§4)**

| | Figure |
|---|---|
| Subtotal as printed | 6,210 ft² |
| Sum of the three rows, recomputed | **6,210 ft²** |
| Difference | 0 |

The ft² subtotal is internally correct.

**M-01 — Unit drift.** The commercial section is in **ft²** while every other
section is in **m²**. The §5 summary carries the commercial line as
**576.9 m²**. No conversion is stated anywhere on the sheet, and **this audit
does not convert it** — the factor used, and whether it was applied once, is
not knowable from the sheet. `[verify manually]`

**Summary (§5)**

| Line as printed | Recomputed from the sections | Note |
|---|---|---|
| Block A 818.0 | 817.5 | Does not match the rows |
| Block B 685.5 | 1,750.5 | Excludes B-10 |
| Commercial 576.9 m² | — | Conversion basis not stated |
| **Total 2,080.4** | 818.0 + 685.5 + 576.9 = **2,080.4** | **Internally consistent with the three printed subtotals, two of which are wrong.** Also sums two measurement bases — see H-01 |
| Total units 21 | 11 (A) + 10 (B) = **21** rows listed | Consistent with the schedule. **Not consistent with the drawings — see §5** |
| Average unit size 71.6 | 1,503.5 ÷ 21 = **71.6** | Arithmetically consistent with the printed subtotals; inherits both errors. Also averages GIA and NIA units together |

**H-05 — The total is "correct" and meaningless.** The summary adds its three
printed subtotals accurately. That is why the error survived: the sheet
reconciles to itself.

---

## §4 — Efficiency

| | Figure |
|---|---|
| Net to gross, as printed | 79% |
| Recomputed: 2,080.4 ÷ 2,640 | **78.8%** `[recomputed]` |

**H-06 — The efficiency figure is not a net-to-gross ratio.** Its numerator is
the mixed-basis "total floor area" from H-01, which already includes a GIA
block. A ratio whose numerator partly *is* GIA cannot describe net to gross.

Note also: **no derivation is given anywhere for the 2,640 m² GIA.** It does
not appear in any section and cannot be recomputed from the sheet.
`[verify manually]`

**Whether 78.8% is a good efficiency for a mill conversion is not assessed
here** — see §8.

---

## §5 — Drawing reconciliation

Counts only. **No areas have been measured from the drawings.**

| Check | Schedule | Drawings (§8) | Status |
|---|---|---|---|
| Block A units | 11 | 11 | Agrees |
| Block B units | **10** | **11** | **Conflict** |
| Block B level 03 units | B-09, B-10 | **B-10 and B-11** | **Conflict** |
| Total residential units | 21 | **22** | **Conflict** |

**H-07 — Unit B-11 is on the drawings and not in the schedule.** The schedule
lists B-09 at level 03; the drawings show B-10 and B-11 at level 03. Either a
unit is missing from the schedule or the drawings are wrong, and the schedule
cannot tell you which.

**M-02 — Revision gap.** The schedule is rev F; the drawings are rev E. Some
of the findings above may be artefacts of that gap, and the gap must be closed
before any of them is actioned.

---

## §6 — Brief reconciliation

**First, the mix table does not match the units it summarises.**

| Type | §6 as printed | Counted from the unit rows `[recomputed]` | Difference |
|---|---|---|---|
| 1B2P | 5 (24%) | **4** (19.0%) | −1 |
| 2B4P | 11 (52%) | 11 (52.4%) | — |
| 3B5P | 5 (24%) | **6** (28.6%) | +1 |
| **Total** | **21** | **21** | — |

**H-08 — Two offsetting errors in the mix table.** One 1B2P too many and one
3B5P too few. Because they cancel, the total of 21 is right and the table
reconciles to the unit count, which is why nobody noticed. Both figures are
reported as printed; which count is correct is a question about the drawings.

**Reconciliation against the brief**

| Requirement (§7) | Stated | Schedule | Status |
|---|---|---|---|
| Total units "approximately 20–24" | 20–24 | 21 (schedule) / 22 (drawings) | Within range on either count |
| Three-bed "no fewer than 30% of the total" | ≥30% | **as printed 5 of 21 = 23.8%** · **as counted 6 of 21 = 28.6%** `[recomputed]` | **Below the stated requirement on either count** |
| 1B2P minimum area | "to meet the nationally described space standard" | 51.5–54.0 m² | **`[verify manually]` — see below** |
| Commercial "at least 600 m² NIA" | ≥600 m² | 576.9 m² as printed | **Below the stated figure as printed.** Conversion basis unverified (M-01) |
| Amenity 25 m² house / 7 m² flat | — | **Not in the schedule at all** | Not scheduled |

**H-09 — The three-bed mix does not meet the brief.** The architect's §9.3
states "I think we're fine on three-beds". It fails on both counts: 23.8% as
the mix table prints it, 28.6% as the unit rows actually count. The brief
requires no fewer than 30%. If B-11 (H-07) is a three-bed the position changes
again, and the schedule cannot tell you whether it is.

**H-10 — Space standard not checked here.** The brief cross-refers to the
nationally described space standard. That document was not supplied, and **its
figures are not reproduced from memory.** Obtain it and the check completes.
`[verify manually]`

**M-03 — Commercial requirement is below target on the printed figure**, by
23.1 m². Given M-01 the true position is unknown, and the gap is small enough
that the conversion factor could account for it either way.

---

## §7 — Ranked findings

**High — each breaks something downstream**

| # | Finding | What it breaks |
|---|---|---|
| H-03 | B-10 listed at 1,065.0 m² | Every Block B figure; any valuation |
| H-04 | Block B subtotal excludes B-10 | Block B subtotal, total, average, efficiency |
| H-01 | GIA + NIA + NIA summed as "total floor area" | The headline figure, in a document going to planning and valuation |
| H-07 | Unit B-11 drawn, not scheduled | Unit count, mix, areas, affordable calculation |
| H-08 | Mix table miscounts 1B2P and 3B5P by one each, offsetting | Every mix percentage; the brief check; affordable mix |
| H-09 | Three-bed mix 23.8% printed / 28.6% counted, against a 30% brief requirement | Brief compliance; the architect believes the opposite |
| H-06 | "Efficiency" computed on a mixed-basis numerator | Any efficiency benchmark or viability input |
| H-05 | Summary reconciles to itself while two subtotals are wrong | Why nobody caught it |
| H-02 | No measurement standard stated on the sheet | Interpretability of every figure |

**Medium**

| # | Finding |
|---|---|
| M-01 | ft² section converted to m² with no stated basis |
| M-02 | Schedule rev F against drawings rev E |
| M-03 | Commercial 23.1 m² below the brief figure as printed |
| M-04 | Block A subtotal 0.5 m² adrift from its rows |
| M-05 | 2,640 m² GIA has no derivation on the sheet |

**Low / Info**

| # | Finding |
|---|---|
| L-01 | "Checked by" field is blank on a schedule issued for planning and valuation |
| L-02 | §6 mix percentages are rounded to whole numbers, masking the discrepancy in H-08 |
| L-03 | Average unit size averages GIA and NIA units together |

---

## §8 — The specific questions asked

**§9.2 — "The QS says our GIA doesn't match the planning submission. Who's
right?"** This audit does not choose between two figures. It can say that the
schedule's own 2,640 m² GIA has no derivation on the sheet (M-05), that the
"total floor area" of 2,080.4 m² is not a GIA and not a usable quantity at all
(H-01), and that Block B is understated by a listed unit (H-04) while that same
unit is itself implausible (H-03). Until those are resolved the schedule cannot
be compared with anything.

**§9.3 — "I think we're fine on three-beds."** No. The schedule prints 24%, the
unit rows actually count 28.6%, and the brief requires no fewer than 30%. It
fails on both counts, and the two figures disagree with each other (H-08, H-09).

**§9.4 — "Is 79% a good efficiency for a mill conversion?"** Not assessed.
This audit checks arithmetic and internal consistency; whether an efficiency is
good, marketable or viable is a judgement with commercial consequences and is
not made here. The arithmetic point stands separately: the figure is 78.8%, and
it is not a net-to-gross ratio (H-06).

---

## §9 — What was not checked

- **No area was measured from any drawing.** Every area is as supplied.
- The 2,640 m² GIA — not derivable from the sheet.
- Whether Block A's "GIA" and Block B's "NIA" were measured to the same code,
  or to any code.
- The ft²→m² conversion factor.
- Space standards — document not supplied.
- Amenity space — not in the schedule.
- Affordable housing quantum — not in the schedule.
- Revisions A to E — not supplied, so no drift analysis.
- Whether the drawings themselves are correct.

**The verdict is only as good as this list.**
