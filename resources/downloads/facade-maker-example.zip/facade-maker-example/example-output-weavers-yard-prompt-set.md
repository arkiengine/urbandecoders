# Weaver's Yard — facade study prompt set

**Source pack:** WY-DIP-02, Rev B, 14 July 2026 (Studio Harle, internal working document)
**Base image:** WY-VIS-001 — `WY-VIS-001_saxton-lane-view.jpg`, south-west corner perspective from Saxton Lane, eye level, overcast-bright sky, adjacent warehouses to the right, grey placeholder cladding on a massing model (asset register, §7)
**RIBA stage:** Stage 2 (Concept Design), as stated in the pack header
**Set prepared:** 8 August 2026 | **Set ref:** WY-FSPS-01

**Status of this set.** These are prompts for the design team to run and review.
The images they produce are **design studies, not Verified Views or AVRs**, not
planning drawings, and not accurate representations of a consented scheme. See
Q-02 — the pack's stated intention for these images cannot be met by this
method. Nothing in this set is a design decision; every variant is an option
for the architect to review.

---

## 1. What was requested, and what this set delivers

| Requested (pack §3–4) | Delivered | Note |
|---|---|---|
| Material options, five (§3.1) | **Study A — 5 prompts, ready to run** | Extent conflict logged (Q-03); M5 reveal variable split out (Q-09) |
| Proportion pair, 35% / 45% (§3.2) | **Study C — 2 prompts drafted, HELD** | Ratio definition unstated (Q-04); as-drawn condition sits outside the studied range (Q-11) |
| Bay study, coursing + joints (§3.3) | **Study B — 2 prompts drafted, BLOCKED** | Base image identity unresolved (Q-01); mortar colour TBC (Q-06); bay width contradicts itself (Q-05) |
| A4 comparison board (§4) | **Not specified yet** | Specified once you confirm which images actually exist — see §7 |
| "Indicate which two material options you recommend" (§4) | **Declined** | Selection is a design decision. Review criteria supplied instead — §8 |
| "Make the options look premium and refined" (§1) | **Not encoded** | Not a stated material or geometric property; encoding it would apply a styling decision to every option unequally. See Q-13 |
| Precedent character — Accordia, Brick Awards schemes (§6) | **Not encoded** | Precedents are cited without stating which attributes bind. See Q-14 |

---

## 2. Stated variables extracted (with provenance)

Only these appear in the prompts. Anything absent from this table is either
locked to the base image or raised in §6.

| Variable | Stated value | Source |
|---|---|---|
| Storeys | 6 (ground + 5 upper) | §1, §2.1 |
| Bay rhythm | 9 bays to Saxton Lane | §2.2 |
| Bay width | 3.6 m *(narrative)* / 3.75 m *(schedule D-01)* — **conflict, both recorded** | §2.2 / D-01 |
| Cladding extent | Upper floors; ground floor a separate package | §2.3, §3.1 heading |
| Frames | Slate grey PPC aluminium *(§2.3)* / dark bronze anodised *(§3.1 schedule)* — **conflict, both recorded** | §2.3 / §3.1 |
| Cills | Dark grey precast | §2.3, §3.1 |
| M1 | Red-brown tumbled handmade clay brick, Flemish bond. Mortar `[not stated — "TBC"]` | §3.1 |
| M2 | Buff waterstruck brick, stretcher bond, flush joints | §3.1 |
| M3 | Timber-effect fibre cement boards, 200 mm horizontal boards, open joints | §3.1 |
| M4 | Off-white glazed ceramic tiles, 440 × 1200 mm, fine joints, semi-matte | §3.1 |
| M5 | Board-marked precast concrete panels, light grey | §3.1 |
| Reveal depth (M5 only) | 200 mm | §3.1 — a geometric variable, held: Q-09 |
| Window-to-wall ratios to test | 35% and 45% | §3.2 |
| Sky / light | As base image (overcast-bright) | §7 |

Not stated anywhere and therefore not in any prompt: mortar colour, brick
texture beyond "tumbled"/"waterstruck", tile grout colour, board sheen,
concrete aggregate or board-mark grain direction, parapet band-course profile
("to be developed", §2.1), landscape, signage, entrance treatment.

---

## 3. Study A — material options (READY TO RUN)

### 3.1 Consistency block (LOCK) — Study A

Paste this **verbatim** into every Study A prompt. One lock per study; do not
edit it between runs. If it needs to change, it changes for all five and the
earlier images stop being comparable.

> Keep the exact camera position, framing, crop and aspect ratio of the
> attached base image. Preserve the building's massing, its six storeys, its
> nine-bay rhythm, and every window and door position and size exactly. Keep
> the glazing, window frames and cills exactly as in the base image. Keep the
> ground floor — plinth, maker-unit frontage and openings — exactly as in the
> base image. Keep all surrounding context, including the adjacent warehouses,
> the street, planting, people and vehicles, unchanged; add nothing and remove
> nothing. Keep the same overcast-bright sky, time of day, sun direction and
> shadow pattern as the base image. Architectural photography, neutral
> rectilinear lens, physically accurate daylight falling on the new material.

### 3.2 Negative block — Study A

Append **verbatim** to every Study A prompt.

> Do not: redesign any element, alter geometry or proportions, move or resize
> any opening, change the camera position or crop, change the sky or time of
> day, apply a painterly or illustrative style, add text, logos or watermarks,
> add or remove people or vehicles.

### 3.3 Prompts

Each prompt below is complete and copy-paste runnable: variant line, then the
lock, then the negatives. Run each on the **same** base image, WY-VIS-001.

---

**A-01 — Handmade clay brick** · *Option for review — no preference implied*

```
Replace ONLY the upper-floor cladding of the building with red-brown tumbled
handmade clay brick, laid in Flemish bond. Apply it to the upper five floors
only; leave the ground floor unchanged.

Keep the exact camera position, framing, crop and aspect ratio of the attached
base image. Preserve the building's massing, its six storeys, its nine-bay
rhythm, and every window and door position and size exactly. Keep the glazing,
window frames and cills exactly as in the base image. Keep the ground floor —
plinth, maker-unit frontage and openings — exactly as in the base image. Keep
all surrounding context, including the adjacent warehouses, the street,
planting, people and vehicles, unchanged; add nothing and remove nothing. Keep
the same overcast-bright sky, time of day, sun direction and shadow pattern as
the base image. Architectural photography, neutral rectilinear lens,
physically accurate daylight falling on the new material.

Do not: redesign any element, alter geometry or proportions, move or resize any
opening, change the camera position or crop, change the sky or time of day,
apply a painterly or illustrative style, add text, logos or watermarks, add or
remove people or vehicles.
```

*Note (not part of the prompt):* mortar colour is "TBC" in the pack, so no
mortar wording is given and the model will choose one. At this view distance
that is tolerable; at bay range it is not (Q-06).

---

**A-02 — Waterstruck brick** · *Option for review — no preference implied*

```
Replace ONLY the upper-floor cladding of the building with buff waterstruck
brick, laid in stretcher bond with flush joints. Apply it to the upper five
floors only; leave the ground floor unchanged.

[LOCK — paste §3.1 verbatim]

[NEGATIVE — paste §3.2 verbatim]
```

---

**A-03 — Fibre cement boards** · *Option for review — no preference implied*

```
Replace ONLY the upper-floor cladding of the building with timber-effect fibre
cement boards, 200 mm deep horizontal boards with open joints. Apply them to
the upper five floors only; leave the ground floor unchanged.

[LOCK — paste §3.1 verbatim]

[NEGATIVE — paste §3.2 verbatim]
```

*Note (not part of the prompt):* the pack calls this product "A2-rated". A
fire classification is a certified product property, not a visual one; it is
not written into the prompt and it is not verifiable from an image. Carried as
`[to verify]` at Q-08.

---

**A-04 — Glazed ceramic tiles** · *Option for review — no preference implied*

```
Replace ONLY the upper-floor cladding of the building with off-white glazed
ceramic tiles, 440 × 1200 mm, with fine joints and a semi-matte finish. Apply
them to the upper five floors only; leave the ground floor unchanged.

[LOCK — paste §3.1 verbatim]

[NEGATIVE — paste §3.2 verbatim]
```

---

**A-05 — Board-marked precast concrete** · *Option for review — no preference implied*

```
Replace ONLY the upper-floor cladding of the building with light grey
board-marked precast concrete panels. Apply them to the upper five floors
only; leave the ground floor unchanged.

[LOCK — paste §3.1 verbatim]

[NEGATIVE — paste §3.2 verbatim]
```

*Note (not part of the prompt):* the pack couples this material with reveals
deepened to 200 mm. That is a second, geometric variable; running it inside
A-05 would produce an image that answers neither question. It is split out and
held at Q-09 — if you want the coupled condition studied, say so and it
becomes A-05b with the deepened reveal added to all five, or to none.

---

## 4. Study C — proportion options (DRAFTED, HELD at Q-04)

Study C varies opening size, so the lock drops its opening-size clause and
tightens everything else. **Do not run these until Q-04 is answered** — the
pack does not define what its percentage is measured against, so the model
will pick a reading of its own, and the two images will not be comparable with
each other or with the base.

### 4.1 Consistency block (LOCK) — Study C

> Keep the exact camera position, framing, crop and aspect ratio of the
> attached base image. Preserve the building's massing, its six storeys, and
> its nine-bay rhythm. Keep the same number of openings, in the same positions,
> with head and cill lines aligned across each floor. Keep the ground floor —
> plinth, maker-unit frontage and openings — exactly as in the base image. Keep
> the cladding material, colour and texture exactly as in the base image. Keep
> the glazing appearance, frames and cills exactly as in the base image. Keep
> all surrounding context unchanged; add nothing and remove nothing. Keep the
> same overcast-bright sky, time of day, sun direction and shadow pattern.
> Architectural photography, neutral rectilinear lens.

Negative block as §3.2, plus: *do not change the number of openings, do not
change the number of storeys, do not shift any opening horizontally within its
bay.*

### 4.2 Prompts (held)

**C-01 — Window-to-wall ratio 35%** · *Option for review — no preference implied*

```
Adjust ONLY the width of the upper-floor window openings so that the glazing
reaches a window-to-wall ratio of 35% on the upper floors. Keep every opening
centred in its bay, keep the same number of openings, and keep head and cill
lines aligned across each floor.

[LOCK — paste §4.1 verbatim]

[NEGATIVE — paste §3.2 verbatim, plus the Study C additions]
```

**C-02 — Window-to-wall ratio 45%** · *Option for review — no preference implied*

```
Adjust ONLY the width of the upper-floor window openings so that the glazing
reaches a window-to-wall ratio of 45% on the upper floors. Keep every opening
centred in its bay, keep the same number of openings, and keep head and cill
lines aligned across each floor.

[LOCK — paste §4.1 verbatim]

[NEGATIVE — paste §3.2 verbatim, plus the Study C additions]
```

**Arithmetic offered so Q-04 can be answered in one line** (this is arithmetic
on the pack's own figures, not a recommendation):

- As drawn, opening 2.1 m (D-04) in a 3.75 m bay (D-01) = **56% of bay width**;
  in a 3.6 m bay (§2.2 narrative) = **58%**.
- Openings are described as full height (§2.3), so a ratio measured on
  elevation *area* lands close to the same figures.
- Both stated study values (35%, 45%) are therefore **below the as-drawn
  condition**, and neither matches the "around 50%" of §1 (Q-11). If you intend
  a *reduction* study, the prompts stand; if 35/45% was meant as a range
  *around* the as-drawn condition, the figures need restating.
- Under a bay-width reading with D-01 at 3.75 m: 35% → opening 1.31 m, pier
  2.44 m; 45% → opening 1.69 m, pier 2.06 m. Substituting these explicit
  dimensions for the percentage would make the prompts far more reliable — your
  call.

---

## 5. Study B — bay study (BLOCKED)

Blocked on three counts; the prompts are drafted so you can see what will run
once they clear, but **do not run them yet**.

**Blocking issues:** Q-01 (base image identity), Q-05 (bay width contradiction),
Q-06 (mortar colour TBC — and at bay range mortar is half the image).

**B-01 — Coursing: Flemish bond (as stated) vs stack bond alternative** ·
*Option for review — no preference implied*

```
Change ONLY the brick coursing of the bay to [Flemish bond / stack bond] .
Keep the bay's dimensions, the opening size and position, the brick colour and
texture, the frame and cill, and the lighting exactly as in the base image.

[LOCK — Study B lock, to be written once the base is confirmed]

[NEGATIVE — paste §3.2 verbatim]
```

**B-02 — Joint treatment: flush vs raked** — cannot be written. The pack makes
joint treatment "subject to the mortar decision" (§3.3), and mortar colour is
TBC. A raked joint reads as shadow; a flush joint in an unknown mortar reads as
whatever the model invents. Two undecided variables in one image is not a
study. Held until Q-06 is answered.

**On the base:** the crop route is preferred and the pack says one exists
(WY-VIS-002) — but the register entry contradicts itself (Q-01). The
described-bay route is not available as a fallback either, because the bay
width is stated twice with different values (Q-05); a stand-in bay built on the
wrong module would be a fictional proportion presented as the scheme's.

---

## 6. Open questions

Numbered; each names what it blocks. Nothing here has been resolved in your
favour or against it.

| # | Question | Source | Why it matters | Affects |
|---|---|---|---|---|
| Q-01 | Asset WY-VIS-002 is described as "typical upper-floor bay, straight-on crop from the base render", but is filed under the filename `WY-EL-N-02_north-elevation.pdf` — a north elevation PDF, not a crop of a south-west perspective. Which is it, and is there an actual bay crop? | §7 | Every prompt in a study inherits its base; an identity error poisons the whole set | **Blocks Study B** |
| Q-02 | §1 states these images "will support the planning submission as verified views of the consented scheme". They cannot. AI-generated studies are not Verified Views / AVRs (which are a surveyed, methodological exercise), and the pack elsewhere says the submission is targeted for November 2026 (§5) — so there is no consented scheme. Confirm the images are for internal/design-team review only, or commission verified views separately. | §1 vs §5 | Misuse of these images in a submission is a reputational and procedural risk | Whole set |
| Q-03 | Cladding extent contradicts itself: §2.3 and the §3.1 heading say upper floors only (ground floor a separate package, dark engineering brick plinth); §4 asks for the options "applied to the full facade treatment". **Study A has been written to the upper floors**, being the wording stated twice and the more specific. Confirm or correct. | §2.3 / §3.1 / §4 | Changes what five images show | Study A |
| Q-04 | "Window-to-wall ratio" 35% / 45% — measured against what: bay width, bay elevation area, gross elevation area, or the upper-floor facade excluding piers? The pack does not say, and the answer changes the opening width materially. | §3.2 | Undefined ratio = the model picks its own | **Holds Study C** |
| Q-05 | Bay width is 3.6 m in the narrative (§2.2) and 3.75 m in the dimension schedule (D-01). Arithmetic favours the schedule — opening 2.1 m (D-04) + pier 1.65 m (D-05) = 3.75 m — but that is evidence, not a decision. Also: 9 bays gives a 32.4 m or 33.75 m frontage, a 1.35 m difference. | §2.2 vs D-01, D-04, D-05 | Any described-bay or dimensioned prompt inherits the error | **Blocks Study B**; affects Q-04 arithmetic |
| Q-06 | Mortar colour is "TBC" (M1), and §3.3 makes joint treatment conditional on it. `[not stated]` — not filled in. | §3.1, §3.3 | At street range the model's invented mortar is tolerable; at bay range it dominates the image | **Blocks B-02**; caveat on A-01 |
| Q-07 | Window frames: slate grey polyester powder-coated aluminium (§2.3) vs dark bronze anodised aluminium (§3.1 materials schedule) — both in Rev B. **The prompts lock frames to the base image** rather than choose. Confirm which is current. | §2.3 vs §3.1 | Frame colour reads strongly against every cladding option; if it is wrong, all five images are wrong together | Studies A and C |
| Q-08 | M3 is described as "A2-rated" fibre cement. Fire classification is a certified product property and is **not** written into the prompt, nor inferable from an image. Confirm against the product certificate / specification — not from memory or from a rendering. `[to verify]` | §3.1 | Performance claims must not enter the visual record | A-03 |
| Q-09 | M5 couples a material change with a geometry change (reveals deepened to 200 mm). A-05 varies the material only. Do you want the deepened reveal studied — (a) not at all, (b) as A-05b alongside A-05, or (c) applied to all five so the comparison stays like-for-like? | §3.1 | Two variables in one image answers neither question | A-05 |
| Q-10 | Storey heights do not sum to the stated height: 4.2 m + (5 × 3.15 m) = **19.95 m**, against a stated 18.4 m to top of parapet (§2.1) — a 1.55 m discrepancy. Which figure is current? | §2.1 | Not blocking (geometry is locked to the base image), but it will block the moment anything is drawn or dimensioned from this pack | Downstream |
| Q-11 | Glazing quantum is stated as "around 50%" in §1 and as 35% / 45% in §3.2, and the as-drawn opening is ~56% of bay width. Three figures. Is the proportion study a reduction study, or were the values meant to bracket the as-drawn condition? | §1 vs §3.2 vs D-04/D-01 | Determines whether the base image is inside or outside the studied range | **Holds Study C** |
| Q-12 | §1 says the conservation officer "has confirmed that brick will be required on Saxton Lane", then states this was indicated on a walkover and that the formal pre-app response is awaited (§5). **Recorded as an informal officer comment, not a planning position.** It has not been allowed to reorder, favour or reword the brick options — M1 and M2 sit in the pack's own order and are described in the pack's own words. Confirm the position when the written response arrives. | §1, §5 | An informal comment hardening into a constraint is how options quietly disappear | Set ordering (deliberately unaffected) |
| Q-13 | §1 asks that the studies "make the options look premium and refined". That is a styling instruction, not a stated material or geometric property, and applying it would flatter some options more than others — the opposite of a comparison. **Not encoded.** If you want a consistent presentation register beyond "architectural photography, neutral lens", state it once and it goes into the lock for all five. | §1 | Uneven flattery invalidates a comparison | Whole set |
| Q-14 | Precedents (Accordia; Brick Awards warehouse-infill schemes, §6) are cited without stating which attributes bind — coursing? reveal depth? tone? massing? **Not encoded**, and no precedent look-ups have been done (pack is confidential; say the word if you want them). | §6 | "Sit comfortably in that company" is not a promptable property | Whole set |
| Q-15 | The parapet band course (§2.1) is "profile to be developed", is described as brick, and sits below a dark grey precast coping — while three of the five options are not brick. Does the band course persist in every option? The base image is a **grey placeholder massing model**, so the band course and the "deep reveals" of §1 may not be present in it at all — and the lock will faithfully preserve their absence in all five images. | §1, §2.1, §7 | The five images may collectively omit two features the pack considers characteristic | Study A — worth checking the base before you run |
| Q-16 | WY-DWG-110 is a Revit elevation export "with dimensions and title block". If an elevation-to-render study is wanted later, re-export it clean: no dimensions, no annotation, no title block, hidden-line, shadows off. Cluttered linework makes image models hallucinate around the annotation. | §7 | Not blocking today — no elevation-to-render requested | Future Study D |

---

## 7. Run instructions

1. **Run all five Study A prompts on the same base image**, WY-VIS-001,
   in the same tool and the same session settings. Default phrasing here targets
   Nano Banana / Gemini image editing; other tools may need the lock repeated at
   the end of the prompt as well as the start.
2. **Do not run Study C or Study B yet** — see Q-04, Q-01, Q-05, Q-06.
3. **Check the base image against Q-15 before you start.** If the placeholder
   massing lacks the deep reveals and the parapet band course, all five images
   will lack them too, consistently — which is fine for a material comparison
   and misleading if the images travel.
4. **Count everything in every output before you show it to anyone.** Image
   models drift on window counts, storey counts, coursing and bay rhythm. Nine
   bays, six storeys, one opening per upper bay. An image that has quietly
   become eight bays is not a variant of this building.
5. **Expect iteration on M1, M2 and M4.** Handmade brick tone, waterstruck
   texture and fine tile jointing are the three finishes that most often need a
   second round. That is a rendering limitation, not a reason to substitute an
   easier material — the stated palette stays as stated.
6. **Report failures verbatim** ("the brick reads too orange", "it moved the
   windows", "it dropped a bay") and one prompt will be revised at a time. If
   the *lock* has to change, it changes for all five and every earlier image
   stops being comparable — that will be said out loud, in the log and in chat.
7. **The comparison board comes last.** Confirm which images exist and are
   approved, then the board is specified (the pack asks for a single A4 —
   A4 portrait, 2 × 3, base plus five options, titled cells, even margins,
   light page ground, is the obvious fit for Study A). No board is drafted, and
   no result is described, before that confirmation.

---

## 8. Instead of a recommendation — review criteria

The pack (§4) asks which two options to take forward. That is a design
decision, and it is yours. What the study can honestly offer is what each
option would settle, and what each depends on:

| Option | What looking at it will settle | What it depends on |
|---|---|---|
| A-01 handmade brick | Whether a tumbled, irregular brick reads as continuation or pastiche against the Victorian warehouses | Mortar colour (Q-06); bond legibility at 3.75 m bay (Q-05) |
| A-02 waterstruck brick | Whether a flatter, buff brick holds the "load-bearing" reading §1 asks for, or reads lighter than intended | Same mortar question; flush joints reduce shadow — check against the "shadow and weight" ambition |
| A-03 fibre cement boards | Whether a horizontal board grain can carry a facade the pack describes as vertical, structural and repetitive | Certification (Q-08); open joints read dark — check against reveal depth |
| A-04 ceramic tiles | Whether an off-white, reflective field sits inside the conservation-area setting | Q-12's informal brick comment could make this option moot — or not, until the written response lands |
| A-05 precast concrete | Whether board-marked precast delivers the depth §1 wants without the deepened reveal | Q-09 — the coupled reveal is the point of this option, and is currently unstudied |

Useful sequencing: answer Q-01, Q-03, Q-04 and Q-09 first — they are cheap to
answer and each unblocks a whole study.

---

## 9. Iteration log

One row per revision. Empty until you report results.

| Rev | Prompt | What the architect reported | What changed in the prompt | Lock touched? |
|---|---|---|---|---|
| — | — | — | — | — |

If **Lock touched?** is ever *Yes*, every image generated before that revision
is no longer comparable with those after it — the row will say so, and so will
the chat message that delivers it.

---

*Set WY-FSPS-01. Design study material for Studio Harle internal review.
Not a Verified View, not a planning drawing, not a design decision.*
