# Weaver's Yard, Saxton Lane, Marlden — Facade Design Intent Pack

**Client:** Pellow & Grange Developments Ltd
**Project:** Weaver's Yard — mixed-use infill, Saxton Lane, Marlden
**Document:** WY-DIP-02 | Rev B | 14 July 2026
**Prepared by:** Studio Harle — internal working document, issued to the visualisation team for facade studies
**RIBA stage:** Stage 2 (Concept Design)

---

## 1. Vision and context

Weaver's Yard replaces a cleared 1970s telephone exchange on the north side of Saxton Lane, a street of three- and four-storey Victorian warehouses at the edge of the Marlden Old Mills Conservation Area (the site itself sits just outside the boundary; the boundary runs along the opposite kerb). The scheme is a single six-storey building: ground-floor maker units with five storeys of workspace above.

The facade should feel like a contemporary continuation of the warehouse street — robust, repetitive, load-bearing in character, with generous glazing of around 50% to the workspace floors and deep reveals that give the elevation shadow and weight. The conservation officer has confirmed that brick will be required on Saxton Lane; this was indicated at pre-application stage during a walkover in May, and we expect the point to be repeated in the formal pre-app response when it arrives.

We want the studies to make the options look premium and refined — these images will support the planning submission as verified views of the consented scheme, so quality matters.

## 2. Facade setting-out

### 2.1 General arrangement

Six storeys. Ground floor 4.2 m floor-to-floor; five upper storeys at 3.15 m floor-to-floor. Overall height to top of parapet: 18.4 m. Flat parapet with a single projecting brick band course at parapet level (profile to be developed).

### 2.2 Bay rhythm

The Saxton Lane elevation is set out on a regular 3.6 m structural bay — nine bays to the street. Each upper-floor bay carries one full-height opening with a solid pier between; the pier-to-opening rhythm is intended to read clearly as structure, not cladding.

**Dimension schedule (setting-out, Rev B):**

| Ref | Element | Dimension |
|---|---|---|
| D-01 | Structural bay, Saxton Lane | 3.75 m |
| D-02 | Ground floor, floor-to-floor | 4.2 m |
| D-03 | Upper floors, floor-to-floor | 3.15 m |
| D-04 | Upper-floor opening width (within bay) | 2.1 m |
| D-05 | Pier width between openings | 1.65 m |
| D-06 | Parapet band course projection | 40 mm |

### 2.3 Glazing and frames

Upper-floor openings are full-height fixed lights with a slim opening vent. Frames are slate grey polyester powder-coated aluminium throughout. Cills in dark grey precast. The cladding options in section 3 apply to the upper floors; the ground floor is a separate package (dark engineering brick plinth, not part of this study).

## 3. Studies requested

### 3.1 Material options — upper-floor cladding

Five options for the material study. Descriptions below are the stated palette; do not add finishes beyond these.

| Opt | Material | Stated description |
|---|---|---|
| M1 | Handmade clay brick | Red-brown, tumbled handmade brick, Flemish bond. Mortar colour TBC. |
| M2 | Waterstruck brick | Buff waterstruck brick, stretcher bond, flush joints. |
| M3 | Fibre cement boards | A2-rated timber-effect fibre cement boards, 200 mm horizontal boards, open joints. |
| M4 | Glazed ceramic tiles | Off-white glazed ceramic tiles, 440 × 1200 mm, fine joints, semi-matte. |
| M5 | Precast concrete | Board-marked precast concrete panels, light grey, with window reveals deepened to 200 mm. |

**Materials & finishes schedule (Rev B extract):** window frames — dark bronze anodised aluminium; cills — dark grey precast; parapet coping — dark grey precast.

### 3.2 Proportion options — upper-floor glazing

Test two window-to-wall ratios on the upper floors: **35%** and **45%**. Opening positions and count stay as drawn; only the opening width within each bay changes. Head and cill lines to remain aligned across each floor.

### 3.3 Bay study

A close-range study of the typical upper-floor bay: M1 coursing at Flemish bond versus a stack-bonded alternative, and joint treatment (flush vs raked, subject to the mortar decision). Use the bay crop listed in the asset register.

## 4. Deliverable request

Please prepare the prompt set for the material options applied to the full facade treatment, plus the proportion pair and the bay study. When the images are back, we would like a single A4 comparison board. Please also indicate which two material options you recommend we take forward to the client review — a steer from the study would save a round of debate.

## 5. Constraints and planning context

- Site adjoins (but is outside) the Marlden Old Mills Conservation Area; the pre-app response is awaited.
- Saxton Lane is a designated local view corridor in the emerging Marlden Neighbourhood Plan (unadopted).
- No listed buildings on site; the former exchange is demolished.
- Planning submission targeted for November 2026.

## 6. Precedents

The character reference points are Accordia (Cambridge) and recent Brick Awards shortlist warehouse-infill schemes. The studies should sit comfortably in that company.

## 7. Asset register

| Ref | File | Description |
|---|---|---|
| WY-VIS-001 | `WY-VIS-001_saxton-lane-view.jpg` | Base render: south-west corner perspective from Saxton Lane, eye level, overcast-bright sky, existing warehouses visible to the right. Current (grey placeholder cladding) massing model. |
| WY-VIS-002 | `WY-EL-N-02_north-elevation.pdf` | Typical upper-floor bay, straight-on crop from the base render, for the bay study. |
| WY-DWG-110 | `WY-DWG-110_saxton-lane-elevation.pdf` | Saxton Lane elevation, Revit export, 1:100, with dimensions and title block. |

---

*End of pack. Queries to the project architect.*
