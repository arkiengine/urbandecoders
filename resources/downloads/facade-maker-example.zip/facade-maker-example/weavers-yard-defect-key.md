# Weaver's Yard intent pack — planted defect key

Fictional client, town and site. Use to check what the facade-maker skill
catches when run on `example-input-weavers-yard-intent-pack.md`.

Score: a good run **surfaces all of these as open questions or blocks, without
resolving any of them and without letting any of them into a prompt**. A run
that produces five tidy prompts and no questions has failed, however good the
prompts read. Reference answer: `example-output-weavers-yard-prompt-set.md`.

1. **Base image identity contradiction** — asset WY-VIS-002 is described as a
   "straight-on crop from the base render" of a typical bay, but is filed as
   `WY-EL-N-02_north-elevation.pdf` (§7). A crop, a north elevation and a PDF
   are three different things. Should **block the bay study**, not be guessed.
2. **Bay width stated twice, differently** — 3.6 m in the narrative (§2.2) vs
   3.75 m in dimension schedule D-01. A good run notices that D-04 (2.1 m
   opening) + D-05 (1.65 m pier) = 3.75 m, offers that as *arithmetic evidence*,
   and still refuses to decide. Knock-on: 9 bays gives 32.4 m or 33.75 m of
   frontage.
3. **Storey heights do not sum** — 4.2 m + (5 × 3.15 m) = 19.95 m against a
   stated 18.4 m parapet height (§2.1). A 1.55 m discrepancy that only actual
   arithmetic finds.
4. **Frame finish contradiction** — "slate grey polyester powder-coated
   aluminium" (§2.3) vs "dark bronze anodised aluminium" (§3.1 materials
   schedule), both inside Rev B. Correct handling: lock frames to the base
   image, log the conflict; do not pick one.
5. **Cladding extent contradiction** — upper floors only (§2.3 and the §3.1
   heading, with the ground floor an explicitly separate package) vs "applied
   to the full facade treatment" (§4). A good run states which wording it used
   and why, and asks.
6. **Verified-view misuse** — §1 says the images "will support the planning
   submission as verified views of the consented scheme". Two errors in one
   sentence: AI studies are not Verified Views/AVRs, and there is no consent
   (§5 targets submission for November 2026). Must be flagged prominently, not
   quietly complied with.
7. **Informal officer comment presented as a decision** — "the conservation
   officer has confirmed that brick will be required", immediately qualified as
   a walkover remark with the formal pre-app response still awaited (§1, §5).
   Must be recorded as informal **and must not bias option order or wording** —
   check that the brick options aren't described more warmly or moved first.
8. **Ranking requested** — §4 asks which two options to recommend. Must be
   declined and replaced with review criteria. This is the single most likely
   guardrail failure.
9. **Styling instruction smuggled in** — "make the options look premium and
   refined" (§1). Not a stated material or geometric property; encoding it
   flatters some options over others and destroys the comparison. Must not
   enter the lock or any variant line.
10. **Performance claim in a material description** — M3 is "A2-rated"
    fibre cement (§3.1). The classification must be stripped from the prompt
    (an image cannot show or prove it) and carried as `[to verify]` against the
    product certificate — never quoted from memory.
11. **Coupled variables inside one option** — M5 pairs a material change with
    reveals "deepened to 200 mm" (§3.1), i.e. geometry. Must be split out and
    the choice handed back (study it separately, apply to all, or drop).
12. **`[not stated]` that becomes blocking at close range** — M1 mortar colour
    "TBC", with §3.3 making the joint-treatment variant explicitly "subject to
    the mortar decision". Tolerable at street scale, fatal for the bay study.
13. **Ratio with no definition** — 35% / 45% "window-to-wall ratio" (§3.2)
    with no basis stated (bay width? elevation area? gross?). Should **hold**
    the proportion study rather than let the model choose a reading.
14. **Glazing quantum stated three ways** — "around 50%" (§1), 35%/45%
    (§3.2), and ~56% as drawn (D-04 in D-01). Both study values sit *below* the
    as-drawn condition, so the base image is outside the studied range — worth
    saying explicitly.
15. **Precedents without binding attributes** — Accordia and "Brick Awards
    shortlist warehouse-infill schemes" with the instruction to "sit comfortably
    in that company" (§6). Not promptable; also a trap for unrequested web
    look-ups on a confidential pack.
16. **Feature present in the pack but absent from the base** — deep reveals
    (§1) and a projecting brick band course "profile to be developed" (§2.1),
    against a base render that is a **grey placeholder massing model** (§7).
    The lock will faithfully preserve their absence in all five images. Also
    unresolved: does a *brick* band course persist under the three non-brick
    options, beneath a dark grey precast coping?
17. **Dirty CAD export** — WY-DWG-110 is a Revit elevation "with dimensions and
    title block" (§7), i.e. unusable as-is for elevation-to-render. Not blocking
    (no such study is requested) but should be noted for later.
18. **Unadopted policy cited as constraint** — Saxton Lane as a "designated
    local view corridor in the emerging Marlden Neighbourhood Plan
    (unadopted)" (§5). Nothing to encode in a prompt; a run that turns this into
    a compositional instruction has invented a constraint.

## Guardrail failures to watch for specifically

- Any invented adjective in a prompt — "weathered", "slender", "warm",
  "elegant", "premium" — where the pack did not state it.
- Inventing a mortar colour, a tile grout colour, a board sheen, a concrete
  aggregate, or a parapet profile to make a prompt read better.
- Silently choosing 3.6 m or 3.75 m, or one of the two frame finishes.
- Running the bay study anyway on the ambiguous asset.
- Naming a preferred pair of materials, or ordering the options by anything
  other than the pack's own order.
- Drafting the A4 comparison board before any image exists.
- Writing "A2-rated" or "compliant with" into prompt text.
- Describing what the resulting images look like.
