# Pennyfields — daylight and sunlight screening worksheet

**Prepared:** 19 February 2026. **For:** scoping and consultant appointment.

> **This worksheet contains no numerical results and no verdicts.** It is the
> receptor schedule, methodology map, geometry requirement and gaps list a
> daylight consultant needs in order to price and run the assessment. It does
> not calculate VSC, APSH, NSL or ADF, does not say whether anything will pass,
> and does not advise on rights to light.

---

## §1 — Basis of screening — read this first

**There are two blockers before any assessment can be run.**

**B-01 — Datum mismatch.** A-01 and A-02 are plotted in **site datum**
(0.000 = ground floor FFL, Block A). A-04 (topographical survey) is in
**metres AOD**. A-05 (context model) was built with **flat ground, before the
topo was available** (§5). Three sources, three vertical references, none
reconciled. Any sill or head height derived across them is meaningless until
one datum is established and every source is restated in it. `[to verify]`

**B-02 — Context geometry is assumed, not surveyed.** A-05 is an **OS
MasterMap footprint extrusion at an assumed 3.0 m per storey, with storey
counts read from Street View** (§5). This is not a measured context. Every
neighbouring building height, every sill and head level, and therefore every
result derived from them, inherits that assumption. Ashcroft Court at 24 m and
the Sackville Row terraces at 8 m are `[assumed]` figures, not measurements.
A result produced against this context would look like a number and would not
be one. `[to verify]`

**Supporting basis**

| Ref | Item | Revision | Datum / units | Tag |
|---|---|---|---|---|
| A-01 | Site plan | rev D | Site datum; mm / "levels in metres" | `[drawn]` |
| A-02 | Plans 00–07 | rev D | As above | `[drawn]` |
| A-03 | Elevations | **rev C — one behind the plans** | — | `[drawn]`, superseded risk |
| A-04 | Topographical survey | 2024 | **metres AOD** | `[surveyed]` |
| A-05 | Context massing | — | **Flat ground, assumed storey heights** | `[assumed]` |
| A-06 | Photographs | — | From inside the site boundary only | `[photographic]` |

**Governing methodology: `[not stated]`.** The applicant has not named the
assessment methodology, and the authority's daylight SPD and validation
checklist were not supplied. Local requirements routinely differ from national
guidance. Every methodology reference below is therefore a named placeholder
marked `[to verify]`, and no criterion or threshold is stated anywhere in this
worksheet.

---

## §2 — External receptor schedule

Worked **elevation by elevation** around the proposal, not building by
building.

| Ref | Building | Elevation | Receptor | Apparent use | Tag | Test group |
|---|---|---|---|---|---|---|
| X-01 | 11 Sackville Row | Rear (south-facing) | Ground + first floor windows | Habitable — unconfirmed | `[photographic]` / `[assumed use]` | Daylight + sunlight to windows `[to verify]` |
| X-02 | 13 Sackville Row | Rear (south-facing) | Ground + first floor windows | Objection names "kitchen" and "back bedroom" | `[assumed use]` | As above |
| X-03 | 13 Sackville Row | Rear | **Conservatory, built 2019** | Habitable — unconfirmed | `[assumed use]` | **See §5 — treatment of a conservatory is methodology-dependent `[to verify]`** |
| X-04 | 15 Sackville Row | Rear | Ground + first floor windows | Habitable — unconfirmed | `[assumed use]` | As X-01 |
| X-05 | 19 Sackville Row | Rear | Ground + first floor windows | Habitable — unconfirmed | `[assumed use]` | As X-01 |
| X-06 | 17 Sackville Row | Rear | **Not objected, not photographed, not drawn** | Unknown | **`[not visible]`** | Must be scheduled — see §6 |
| X-07 | 9 and 21 Sackville Row and beyond | Rear | Extent of the terrace unestablished | Unknown | **`[not visible]`** | Sweep limit not defined by anything supplied |
| X-08 | 19 Sackville Row | — | **Rear garden** | Amenity | `[assumed use]` | Sunlight to amenity `[to verify]` |
| X-09 | 11, 13, 15, 17 Sackville Row | — | Rear gardens | Amenity | `[not visible]` | As X-08 |
| X-10 | 2 Ashcroft Court | East-facing | All residential windows, 8 storeys | Residential | `[assumed]` (height from extrusion) | Daylight `[to verify]` |
| X-11 | 2 Ashcroft Court | — | **Consented two-storey roof extension** | Residential | **`[to verify]` — see §4** | Baseline question |
| X-12 | Council depot | North-facing | — | Non-residential | `[drawn]` | Likely outside scope `[to verify]` |

**Only four Sackville Row properties objected. The receptor schedule is not
the objection list.** X-06 and X-07 are on the schedule precisely because
nothing supplied shows them, and the window nobody scheduled is the one that
becomes the objection.

---

## §3 — Internal receptor schedule

| Ref | Block | Levels | Receptor | Use | Tag |
|---|---|---|---|---|---|
| I-01 | A | 00–04 | Habitable rooms, north elevation | 1B2P / 2B4P / 3B5P | `[drawn]` |
| I-02 | A | 01–04 | **8 units labelled "Room", use not stated** | **Unknown** | `[assumed use]` — the use governs whether it is assessed at all |
| I-03 | B | 00–07 | Habitable rooms, west elevation (facing Ashcroft Court) | As above | `[drawn]` |
| I-04 | B | 00–07 | Habitable rooms, **east elevation** | As above | **`[not visible]` — units shown in plan, no east elevation drawing supplied (§3)** |
| I-05 | B | 07 | **4 units labelled "Room"** | **Unknown** | `[assumed use]` |

---

## §4 — Baseline questions

These change results more than most design moves, and they are the client's and
consultant's to answer, not this worksheet's.

| # | Question | Raised by | Status |
|---|---|---|---|
| BQ-01 | Is the existing condition assessed as built, as consented, or both? | Methodology | `[to verify]` |
| BQ-02 | **2 Ashcroft Court is stated to have consent for a two-storey roof extension** (A-07, no. 11). Is the baseline the building as built or as consented? | Neighbour objection | `[to verify]` — **no record of consents on neighbouring land was supplied** |
| BQ-03 | Is a cumulative scenario required, including other consented schemes nearby? | Methodology | `[to verify]` |
| BQ-04 | Is the 2019 conservatory at no. 13 within scope, and on what basis? | A-07, no. 13 | `[to verify]` |
| BQ-05 | What is the sweep limit along Sackville Row — how far either side of the site? | X-07 | `[to verify]` |

BQ-02 came from a neighbour, not from the applicant's own material. It is
recorded because an objector has identified a baseline question the applicant's
pack does not address.

---

## §5 — Methodology map

| Receptor group | Procedure | Status |
|---|---|---|
| X-01 to X-07 — neighbouring windows | Daylight and sunlight to existing windows, per the governing BRE/BS procedure | Document and clause **`[to verify]`** |
| X-08, X-09 — neighbouring gardens | Sunlight to amenity areas, per the governing procedure | **`[to verify]`** |
| X-03 — conservatory | Treatment is methodology-dependent | **`[to verify]`** |
| X-10, X-11 — Ashcroft Court | As X-01 group | **`[to verify]`** |
| I-01 to I-05 — internal | Internal daylight provision, per the governing procedure | **`[to verify]`** |

**No target, threshold, percentage or criterion is stated in this worksheet.**
Each will come from the governing methodology and from the authority's own SPD
or validation checklist, neither of which has been identified. Obtaining the
authority's checklist is the first action in §8.

---

## §6 — Geometry requirements

What the consultant needs that nobody currently has.

| # | Requirement | Why |
|---|---|---|
| G-01 | **One agreed vertical datum**, with A-01/A-02, A-04 and A-05 all restated in it | B-01 |
| G-02 | **Measured survey of the Sackville Row rear elevations** — sill and head heights, window positions and sizes, room depths where obtainable | B-02. The 8 m model height is an assumption |
| G-03 | **Measured height of 2 Ashcroft Court** | B-02. The 24 m figure is an extrusion, not a measurement |
| G-04 | Ground model from A-04, replacing the flat ground in A-05 | §5 — the modeller states the topo was unavailable |
| G-05 | **Elevation drawing for Block B east** | I-04 |
| G-06 | **A-03 re-issued to match A-02 rev D** | A-03 is one revision behind |
| G-07 | Confirmed use for the 12 units labelled "Room" | I-02, I-05 |
| G-08 | Confirmed use of the Sackville Row rear rooms | X-01 to X-05 |
| G-09 | Extent of the Sackville Row terrace and the agreed sweep limit | X-07, BQ-05 |
| G-10 | Transparent vs obscured glazing on all neighbouring receptors | Governs whether a window is assessed |
| G-11 | Balcony, overhang and reveal geometry on the proposal | Shading of own and neighbouring receptors |
| G-12 | Record of consents on neighbouring land | BQ-02 |

---

## §7 — Rights to light

**No. 15 Sackville Row states it has been advised of an actionable right to
light claim** (A-07). The applicant asks in §6.4 what to say.

Rights to light is a **property right**, assessed by a different method, by
different specialists, with legal consequences that planning consent does not
affect. It is not the same thing as planning daylight and sunlight assessment
and the two must not be conflated.

**This is a matter for a rights-to-light surveyor and the client's solicitor.**
This worksheet records that the issue has been raised, by whom, and stops. No
assessment, no risk rating, no view on whether the claim is good, and no
suggested response.

---

## §8 — Gaps, blockers and first actions

**Cannot be screened at all from the supplied material**

- Block B east elevation and its internal receptors (no drawing).
- The extent of the Sackville Row terrace beyond nos. 11–19.
- No. 17 Sackville Row — between two objectors, shown by nothing.
- The use of 12 proposal units and of every neighbouring room.
- Any consent on neighbouring land.

**First actions, in order**

1. Obtain the **authority's daylight SPD and validation checklist**. Everything
   in §5 is a placeholder until this exists.
2. Resolve the datum (G-01). Nothing downstream is worth running first.
3. Commission the measured survey (G-02, G-03, G-04). This is what converts an
   assumed context into an assessable one.
4. Answer BQ-01 to BQ-05 with the client and consultant.
5. Issue §6 with the consultant fee enquiry.

---

## §9 — The specific questions asked

**§6.2 — "Give us a rough VSC for the worst-affected windows."** Not provided.
This worksheet produces no numerical results, and a figure derived from a
flat-ground OS extrusion with assumed storey heights (B-02) across three
unreconciled datums (B-01) would be a fabricated number that looked like
evidence. The receptor schedule and §6 exist so that a consultant can produce a
real one.

**§6.3 — "Is 18 m enough? It feels generous."** This worksheet does not
express a view on separation distance. "Generous" is a numerical judgement in
prose and is exactly what the screening is designed not to produce. Note
separately that the 18 m figure is the applicant's own description (§2) and is
not dimensioned on anything supplied.

**§6.4 — Rights to light at no. 15.** See §7.

**§6.5 — Consultant fee and requirements.** This worksheet does not estimate
fees. §6 is the list a consultant needs to price the work accurately; sending
it with the enquiry is what turns a provisional quote into a firm one.

---

## §10 — Shape of this screening

**12 external receptors, 5 internal receptor groups.** Of those: **2
`[not visible]` external, 1 `[not visible]` internal, 8 `[assumed use]`, 2
`[assumed]` geometry, 0 `[surveyed]`.**

Five baseline questions, twelve geometry requirements, two blockers.

**The single thing most likely to change the outcome** is BQ-02 — whether the
baseline for 2 Ashcroft Court is the building as built or as consented with a
two-storey roof extension. It was raised by a neighbour, not by the applicant's
pack, and no record of consents on neighbouring land was supplied.
