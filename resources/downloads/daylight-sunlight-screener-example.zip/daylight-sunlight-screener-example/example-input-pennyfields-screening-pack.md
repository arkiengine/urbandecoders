# Pennyfields — daylight and sunlight screening pack

**Scheme:** Pennyfields, Marlden — 64 apartments in two blocks, 5 and 8 storeys
**Stage:** pre-application, approaching submission
**Instruction:** "Screen this before we appoint a daylight consultant. The
neighbours on Sackville Row have already written in."

*Fictional scheme, neighbours and authority. Deliberately imperfect.*

---

## §1 — Material supplied

| Ref | Item | Notes as supplied |
|---|---|---|
| A-01 | Proposed site plan, rev D | 1:500 @ A1. Plotted in **site datum**, 0.000 = ground floor FFL Block A |
| A-02 | Proposed plans, levels 00–07, rev D | 1:200 @ A1 |
| A-03 | Proposed elevations, rev C | **One revision behind the plans** |
| A-04 | Topographical survey | Pelham Surveys, 2024. Levels in **metres AOD** |
| A-05 | Context massing model (.skp) | "Built from OS MasterMap footprints, extruded at 3.0 m per storey, storey counts from Street View" |
| A-06 | Site photographs (9 no.) | Taken from within the site boundary only |
| A-07 | Neighbour objection letters (4 no.) | Sackville Row nos. 11, 13, 15, 19 |

**Not supplied:** measured survey of neighbouring buildings; the authority's
daylight SPD or validation checklist; any record of consents on neighbouring
land; drawings of the east elevation of Block B.

---

## §2 — Site description as given by the applicant

> The site is bounded by Sackville Row to the north (two-storey Victorian
> terraces, rear gardens backing onto our boundary), Pennyfields Lane to the
> east, a council depot to the south, and no. 2 Ashcroft Court to the west —
> an eight-storey 1970s residential block.
>
> Block A (5 storeys) sits to the north, Block B (8 storeys) to the south. The
> separation to the Sackville Row rear elevations is around 18 m, which should
> be fine given they're only two storeys.
>
> The west elevation of Block B faces Ashcroft Court across about 12 m.

---

## §3 — Drawing notes from A-02 (proposed plans)

- Levels 00–04: Block A. Levels 00–07: Block B.
- Unit types: 1B2P, 2B4P, 3B5P.
- **Twelve units are labelled "Room" on the plans with no use stated** — eight
  in Block A (north elevation, levels 01–04) and four in Block B (level 07).
- Several plans carry the note "Dimensions in mm unless noted. **Levels in
  metres.**"
- Block B east elevation units are shown in plan, but **no east elevation
  drawing is included in A-03**.

---

## §4 — Neighbour objections (A-07, extracts)

**No. 13 Sackville Row:**
> "Our kitchen and the back bedroom will lose all their morning light. We also
> have a conservatory which was built in 2019."

**No. 15 Sackville Row:**
> "The proposal will interfere with our right to light. We have been advised
> that we have an actionable claim."

**No. 19 Sackville Row:**
> "The garden is the only outdoor space we have and it will be in shadow."

**No. 11 Sackville Row:**
> "No. 2 Ashcroft Court was given permission last year for a two-storey roof
> extension. Has that been taken into account?"

---

## §5 — Context model note (A-05, from the modeller)

> "Context built from OS MasterMap. Where I couldn't count storeys from Street
> View I assumed 3.0 m per storey and worked back from the ridge. Ashcroft
> Court is modelled at 24 m. The Sackville Row terraces are modelled at 8 m.
> Ground is flat — I didn't have the topo when I built it."

---

## §6 — What the applicant has asked for

1. "Screen it — what needs assessing?"
2. "Give us a rough VSC for the worst-affected Sackville Row windows so we know
   if we have a problem."
3. "Is 18 m enough? It feels generous for two-storey houses."
4. "What do we say to no. 15 about the right to light?"
5. "How much will a consultant charge, and what do they need from us?"
