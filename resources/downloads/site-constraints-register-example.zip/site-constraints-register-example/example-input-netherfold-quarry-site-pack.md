# Netherfold Quarry — site information pack

**Issued to:** Hallam & Roe Architects
**Issued by:** Brindlewood Land Ltd (via Carrick Vaughan, agent)
**Date of transmittal:** 14 February 2026
**Purpose:** "Everything we have. We're deciding whether to bid by the 6th."

*Fictional client, site and town. Deliberately imperfect.*

---

## §1 — Transmittal email (verbatim extract)

> From: j.carrick@carrickvaughan.example
> Sent: 14 February 2026, 17:48
> Subject: Netherfold — the pack
>
> Hi — here's the bundle. It's most of what we hold. The title's clean, there's
> no contamination to speak of (it was only ever a sandstone quarry, never
> industrial), and the Environment Agency mapping shows it well clear of the
> flood plain. There's a TPO on the beech line along the eastern boundary —
> Michael mentioned it on the walkover — but nothing that affects the
> developable area.
>
> The old 1987 deed of easement for the water main is in our archive somewhere,
> I'll dig it out. Severn Trent confirmed capacity verbally last autumn.
>
> We're working to 2.4 ha developable and roughly 85 units. Can you confirm
> that stacks up and flag anything that would stop us?
>
> J.

---

## §2 — Documents supplied

| Ref | Document | Author | Dated | Status as stated on the document |
|---|---|---|---|---|
| D-01 | Netherfold Quarry — Preliminary Site Appraisal | Carrick Vaughan | Nov 2025 | "Marketing document. Not a survey. Figures indicative." |
| D-02 | Phase 1 Desktop Environmental Study | Garrowby Geoenvironmental | Aug 2024 | "Desktop study. Conclusions are indicative and require intrusive investigation." |
| D-03 | Title Register extract (sheet 2 of 6) | HM Land Registry | Jan 2026 | Extract only |
| D-04 | Topographical survey | Pelham Surveys | Jun 2023 | "Issued for information" |
| D-05 | Flood Risk Screening Note | Garrowby Geoenvironmental | Aug 2024 | "Screening only" |
| D-06 | Site photographs (14 no.) | Carrick Vaughan | Jan 2026 | — |
| D-07 | Severn Trent correspondence | — | Oct 2025 | Email chain |

Not supplied: full title register, title plan, local authority search, drainage
and water search, environmental search (regulated), utility asset enquiries,
tree survey, ecology survey, mining search, measured survey of the retained
structures.

---

## §3 — Extracts from D-01 (Preliminary Site Appraisal, Carrick Vaughan)

§3.1 "The site extends to approximately 3.1 ha, of which 2.4 ha is
developable."

§3.2 "The quarry was worked for building sandstone until 1974 and has since
been used for informal grazing. There is no history of industrial use and no
known contamination."

§3.3 "Vehicular access is taken from Netherfold Lane to the north. The lane is
adopted to the site entrance."

§3.4 "A mature beech line to the eastern boundary is subject to a Tree
Preservation Order and will be retained as a landscape feature."

§3.5 "The site lies outside Flood Zone 2."

---

## §4 — Extracts from D-02 (Phase 1 Desktop Study, Garrowby)

§4.1 "The site is recorded on historic mapping as Netherfold Quarry
(sandstone), worked from at least 1861 to approximately 1974. A tramway is
shown crossing the site on the 1912 edition."

§4.2 "Made ground is anticipated across the former quarry void in the southern
third of the site. **Depth is unknown.** The extent shown on Figure 3 is
indicative and derived from historic mapping only."

§4.3 "A former fuel store and workshop are shown on the 1938 edition in the
north-west corner. These are potential contaminative uses."

§4.4 "The site lies within a Development High Risk Area for past mining.
A Coal Authority / Mining Report has not been obtained and is recommended."

§4.5 "No intrusive investigation has been undertaken. This report must not be
relied upon as evidence of ground conditions."

---

## §5 — Extracts from D-05 (Flood Risk Screening Note, Garrowby)

§5.1 "The majority of the site lies within Flood Zone 1."

§5.2 "The southern boundary adjoining Netherfold Brook falls within Flood
Zone 3a. The extent is taken from published national mapping and is
indicative at this scale; site-specific modelling would be required."

§5.3 "Surface water flood risk is indicated along the line of the former
tramway. Extent not modelled."

---

## §6 — Extracts from D-03 (Title Register extract, sheet 2 of 6)

§6.1 Entry 4: "The land is subject to the rights granted by a Deed of Easement
dated 11 March 1987 referred to in the Charges Register."

§6.2 Entry 7: "The land tinted blue on the filed plan is subject to a right of
way on foot at all times."

§6.3 *Note: the filed plan is not included in this extract. Sheets 1, 3, 4, 5
and 6 are not included.*

§6.4 Entry 11: "A strip of land 3 metres in width fronting Netherfold Lane is
excluded from the title."

---

## §7 — Extracts from D-07 (Severn Trent correspondence)

> "Further to our call, I can confirm there is capacity in the Netherfold Lane
> main for a development of the scale discussed. Please note this is an
> informal indication and does not constitute a formal capacity assessment or
> an offer to connect. A formal enquiry would be required."
> — Severn Trent, 3 October 2025

No apparatus plan was attached to the chain.

---

## §8 — What the client has asked for

1. A constraints register.
2. Confirmation that 2.4 ha developable and 85 units "stacks up".
3. "Flag anything that would stop us."
4. A view on whether the site is clean, "so we can price it without a big
   contingency".
