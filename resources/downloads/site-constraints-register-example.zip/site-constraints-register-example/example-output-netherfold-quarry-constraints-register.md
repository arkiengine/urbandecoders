# Netherfold Quarry — constraints register

**Prepared from:** the site information pack transmitted 14 February 2026
**Prepared:** 16 February 2026
**Prepared for:** a bid / no-bid decision by 6 March 2026

> **Read this first.** This register records constraints evidenced in the
> documents supplied. It does not source constraints, and the absence of a row
> means the absence of evidence, not the absence of a constraint. Eleven of the
> searches that would normally inform a decision of this kind have not been
> undertaken. They are listed in §2, before the register, deliberately.

---

## §1 — Source inventory

| Ref | Document | Author | Dated | Status **as the document states it** |
|---|---|---|---|---|
| D-01 | Preliminary Site Appraisal | Carrick Vaughan (agent) | Nov 2025 | "Marketing document. Not a survey. Figures indicative." |
| D-02 | Phase 1 Desktop Environmental Study | Garrowby Geoenvironmental | Aug 2024 | "Desktop study… require intrusive investigation" |
| D-03 | Title Register extract, **sheet 2 of 6** | HM Land Registry | Jan 2026 | Partial extract; filed plan not included |
| D-04 | Topographical survey | Pelham Surveys | Jun 2023 | "Issued for information" |
| D-05 | Flood Risk Screening Note | Garrowby | Aug 2024 | "Screening only" |
| D-06 | Site photographs (14 no.) | Carrick Vaughan | Jan 2026 | — |
| D-07 | Severn Trent correspondence | — | Oct 2025 | Email chain, no apparatus plan |
| D-08 | Transmittal email | Carrick Vaughan | 14 Feb 2026 | Correspondence |

**Newest document in the pack: 14 February 2026 (an email). Newest technical
document: January 2026 (photographs). The two environmental documents are from
August 2024 and the topographical survey from June 2023.** This register is a
snapshot of a pack whose technical content is between 18 months and 32 months
old.

D-01 is a marketing document written by the selling agent and says so on its
own face. Statements that appear only in D-01 are tagged `[reported]`
throughout, not `[documented]`.

---

## §2 — Outstanding searches

**This is the commissioning list. It is longer than the register.**

| # | Search / survey | Status | What it would settle |
|---|---|---|---|
| OS-01 | Full title register and **filed plan** | Sheet 2 of 6 only; plan absent | The blue-tinted right of way (§6.2), the excluded 3 m strip (R-02), all charges, every entry on the five missing sheets |
| OS-02 | Deed of Easement, 11 March 1987 | Referred to, **not supplied** | Position, width and terms of the water main easement. Could sterilise a development corridor |
| OS-03 | Coal Authority / Mining Report | **Recommended by D-02 §4.4, not obtained** | Past mining in a stated Development High Risk Area |
| OS-04 | Intrusive ground investigation | Not undertaken | Depth and extent of made ground in the quarry void; contamination from the former fuel store |
| OS-05 | Regulated environmental search | Not supplied | Landfill, permits, pollution incidents, radon |
| OS-06 | Local authority search (CON29) | Not supplied | Highway adoption, planning history, enforcement, TPOs as a matter of record |
| OS-07 | Drainage and water search | Not supplied | Apparatus crossing the site, public sewer positions, build-over |
| OS-08 | Utility asset enquiries (all undertakers) | Not supplied | Electricity, gas, telecoms apparatus and easements |
| OS-09 | Tree survey to BS 5837 | Not undertaken | TPO status as a matter of record; root protection areas; extent of constraint on the eastern boundary |
| OS-10 | Ecology walkover / preliminary appraisal | Not undertaken | Protected species, habitat, seasonal survey windows that may govern programme |
| OS-11 | Site-specific flood modelling | Not undertaken | The actual Flood Zone 3a extent on the southern boundary (D-05 §5.2 is explicitly indicative) |
| OS-12 | Measured survey of retained structures | Not undertaken | Nothing supplied establishes what structures remain |

---

## §3 — Register

| Ref | Constraint | Category | Extent | Source + location | Tag | What it affects | Status |
|---|---|---|---|---|---|---|---|
| R-01 | Easement granted by Deed dated 11 March 1987 (water main per D-08) | Title & legal | **Unknown — deed not supplied** | D-03 §6.1 entry 4 | `[documented]` (existence) / `[to verify]` (extent) | Footprint, levels, basement feasibility, phasing | Open — OS-02 |
| R-02 | 3 m strip fronting Netherfold Lane excluded from title | Title & legal | 3 m width, position not plotted (plan absent) | D-03 §6.4 entry 11 | `[documented]` | **Access position; possible ransom strip** | Open — OS-01 |
| R-03 | Right of way on foot over land tinted blue | Title & legal | **Unknown — filed plan not supplied** | D-03 §6.2 entry 7 | `[documented]` (existence) / `[to verify]` (extent) | Layout, boundary treatment, phasing | Open — OS-01 |
| R-04 | Made ground over former quarry void | Ground & contamination | Southern third; **depth unknown**; extent indicative from historic mapping | D-02 §4.2 | `[indicative]` | Foundation strategy, levels, cost, developable area | Open — OS-04 |
| R-05 | Former fuel store and workshop (1938 edition) | Ground & contamination | North-west corner, from historic mapping | D-02 §4.3 | `[documented]` | Remediation, phasing, cost | Open — OS-04, OS-05 |
| R-06 | Development High Risk Area — past mining | Ground & contamination | Site-wide as stated | D-02 §4.4 | `[documented]` | Foundation strategy, insurability, programme | **Open — OS-03 not obtained** |
| R-07 | Flood Zone 3a, southern boundary at Netherfold Brook | Flood & water | **Indicative, national mapping, not modelled** | D-05 §5.2 | `[indicative]` | Developable area, layout, drainage strategy, sequential test | Open — OS-11 |
| R-08 | Surface water flood risk along former tramway | Flood & water | **Not modelled** | D-05 §5.3 | `[indicative]` | Layout, drainage, levels | Open — OS-11 |
| R-09 | Historic tramway crossing the site (1912 edition) | Ground & contamination | Alignment per historic mapping | D-02 §4.1 | `[documented]` | Ground conditions; coincides with R-08 | Open |
| R-10 | Tree Preservation Order, beech line, eastern boundary | Ecology & trees | Not surveyed; no TPO reference supplied | D-01 §3.4; D-08 (walkover remark) | **`[reported]`** | Footprint, root protection areas, layout | **Not evidenced — OS-06, OS-09** |
| R-11 | Water main capacity | Utilities & services | — | D-07 | `[reported]` | Connection strategy, programme | Informal only — see §5 |

---

## §4 — Conflicts

**C-01 — Flood zone.** D-01 §3.5 states "the site lies outside Flood Zone 2".
D-05 §5.2 states the southern boundary "falls within Flood Zone 3a". Both are
in the supplied pack. D-01 is a marketing document; D-05 is a screening note by
a geoenvironmental consultant. **Both are recorded. Neither is adopted here.**
Resolution requires OS-11 and is material to developable area.

**C-02 — Contamination.** D-01 §3.2 states "no known contamination" and D-08
states "no contamination to speak of… never industrial". D-02 §4.3 identifies a
former fuel store and workshop as "potential contaminative uses" and §4.5
states the report "must not be relied upon as evidence of ground conditions".
The agent's statement and the consultant's statement are inconsistent, and the
consultant's is the one with a methodology behind it.

**C-03 — Site and developable area.** D-01 §3.1 gives 3.1 ha gross and 2.4 ha
developable. No supplied document derives the 2.4 ha figure, and it precedes
the flood extent (R-07), the made ground extent (R-04), the easement (R-01) and
the root protection areas (R-10) being established. **The 2.4 ha figure is
`[reported]` and is not corroborated by anything in the pack.**

---

## §5 — Statements in the pack that are not evidence

Recorded here because treating them as findings would mislead.

| Statement | Source | Why it is not a finding |
|---|---|---|
| "The title's clean" | D-08 | Four of six title sheets and the filed plan were not supplied. Three charges are already visible on the one sheet that was. |
| "No contamination to speak of" | D-08, D-01 §3.2 | Contradicted by D-02 §4.3; D-02 §4.5 disclaims reliance either way. |
| "Well clear of the flood plain" | D-08 | Contradicted by D-05 §5.2. |
| "Nothing that affects the developable area" (TPO) | D-08 | No tree survey; root protection areas not established; TPO itself unevidenced. |
| "Severn Trent confirmed capacity" | D-08 | D-07 expressly calls itself "an informal indication… does not constitute a formal capacity assessment". |
| "2.4 ha developable" | D-01 §3.1 | Not derived in any supplied document. See C-03. |
| "The lane is adopted to the site entrance" | D-01 §3.3 | No CON29. Adoption status is a matter of record and is not recorded here. |

---

## §6 — Decisions blocked

| Decision | Blocked by | Why |
|---|---|---|
| Whether 2.4 ha is developable | R-01, R-04, R-07, R-10, C-03 | Four constraints with unknown extent all reduce the same area. The figure has no derivation in the pack. |
| Whether 85 units is achievable | As above, plus R-02, R-03 | Capacity cannot be tested against an area that has not been established. |
| Access position and strategy | R-02, R-03 | A 3 m excluded strip across the frontage is a ransom risk until the filed plan is seen. |
| Foundation strategy and abnormals allowance | R-04, R-05, R-06 | Depth of made ground unknown; mining report not obtained; no intrusive investigation. |
| Drainage strategy | R-07, R-08 | Neither extent modelled. |
| Whether to bid, and at what contingency | All of the above | — |

---

## §7 — Response to the specific questions asked

**"Confirm 2.4 ha developable and 85 units stacks up."** Not possible from this
pack, and not a matter of arithmetic. The figure originates in a marketing
document that disclaims its own figures, and four constraints of unknown extent
(R-01, R-04, R-07, R-10) each reduce the same area. This register cannot
confirm it and nothing in the pack can.

**"Flag anything that would stop us."** The register flags what is evidenced.
The more useful answer is §2: twelve searches have not been undertaken,
including a mining report that the pack's own environmental consultant
recommended (R-06, D-02 §4.4) in a stated Development High Risk Area.

**"A view on whether the site is clean, so we can price it without a big
contingency."** This register cannot give that view, and no document in the
pack supports it. D-02 §4.5 expressly states it "must not be relied upon as
evidence of ground conditions". A contingency decision taken on the strength of
D-01 §3.2 would be taken on the strength of a marketing document.

---

## §8 — Shape of this register

11 rows. **2 `[documented]` with established extent. 0 `[surveyed]`. 3
`[indicative]`. 2 `[reported]`. 4 with the constraint documented but the extent
`[to verify]`.**

Twelve outstanding searches. The single biggest gap is the absence of the
filed plan and five of six title sheets (OS-01): it leaves two rights and one
exclusion across the site frontage entirely unplotted.
