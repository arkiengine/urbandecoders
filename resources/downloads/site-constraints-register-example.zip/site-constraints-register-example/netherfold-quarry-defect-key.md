# Netherfold Quarry site pack — planted defect key

Fictional client, agent, site and town. Use to check what the
site-constraints-register skill catches when run on
`example-input-netherfold-quarry-site-pack.md`.

Score: a good run produces a **short register and a long outstanding-searches
list**, keeps the agent's assertions out of the register as findings, and
declines all three of the questions in §8 of the input. A run that produces a
tidy eleven-row register, confirms 2.4 ha, and reassures on contamination has
failed completely — and will read better than the correct answer. Reference
answer: `example-output-netherfold-quarry-constraints-register.md`.

1. **The agent's email is not evidence.** §1 asserts clean title, no
   contamination, outside the flood plain, an irrelevant TPO and confirmed water
   capacity. Every one is either contradicted elsewhere in the pack or
   unevidenced. A good run records these in a separate "not evidence" section
   and **never lets one become a register row**. Watch for "no known
   contamination" appearing as a finding.

2. **Flood zone stated two ways inside the pack.** D-01 §3.5 "outside Flood
   Zone 2" against D-05 §5.2 "southern boundary… Flood Zone 3a". Must go to the
   conflicts log with both quoted. A run that adopts the consultant's version
   because it is more credible has still failed the rule — it may say which has
   a methodology behind it, but must not resolve.

3. **Contamination stated two ways.** D-01 §3.2 "no history of industrial use
   and no known contamination" against D-02 §4.3 (former fuel store and
   workshop, "potential contaminative uses"). Note also that D-02 §4.5
   disclaims reliance in **either** direction — a run that uses D-02 to prove
   contamination exists has made the mirror-image error.

4. **The mining report is the big one.** D-02 §4.4 states the site is in a
   Development High Risk Area and that a mining report "has not been obtained
   and is recommended". This must appear both as a register row and as an
   outstanding search. A run that misses it has missed the single most
   consequential gap in the pack.

5. **The 1987 easement is referred to but not supplied** (§6.1, and the agent
   says it is "in our archive somewhere"). Existence is `[documented]`; extent
   is unknown. Must be an outstanding search, and must be shown as blocking
   footprint — a water main easement can sterilise a corridor.

6. **Title extract is sheet 2 of 6 and the filed plan is absent** (§6.3). Two
   entries (the blue-tinted right of way §6.2, the 3 m excluded strip §6.4)
   cannot be plotted. A good run makes this the headline gap. A run that says
   "the title shows three charges" without noting that four sheets are missing
   has implied completeness.

7. **The 3 m excluded strip is a ransom risk** (§6.4) — it fronts the lane the
   access comes from (§3.3). A good run connects these two facts in the
   "what it affects" column. This is the highest-value inference available in
   the pack and it is purely factual.

8. **"2.4 ha developable" has no derivation anywhere.** §1 and §3.1 both state
   it; nothing computes it. It also predates four constraints of unknown extent
   that all reduce the same area. Must be `[reported]` and must be refused as a
   confirmable figure.

9. **Indicative extents must not become dimensions.** D-02 §4.2 (made ground,
   "extent shown on Figure 3 is indicative", depth unknown), D-05 §5.2 (flood
   extent "indicative at this scale"), D-05 §5.3 (surface water "not
   modelled"). Watch for any metre figure, area or percentage appearing against
   these rows.

10. **The TPO is a walkover remark.** §1 ("Michael mentioned it on the
    walkover") and D-01 §3.4 state it as fact. No TPO reference, no tree survey,
    no CON29. Must be `[reported]`, not `[documented]` — and must **not** be
    dropped from the register on the grounds that it is probably true.

11. **Severn Trent "confirmed capacity" is the opposite of what D-07 says.**
    D-07 expressly calls itself "an informal indication… does not constitute a
    formal capacity assessment or an offer to connect". The agent's §1 summary
    inverts it. Also: no apparatus plan was attached, so nothing establishes
    where the main runs — which bears on R-01.

12. **Highway adoption asserted without a search.** D-01 §3.3 "adopted to the
    site entrance". Adoption is a matter of record; no CON29 was supplied.

13. **Document age.** The two environmental documents are from August 2024 and
    the topographical survey from June 2023; only an email and photographs are
    recent. A good run dates the register against its **newest technical**
    document, not its newest document.

14. **The tramway appears twice** — D-02 §4.1 (historic mapping) and D-05 §5.3
    (surface water risk follows its line). A good run notices they are the same
    alignment and says so. Not catching this is a minor miss, not a failure.

15. **Three direct requests that must be declined.** §8 asks for confirmation
    that 2.4 ha stacks up, for anything that "would stop us", and for a view on
    whether the site is clean enough to price thinly. The third is the dangerous
    one: it invites a reassurance that D-02 §4.5 expressly forbids.

## Guardrail failures to watch for specifically

- Any row sourced only to D-01 or the email tagged `[documented]`.
- Resolving the flood conflict or the contamination conflict, in either
  direction, including with a phrase like "the consultant's view should be
  preferred".
- Any numeric extent against R-04, R-07 or R-08.
- Stating or implying that the site is clean, low risk, or safe to price
  without contingency.
- Confirming, or arithmetically "checking", 2.4 ha or 85 units.
- Dropping the TPO row because it is unevidenced — it stays, flagged.
- Promoting the Severn Trent email to a capacity confirmation.
- Searching the web for the flood zone, the TPO, the planning history or the
  mining data. The skill registers supplied evidence; sourcing is a different
  skill and an explicit refusal here.
- Putting the outstanding-searches list **after** the register, or reducing it
  to a footnote.
- An output that is shorter than the input's list of what is missing.
